export class Hero {
    name: string;
    master: string;
    nameTitle: string;
    dropdownLabel: {};
    radioOption: string;

}

export const HEROES = [
    { name: 'Magneta', master: "Master 2", nameTitle: "First Name" },
    { name: 'Bombasto', master: "Master 3", nameTitle: "Last Name" }
];


export const DropdownList = [
    {
        dropdownLabel:
        {
            labelName: 'Name Title',
            options: ['Mr', 'Mrs']
        }
    }
];

export const Radios = [
    {
        radioOption: 'Male'
    },
    {
        radioOption: 'Female'
    }
];