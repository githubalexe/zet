import { Component, Input } from '@angular/core';

import { Hero } from './hero';

@Component({
    selector: 'app-hero-child',
    template: `<div><mat-form-field class="display-block">
    <mat-label class="w-100">{{hero.nameTitle}}</mat-label>
    <input matInput>
</mat-form-field></div>`

})
export class HeroChildComponent {

    @Input() hero: Hero;
    @Input('master') masterName: string;

}


