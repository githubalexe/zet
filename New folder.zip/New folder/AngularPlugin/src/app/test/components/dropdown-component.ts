import { Component, Input } from '@angular/core';
import { Hero } from '../hero';


@Component({
    selector: 'dropdown-component',
    template: `<div><mat-form-field>
    <mat-select placeholder={{drop.dropdownLabel.labelName}}>
     <mat-option value="mr">Mr</mat-option>
     <mat-option value="mrs">Mrs</mat-option>
    </mat-select>
</mat-form-field></div>`

})

export class DropdownComponent {
    @Input() drop: Hero
}
