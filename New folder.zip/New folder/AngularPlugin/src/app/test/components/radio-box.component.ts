import { Component, Input } from '@angular/core';
import { Hero } from '../hero';



@Component({
    selector: 'radio-box-component',
    template: `<mat-radio-button class="example-radio-button" >
            {{radiooo.radioOption}}
              </mat-radio-button>`
})

export class RadioBoxComponent {
    @Input() radiooo: Hero
}
