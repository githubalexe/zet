import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MaterialModule } from './material';
import { FormTemplateComponent } from './form-template/form-template.component';
import { HeroParentComponent } from './test/hero-parent.component';
import { HeroChildComponent } from './test/hero-child.component';
import { FloatingLabelComponent } from './test/components/float-label.component';
import { DropdownComponent } from './test/components/dropdown-component';
import { RadioBoxComponent } from './test/components/radio-box.component';

@NgModule({
  declarations: [
    AppComponent,
    FormTemplateComponent,
    HeroChildComponent,
    HeroParentComponent,
    FloatingLabelComponent,
    DropdownComponent,
    RadioBoxComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
