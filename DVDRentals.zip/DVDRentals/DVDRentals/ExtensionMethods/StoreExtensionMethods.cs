﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static IEnumerable<StoreResponse> ResponseList(this IEnumerable<Store> storeList)
        {
            IList<StoreResponse> storeResponseList = new List<StoreResponse>();
            foreach (Store store in storeList)
            {
                StoreResponse storeResponse = Response(store);
                storeResponseList.Add(storeResponse);
            }
            return storeResponseList;
        }
        public static StoreResponse Response(this Store store)
        {
            return new StoreResponse
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                LastUpdate = store.LastUpdate
            };
        }
    }
}
