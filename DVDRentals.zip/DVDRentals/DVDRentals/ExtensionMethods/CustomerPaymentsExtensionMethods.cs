﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerPaymentsExtensionMethods
    {
        public static CostomerPaymentsResponse ToCustomerPaymentsResponse(this Customer customer)
        {
            CostomerPaymentsResponse customerResponse = new CostomerPaymentsResponse()
            {
                CustomerId = customer.CustomerId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
            };

            return customerResponse;
        }
        public static CostomerPaymentsResponse ToCustomerPaymentListResponse(this Customer customer, List<PaymentForCustomerResponse> paymentResponseList)
        {
            CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentsResponse();
            customerResponse.Payments = paymentResponseList;

            return customerResponse;
        }

    }
}
