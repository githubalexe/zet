﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static IEnumerable<StaffResponse> ResponseList(this IEnumerable<Staff> staffList)
        {
            IList<StaffResponse> staffResponseList = new List<StaffResponse>();
            foreach (Staff staff in staffList)
            {
                StaffResponse staffResponse = Response(staff);
                staffResponseList.Add(staffResponse);
            }

            return staffResponseList;
        }
        public static StaffResponse Response(this Staff staff)
        {
            return new StaffResponse
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                AddressId = staff.AddressId,
                Picture = staff.Picture,
                Email = staff.Email,
                StoreId = staff.StoreId,
                Active = staff.Active,
                Username = staff.Username,
                LastUpdate = staff.LastUpdate
            };
        }
    }
}
