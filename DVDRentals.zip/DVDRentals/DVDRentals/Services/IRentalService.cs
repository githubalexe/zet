﻿namespace DVDRentals.Services
{
    public interface IRentalService
    {
        void DeleteRental(int inventoryId);
    }
}