﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public interface IFilmCategoryDeleteServices
    {
        void DeleteFilmCategoryAsync(int filmId);
        void DeleteFilmActorAsync(int filmId);
        void DeleteFilmInventoryAsync(int filmId);
    }
}
