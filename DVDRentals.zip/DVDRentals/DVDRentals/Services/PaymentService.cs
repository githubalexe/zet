﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class PaymentService : IPaymentService
    {
        private IPaymentRepository _paymentRepository;

        public PaymentService(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        public async Task DeleteCustomerPaymentsAsync(int customerId)
        {
            IEnumerable<Payment> paymentList = await _paymentRepository.GetCustomerPaymentsAsync(customerId);

            if (paymentList != null)
            {
                foreach (Payment payment in paymentList)
                {
                    _paymentRepository.DeletePayment(payment);
                }
            }
        }

        public async Task DeleteStaffPaymentsAsync(int staffId)
        {
            IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staffId);

            if (paymentList != null)
            {
                foreach (Payment payment in paymentList)
                {
                    _paymentRepository.DeletePayment(payment);
                }
            }
        }
    }
}
