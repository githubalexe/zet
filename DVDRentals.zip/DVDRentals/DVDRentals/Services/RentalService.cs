﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class RentalService : IRentalService
    {
        private IRentalRepository _rentalRepository;
        public RentalService(IRentalRepository rentalRepository)
        {
            _rentalRepository = rentalRepository;
        }
        public async void DeleteRental(int inventoryId)
        {
            IEnumerable<Rental> rentalList = await _rentalRepository.GetRentalsInventoryAsync(inventoryId);

            if (rentalList != null)
            {
                foreach (Rental rental in rentalList)
                {
                    Rental newRental = rental;
                    rental.InventoryId = inventoryId;
                    _rentalRepository.UpdateRental(newRental);
                }
            }
        }
    }
}
