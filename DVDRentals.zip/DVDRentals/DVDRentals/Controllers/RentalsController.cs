﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.Domain;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class RentalsController : Controller
    {
        private IRentalRepository _rentalRepository;
        private IStoreRepository _storeRepository;

        public RentalsController(IRentalRepository rentalRepository, IStoreRepository storeRepository)
        {
            _rentalRepository = rentalRepository;
            _storeRepository = storeRepository;
        }

        [HttpGet("Rentals")]
        public async Task<IEnumerable<Rental>> GetAll()
        {
            IEnumerable<Rental> rentalList = await _rentalRepository.GetAllAsync();

            return rentalList;
        }
    }
}