﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffRepository _staffRepository;
        public StaffsController(IStaffRepository staffRepository)
        {
            _staffRepository = staffRepository;
        }

        [HttpGet("stores/{storeId}/staffs")]
        public async Task<IActionResult> GetAllAsync(int storeId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetAllAsync(storeId);
            IEnumerable<StaffResponse> staffResponseList = StaffExtensionMethods.ResponseList(staffList);

            return Ok(staffResponseList);
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> GetAsync(int storeId,int staffId)
        {
            Staff staff = await _staffRepository.GetAync(storeId, staffId);
            StaffResponse staffResponse = StaffExtensionMethods.Response(staff);

            return Ok(staffResponse);
        }
    }
}