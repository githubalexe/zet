﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;
using DVDRentals.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;

namespace DVDRentals.Controllers
{
    public class CategoriesController : Controller
    {
        private ICategoryRepository _categoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        public CategoriesController(ICategoryRepository categoryRepository, IFilmCategoryRepository filmCategoryRepository)
        {
            _categoryRepository = categoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
        }
        [HttpGet("Categories")]
        public async Task<IActionResult> GetCategoriesAsync()
        {
            IEnumerable<Category> categoryList = await _categoryRepository.GetCategoriesAsync();
            List<CategoryResponse> categoryResponseList = categoryList.ToCategoryResponseList();

            return Ok(categoryResponseList);
        }

        [HttpGet("Categories/{categoryId}/Films")]
        public async Task<IActionResult> GetFilmsCategoryAsync(int categoryId)
        {
            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmsCategoryAsync(categoryId);
            List<FilmResponse> filmResponseList = new List<FilmResponse>();

            foreach (FilmCategory filmCategory in filmCategoryList)
            {
                filmResponseList.Add(filmCategory.Film.ToFilmResponse());
            }

            return Ok(filmResponseList);
        }

        [HttpGet("Categories/{categoryId}", Name = "GetCategoryAsync")]
        public async Task<IActionResult> GetCategoryAsync(int categoryId)
        {
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);
            if (category != null)
            {
                CategoryResponse categoryResponse = category.ToCategoryResponse();

                return Ok(categoryResponse);
            }

            return NotFound("The category doesn't exist!");
        }

        [HttpPost("Categories")]
        public IActionResult AddCategoryAsync([FromBody] CategoryCreateRequest request)
        {
            Category category = request.ToCategoryModel();
            _categoryRepository.AddCategory(category);
            _categoryRepository.SaveChanges();
            CategoryResponse categoryResponse = category.ToCategoryResponse();

            return CreatedAtRoute("GetCategoryAsync", new { categoryId = category.CategoryId }, categoryResponse);
        }

        [HttpDelete("Categories/{categoryId}")]
        public async Task<IActionResult> DeleteCategoryAsync(int categoryId)
        {
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category != null)
            {
                _categoryRepository.DeleteCategory(category);
                _categoryRepository.SaveChanges();
                
                return Ok("The category has been deleted!");
            }

            return NotFound("The category doesn't exist!");
        }
    }
}