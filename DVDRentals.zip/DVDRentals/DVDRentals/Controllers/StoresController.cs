﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StoresController : Controller
    {
        private IStoreRepository _storeRepository;
        private IAddressRepository _addressRepository;

        public StoresController(IStoreRepository storeRepository, IAddressRepository addressRepository)
        {
            _storeRepository = storeRepository;
            _addressRepository = addressRepository;
        }

        [HttpGet("Stores")]
        public async Task<IActionResult> GetAll()
        {
            IEnumerable<Store> storeList = await _storeRepository.GetAllAsync();
            IEnumerable<StoreResponse> storeResponseList = StoreExtensionMethods.ResponseList(storeList);

            return Ok(storeResponseList);
        }

        [HttpGet("Stores/{storeId}")]
        public async Task<IActionResult> Details(ushort storeId)
        {
            Store store = await _storeRepository.GetAsync(storeId);
            StoreResponse storeResponse = StoreExtensionMethods.Response(store);

            return Ok(storeResponse);
        }

        //[HttpGet("Home/GetAddress/{addressId}")]
        public async Task<Address> GetAddress(ushort addressId)
        {
            Address address = await _addressRepository.GetAsync(addressId);

            return address;
        }
    }
}