﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class ActorsController : Controller
    {
        private IActorRepository _actorRepository;
        public ActorsController(IActorRepository actorRepository)
        {
            _actorRepository = actorRepository;
        }

        [HttpGet("Actors")]
        public async Task<IActionResult> GetActorsAsync()
        {
            IEnumerable<Actor> actorList = await _actorRepository.GetActorsAsync();
            List<ActorResponse> actorResposesList = actorList.ToActorResponseList();

            return Ok(actorResposesList);
        }

        [HttpGet("Actors/{actorId}", Name = "GetActorsAsync")]
        public async Task<IActionResult> GetActorsAsync(int actorId)
        {
            Actor actor = await _actorRepository.GetActorAsync(actorId);
            if (actor != null)
            {
                ActorResponse actorResposes = actor.ToActorResponse();

                return Ok(actorResposes);
            }

            return NotFound("The actor doesn't exist!");
        }

        [HttpPost("Actors")]
        public IActionResult AddActorAsync([FromBody]ActorCreateRequest request)
        {
            Actor actor = request.ToActorModel();
            _actorRepository.AddActor(actor);
            _actorRepository.SaveChanges();
            ActorResponse actorResponse = actor.ToActorResponse();

            return CreatedAtRoute("GetActorsAsync", new { actorId = actor.ActorId }, actorResponse);
        }

        [HttpPut("Actors/{actorId}")]
        public async Task<IActionResult> UpdateActorAsync([FromBody]ActorUpdateRequest request, int actorId)
        {
            Actor actor = await _actorRepository.GetActorAsync(actorId);
            if (actor != null)
            {
                actor = request.ToActorModel(actor);
                _actorRepository.UpdateActor(actor);
                _actorRepository.SaveChanges();
                ActorResponse actorResponse = actor.ToActorResponse();

                return Ok(actorResponse);
            }

            return NotFound("The actor doesn't exist!");
        }

        [HttpDelete("Actors/{actorId}")]
        public async Task<IActionResult> DeleteActorAsync(int actorId)
        {
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor != null)
            {
                _actorRepository.DeleteActor(actor);
                _actorRepository.SaveChanges();

                return Ok("The actor has been deleted!");
            }

            return NotFound("The actor doesn't exist!");
        }
    }
}