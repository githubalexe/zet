﻿using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Address;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class AddressController : Controller
    {
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICustomerRepository _customerRepository;
        private IStaffRepository _staffRepository;
        private IStoreRepository _storeRepository;

        public AddressController(IAddressRepository addressRepository, ICityRepository cityRepository, ICustomerRepository customerRepository, IStaffRepository staffRepository, IStoreRepository storeRepository)
        {
            _addressRepository = addressRepository;
            _cityRepository = cityRepository;
            _customerRepository = customerRepository;
            _staffRepository = staffRepository;
            _storeRepository = storeRepository;
        }

        [HttpGet("address/{addressId}", Name = "GetAddressAsync")]
        public async Task<IActionResult> GetAddressAsync(int addressId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address == null)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }

        [HttpPost("address")]
        public async Task<IActionResult> CreateAddress([FromBody] AddressCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = AddressMessages.InvalidAddressRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool city = await _cityRepository.GetCityValidAsync(request.CityId);

            if (city == false)
            {
                errorMessage.Message = CityMessages.NoCityResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            Address address = request.ToAddressModel();
            _addressRepository.AddAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return CreatedAtRoute("GetAddressAsync", new { addressId = address.AddressId }, addressResponse);
        }

        [HttpPut("address/{addressId}")]
        public async Task<IActionResult> UpdateAddress([FromBody] AddressUpdateRequest request, int addressId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (request == null)
            {
                errorMessage.Message = AddressMessages.InvalidAddressRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool city = await _cityRepository.GetCityValidAsync(request.CityId);

            if (address == null)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (city == false)
            {
                errorMessage.Message = CityMessages.NoCityResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            address = request.ToAddressModel(address);
            _addressRepository.UpdateAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }

        [HttpDelete("address/{addressId}")]
        public async Task<IActionResult> DeleteAddress(int addressId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address == null)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool store = await _storeRepository.HasStoreAddressAsync(address.AddressId);
            bool staff = await _staffRepository.HasStaffAddressAync(address.AddressId);
            bool customer = await _customerRepository.HasCustomerAddressAsync(address.AddressId);

            if (store == true || staff == true || customer == true)
            {
                errorMessage.Message = AddressMessages.DeleteAddressFalid.GetDescription();

                return BadRequest(errorMessage);
            }

            _addressRepository.DeleteAddress(address);
            _addressRepository.SaveChanges();

            return Ok();
        }
    }
}
