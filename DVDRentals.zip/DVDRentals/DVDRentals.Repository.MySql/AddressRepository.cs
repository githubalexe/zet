﻿using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository.MySql
{
    public class AddressRepository : IAddressRepository
    {
        private UnitOfWork _context;
        public AddressRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<Address> GetAddressAsync(int addressId)
        {
            return await _context.Address.Include(a => a.City)
                                         .ThenInclude(c => c.Country)
                                         .FirstOrDefaultAsync(a => a.AddressId == addressId);
        }
        public async Task<bool> ExistAddressAsync(int addressId)
        {
            return await _context.Address.AnyAsync(a => a.AddressId == addressId);
        }

        public void AddAddress(Address address)
        {
            _context.Address.Add(address);
        }

        public void UpdateAddress(Address address)
        {
            _context.Address.Update(address);
        }

        public void DeleteAddress(Address address)
        {
            _context.Address.Remove(address);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
