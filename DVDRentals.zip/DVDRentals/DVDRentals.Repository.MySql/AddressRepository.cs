﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository.MySql
{
    public class AddressRepository : IAddressRepository
    {
        private UnitOfWork _context;
        public AddressRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<Address> GetAsync(ushort addressId)
        {
            Address address = _context.Address.FirstOrDefault(a => a.AddressId == addressId);

            return address;
        }
    }
}
