﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;

namespace DVDRentals.Repository.MySql
{
    public class StaffRepository : IStaffRepository
    {
        private UnitOfWork _context;
        public StaffRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Staff>> GetAllAsync(int storeId)
        {
            return _context.Staff.Where(s => s.StoreId == storeId)
                                  .ToList();
        }

        public async Task<Staff> GetAync(int storeId, int staffId)
        {
            return _context.Staff.Where(s => s.StoreId == storeId)
                                .FirstOrDefault(s => s.StaffId == staffId);
        }
    }
}
