﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class LanguageRepository : ILanguageRepository
    {
        private UnitOfWork _context;
        public LanguageRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<Language> GetLanguageAsync(int languageId)
        {
            return await _context.Language.FirstAsync(l => l.LanguageId == languageId);
        }

        public async Task<IEnumerable<Language>> GetLanguagesAsync()
        {
            return await _context.Language.ToListAsync();
        }

        public void AddLanguage(Language language)
        {
            _context.Language.Add(language);
        }

        public void DeleteLanguage(Language language)
        {
            _context.Language.Remove(language);
        }
        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
