﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;

namespace DVDRentals.Repository.MySql
{
    public class StoreRepository : IStoreRepository
    {
        private UnitOfWork _context;
        public StoreRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<Store> GetAsync(ushort storeId)
        {
            Store store = _context.Store.FirstOrDefault(s => s.StoreId == storeId);
            //Address address = _context.Address.FirstOrDefault(a => a.AddressId == store.AddressId); ;
            //store.Address.Address1 = address.Address1;
            //store.Address.City = address.City;
     
            return store;
        }

        public async Task<IEnumerable<Store>> GetAllAsync()
        {
          return _context.Store.OrderBy(s => s.StoreId)
                               .ToList();
        }


    }
}
