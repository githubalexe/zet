﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;

namespace DVDRentals.Repository.MySql
{
    public class RentalRepository : IRentalRepository
    {
        private UnitOfWork _context;
        public RentalRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Rental>> GetAllAsync()
        {
            // Store store = _context.Store.FirstOrDefault(s => s.StoreId == storeId);

            IEnumerable<Rental> rentalList = _context.Rental.OrderBy(r => r.RentalId);

            return rentalList;


        }

        public Task<Store> GetAsync(ushort rentalId)
        {
            throw new NotImplementedException();
        }
    }
}
