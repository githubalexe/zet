﻿using System.ComponentModel.DataAnnotations;

namespace DVDRentals.API.Request.CreateRequest
{
    public class InventoryCreateRequest
    {
        [Required(ErrorMessage = "FilmId is required.")]
        public int FilmId { get; set; }
    }
}
