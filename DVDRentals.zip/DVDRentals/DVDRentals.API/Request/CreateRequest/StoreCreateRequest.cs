﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    class StoreCreateRequest
    {
        public byte StoreId { get; set; }
        public byte ManagerStaffId { get; set; }
        public ushort AddressId { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
