﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class PaymentCreateRequest
    {
        [Required(ErrorMessage = "CustomerId is required.")]
        public int CustomerId { get; set; }
        [Required(ErrorMessage = "StaffId is required.")]
        public int StaffId { get; set; }
        [Required(ErrorMessage = "RentalId is required.")]
        public int? RentalId { get; set; }
        [Required(ErrorMessage = "Amount is required.")]
        public decimal Amount { get; set; }
        [Required(ErrorMessage = "PaymentDate is required.")]
        public DateTime PaymentDate { get; set; }
    }
}
