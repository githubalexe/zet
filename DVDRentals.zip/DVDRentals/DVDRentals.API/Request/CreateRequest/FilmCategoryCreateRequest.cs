﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class FilmCategoryCreateRequest
    {
        public int FilmId { get; set; }
        public int CategoryId { get; set; }
    }
}
