﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IRentalRepository
    {
        Task<IEnumerable<Rental>> GetAllRentalsAsync(int id);
        Task<Rental> GetRentalAsync(int? rentalId);
        Task<IEnumerable<Rental>> GetRentalsInventoryAsync(int inventoryId);
        void AddRental(Rental rental);
        void UpdateRental(Rental rental);
        void DeleteRental(Rental rental);
        void SaveChanges();
    }
}
