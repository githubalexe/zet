﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IStaffRepository
    {
        Task<IEnumerable<Staff>> GetStaffsAsync(int storeId);
        Task<Staff> GetStaffAync(int storeId, int staffId);
        Task<bool> ExistStaffAync(int staffId);
        Task<bool> HasStaffAddressAync(int addressId);
        void AddStaff(Staff staff);
        void UpdateStaff(Staff staff);
        void DeleteStaff(Staff staff);
        void SaveChanges();
    }
}
