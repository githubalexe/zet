﻿using DVDRentals.Domain;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICountryRepository
    {
        Task<Country> GetCountryAsync(int id);
    }
}
