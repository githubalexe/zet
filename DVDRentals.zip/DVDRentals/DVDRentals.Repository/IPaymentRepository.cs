﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IPaymentRepository
    {
        Task<Payment> GetCustomerPaymentAsync(int customerId, int paymentId);
        Task<Payment> GetStaffPaymentAsync(int staffId, int paymentId);
        Task<Payment> GetPaymentAsync(int paymentId);
        Task<IEnumerable<Payment>> GetCustomerPaymentsAsync(int customerId);
        Task<IEnumerable<Payment>> GetStaffPaymentsAsync(int staffId);
        void AddPayment(Payment payment);
        void UpdatePayment(Payment payment);
        void DeletePayment(Payment payment);
        void SaveChanges();
    }
}
