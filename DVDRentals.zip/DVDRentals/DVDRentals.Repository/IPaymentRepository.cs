﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IPaymentRepository
    {
        Task<Payment> GetCustomerPaymentAsync(int customerId, int paymentId);
        Task<Payment> GetStaffPaymentAsync(int staffId, int paymentId);
        Task<Payment> GetAsync(int id);

        Task<IEnumerable<Payment>> GetListAsync(IQueriable<Payment> query);

        //Task<Payment> GetPaymentRentalAsync(int rentalId);
        //Task<IEnumerable<Payment>> GetCustomerPaymentsAsync(IQueriable<Payment> query, int customerId);
        //Task<IEnumerable<Payment>> GetStaffPaymentsAsync(IQueriable<Payment> query, int staffId);
        void AddPayment(Payment payment);
        void UpdatePayment(Payment payment);
        void DeletePayment(Payment payment);
        void SaveChanges();
    }
}
