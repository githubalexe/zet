require.config({
    paths: {
        "jquery": "node_modules/jquery/dist/jquery.min",
        "jqueryValidation": "node_modules/jquery-validation/dist/jquery.validate.min",
        "MDC":"node_modules/material-components-web/dist/material-components-web.min"
    }
});
