(function () {

    ImageSlider = function (options) {

        var self = this;
        self.container = options.container;

        self.buildBody();
        self.addFiles();
        self.createEvents();
        
    }

    ImageSlider.prototype.buildBody = function () {
        var self = this;
        var pluginWrapper = document.createElement('div');
        pluginWrapper.classList.add('image-slider');

        var sliderTitle = document.createElement('p');
        sliderTitle.classList.add('title');
        sliderTitle.innerHTML = 'Photos Editor';

        var imagesContainer = document.createElement('output');
        imagesContainer.setAttribute('id', 'imagesContainer');

        var imagesInput = document.createElement('input');
        imagesInput.setAttribute('id', 'imagesInput');
        imagesInput.setAttribute('type', 'file');
        imagesInput.setAttribute('multiple', true);
        imagesInput.setAttribute('hidden', true);

        var addPhotoButton = document.createElement('input');
        addPhotoButton.setAttribute('id', 'add-button');
        addPhotoButton.setAttribute('type', 'button');
        addPhotoButton.value = 'AddPhoto';

        var prevButton = document.createElement('input');
        prevButton.setAttribute('id', 'prevButton');
        prevButton.setAttribute('type', 'button');
        prevButton.value = '';

        var nextButton = document.createElement('input');
        nextButton.setAttribute('id', 'nextButton');
        nextButton.setAttribute('type', 'button');
        nextButton.value = '';

        self.container.appendChild(pluginWrapper);
        pluginWrapper.appendChild(sliderTitle);
        pluginWrapper.appendChild(imagesContainer);
        pluginWrapper.appendChild(addPhotoButton);
        pluginWrapper.appendChild(imagesInput);
    }

    ImageSlider.prototype.addFiles = function () {

        var imagesInput = document.getElementById('imagesInput', self.container);
        var imagesContainer = document.getElementById('imagesContainer', self.container);

        imagesInput.addEventListener('change', function (event) {
            var files = event.target.files;
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                if (file.type.match('image.*')) {
                    imagesInput.innerHTML = '';
                    var image = document.createElement('img');
                    image.classList.add('image');
                    image.src = URL.createObjectURL(file);
                    image.setAttribute('src', image.src);
                    imagesContainer.appendChild(image);
                }
            }
        });
    }

    ImageSlider.prototype.createEvents = function () {

        var self = this;

        var imagesInput = document.querySelector('#imagesInput');

        var addPhotoButton = document.getElementById('add-button', self.container);
        var prevButton = document.getElementById('prevButton', self.container);
        var nextButton = document.getElementById('nextButton', self.container);
        var images = document.querySelector('#imagesContainer img');
        var imagesContainer = document.querySelector('#imagesContainer');

        // var counter = 1;
        // var size = images[0].clientWidth;

        // imagesContainer.style.transform = 'translateX(' + (-size * counter) + 'px)';

        addPhotoButton.addEventListener('click', function () {
            imagesInput.click();
            
        });
    }

    // ImageSlider.prototype.getImages = function(){

    // }

}());