(function () {

    ImageSlider = function (options) {

        var self = this;
        self.container = options.container;

        self.buildBody();

        self.createEvents();

    }

    ImageSlider.prototype.buildBody = function () {
        var self = this;
        var pluginWrapper = document.createElement('div');
        pluginWrapper.classList.add('image-slider');

        var sliderTitle = document.createElement('p');
        sliderTitle.classList.add('title');
        sliderTitle.innerHTML = 'Photos Editor';

        var imagesContainer = document.createElement('output');
        imagesContainer.setAttribute('id', 'imagesContainer');

        var imagesInput = document.createElement('input');
        imagesInput.setAttribute('id', 'imagesInput');
        imagesInput.setAttribute('type', 'file');
        imagesInput.setAttribute('multiple', true);
        imagesInput.setAttribute('hidden', true);

        var addPhotoButton = document.createElement('input');
        addPhotoButton.setAttribute('id', 'add-button');
        addPhotoButton.setAttribute('type', 'button');
        addPhotoButton.value = 'AddPhoto';

        var prevButton = document.createElement('a');
        prevButton.setAttribute('id', 'prevButton');
        prevButton.innerHTML = '&#10094;';


        var nextButton = document.createElement('a');
        nextButton.setAttribute('id', 'nextButton');
        nextButton.innerHTML = '&#10095;';


        self.container.appendChild(pluginWrapper);
        pluginWrapper.appendChild(sliderTitle);
        pluginWrapper.appendChild(imagesContainer);
        imagesContainer.appendChild(prevButton);
        imagesContainer.appendChild(nextButton);
        pluginWrapper.appendChild(addPhotoButton);
        pluginWrapper.appendChild(imagesInput);
    }


    ImageSlider.prototype.createEvents = function () {

        var self = this;

        var imagesInput = document.getElementById('imagesInput', self.container);
        var slides = 0;

        var addPhotoButton = document.getElementById('add-button', self.container);
        var prevButton = document.getElementById('prevButton', self.container);
        var nextButton = document.getElementById('nextButton', self.container);
        var slides = document.getElementById('imagesContainer');

        addPhotoButton.addEventListener('click', function () {
            imagesInput.click();
        });
        imagesInput.addEventListener('change', function (event) {
            var files = event.target.files;

            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                if (file.type.match('image.*')) {
                    var image = document.createElement('img');
                    image.classList.add('image');
                    image.src = URL.createObjectURL(file);
                    image.setAttribute('src', image.src);
                    imagesContainer.appendChild(image);
              
                }
            }
         
        });

        prevButton.addEventListener('click',function(){
            plusSlides(-1);
        });

        nextButton.addEventListener('click',function(){
            plusSlides(1);
        });

        var slideIndex = 1;
        showSlides(slideIndex);

        function plusSlides(n) {
            showSlides(slideIndex += n);
        }

        function showSlides(n) {
            var i;
            if (n > slides.length) { slideIndex = 1 }
            if (n < 1) { slideIndex = slides.length }
            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
            }

           // slides[slideIndex - 1].style.display = "block";
        
        }

    }



}());