(function () {

    ImageSlider = function (options) {

        var self = this;
        self.container = options.container;
        self.imagePageEditor = options.imagePageEditor;

        self.buildBody();
        self.addImages();
        self.createEvents();


    }

    ImageSlider.prototype.buildBody = function () {
        var self = this;

        var pluginWrapper = document.createElement('div');
        pluginWrapper.classList.add('image-slider');

        var sliderTitle = document.createElement('p');
        sliderTitle.classList.add('title');
        sliderTitle.innerHTML = 'Photos Editor';

        var imagesContainer = document.createElement('output');
        imagesContainer.setAttribute('id', 'imagesContainer');

        var imagesInput = document.createElement('input');
        imagesInput.setAttribute('id', 'imagesInput');
        imagesInput.setAttribute('type', 'file');
        imagesInput.setAttribute('multiple', true);
        imagesInput.setAttribute('hidden', true);

        var addPhotoButton = document.createElement('input');
        addPhotoButton.setAttribute('id', 'add-button');
        addPhotoButton.setAttribute('type', 'button');
        addPhotoButton.value = 'AddPhoto';

        var prevButton = document.createElement('a');
        prevButton.setAttribute('id', 'prevButton');
        prevButton.innerHTML = '&#10094;';


        var nextButton = document.createElement('a');
        nextButton.setAttribute('id', 'nextButton');
        nextButton.innerHTML = '&#10095;';


        pluginWrapper.appendChild(sliderTitle);
        pluginWrapper.appendChild(imagesContainer);
        imagesContainer.appendChild(prevButton);
        imagesContainer.appendChild(nextButton);
        pluginWrapper.appendChild(addPhotoButton);
        pluginWrapper.appendChild(imagesInput);
        self.container.appendChild(pluginWrapper);

        //create edit page

    }

    ImageSlider.prototype.buildImagePageEditor = function () {
        var self = this;
        var editorContainer = document.createElement('div');
        editorContainer.classList.add('editor-container');

        var filtersTitle = document.createElement('p');
        filtersTitle.classList.add('title');
        filtersTitle.innerHTML = 'Filters';

        var efectsTitle = document.createElement('p');
        efectsTitle.classList.add('title');
        efectsTitle.innerHTML = 'Effects';

        var filters = document.createElement('div');
        filters.classList.add('filters');

        var effects = document.createElement('div');
        effects.classList.add('effects');

        var submitButtons = document.createElement('div');
        effects.classList.add('submit-buttons');

        var imageContainer = document.createElement('canvas');
        imageContainer.setAttribute('id', 'imageCanvas');

        ////brightness
        var brightnessContainer = document.createElement('div');
        brightnessContainer.classList.add('button-container');

        var brightnessLabel = document.createElement('label');
        brightnessLabel.classList.add('label');
        brightnessLabel.innerHTML = 'Brightness';

        var minusBrightnessButton = document.createElement('button');
        minusBrightnessButton.setAttribute('id', 'minusBrightnessButton');
        minusBrightnessButton.classList.add('minus-button');
        minusBrightnessButton.classList.add('button');
        minusBrightnessButton.innerHTML = '-';

        var plusBrightnessButton = document.createElement('button');
        plusBrightnessButton.setAttribute('id', 'plusBrightnessButton');
        plusBrightnessButton.classList.add('plus-button');
        plusBrightnessButton.classList.add('button');
        plusBrightnessButton.innerHTML = '+';
        //contrast
        var contrastContainer = document.createElement('div');
        contrastContainer.classList.add('button-container');

        var contrastLabel = document.createElement('label');
        contrastLabel.classList.add('label');
        contrastLabel.innerHTML = 'Contrast';

        var minusContrastButton = document.createElement('button');
        minusContrastButton.setAttribute('id', 'minusContrastButton');
        minusContrastButton.classList.add('minus-button');
        minusContrastButton.classList.add('button');
        minusContrastButton.innerHTML = '-';

        var plusContrastButton = document.createElement('button');
        plusContrastButton.setAttribute('id', 'plusContrastButton');
        plusContrastButton.classList.add('plus-button');
        plusContrastButton.classList.add('button');
        plusContrastButton.innerHTML = '+';

        //Saturation
        var saturationContainer = document.createElement('div');
        saturationContainer.classList.add('button-container');

        var saturationLabel = document.createElement('label');
        saturationLabel.classList.add('label');
        saturationLabel.innerHTML = 'Saturation';

        var minusSaturationButton = document.createElement('button');
        minusSaturationButton.setAttribute('id', 'minusSaturationButton');
        minusSaturationButton.classList.add('minus-button');
        minusSaturationButton.classList.add('button');
        minusSaturationButton.innerHTML = '-';

        var plusSaturationButton = document.createElement('button');
        plusSaturationButton.setAttribute('id', 'plusSaturationButton');
        plusSaturationButton.classList.add('plus-button');
        plusSaturationButton.classList.add('button');
        plusSaturationButton.innerHTML = '+';

        //vibrance
        var vibranceContainer = document.createElement('div');
        vibranceContainer.classList.add('button-container');

        var vibranceLabel = document.createElement('label');
        vibranceLabel.classList.add('label');
        vibranceLabel.innerHTML = 'Vibrance';

        var minusVibranceButton = document.createElement('button');
        minusVibranceButton.setAttribute('id', 'minusVibranceButton');
        minusVibranceButton.classList.add('minus-button');
        minusVibranceButton.classList.add('button');
        minusVibranceButton.innerHTML = '-';

        var plusVibranceButton = document.createElement('button');
        plusVibranceButton.setAttribute('id', 'plusVibranceButton');
        plusVibranceButton.classList.add('plus-button');
        plusVibranceButton.classList.add('button');
        plusVibranceButton.innerHTML = '+';

        ///Effects buttons
        var vintageEfectButton = document.createElement('button');
        vintageEfectButton.setAttribute('id', 'vintageEfectButton');
        vintageEfectButton.classList.add('effect-button');
        vintageEfectButton.innerHTML = 'Vintage';

        var lemoEffectButton = document.createElement('button');
        lemoEffectButton.setAttribute('id', 'lemoeffectButton');
        lemoEffectButton.classList.add('effect-button');
        lemoEffectButton.innerHTML = 'Lemo';

        var clarityEffectButton = document.createElement('button');
        clarityEffectButton.setAttribute('id', 'clarityEffectButton');
        clarityEffectButton.classList.add('effect-button');
        clarityEffectButton.innerHTML = 'Clarity';

        var sinCityEffectButton = document.createElement('button');
        sinCityEffectButton.setAttribute('id', 'sinCityEffectButton');
        sinCityEffectButton.classList.add('effect-button');
        sinCityEffectButton.innerHTML = 'Sin City';

        var crossProcessEffectButton = document.createElement('button');
        crossProcessEffectButton.setAttribute('id', 'crossProcessEffectButton');
        crossProcessEffectButton.classList.add('effect-button');
        crossProcessEffectButton.innerHTML = 'Cross Process';

        var pinholeEffectButton = document.createElement('button');
        pinholeEffectButton.setAttribute('id', 'pinholeEffectButton');
        pinholeEffectButton.classList.add('effect-button');
        pinholeEffectButton.innerHTML = 'Pinhole';

        var nostalgiaEffectButton = document.createElement('button');
        nostalgiaEffectButton.setAttribute('id', 'nostalgiaEffectButton');
        nostalgiaEffectButton.classList.add('effect-button');
        nostalgiaEffectButton.innerHTML = 'Nostalgia';

        var herMajestyEffectButton = document.createElement('button');
        herMajestyEffectButton.setAttribute('id', 'herMajestyEffectButton');
        herMajestyEffectButton.classList.add('effect-button');
        herMajestyEffectButton.innerHTML = 'Nostalgia';

        //download and remove filters

        var saveButton = document.createElement('button');
        saveButton.setAttribute('id', 'saveButton');
        saveButton.classList.add('effect-button');
        saveButton.innerHTML = 'Save';

        var removeEffectsButton = document.createElement('button');
        removeEffectsButton.setAttribute('id', 'removeEffectsButton');
        removeEffectsButton.classList.add('effect-button');
        removeEffectsButton.innerHTML = 'Remove Filters';


        //////////
        editorContainer.appendChild(imageContainer);

        brightnessContainer.appendChild(minusBrightnessButton);
        brightnessContainer.appendChild(brightnessLabel);
        brightnessContainer.appendChild(plusBrightnessButton);

        contrastContainer.appendChild(minusContrastButton);
        contrastContainer.appendChild(contrastLabel);
        contrastContainer.appendChild(plusContrastButton);

        saturationContainer.appendChild(minusSaturationButton);
        saturationContainer.appendChild(saturationLabel);
        saturationContainer.appendChild(plusSaturationButton);

        vibranceContainer.appendChild(minusVibranceButton);
        vibranceContainer.appendChild(vibranceLabel);
        vibranceContainer.appendChild(plusVibranceButton);


        filters.appendChild(brightnessContainer);
        filters.appendChild(contrastContainer);
        filters.appendChild(saturationContainer);
        filters.appendChild(vibranceContainer);

        effects.appendChild(vintageEfectButton);
        effects.appendChild(lemoEffectButton);
        effects.appendChild(clarityEffectButton);
        effects.appendChild(sinCityEffectButton);
        effects.appendChild(crossProcessEffectButton);
        effects.appendChild(pinholeEffectButton);
        effects.appendChild(nostalgiaEffectButton);
        effects.appendChild(herMajestyEffectButton);

        submitButtons.appendChild(removeEffectsButton);
        submitButtons.appendChild(saveButton);

        editorContainer.appendChild(filtersTitle);
        editorContainer.appendChild(filters);
        editorContainer.appendChild(efectsTitle);
        editorContainer.appendChild(effects);
        editorContainer.appendChild(submitButtons);

        self.imagePageEditor.appendChild(editorContainer);
    }

    ImageSlider.prototype.addImages = function () {
        var self = this;
        var imagesContainer = document.getElementById('imagesContainer', self.container);
        var imagesInput = document.getElementById('imagesInput', self.container);


        imagesInput.addEventListener('change', function (event) {
            var files = event.target.files;
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                if (file.type.match('image.*')) {
                    var image = document.createElement('img');
                    image.classList.add('image');
                    image.src = URL.createObjectURL(file);
                    image.setAttribute('src', image.src);
                    imagesContainer.appendChild(image);

                    ///

                }
            }
        });
    }


    ImageSlider.prototype.createEvents = function () {

        var self = this;

        var imagesInput = document.getElementById('imagesInput', self.container);
        var image = document.querySelector('.image', self.container);
        var addPhotoButton = document.getElementById('add-button', self.container);
        var prevButton = document.getElementById('prevButton', self.container);
        var nextButton = document.getElementById('nextButton', self.container);



        //edit buttons
        var minusBrightnessButton = document.getElementById('minusBrightnessButton');

        addPhotoButton.addEventListener('click', function () {
            imagesInput.click();
        });

        prevButton.addEventListener('click', function () {
            //event
        });

        nextButton.addEventListener('click', function () {
            alert('next');
        });

        nextButton.addEventListener('click', function () {
            // var newPage = document.createElement('a');
            // newPage.setAttribute('href', './index.html');

            window.open("./imageEditor.html");
            self.buildImagePageEditor();
        });


    }



}());