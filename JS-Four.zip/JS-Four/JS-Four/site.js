var options = {
    container: document.getElementById('plugin1'),
    imagePageEditor:document.getElementById('imagePageEditor')
}


var plugin1 = new ImageSlider(options);

