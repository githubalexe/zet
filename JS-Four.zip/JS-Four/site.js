var options = {
    container: document.getElementById('plugin1')
}

var plugin1 = new ImageSlider(options);


