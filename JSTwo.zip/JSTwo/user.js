class UserPost {

    constructor(options) {
        this.firstName = options.firstName;
        this.lastName = options.lastName;
        this.textPost = options.textPost;
        this.postDate = options.postDate;
        this.postTime = options.postTime;
        this.fileInput = options.fileInput;
    }
    displayUser() {

        console.log(
            this.firstName,
            this.lastName,
            this.textPost,
            this.postDate,
            this.postTime,
            this.fileInput);
    }
    
}