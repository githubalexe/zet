
(function () {

    $('#textContent').keypress(function (e) {
        var textValue = $('textarea').val(),
            textLength = textValue.length,
            set = 500,
            remain = parseInt(set - textLength);
        $('#wordCount').text(remain);
        if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
            $('#textContent').val((textValue).substring(0, textLength - 1));
            return false;
        }
    })

    $('#textContent').keyup('change drop keydown cut paste', function () {
        if ($('#textContent').val() === "") {
            $('#textContent').animate({ height: 25 });;
        }
    });
    $('#textContent').focusout(function () {
        if ($('#textContent').val() === "") {
            $('#textContent').animate({ height: 25 });;
        }
    });

    $('#textContent').click(function () {
        $('#textContent').animate({ height: 55 });;
    });

    $('#textContent').keyup('change drop keydown cut paste', function () {
        $('#textContent').height('auto');
        $('#textContent').height($('#textContent').prop('scrollHeight'));
    });

    $('#textContent').keyup('change drop keydown cut paste', function () {
        $('#textContent').height('auto');
        $('#textContent').height($('#textContent').prop('scrollHeight'));
    });

    //   $('#textContent').keyup(function () {
    //   if ($('#textContent').val() !== "") {
    //      $('#postButton').css('background-color', '#00A8FF');
    //       $('#postButton').css('color', 'white');
    //   }
    //   else {
    //       $('#postButton').css('background-color', '#CECECE');
    //     $('#postButton').css('color', '8A8A8A');
    // }
    //  });


    $('#fileInput').change(function (event) {
        var files = event.target.files; //FileList object
        var output = document.getElementById('fileDisplayArea');
        //var $output = $('#fileDisplayArea');
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            if (file.type.match('image.*')) {
                var picReader = new FileReader();
                picReader.addEventListener("load", function (event) {
                    var picFile = event.target;
                    var div = document.createElement("div");
                    //var $newDiv = $("<div/>");
                    div.innerHTML = " <div class='parent'> <span class='remove'></span><img class='myImage' src='" + picFile.result + "'" + "title='preview image'/></div>";
                    output.insertBefore(div, null);
                    $(".parent .remove").click(function () {
                        $(this).parent().remove();
                    });
                });
            }
            else
                if (file.type.match('video.*')) {
                    var div = document.createElement("div");
                    var source = document.createElement('video');
                    source.controls = true;
                    source.src = URL.createObjectURL(files[i]);
                    source.innerHTML = "<video controls><source  src=" + source.src + " class='myVideo'  id='video_here'></video>";
                    div.innerHTML = "<div class='parent'> <span class='remove'></span>" + source.innerHTML + "</div>";
                    output.insertBefore(div, null);
                    $(".parent .remove").click(function () {
                        $(this).parent().remove();
                    });
                }
            $('#fileDisplayArea ,#textLine').show();
            picReader.readAsDataURL(file);
        }
    });

    function getSrcImage() {
        var file = $("#fileDisplayArea").html();
        var imageFileCollection = [];
        $(".myImage", file).each(function () {
            imgsrc = this.src;
            imageFileCollection.push(imgsrc);
        });
        return imageFileCollection;
    }

    function getSrcVideo() {
        var videoFileCollection = [];
        $(".myVideo", $("#fileDisplayArea")).each(function () {
            videosrc = this.src;
            videoFileCollection.push(videosrc);
        });
        return videoFileCollection;
    }

    function getImages() {
        
        var fileImageInput = getSrcImage();
        var listOfImages = [];
        output = document.getElementById('fileDisplayArea');
        for (var i = 0; i < fileImageInput.length; i++) {
            var div = document.createElement("div");
            div.innerHTML = '<img class="active"  src=' + fileImageInput[i] + '>';
            listOfImages.push(div.innerHTML);
            output.insertBefore(div, null);
        }
        return listOfImages;
    }

    function getVideo() {
        var fileVideoInput = getSrcVideo();
        output = document.getElementById('fileDisplayAreaPost');
        for (var i = 0; i < fileVideoInput.length; i++) {
            var div = document.createElement("div");
            var source = document.createElement('video');
            source.controls = true;
            source.src = fileVideoInput[i];
            source.innerHTML = "<video controls><source  src=" + source.src + " class='myVideo'  id='video_here'></video>";
            div.innerHTML = "<div class='parent'>" + source.innerHTML + "</div>";
            output.insertBefore(div, null);
        }
        $('#fileDisplayAreaPost').show();
    }
    //  function clearAll() {
    //  $('#textLine', $('.container'), $('.content')).hide();
    // $('#fileInput', $('.inputButton'), $('.input-content'), $('.content'), $('.container')).val("");
    // $('#fileDisplayArea', $('.input-content'), $('.content'), $('.container')).html("");
    //$('#textContent', $('.input-content'), $('.content'), $('.container')).val("");
    // }

 
        $('.next').on('click', function(){
          var currentImg = $('.active');
          var nextImg = currentImg.next();
      
          if(nextImg.length){
            currentImg.removeClass('active').css('z-index', -10);
            nextImg.addClass('active').css('z-index', 10);
          }
        });
      
        $('.prev').on('click', function(){
          var currentImg = $('.active');
          var prevImg = currentImg.prev();
      
          if(prevImg.length){
            currentImg.removeClass('active').css('z-index', -10);
            prevImg.addClass('active').css('z-index', 10);
          }
        });
      

    function clearAll() {
        $('#textLine').hide();
        $("#textContent").val("");
        $('#fileInput').val("");
        $('#fileDisplayArea').html("");
        $('#fileDisplayAreaPost').html("");
        $("#textContent").html('');
    }

    function createPost()
    {
        var firstNameUser = "Alex";
        var lastNameUser = "Badescu";
        var textContent = $("#textContent").val();
        var file = getImages();
        var options = {
            firstName: firstNameUser,
            lastName: lastNameUser,
            textPost: textContent,
            fileInput: file
        };
        var post = new Post(options);
        $("#space").prepend(post.setPost(firstNameUser, lastNameUser, textContent, file));
  
            $('.next').on('click', function(){
              var currentImg = $('.active');
              var nextImg = currentImg.next();
          
              if(nextImg.length){
                currentImg.removeClass('active').css('z-index', -10);
                nextImg.addClass('active').css('z-index', 10);
              }
            });
          
            $('.prev').on('click', function(){
              var currentImg = $('.active');
              var prevImg = currentImg.prev();
          
              if(prevImg.length){
                currentImg.removeClass('active').css('z-index', -10);
                prevImg.addClass('active').css('z-index', 10);
              }
          });
          
    }

    $('#postButton').click(function () {
        createPost();
        clearAll();
        
    });

})();