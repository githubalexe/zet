(function () {

    var imageFileCollection=[];

    $('#textContent').keyup(function (e) {
        var tval = $('textarea').val(),
            tlength = tval.length,
            set = 499,
            remain = parseInt(set - tlength);
        $('#wordCount').text(remain);
        if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
            $('#textContent').val((tval).substring(0, tlength - 1));
            return false;
        }
    })

    $('#textContent').keyup('change drop keydown cut paste', function () {
        if ($('#textContent').val() === "") {
            $('#textContent').animate({ height: 25 });;
        }
    });
    $('#textContent').focusout(function () {
        if ($('#textContent').val() === "") {
            $('#textContent').animate({ height: 25 });;
        }
    });

    $('#textContent').click(function () {
        $('#textContent').animate({ height: 55 });;
    });

    $('#textContent').keyup('change drop keydown cut paste', function () {
        $('#textContent').height('auto');
        $('#textContent').height($('#textContent').prop('scrollHeight'));
    });


    $('#fileInput').change(function (event) {
        var files = event.target.files; //FileList object
        var output=document.getElementById('result');
        imageFileCollection.push(file);
        var counter = 0;

        for (var i = 0; i < files.length; i++) {
            var file = files[i];


            if (file.type.match('image.*')) {

                var picReader = new FileReader();
                picReader.addEventListener("load", function (event) {
                    var picFile = event.target;
                    var div = document.createElement("div");
                    div.innerHTML = " <div class='child'> <span class='remove'></span><img id='myImage' data-id="+counter+" src='" + picFile.result + "'" +
                    "title='preview image'/></div>";        
                    output.insertBefore(div, null);
                    $(".child .remove").click( function() {
                       $(this).parent().remove();
                    });

                });
            
                $('#result ,#textLine , #rez').show();
                picReader.readAsDataURL(file);

            } else {
                alert("You can only upload image file.");
                $(this).val("");
            }
        }
    });


    function createPost(){
        var todayDate = new Date();
        var time = todayDate.toLocaleTimeString();
        var date = todayDate.toLocaleDateString();
        var firstName = "Alex";
        var lastName = "Badescu";
        var textContent = $("#textContent").val();
    
     

        var templatePost= '<div class="new-post content-atributes">'+
       '<div class="input">'+
            '<div id="userAvatar"></div>'+
            '<div id="userName">'+
                 '<label  for="firstName" class="colorUserDetails" id="firstName">'+firstName+'</label>'+
                 '<label  for="lastName" class="colorUserDetails text-margin" id="lastName">'+lastName+'</label><br>'+
                 '<label  class="colorUserDetails smallFont">Posted on: </label>'+
                 '<label  for="postDate" class="colorUserDetails smallFont" id="postDate">'+date+'</label>'+
                 '<label  for="postTime" class="colorUserDetails smallFont text-margin" id="postTime">'+time+'</label>'+
            '</div>'+
            '<div class="clear"></div>'+
        '</div>'+
        '<div class="input">'+
             '<hr class="line" id="postLine">'+
             '<div class="input" id="thePost">'+
                 '<label  for="textPost" class="colorUserDetails" id="textPost">'+textContent+'</label>'+
                 '<div class="main-post">'+
                     '<div id="resultPost"></div>'+
                 '</div>'+
             '</div>'+
        '</div>'+
     '</div>'+
     '<div class="content-atributes" id="margin"></div>';


     return templatePost;
    }


    $('#postButton').click(function () {

        var post = createPost();
        $("#space").prepend(post);
        var resultClone = $("#result").clone();

        $("#resultPost").html(resultClone);
        $('#textLine').hide();
        $("#textContent").val()
        $('#fileInput').val("");
        $('#result').html("");
        $("#textContent").html('');
    });



    // $('#fileInput').click(function () {
    //  $('.thumbnail').parent().remove();
    // $('result').hide();
    // $(this).val("");
    //});

    // $('#clear').click(function () {
    //   $('.thumbnail').parent().remove();
    //   $('#result').hide();
    //    $('#files').val("");
    // $('#textLine').hide();
    //$(this).hide();
    // });


})();


