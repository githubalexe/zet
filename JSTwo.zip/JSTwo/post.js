class Post
{
   static getPost()
    {
        $('.content').append('<div class="new-post"><div class="input"><div id="userAvatar"></div><div id="userName"><label  for="firstName" class="colorUserDetails" id="firstName"></label><label  for="lastName" class="colorUserDetails" id="lastName"></label><br><label class="colorUserDetails smallFont">Posted on: </label><label  for="postDate" class="colorUserDetails smallFont" id="postDate"></label><label  for="postTime" class="colorUserDetails smallFont" id="postTime"></label></div><div class="clear"></div></div><div class="input"><hr class="line" id="postLine"><div class="input" id="thePost"><label  for="textPost" class="colorUserDetails" id="textPost"></label><div class="main-post"><div id="resultPost"></div></div></div></div></div>');
    }
}