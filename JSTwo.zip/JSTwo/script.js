(function() {
    var myText = document.getElementById("myText");
    var wordCount = document.getElementById("wordCount");
    
    myText.addEventListener("keyup",function(){
        var characters = myText.value.split('');
        var value=500;
        value=value- characters.length;
      wordCount.innerText = value;
    });
})();


