define(["jquery", "CodeMirror", "JsonSchemaValidation", "bootstrap"], function($, CodeMirror, JsonSchemaValidation) {

    var $jsonSchema = $("#jsonSchema");
    var $jsonData = $("#jsonData");
    var $jsonValidationSchema = $("#jsonValidationSchema");
    var $errorsInput = $("#errorsInput");
    var $submitButton = $("#submitButton");
    var jsonSchemaValidation = null;
    var controls = [];

    var $jsonSchemaEditor = CodeMirror.fromTextArea($jsonSchema[0], {
        lineNumbers: true,
    });
    var $jsonDataEditor = CodeMirror.fromTextArea($jsonData[0], {
        lineNumbers: true,
    });
    var $jsonValidationSchemaEditor = CodeMirror.fromTextArea($jsonValidationSchema[0], {
        lineNumbers: true,
    });
    var $errorsInputEditor = CodeMirror.fromTextArea($errorsInput[0], {
        lineNumbers: true,
    });

    $jsonSchemaEditor.setValue(`[  
        {  
            "name":"textbox1",
           "inputType":"textbox"
        },
        {  
            "name":"textbox2",
           "inputType":"textbox"
        }
     ]
     `);
    $jsonDataEditor.setValue(`
    [  
        {  
           "name":"textbox1",
           "value":25
        },
        {  
           "name":"textbox2",
           "value":"Alex"
        }
     ]`);
    $jsonValidationSchemaEditor.setValue(`[  
        {  
           "name":"textbox1",
           "validationRules":{  
              "required":false,
              "length":{  
                 "min":2,
                 "max":10
              },
              "dataType":"number"
           }
        },
        {  
           "name":"textbox2",
           "validationRules":{  
              "required":false,
              "length":{  
                 "min":2,
                 "max":10
              },
              "dataType":"string"
           }
        }
     ]`);

    bindEvents();

    function initializeJsonSchema() {
        var inputs = $jsonSchemaEditor.getValue();
        var values = $jsonDataEditor.getValue();
        var validations = $jsonValidationSchemaEditor.getValue();

        var options = {
            onCreateControl: function(control) {
                createControl(control);
            }
        }
        jsonSchemaValidation = new JsonSchemaValidation(options);

        jsonSchemaValidation.createInputByJsonValue(inputs, values, validations);
    }

    function bindEvents() {
        $submitButton.on("click", function() {
            initializeJsonSchema();
        })
    }

    function createControl(control) {
        console.log(control);
        console.log(control.GetErrorResult());
    }
});