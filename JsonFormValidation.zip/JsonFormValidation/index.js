define(["jquery", "CodeMirror", "bootstrap"], function($, CodeMirror) {

    var $jsonSchema = $("#jsonSchema");
    var $jsonData = $("#jsonData");
    var $jsonValidationSchema = $("#jsonValidationSchema");
    var $errorsInput = $("#errorsInput");

    var $jsonSchemaEditor = CodeMirror.fromTextArea($jsonSchema[0], {
        lineNumbers: true,
    });
    var $jsonDataEditor = CodeMirror.fromTextArea($jsonData[0], {
        lineNumbers: true,
    });
    var $jsonValidationSchemaEditor = CodeMirror.fromTextArea($jsonValidationSchema[0], {
        lineNumbers: true,
    });
    var $errorsInputEditor = CodeMirror.fromTextArea($errorsInput[0], {
        lineNumbers: true,
    });


});