requirejs.config({
    paths: {
        jquery: "node_modules/jquery/dist/jquery.min",
        bootstrap: "node_modules/bootstrap/dist/js/bootstrap.bundle.min",
        knockout: "node_modules/knockout/build/output/knockout-latest",
        CodeMirror: "node_modules/codeMirror/lib/codemirror",
        JsonHelper: "JsonSchemaValidation/Helpers/JsonHelper",
        JsonSchemaValidation: "JsonSchemaValidation/Main/JsonSchemaValidation",
        InputsType: "JsonSchemaValidation/Dictionary/InputsType",
        InputErrorMessages: "JsonSchemaValidation/Dictionary/InputErrorMessages",
        DataTypes: "JsonSchemaValidation/Dictionary/DataTypes",
        InputFactory: "JsonSchemaValidation/Factory/InputFactory",
        Control: "JsonSchemaValidation/Control/Control",
        TextboxInput: "JsonSchemaValidation/Inputs/TextboxInput",

    }
});