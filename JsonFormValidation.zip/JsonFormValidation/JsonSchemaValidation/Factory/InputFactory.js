define(["InputsType"], function(InputsType) {

    var InputFactory = {};

    InputFactory.CreateControl = function(options, callback) {
        var inputType = options.inputType;

        switch (inputType) {
            case InputsType.Textbox:
                {
                    require(["TextboxInput"], function(TextboxInput) {
                        var control = new TextboxInput(options);
                        callback(control);
                    })
                }
                break;
            default:
                {
                    console.log("something wrong");
                }
        }
    };

    return InputFactory;
});