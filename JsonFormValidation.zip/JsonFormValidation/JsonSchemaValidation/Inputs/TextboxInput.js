define(["Control"], function(Control) {

    function TextboxInput(options) {
        this.options = $.extend({}, TextboxInput.defaultOptions, true, options);
        this.inputName = this.options.inputName;
        this.value = this.options.value;
        this.validations = this.options.validations;

        Control.call(this);
    };

    TextboxInput.defaultOptions = {
        inputOptions: {},
        value: {},
        validations: {},
    }

    return TextboxInput;
})