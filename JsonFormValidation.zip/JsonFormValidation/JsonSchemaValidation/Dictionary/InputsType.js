define([], function() {

    var InputsType = {
        Textbox: "textbox",
        Dropdown: "dropdown"
    };


    return InputsType;
});