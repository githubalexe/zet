define([], function() {

    var InputErrorMessages = {}

    InputErrorMessages.GetErrorMessageForDataType = function(dataType) {
        var errorMessage = "The field must be a " + dataType + "!";

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForNumberValue = function(min, max) {
        var errorMessage = "The mumber must be between " + min + " and " + max + "!";

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForStringValue = function(min, max) {
        var errorMessage = "Length required is between " + min + " and " + max + " characters!";

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForRequired = function() {
        var errorMessage = "This field is required!";

        return errorMessage;
    }

    return InputErrorMessages;
});