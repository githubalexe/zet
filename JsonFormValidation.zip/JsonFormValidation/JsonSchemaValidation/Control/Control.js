define(["DataTypes", "InputErrorMessages"], function(DataTypes, InputErrorMessages) {

    function Control() {

        this.GetErrorResult = function() {
            var controlValue = this.value;
            var isControlRequired = this.validations.required;
            var dataTypeValidation = this.validations.dataType;
            var controlValueDataType = $.type(controlValue);
            var minValidation = this.validations.length.min;
            var maxValidatiton = this.validations.length.max;
            var value = GetValue(dataTypeValidation, controlValue);
            var errors = [];
            var errorMessage = "";

            if ((controlValue) && (isControlRequired)) {
                errorMessage = InputErrorMessages.GetErrorMessageForRequired();
                errors.push(errorMessage);
            }

            if (controlValueDataType !== dataTypeValidation) {
                errorMessage = InputErrorMessages.GetErrorMessageForDataType(dataTypeValidation);
                errors.push(errorMessage);
            }

            if (!((value <= maxValidatiton) && (value >= minValidation))) {
                errorMessage = GetValueErrorMessage(dataTypeValidation, minValidation, maxValidatiton);
                errors.push(errorMessage);
            }

            return errors;
        }
    };

    function GetValueErrorMessage(dataType, min, max) {
        switch (dataType) {
            case DataTypes.Number:
                {
                    return InputErrorMessages.GetErrorMessageForNumberValue(min, max);
                }
            case DataTypes.String:
                {
                    return InputErrorMessages.GetErrorMessageForStringValue(min, max);
                }
            default:
                {
                    console.log("something went wrong");
                }
        }
    }

    function GetValue(dataType, value) {
        switch (dataType) {
            case DataTypes.Number:
                {
                    return value;
                }
            case DataTypes.String:
                {
                    return value.length;
                }
            default:
                {
                    console.log("something went wrong");
                }
        }
    }

    return Control;
});