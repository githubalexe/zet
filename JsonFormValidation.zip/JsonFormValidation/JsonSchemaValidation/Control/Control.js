define(["jquery"], function($) {

    function Control() {

        this.inputName = null;
        this.inputRules = null;

        this.InputOptions = function(options) {

        }

        this.IsRequired = function() {

        }
    }


    return Control;
});