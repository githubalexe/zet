define(["jquery", "JsonHelper", "InputFactory", "bootstrap"], function($, JsonHelper, InputFactory) {

    function JsonSchemaValidation(options) {
        this.options = $.extend({}, true, JsonSchemaValidation.defaultOptions, options);
        this.onCreateControl = this.options.onCreateControl;

        this.jsonOptions = {};
        this.controls = [];

    };

    JsonSchemaValidation.prototype.createInputByJsonValue = function(inputs, dataValues, validations) {
        if (JsonHelper.IsJson(inputs) && JsonHelper.IsJson(dataValues) && JsonHelper.IsJson(validations)) {
            this.jsonOptions = {
                inputs: JSON.parse(inputs),
                dataValues: JSON.parse(dataValues),
                validations: JSON.parse(validations)
            }

            this.createInput();
        }
    };

    JsonSchemaValidation.prototype.createInput = function() {
        var self = this;
        var inputsArray = [...self.jsonOptions.inputs];
        var dataValuesArray = [...self.jsonOptions.dataValues];
        var validationsArray = [...self.jsonOptions.validations];
        var inputsArrayLength = inputsArray.length;
        var dataValuesArrayLength = dataValuesArray.length;
        var validationsArrayLength = validationsArray.length;

        for (var i = 0; i < inputsArrayLength; i++) {
            options = {
                inputName: inputsArray[i].name,
                inputType: inputsArray[i].inputType,
                value: null,
                validations: null
            }

            for (var j = 0; j < dataValuesArrayLength; j++) {
                if (inputsArray[i].name === dataValuesArray[j].name) {
                    options.value = dataValuesArray[j].value;
                    break;
                }
            }

            for (var k = 0; k < validationsArrayLength; k++) {
                if (inputsArray[i].name === validationsArray[k].name) {
                    options.validations = validationsArray[k].validationRules;
                    break;
                }
            }

            InputFactory.CreateControl(options, function(control) {
                self.onCreateControl(control);
                self.controls.push(control);
            })
        }
    };

    JsonSchemaValidation.defaultOptions = {
        $inputsContainer: $({}),
        onControlDestroy: null,
        onControlCreate: null,
    };

    return JsonSchemaValidation;
});