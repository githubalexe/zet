define(["jquery", "JsonHelper", "bootstrap"], function($, JsonHelper) {

    function JsonSchemaValidation(options) {
        this.options = $.extend({}, true, JsonSchemaValidation.defaultOptions, options);
        this.$rulesInput = this.options.$rulesInput;
        this.$errorsOutput = this.options.$errorsOutput;
        this.$textboxInput = this.options.$textboxInput;
        this.jsonRulesOptions = {};
    };

    JsonSchemaValidation.prototype.verifyJsonRulesValue = function(value) {
        var self = this;

        if (JsonHelper.IsJson(value)) {
            self.jsonRulesOptions = JSON.parse(value);
        }
    };

    JsonSchemaValidation.defaultOptions = {
        $inputsContainer: $({}),
        onControlDestroy: null,
        onControlCreate: null,
    };

    return JsonSchemaValidation;
});