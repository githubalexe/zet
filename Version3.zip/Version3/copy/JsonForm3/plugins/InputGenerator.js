define(["InputHelper", "InputFactory", "bootstrap"], function(InputHelper, InputFactory) {

    function InputGenerator(options) {

        this.$generateButton = options.$generateButton;
        this.$textInput = options.$textInput;
        this.$inputsContainer = options.$inputsContainer;
        this.$clearButton = options.$clearButton;
        this.$itemTemplate = options.$itemTemplate;
        this.jsonOptions = {};

        this.bindEvents();
    };

    InputGenerator.prototype.bindEvents = function() {

        var self = this;

        self.$generateButton.on("click", function() {

            var value = self.$textInput.val();

            self.getJsonFromValue(value);

        });
    };

    InputGenerator.prototype.getJsonFromValue = function(value) {

        if (InputHelper.IsJson(value)) {

            this.jsonOptions = JSON.parse(value);

            this.createInput();

        } else {
            //error
        }

    };

    //have to do something
    InputGenerator.prototype.createInput = function() {

        var self = this;
        //am container si il trimit ca parametru
        if (InputHelper.IsArray(self.jsonOptions)) {

            var inputs = [...self.jsonOptions];

            for (i = 0; i < inputs.length; i++) {

                var jsonObject = {
                    $inputsContainer: self.$inputsContainer,
                    jsonOptions: inputs[i]
                };

                InputFactory.LoadFileInput(jsonObject);
            }
        } else {

            var jsonObject = {
                $inputsContainer: self.$inputsContainer,
                jsonOptions: self.jsonOptions
            };

            InputFactory.LoadFileInput(jsonObject);

        }

    };

    InputGenerator.prototype.createContainer = function() {

        var container = $("<li/>", {
            id: InputHelper.CreateGuid(),
            class: "form-grup"
        });

        return container;
    };


    return InputGenerator;
});