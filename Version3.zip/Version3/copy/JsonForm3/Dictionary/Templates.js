define([], function() {

    var Templates = {
        TextBoxTemplate: "textboxTemplate",
        DropDownListTemplate: "dropDownListTemplate"
    }

    return Templates;

});