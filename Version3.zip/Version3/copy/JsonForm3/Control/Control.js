define(["jquery", "knockout", "InputHelper"], function($, ko, InputHelper) {

    var Control = {};

    Control.CreateContainer = function() {

        var container = $("<li/>", {
            id: InputHelper.CreateGuid(),
            class: "form-grup"
        });

        return container;
    };

    Control.BuildHtml = function(container, template, options) {

        ko.applyBindingsToNode(container[0], {
            template: {
                name: template,
                data: options
            }
        });
        container.find("[data-bind]").removeAttr("data-bind");
    };

    Control.SetValue = function(container) {

    };

    Control.GetValue = function(container) {

    };

    Control.DeleteInput = function(container) {

        var containerIdName = container[0].id;

        var $inputId = InputHelper.GetJqueryId(containerIdName);

        $inputId.remove();
    };

    return Control;
});