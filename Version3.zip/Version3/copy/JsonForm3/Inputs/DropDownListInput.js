define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function DropDownListInput(options) {

        this.jsonOptions = options.jsonOptions;
        this.$inputsContainer = options.$inputsContainer;
        this.dropDownListOptions = {};

        this.setDropDownList();
    }

    DropDownListInput.prototype.initializeDropDownListOptions = function(container) {

        this.dropDownListOptions = {
            labelField: this.jsonOptions.dropDownListOptions.label,
            dropdownList: new DropDownList(this.jsonOptions.dropDownListOptions.items),
            remove: function() {
                Control.DeleteInput(container);
            }
        }
    };

    DropDownListInput.prototype.setDropDownList = function() {

        var container = Control.CreateContainer();

        this.initializeDropDownListOptions(container);

        Control.BuildHtml(container, Templates.DropDownListTemplate, this.dropDownListOptions);

        this.$inputsContainer.append(container);
    };

    function DropDownList(items) {

        var dropDownListItems = [];

        for (i = 0; i < items.length; i++) {

            dropDownListItems.push(new Item(items[i]));
        }

        return dropDownListItems;
    };

    function Item(option) {

        return {
            text: option.text,
            value: option.value
        };
    };

    return DropDownListInput;

});