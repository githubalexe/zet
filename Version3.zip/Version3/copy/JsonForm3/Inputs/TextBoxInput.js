define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function TextBoxInput(options) {

        this.jsonOptions = options.jsonOptions;
        this.$inputsContainer = options.$inputsContainer;
        this.textBoxOptions = {};

        this.setTextBox();
    }

    TextBoxInput.prototype.initializeTextBoxOptions = function(container) {

        this.textBoxOptions = {
            labelField: this.jsonOptions.textboxOptions.label,
            inputPlaceholder: this.jsonOptions.textboxOptions.placeholder,
            setValue: function() {
                Control.SetValue(container);
            },
            getValue: function() {
                Control.GetValue(container);
            },
            remove: function() {
                Control.DeleteInput(container);
            }
        }
    };

    TextBoxInput.prototype.setTextBox = function() {

        var container = Control.CreateContainer();

        this.initializeTextBoxOptions(container);

        Control.BuildHtml(container, Templates.TextBoxTemplate, this.textBoxOptions);

        this.$inputsContainer.append(container);
    };

    return TextBoxInput;
});