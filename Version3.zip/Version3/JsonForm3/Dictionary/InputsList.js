define([], function() {

    var InputsList = {
        TextBox: "textbox",
        DropDownList: "dropDownList"
    }

    return InputsList;

});