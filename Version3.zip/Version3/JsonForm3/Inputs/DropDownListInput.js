define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function DropDownListInput(options) {

        this.jsonOptions = options.jsonOptions;
        this.container = options.container;
        this.dropDownListOptions = {};

        this.initializeDropDownListOptions();

        Control.call(this);

        this.BuildHtml(this.container, Templates.DropDownListTemplate, this.dropDownListOptions);
    }

    DropDownListInput.prototype.initializeDropDownListOptions = function() {

        this.dropDownListOptions = {
            labelField: this.jsonOptions.dropDownListOptions.label,
            dropdownList: new DropDownList(this.jsonOptions.dropDownListOptions.items),
            remove: function() {
                this.DeleteInput(this.container);
            }
        }
    };

    function DropDownList(items) {

        var dropDownListItems = [];

        for (i = 0; i < items.length; i++) {

            dropDownListItems.push(new Item(items[i]));
        }

        return dropDownListItems;
    };

    function Item(option) {

        return {
            text: option.text,
            value: option.value
        };
    };

    return DropDownListInput;

});