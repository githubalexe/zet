define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function TextBoxInput(options) {

        var self = this;

        this.mainContainer = options.mainContainer;
        this.templateContainer = options.templateContainer;
        this.jsonOptions = options.jsonOptions;

        Control.call(this);

        this.BuildHtml(
            self.templateContainer,
            Templates.TextBoxTemplate,
            self.jsonOptions.inputOptions
        );

        this.DeleteInput();
        this.SetValue();
        this.GetValue();
    };

    return TextBoxInput;

});