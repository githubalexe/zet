define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function TextBoxInput(options) {

        var self = this;

        this.jsonOptions = options.jsonOptions;
        this.container = options.container;
        this.textBoxOptions = {};

        this.initializeTextBoxOptions();

        Control.call(this);



        this.textBoxOptions = self.InitializeInput(self.InitializeInput(self.jsonOptions.textboxOptions, self.container));

        console.log(self.container);

        this.BuildHtml(this.container, Templates.TextBoxTemplate, this.textBoxOptions);
    }

    TextBoxInput.prototype.initializeTextBoxOptions = function() {

        var self = this;

        self.textBoxOptions = {

            inputPlaceholder: this.jsonOptions.textboxOptions.placeholder
        };
    };

    return TextBoxInput;

});