define(["jquery", "InputGenerator", "CodeMirror", "bootstrap"], function($, InputGenerator, CodeMirror) {

    // var $textInput = $("#textInput");
    // var $clearButton = $("#clearButton");
    // var $generateButton = $("#generateButton");
    // var $inputsContainer = $("#inputsContainer");
    // var $itemTemplate = $("#itemTemplate");

    // initializeInputGenerator();


    // function initializeInputGenerator() {

    //     var options = {
    //         $generateButton: $generateButton,
    //         $textInput: $textInput,
    //         $inputsContainer: $inputsContainer,
    //         $clearButton: $clearButton,
    //         $itemTemplate: $itemTemplate
    //     }

    //     new InputGenerator(options);
    // }

    var option = [{
            "type": "textbox",
            "textboxOptions": {
                "label": "Age",
                "placeholder": "Write your age",
                "type": "integer"
            }
        },
        {
            "type": "textbox",
            "textboxOptions": {
                "label": "Age",
                "placeholder": "Write your age",
                "type": "integer"
            }
        }
    ]

    $("somebutton").on("click", function() {
        var jsonGenerator = new InputGenerator(options);
    });

    function setTextarea() {

        var $code = $("#textInput")[0];

        var editor = CodeMirror.fromTextArea($code, {
            lineNumbers: true,
            mode: "text/html"
        });

    }
});