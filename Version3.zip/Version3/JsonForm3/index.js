define(["jquery", "InputGenerator", "bootstrap"], function($, InputGenerator) {

    var $textInput = $("#textInput");
    var $clearButton = $("#clearButton");
    var $generateButton = $("#generateButton");
    var $inputsContainer = $("#inputsContainer");
    var $itemTemplate = $("#itemTemplate");


    initializeInputGenerator();

    function initializeInputGenerator() {

        var options = {
            $generateButton: $generateButton,
            $textInput: $textInput,
            $inputsContainer: $inputsContainer,
            $clearButton: $clearButton,
            $itemTemplate: $itemTemplate
        }

        new InputGenerator(options);
    }
});