define(["jquery", "knockout", "InputsList", "InputHelper", "bootstrap"], function($, ko, InputList, InputHelper) {

    function InputGenerator(options) {

        this.$generateButton = options.$generateButton;
        this.$textInput = options.$textInput;
        this.$inputsContainer = options.$inputsContainer;
        this.$clearButton = options.$clearButton;
        this.$itemTemplate = options.$itemTemplate;

        this.bindEvents();
    };

    InputGenerator.prototype.bindEvents = function() {

        var self = this;

        self.$generateButton.on("click", function() {

            var value = self.$textInput.val();

            var inputType = self.getTypeOfInput(value);

            if (inputType.input === InputList.TextBox) {

                var options = self.initializeTextbox();

                var inputContainer = $("<div/>", {
                    id: InputHelper.createGuid()
                });

                ko.applyBindingsToNode(inputContainer[0], {
                    template: {
                        name: "textboxTemplate",
                        data: {
                            labelField: options.label,
                            inputPlaceholder: options.placeholder
                        }
                    }
                });

                inputContainer.find("[data-bind]").removeAttr("data-bind");

                self.$inputsContainer.append(inputContainer);

            } else if (inputType.input === InputList.DropDownList) {

                var options = self.initializeList();

                console.log(options.items);

                var inputContainer = $("<div/>", {
                    id: InputHelper.createGuid()
                });

                ko.applyBindingsToNode(inputContainer[0], {
                    template: {
                        name: "listTemplate",
                        data: {
                            labelField: options.label,
                            dropdownList: new dropDownList(options)
                        }
                    }
                });

                inputContainer.find("[data-bind]").removeAttr("data-bind");

                self.$inputsContainer.append(inputContainer);
            }
        });
    };

    InputGenerator.prototype.defineTexboxModel = function() {

        var self = this;

        var viewModel = {
            textboxInputs: ko.observableArray([]),
            addInput: function() {

                var options = self.initializeTextbox();

                if (!$.isEmptyObject(options)) {

                    this.textboxInputs.push(new textboxInput(viewModel.textboxInputs, options))
                }
            }
        }

        ko.applyBindings(viewModel);

    };

    InputGenerator.prototype.initializeTextbox = function() {

        var text = this.$textInput.val();
        var isJson = this.isJson(text);
        var object = {};

        if (isJson === true) {

            var obj = JSON.parse(text);

            object.label = obj.textbox.label;
            object.placeholder = obj.textbox.placeholder;
        }

        return object;
    };

    //list
    InputGenerator.prototype.defineListModel = function() {

        var self = this;

        var viewModel = {
            textboxInputs: ko.observableArray([]),
            addInput: function() {

                var options = self.initializeList();

                if (!$.isEmptyObject(options)) {

                    this.textboxInputs.push(new dropDownList(viewModel.textboxInputs, options))
                }
            }
        }

        ko.applyBindings(
            viewModel
        );
    };

    InputGenerator.prototype.getTypeOfInput = function(value) {

        var isJson = this.isJson(value);
        var object = {};

        if (isJson === true) {

            var obj = JSON.parse(value);

            object.input = obj.input;
        }

        return object;
    };

    InputGenerator.prototype.initializeList = function() {

        var text = this.$textInput.val();
        var isJson = this.isJson(text);
        var object = {};

        if (isJson === true) {

            var obj = JSON.parse(text);

            object.label = obj.dropDownList.label;
            object.items = obj.dropDownList.items;
        }


        return object;
    };

    function dropDownList(options) {

        var array = [];
        console.log(options.items);

        for (i = 0; i < options.items.length; i++) {

            array.push(new item(options.items[i]));
        }


        return array;
    };

    function item(option) {
        console.log(option);
        return {
            itemList: option,
        };
    };

    ///
    function textboxInput(textboxInputs, options) {
        return {
            labelField: options.label,
            inputPlaceholder: options.placeholder,
            remove: function() {
                textboxInputs.remove(this);
            }
        };
    };

    InputGenerator.prototype.isJson = function(text) {
        try {
            JSON.parse(text);
        } catch (e) {
            return false;
        }
        return true;
    };

    return InputGenerator;
});