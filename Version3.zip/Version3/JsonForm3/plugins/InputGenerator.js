define(["InputHelper", "InputFactory", "bootstrap"], function(InputHelper, InputFactory) {

    function InputGenerator(options) {

        this.$generateButton = options.$generateButton;
        this.$textInput = options.$textInput;
        this.$inputsContainer = options.$inputsContainer;
        this.$clearButton = options.$clearButton;
        this.$itemTemplate = options.$itemTemplate;
        this.jsonOptions = {};

        this.bindEvents();
    };

    InputGenerator.prototype.bindEvents = function() {

        var self = this;

        self.$generateButton.on("click", function() {

            var value = self.$textInput.val();

            self.getJsonFromValue(value);

        });
    };

    InputGenerator.prototype.getJsonFromValue = function(value) {

        if (InputHelper.IsJson(value)) {

            this.jsonOptions = JSON.parse(value);

            this.createInput();

        } else {
            //error
        }
    };

    InputGenerator.prototype.createInput = function() {

        var self = this;

        if (InputHelper.IsArray(self.jsonOptions)) {

            var inputs = [...self.jsonOptions];

            for (i = 0; i < inputs.length; i++) {

                var jsonObject = {
                    container: self.createContainer(),
                    jsonOptions: inputs[i]
                };

                InputFactory.LoadFileInput(jsonObject);
            }
        } else {

            var jsonObject = {
                container: self.createContainer(),
                jsonOptions: self.jsonOptions
            };

            InputFactory.LoadFileInput(jsonObject);
        }
    };

    InputGenerator.prototype.createContainer = function() {

        var container = $("<li/>", {
            id: InputHelper.CreateGuid(),
            class: "form-grup"
        });

        this.$inputsContainer.append(container);

        return container;
    };

    return InputGenerator;
});