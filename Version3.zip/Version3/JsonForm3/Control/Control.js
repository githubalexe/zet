define(["jquery", "knockout", "InputHelper"], function($, ko, InputHelper) {

    function Control() {

        this.BuildHtml = function(container, template, options) {

            ko.applyBindingsToNode(container[0], {
                template: {
                    name: template,
                    data: options
                }
            });
            container.find("[data-bind]").removeAttr("data-bind");
        };

        this.InitializeInput = function(options, container) {

            var inputOptions = {
                labelField: options.label,
                setValue: function() {
                    this.SetValue(container);
                },
                getValue: function() {
                    this.GetValue(container);
                },
                remove: function() {
                    this.DeleteInput(container);
                }
            };

            return inputOptions;
        }

        this.SetValue = function(container) {

        };

        this.GetValue = function(container) {

        };

        this.DeleteInput = function(container) {

            var containerIdName = container[0].id;

            var $inputId = InputHelper.GetJqueryId(containerIdName);

            $inputId.remove();
        };
    };

    return Control;

});