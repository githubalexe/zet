define(["jquery", "knockout", "InputHelper"], function($, ko, InputHelper) {

    function Control() {

        this.BuildHtml = function(container, template, options) {

            ko.applyBindingsToNode(container[0], {
                template: {
                    name: template,
                    data: options
                }
            });
            container.find("[data-bind]").removeAttr("data-bind");
        };


        this.SetValue = function() {

            $("[name='setValue']").on("click", function() {

                var $inputValue = $(this).siblings("[name='input']");
                var $mainInput = $(this).parent().siblings(".template").children("[name='mainInput']");

                $mainInput.val($inputValue.val());

            })

        };

        this.GetValue = function() {

            $("[name='getValue']").on("click", function() {

                var $inputValue = $(this).siblings("[name='input']");
                var $mainInput = $(this).parent().siblings(".template").children("[name='mainInput']");

                $inputValue.val($mainInput.val());

            })

        };

        this.DeleteInput = function() {

            $("[name='remove']").on("click", function() {
                var child = $(this).parent();
                $(child).parent().remove();
            })

        };
    };

    // Control.options = {
    //     $parent: $("#id"),
    //     label: "",
    //     placeholder: "",
    //     $parent: $({}),
    //     name: "",
    //     onControlCreated: function() {
    //         this.options.$parent.append(
    //             "<button id='asdasd'>"
    //         )
    //     }
    // };

    return Control;

});