define(["jquery"], function($) {

    function ControllerInput() {

    };

    ControllerInput.prototype.appendContainer = function() {


    };

    ControllerInput.prototype.deleteContainer = function() {


    };

    ControllerInput.prototype.setInput = function() {


    };

    return ControllerInput;

});