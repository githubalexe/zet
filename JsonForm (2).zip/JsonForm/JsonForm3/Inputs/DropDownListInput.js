define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function DropDownListInput(options) {

        var self = this;

        this.mainContainer = options.mainContainer;
        this.templateContainer = options.templateContainer;
        this.jsonOptions = options.jsonOptions;

        this.dropDownListOptions = {};
        this.initializeDropDownListOptions();

        console.log(this.jsonOptions.inputOptions);

        Control.call(this);

        this.BuildHtml(
            self.templateContainer,
            Templates.DropDownListTemplate,
            self.dropDownListOptions
        );
    }

    DropDownListInput.prototype.initializeDropDownListOptions = function() {

        this.dropDownListOptions = {
            label: this.jsonOptions.inputOptions.label,
            dropdownList: new DropDownList(this.jsonOptions.inputOptions.items)
        }
    };

    function DropDownList(items) {

        var dropDownListItems = [];

        for (i = 0; i < items.length; i++) {

            dropDownListItems.push(new Item(items[i]));
        }

        return dropDownListItems;
    };

    function Item(option) {

        return {
            text: option.text,
            value: option.value
        };
    };

    return DropDownListInput;

});