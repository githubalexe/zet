define(["jquery", "knockout", "InputHelper"], function($, ko, InputHelper) {

    var _index = null;

    function generateInputId() {

        return "input-" + _index;
    }

    function generateContainerInputId() {

        return "input-" + _index + "-container";
    }

    function generateId() {
        _index = InputHelper.CreateGuid();
    }

    function Control() {

        generateId();

        this.inputId = generateInputId();
        this.containerId = generateContainerInputId();

        this.BuildHtml = function(container, template, options) {

            ko.applyBindingsToNode(container[0], {
                template: {
                    name: template,
                    data: options
                }
            });
            container.find("[data-bind]").removeAttr("data-bind");
        };

        this.SetValue = function() {

            console.log("verifica")
        };

        this.GetValue = function() {

        };

        this.DeleteInput = function() {

        };
    };

    return Control;

});