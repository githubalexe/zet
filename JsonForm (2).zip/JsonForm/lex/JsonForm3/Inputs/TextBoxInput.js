define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function TextBoxInput(options) {

        var self = this;

        this.options = $.extend({}, options, TextBoxInput.defaultOptions);

        this.mainContainer = this.options.mainContainer;
        this.templateContainer = options.templateContainer;
        this.jsonOptions = options.jsonOptions;

        Control.call(this);

        this.BuildHtml(
            self.templateContainer,
            Templates.TextBoxTemplate,
            self.jsonOptions.inputOptions
        );

        this.DeleteInput();
        this.SetValue();
        this.GetValue();
    };

    TextBoxInput.defaultOptions = {
        mainContainer: $("ceva"),
        templateContainer = null,
        jsonOptions = null
    }

    return TextBoxInput;

});