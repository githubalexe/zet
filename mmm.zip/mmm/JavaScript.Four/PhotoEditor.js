$(function () {

    PhotoEditor = function (options) {
        var self = this;

        self.$container = options.$container;
        self.buildBody();
    }

    PhotoEditor.prototype.buildBody = function () {
        //create edit page
        var self = this;
        var $editorContainer = $('<div/>', {
            class: 'editor-container'
        });
        var $filtersTitle = $('<p/>', {
            class: 'title'
        });
        $filtersTitle.text('Filters');
        var $efectsTitle = $('<p/>', {
            class: 'title'
        });
        $efectsTitle.text('Effects');
        var filters = document.createElement('div');
        filters.classList.add('filters');
        var $filters = $('<div/>', {
            class: 'filters'
        });
        var $effects = $('<div/>', {
            class: 'effects'
        });
        var $submitButtons = $('<div/>', {
            class: 'submit-buttons'
        });
        var $imageContainer = $('<canvas/>', {
            id: 'imageCanvas'
        });

        ////brightness
        var $brightnessContainer = $('<div/>', {
            class: 'button-container'
        });
        var $brightnessLabel = $('<label/>', {
            class: 'label'
        });
        $brightnessLabel.text('Brightness');
        var $minusBrightnessButton = $('<button/>', {
            id: 'minusBrightnessButton',
            class: 'minus-button button',
        });
        $minusBrightnessButton.text('-');
        var $plusBrightnessButton = $('<button/>', {
            id: 'plusBrightnessButton',
            class: 'minus-button button',
        });
        $plusBrightnessButton.text('+');

        //contrast
        var $contrastContainer = $('<div/>', {
            class: 'button-container'
        });
        var $contrastLabel = $('<label/>', {
            class: 'label'
        });
        $contrastLabel.text('Brightness');
        var $minusContrastButton = $('<button/>', {
            id: 'minusContrastButton',
            class: 'minus-button button',
        });
        $minusContrastButton.text('-');
        var $plusContrastButton = $('<button/>', {
            id: 'plusContrastButton',
            class: 'minus-button button',
        });
        $minusBrightnessButton.text('+');

        //Saturation
        var $saturationContainer = $('<div/>', {
            class: 'button-container'
        });
        var $saturationLabel = $('<label/>', {
            class: 'label'
        });
        $saturationLabel.text('Brightness');
        var $minusSaturationButton = $('<button/>', {
            id: 'minusSaturationButton',
            class: 'minus-button button',
        });
        $minusSaturationButton.text('-');
        var $plusSaturationButton = $('<button/>', {
            id: 'plusSaturationButton',
            class: 'minus-button button',
        });
        $plusSaturationButton.text('+');

        //vibrance
        var $vibranceContainer = $('<div/>', {
            class: 'button-container'
        });
        var $vibranceLabel = $('<label/>', {
            class: 'label'
        });
        $vibranceLabel.text('Brightness');
        var $minusVibranceButton = $('<button/>', {
            id: 'minusVibranceButton',
            class: 'minus-button button',
        });
        $minusVibranceButton.text('-');
        var $plusVibranceButton = $('<button/>', {
            id: 'plusVibranceButton',
            class: 'minus-button button',
        });
        $plusVibranceButton.text('+');

        ///Effects buttons
        var $vintageEfectButton = $('<button/>', {
            id: 'vintageEfectButton',
            class: 'effect-button',
        });
        $vintageEfectButton.text('Vintage');

        var $lemoEffectButton = $('<button/>', {
            id: 'lemoeffectButton',
            class: 'effect-button',
        });
        $lemoEffectButton.text('Lemo');


        var $clarityEffectButton = $('<button/>', {
            id: 'clarityEffectButton',
            class: 'effect-button',
        });
        $clarityEffectButton.text('Clarity');

        var $sinCityEffectButton = $('<button/>', {
            id: 'sinCityEffectButton',
            class: 'effect-button',
        });
        $sinCityEffectButton.text('Sin City');

        var $crossProcessEffectButton = $('<button/>', {
            id: 'crossProcessEffectButton',
            class: 'effect-button',
        });
        $crossProcessEffectButton.text('Cross Process');

        var $pinholeEffectButton = $('<button/>', {
            id: 'pinholeEffectButton',
            class: 'effect-button',
        });
        $pinholeEffectButton.text('Pinhole');

        var $nostalgiaEffectButton = $('<button/>', {
            id: 'nostalgiaEffectButton',
            class: 'effect-button',
        });
        $nostalgiaEffectButton.text('Nostalgia');

        var herMajestyEffectButton = document.createElement('button');
        herMajestyEffectButton.setAttribute('id', 'herMajestyEffectButton');
        herMajestyEffectButton.classList.add('effect-button');
        herMajestyEffectButton.innerHTML = 'Nostalgia';
        var $herMajestyEffectButton = $('<button/>', {
            id: 'herMajestyEffectButton',
            class: 'effect-button',
        });
        $herMajestyEffectButton.text('Her Majesty');
        //download and remove filters
        var $saveButton = $('<button/>', {
            id: 'saveButton',
            class: 'effect-button',
        });
        $saveButton.text('Save');
        var $removeEffectsButton = $('<button/>', {
            id: 'removeEffectsButton',
            class: 'effect-button',
        });
        $removeEffectsButton.text('Remove Filters');

        //////////
        $editorContainer.append($imageContainer);
        $brightnessContainer.append($minusBrightnessButton);
        $brightnessContainer.append($brightnessLabel);
        $brightnessContainer.append($plusBrightnessButton);
        $contrastContainer.append($minusContrastButton);
        $contrastContainer.append($contrastLabel);
        $contrastContainer.append($plusContrastButton);
        $saturationContainer.append($minusSaturationButton);
        $saturationContainer.append($saturationLabel);
        $saturationContainer.append($plusSaturationButton);
        $vibranceContainer.append($minusVibranceButton);
        $vibranceContainer.append($vibranceLabel);
        $vibranceContainer.append($plusVibranceButton);
        $filters.append($brightnessContainer);
        $filters.append($contrastContainer);
        $filters.append($saturationContainer);
        $filters.append($vibranceContainer);
        $effects.append($vintageEfectButton);
        $effects.append($lemoEffectButton);
        $effects.append($clarityEffectButton);
        $effects.append($sinCityEffectButton);
        $effects.append($crossProcessEffectButton);
        $effects.append($pinholeEffectButton);
        $effects.append($nostalgiaEffectButton);
        $effects.append($herMajestyEffectButton);
        $submitButtons.append($removeEffectsButton);
        $submitButtons.append($saveButton);
        $editorContainer.append($filtersTitle);
        $editorContainer.append($filters);
        $editorContainer.append($efectsTitle);
        $editorContainer.append($effects);
        $editorContainer.append($submitButtons);
        self.$container.append($editorContainer);
    }

    PhotoEditor.prototype.readImage = function () {
        var $imageCanvas = $('imageCanvas', self.container);
        var $imageCanvasContext = $imageCanvas[0].getContext('2d');
        const ctx = imageCanvas.getContext("2d");

        image.onload = function () {
            imageCanvas.width = image.width;
            imageCanvas.height = image.height;
            ctx.drawImage(image, 0, 0, image.width, image.height);

        };
    }

}());