        $(document).ready(function() {

            function Plugin() {

            }

            Plugin.prototype.setControls = function(controls) {
                var $testId = $("#testId");
                $testId.on("click", function() {
                    var test = {
                        controlType: "dropdown",
                        label: "Name Title",
                        options: [
                            "Mr",
                            "Mrs"
                        ],
                        floatingLabel: "never",
                        style: {

                            width: "100%",
                        },
                        dataModelName: "nameTitle"
                    };

                    let element = new AddItem(DropdownFloatLabelComponent, test);
                    controls.push(element);
                    console.log("It will work for array too!!!");
                });
            }


            return Plugin;
        });