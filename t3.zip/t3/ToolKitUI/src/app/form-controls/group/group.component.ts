import { Component, OnInit, ComponentFactoryResolver, Input, ViewChild } from '@angular/core';
import { AddGroupDirective } from 'src/app/group-service/group.directive';
import { GroupControlsDirective } from 'src/app/group-service/group-controls/group-controls.directive';
import { AddComponent } from 'src/app/service/add.component';
import { GroupControl } from 'src/app/group-service/group-controls/group-controls';

@Component({
    selector: 'group',
    templateUrl: './group.component.html',
    styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
    @Input() controls: GroupControl[];
    @ViewChild(GroupControlsDirective, { static: true }) addHost: GroupControlsDirective;
    currentAdIndex = -1;
    constructor(private componentFactoryResolver: ComponentFactoryResolver) { }

    ngOnInit() {
        this.getControls();
    }

    loadComponent() {
        this.currentAdIndex = (this.currentAdIndex + 1) % this.controls.length;
        const adItem = this.controls[this.currentAdIndex];
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(adItem.component);
        const viewContainerRef = this.addHost.viewContainerRef;
        const componentRef = viewContainerRef.createComponent(componentFactory);
        (<AddComponent>componentRef.instance).data = adItem.data;
    }

    getControls() {
        for (let i = 0; i < this.controls.length; i++) {
            this.loadComponent();
        }
    }
}
