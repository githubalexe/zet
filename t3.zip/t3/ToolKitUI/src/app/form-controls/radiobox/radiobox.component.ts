import { Component, Input } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
  selector: 'radiobox',
  templateUrl: './radiobox.component.html',
  styleUrls: ['./radiobox.component.css']
})
export class RadioboxComponent implements AddComponent  {
    data: any;
  
}
