import { Component, Input } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'input-float-label',
    templateUrl: './input-float-label.component.html',
    styleUrls: ['./input-float-label.component.css']
})
export class InputFloatLabelComponent implements AddComponent {
    data: any;
}
