import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PercentageTextboxComponent } from './percentage-textbox.component';

describe('PercentageTextboxComponent', () => {
  let component: PercentageTextboxComponent;
  let fixture: ComponentFixture<PercentageTextboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PercentageTextboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PercentageTextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
