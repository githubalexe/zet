import { Component, OnInit, ViewChild, Input, ComponentFactoryResolver, OnChanges } from '@angular/core';
import { AddDirective } from '../service/add.directive';
import { AddItem } from '../service/add-item';
import { AddComponent } from '../service/add.component';

@Component({
    selector: 'form-component',
    templateUrl: './form-component.component.html',
    styleUrls: ['./form-component.component.css']
})

export class FormComponentComponent implements OnInit,OnChanges {
    ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
        this.getControls();
    }
    @Input() controls: AddItem[];
    @Input() data: any;
    @ViewChild(AddDirective, { static: true }) addHost: AddDirective;
    currentAdIndex = -1;
    interval: any;

    constructor(private componentFactoryResolver: ComponentFactoryResolver) {}

    ngOnInit() {
        // this.getControls();
        // this.test();
    }

    loadComponent() {
        this.currentAdIndex = (this.currentAdIndex + 1) % this.controls.length;
        const adItem = this.controls[this.currentAdIndex];
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(adItem.component);
        const viewContainerRef = this.addHost.viewContainerRef;
        const componentRef = viewContainerRef.createComponent(componentFactory);
        (<AddComponent>componentRef.instance).data = adItem.data;
    }

    getControls() {
        for (let i = 0; i < this.controls.length; i++) {
            this.loadComponent();
        }
    }

    test2() {
        this.loadComponent();
    }

    // test() {

    //     this.interval = setInterval(() => {
    //         this.loadComponent();

    //     }, 3000);
    // }
}