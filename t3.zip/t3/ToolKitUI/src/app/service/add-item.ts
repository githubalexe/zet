import { Type } from '@angular/core';

export class AddItem {
  constructor(public component: Type<any>, public data: any) {}
}
