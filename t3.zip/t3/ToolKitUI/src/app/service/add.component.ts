export interface AddComponent {
    data: any;
}
