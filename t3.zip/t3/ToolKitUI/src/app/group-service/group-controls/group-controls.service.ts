import { Injectable } from '@angular/core';
import { ControlType } from 'src/app/service/control-types';
import { CheckboxComponent } from 'src/app/form-controls/checkbox/checkbox.component';
import { DatepickerComponent } from 'src/app/form-controls/datepicker/datepicker.component';
import { DropdownFloatLabelComponent } from 'src/app/form-controls/dropdown-float-label/dropdown-float-label.component';
import { InputFloatLabelComponent } from 'src/app/form-controls/input-float-label/input-float-label.component';
import { RadioboxComponent } from 'src/app/form-controls/radiobox/radiobox.component';
import { SubtitleComponent } from 'src/app/form-controls/subtitle/subtitle.component';
import { LeftLabelInputComponent } from 'src/app/form-controls/left-label-input/left-label-input.component';
import { SubtitleTwoComponent } from 'src/app/form-controls/subtitle-two/subtitle-two.component';
import { ShowHideButtonComponent } from 'src/app/form-controls/show-hide-button/show-hide-button.component';
import { GroupControl } from './group-controls';

@Injectable()

export class GroupControlService {
    
    getComponents(controls) {
        var components = [];
        controls.forEach(function (input) {
            switch (input.controlType) {
                case ControlType.checkbox: {
                    let element = new GroupControl(CheckboxComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.datapicker: {
                    let element = new GroupControl(DatepickerComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.dropdownFloatLabel: {
                    let element = new GroupControl(DropdownFloatLabelComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.inputFloatLabel: {
                    let element = new GroupControl(InputFloatLabelComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.radiobox: {
                    let element = new GroupControl(RadioboxComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.subtitle: {
                    let element = new GroupControl(SubtitleComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.leftLabelInput: {
                    let element = new GroupControl(LeftLabelInputComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.subtitleTwo: {
                    let element = new GroupControl(SubtitleTwoComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.showHideButton: {
                    let element = new GroupControl(ShowHideButtonComponent, input);
                    components.push(element);
                    break;
                }
                default:
                    {
                        console.log(ControlType.default);
                    }
            }
        })


        return components;
    }

}