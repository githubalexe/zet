import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[group-controls-directive]',
})
export class GroupControlsDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}

