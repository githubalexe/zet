import { Type } from '@angular/core';

export class GroupControl {
  constructor(public component: Type<any>, public data: any) {}
}
