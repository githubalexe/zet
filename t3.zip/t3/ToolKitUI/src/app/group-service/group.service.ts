import { Injectable } from '@angular/core';
import { DropdownFloatLabelComponent } from '../form-controls/dropdown-float-label/dropdown-float-label.component';
import { InputFloatLabelComponent } from '../form-controls/input-float-label/input-float-label.component';
import { AddGroupItem } from './group-item';
import { ControlType } from '../service/control-types';
import { CheckboxComponent } from '../form-controls/checkbox/checkbox.component';
import { DatepickerComponent } from '../form-controls/datepicker/datepicker.component';
import { RadioboxComponent } from '../form-controls/radiobox/radiobox.component';
import { SubtitleComponent } from '../form-controls/subtitle/subtitle.component';
import { LeftLabelInputComponent } from '../form-controls/left-label-input/left-label-input.component';
import { SubtitleTwoComponent } from '../form-controls/subtitle-two/subtitle-two.component';
import { ShowHideButtonComponent } from '../form-controls/show-hide-button/show-hide-button.component';

@Injectable()

export class AddGroupService {
    getComponents(controls) {
        var components = [];
        controls.forEach(function (input) {
            switch (input.controlType) {
                case ControlType.checkbox: {
                    let element = new AddGroupItem(CheckboxComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.datapicker: {
                    let element = new AddGroupItem(DatepickerComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.dropdownFloatLabel: {
                    let element = new AddGroupItem(DropdownFloatLabelComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.inputFloatLabel: {
                    let element = new AddGroupItem(InputFloatLabelComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.radiobox: {
                    let element = new AddGroupItem(RadioboxComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.subtitle: {
                    let element = new AddGroupItem(SubtitleComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.leftLabelInput: {
                    let element = new AddGroupItem(LeftLabelInputComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.subtitleTwo: {
                    let element = new AddGroupItem(SubtitleTwoComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.showHideButton: {
                    let element = new AddGroupItem(ShowHideButtonComponent, input);
                    components.push(element);
                    break;
                }
                default:
                    {
                        console.log(ControlType.default);
                    }
            }
        })


        return components;
    }

}