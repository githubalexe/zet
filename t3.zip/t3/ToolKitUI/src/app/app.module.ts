import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material';
import { FormComponentComponent } from './form-component/form-component.component';
import { InputFloatLabelComponent } from './form-controls/input-float-label/input-float-label.component';
import { DropdownFloatLabelComponent } from './form-controls/dropdown-float-label/dropdown-float-label.component';
import { TitleLabelComponent } from './form-controls/title-label/title-label.component';
import { RadioboxComponent } from './form-controls/radiobox/radiobox.component';
import { CheckboxComponent } from './form-controls/checkbox/checkbox.component';
import { DatepickerComponent } from './form-controls/datepicker/datepicker.component';
import { AddDirective } from './service/add.directive';
import { AddService } from './service/add.service';
import { AddGroupDirective } from './group-service/group.directive';
import { AddGroupService } from './group-service/group.service';
import { GroupTitleComponent } from './form-controls/group-title/group-title.component';
import { SubtitleComponent } from './form-controls/subtitle/subtitle.component';
import { TabsComponent } from './form-controls/tabs/tabs.component';
import { LeftLabelInputComponent } from './form-controls/left-label-input/left-label-input.component';
import { SubtitleTwoComponent } from './form-controls/subtitle-two/subtitle-two.component';
import { ShowHideButtonComponent } from './form-controls/show-hide-button/show-hide-button.component';
import { PercentageTextboxComponent } from './form-controls/percentage-textbox/percentage-textbox.component';
import { GroupControlService } from './group-service/group-controls/group-controls.service';
import { GroupComponent } from './form-controls/group/group.component';
import { GroupControlsComponent } from './form-controls/group-controls/group-controls.component';
import { GroupControlsDirective } from './group-service/group-controls/group-controls.directive';

@NgModule({
    declarations: [
        AppComponent,
        FormComponentComponent,
        InputFloatLabelComponent,
        DropdownFloatLabelComponent,
        TitleLabelComponent,
        RadioboxComponent,
        CheckboxComponent,
        DatepickerComponent,
        AddDirective,
        AddGroupDirective,
        GroupControlsDirective,
        GroupTitleComponent,
        SubtitleComponent,
        TabsComponent,
        LeftLabelInputComponent,
        SubtitleTwoComponent,
        ShowHideButtonComponent,
        PercentageTextboxComponent,
        GroupComponent,
        GroupControlsComponent

    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        MaterialModule
    ],
    providers: [
        AddService,
        AddGroupService,
        GroupControlService],
    entryComponents: [
        InputFloatLabelComponent,
        DropdownFloatLabelComponent,
        TitleLabelComponent,
        CheckboxComponent,
        RadioboxComponent,
        DatepickerComponent,
        SubtitleComponent,
        TabsComponent,
        LeftLabelInputComponent,
        SubtitleTwoComponent,
        ShowHideButtonComponent,
        PercentageTextboxComponent,
        GroupControlsComponent,
        
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
