import { Component, AfterViewInit, ComponentFactoryResolver, ViewChild } from '@angular/core';
import { AddItem } from './service/add-item';
import { AddService } from './service/add.service';
import { Modal } from './JsonData/jsonData';
import { ApplicantModal } from './JsonData/applicant';
import { IncomeModal } from './JsonData/income';
import { ExpensesModal } from './JsonData/expenses';
import { HouseholdModal } from './JsonData/household';
import * as $ from 'jquery';
import { DropdownFloatLabelComponent } from './form-controls/dropdown-float-label/dropdown-float-label.component';
import { AddComponent } from './service/add.component';
import { AddDirective } from './service/add.directive';
import { GroupControlsDirective } from './group-service/group-controls/group-controls.directive';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
    controls: AddItem[];
    testControls: AddItem[];


    currentAdIndex;
    form: any;
    jsonModal = HouseholdModal;
    @ViewChild(AddDirective, { static: true }) addHost: AddDirective;
    constructor(private addService: AddService, private componentFactoryResolver: ComponentFactoryResolver) { }

    ngAfterViewInit(): void {
        console.log(this.currentAdIndex);
        var self = this;
        var $testId = $("#testId");

        var $dropdownClass = $(".dropdownClass");

        $dropdownClass.on('click', function () {
            // let target = event.source.selected._element.nativeElement;
            // let selectedData = {
            //   value: event.value,
            //   text: target.innerText.trim()
            // };
            // console.log(selectedData);
            console.log("valuarea din lista este: ", this.value);
        })


        $testId.on("click", function () {

            self.currentAdIndex = self.controls.length;
            console.log(self.currentAdIndex);
            console.log(self.controls);

            console.log("valuarea este :", this.value);
            var test = {
                controlType: "dropdown",
                label: "Test Input Float Label",
                options: [
                    "Mr",
                    "Mrs"
                ],
                floatingLabel: "never",
                style: {

                    width: "100%",
                },
                dataModelName: "nameTitle"
            };

            let element = new AddItem(DropdownFloatLabelComponent, test);
            self.controls.push(element);

            self.test();
        });

    }

    onChange(): void {
        console.log('Change made -- onChange');
    }

    ngOnInit() {
        this.form = this.jsonModal.form;
        this.controls = this.addService.getControls(this.jsonModal);
    }

    test() {
        this.controls = this.addService.getControls(IncomeModal);
    }

}
