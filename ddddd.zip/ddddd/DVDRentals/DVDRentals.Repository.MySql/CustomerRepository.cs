﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CustomerRepository : ICustomerRepository
    {
        private UnitOfWork _unitOfWork;

        public CustomerRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateCustomerAsync(Customer customer)
        {
            await _unitOfWork.Customer.AddAsync(customer);
        }

        public async Task<IEnumerable<Customer>> CustomersListAsync(IQueryable<Customer> query, int storeId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(s => s.StoreId == storeId)
                                  .Include(a => a.Address)
                                  .ThenInclude(c => c.City)
                                  .ThenInclude(c => c.Country)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(s => s.StoreId == storeId)
                                  .Include(a => a.Address)
                                  .ThenInclude(c => c.City)
                                  .ThenInclude(c => c.Country)
                                  .ToListAsync();
            }
        }

        public IQueryable<Customer> CustomersQuery()
        {
            IQueryable<Customer> customersQuery = _unitOfWork.Customer;
            return customersQuery;
        }

        public void DeleteCustomer(Customer customer)
        {
            _unitOfWork.Customer.Remove(customer);
        }

        public async Task<Customer> GetCustomerAsync(int storeId, int customerId)
        {
            return await _unitOfWork.Customer.Where(c => c.StoreId == storeId)
                                             .Include(a => a.Address)
                                             .ThenInclude(c => c.City)
                                             .ThenInclude(c => c.Country)
                                             .FirstOrDefaultAsync(c => c.CustomerId == customerId);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}


//public async Task<IEnumerable<Customer>> GetCustomersAsync(int storeId)
//{
//    return await _context.Customer.Where(c => c.StoreId == storeId)
//                                  .Include(a => a.Address)
//                                  .ThenInclude(c => c.City)
//                                  .ThenInclude(c => c.Country)
//                                  .ToListAsync();
//}

//public async Task<bool> HasCustomerAddressAsync(int addressId)
//{
//    return await _context.Customer.AnyAsync(c => c.AddressId == addressId);
//}

//public async Task<Customer> GetCustomerAsync(int storeId, int customerId)
//{
//    return await _context.Customer.Where(c => c.StoreId == storeId)
//                                  .Include(a => a.Address)
//                                  .ThenInclude(c => c.City)
//                                  .ThenInclude(c => c.Country)
//                                  .FirstOrDefaultAsync(c => c.CustomerId == customerId);
//}
//public async Task<bool> ExistCustomerAsync(int customerId)
//{
//    return await _context.Customer.AnyAsync(c => c.CustomerId == customerId);
//}

//public void AddCustomer(Customer customer)
//{
//    _context.Add(customer);
//}

//public void UpdateCustomer(Customer customer)
//{
//    _context.Update(customer);
//}

//public void DeleteCustomer(Customer customer)
//{
//    _context.Remove(customer);
//}

//public void SaveChanges()
//{
//    _context.SaveChanges();
//}