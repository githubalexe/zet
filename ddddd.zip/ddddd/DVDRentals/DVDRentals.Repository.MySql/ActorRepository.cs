﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class ActorRepository : IActorRepository
    {
        private UnitOfWork _unitOfWork;

        public ActorRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<Actor>> ActorsListAsync(IQueryable<Actor> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.AsNoTracking().ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public IQueryable<Actor> ActorsQuery()
        {
            IQueryable<Actor> actorsQuery = _unitOfWork.Actor;
            return actorsQuery;
        }

        public async Task CreateActorAsync(Actor actor)
        {
            await _unitOfWork.Actor.AddAsync(actor);
        }

        public void DeleteActor(Actor actor)
        {
            _unitOfWork.Actor.Remove(actor);
        }

        public async Task<Actor> GetActorAsync(int actorId)
        {
            return await _unitOfWork.Actor.FirstOrDefaultAsync(a => a.ActorId == actorId);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
