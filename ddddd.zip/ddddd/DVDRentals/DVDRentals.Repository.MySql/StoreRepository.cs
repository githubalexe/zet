﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class StoreRepository : IStoreRepository
    {
        private UnitOfWork _unitOfWork;
        public StoreRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Store> GetStoreAsync(int storeId)
        {
            return await _unitOfWork.Store.Include(a => a.Address)
                                    .ThenInclude(c => c.City)
                                    .ThenInclude(c => c.Country)
                                    .FirstOrDefaultAsync(s => s.StoreId == storeId);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }

        public async Task<bool> StaffExistsAsync(int storeId, int staffId)
        {
            return await _unitOfWork.Staff.AnyAsync(s => s.StoreId == storeId && s.StaffId == staffId);
        }

        public async Task<bool> AddressExistsAsync(int addressId)
        {
            return await _unitOfWork.Staff.AnyAsync(a => a.AddressId == addressId);
        }

        public IQueryable<Store> StoresQuery()
        {
            IQueryable<Store> storesQuery = _unitOfWork.Store;
            return storesQuery;
        }

        public async Task<IEnumerable<Store>> StoresListAsync(IQueryable<Store> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Include(a => a.Address)
                                  .ThenInclude(c => c.City)
                                  .ThenInclude(c => c.Country)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }
    }
}
