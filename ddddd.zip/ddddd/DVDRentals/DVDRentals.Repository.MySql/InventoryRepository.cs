﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class InventoryRepository : IInventoryRepository
    {
        private UnitOfWork _unitOfWork;

        public InventoryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateInventoryAsync(Inventory inventory)
        {
            await _unitOfWork.Inventory.AddAsync(inventory);
        }

        public void DeleteInventory(Inventory inventory)
        {
            _unitOfWork.Inventory.Remove(inventory);
        }

        public async Task<bool> ExistInventoryAsync(int inventoryId)
        {
            return await _unitOfWork.Inventory.AnyAsync(i => i.InventoryId == inventoryId);
        }

        public async Task<Inventory> GetInventoryAsync(int storeId, int inventoryId)
        {
            return await _unitOfWork.Inventory.FirstOrDefaultAsync(i => i.StoreId == storeId && i.InventoryId == inventoryId);
        }

        public async Task<Inventory> GetInventoryAsync(int inventoryId)
        {
            return await _unitOfWork.Inventory.FirstOrDefaultAsync(i => i.InventoryId == inventoryId);
        }

        public IQueryable<Inventory> InventoriesQuery()
        {
            IQueryable<Inventory> inventoriesQuery = _unitOfWork.Inventory;
            return inventoriesQuery;
        }

        public async Task<IEnumerable<Inventory>> ListCopiesAsync(IQueryable<Inventory> query, int filmId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(f => f.FilmId == filmId)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(f => f.FilmId == filmId)
                                  .ToListAsync();
            }
        }

        public async Task<IEnumerable<Inventory>> ListInventoriesAsync(IQueryable<Inventory> query, int storeId, int filmId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(i => i.StoreId == storeId && i.FilmId == filmId)
                                  .Include(f => f.Film)
                                  .ThenInclude(l => l.Language)
                                  .Include(f => f.Film)
                                  .ThenInclude(c => c.FilmCategory)
                                  .ThenInclude(c => c.Category)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(i => i.StoreId == storeId && i.FilmId == filmId)
                                  .Include(f => f.Film)
                                  .ThenInclude(l => l.Language)
                                  .Include(f => f.Film)
                                  .ThenInclude(c => c.FilmCategory)
                                  .ThenInclude(c => c.Category)
                                  .ToListAsync();
            }
        }

        public async Task<IEnumerable<Inventory>> ListStoreInventoriesAsync(IQueryable<Inventory> query, int storeId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(i => i.StoreId == storeId)
                                  .Include(f => f.Film)
                                  .ThenInclude(l => l.Language)
                                  .Include(f => f.Film)
                                  .ThenInclude(c => c.FilmCategory)
                                  .ThenInclude(c => c.Category)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(i => i.StoreId == storeId)
                                  .Include(f => f.Film)
                                  .ThenInclude(l => l.Language)
                                  .Include(f => f.Film)
                                  .ThenInclude(c => c.FilmCategory)
                                  .ThenInclude(c => c.Category)
                                  .ToListAsync();
            }
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}


///

//public async Task<IEnumerable<Inventory>> GetFilmsAsync(int storeId)
//{
//    return await _context.Inventory.Where(i => i.StoreId == storeId)
//                                   .Include(f => f.Film)
//                                   .ThenInclude(l => l.Language)
//                                   .Include(f => f.Film)
//                                   .ThenInclude(c => c.FilmCategory)
//                                   .ThenInclude(c => c.Category)
//                                   .ToListAsync();

//}
//public async Task<Inventory> GetInventoryAsync(int storeId, int inventoryId)
//{
//    return await _context.Inventory.FirstOrDefaultAsync(i => i.StoreId == storeId && i.InventoryId == inventoryId);
//}

//public async Task<Inventory> GetInventoryAsync(int inventoryId)
//{
//    return await _context.Inventory.FirstOrDefaultAsync(i => i.InventoryId == inventoryId);
//}

//public async Task<bool> ExistInventoryAsync(int inventoryId)
//{
//    return await _context.Inventory.AnyAsync(i => i.InventoryId == inventoryId);
//}

//public async Task<IEnumerable<Inventory>> GetInventoriesAsync(int storeId, int filmId)
//{
//    return await _context.Inventory.Where(i => i.StoreId == storeId && i.FilmId == filmId)
//                                   .Include(f => f.Film)
//                                   .ThenInclude(l => l.Language)
//                                   .Include(f => f.Film)
//                                   .ThenInclude(c => c.FilmCategory)
//                                   .ThenInclude(c => c.Category)
//                                   .ToListAsync();
//}

//public async Task<IEnumerable<Inventory>> GetInventoriesAsync(int filmId)
//{
//    return await _context.Inventory.Where(i => i.FilmId == filmId)
//                                   .ToListAsync();
//}

//public void AddInventory(Inventory inventory)
//{
//    _context.Inventory.Add(inventory);
//}

//public void UpdateInventory(Inventory inventory)
//{
//    _context.Inventory.Update(inventory);
//}
//public void DeleteInventory(Inventory inventory)
//{
//    _context.Inventory.Remove(inventory);
//}

//public void SaveChanges()
//{
//    _context.SaveChanges();
//}