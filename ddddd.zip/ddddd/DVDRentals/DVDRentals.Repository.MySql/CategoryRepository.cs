﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CategoryRepository : ICategoryRepository
    {
        private UnitOfWork _unitOfWork;
        public CategoryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<Category>> CategoriesListAsync(IQueryable<Category> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.AsNoTracking().ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public IQueryable<Category> CategoriesQuery()
        {
            IQueryable<Category> categoriesQuery = _unitOfWork.Category;
            return categoriesQuery;
        }

        public async Task CreateCategoryAsync(Category category)
        {
            await _unitOfWork.Category.AddAsync(category);
        }

        public void DeleteCategory(Category category)
        {
            _unitOfWork.Category.Remove(category);
        }

        public async Task<Category> GetCategoryAsync(int categoryId)
        {
            return await _unitOfWork.Category.FirstOrDefaultAsync(a => a.CategoryId == categoryId);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
