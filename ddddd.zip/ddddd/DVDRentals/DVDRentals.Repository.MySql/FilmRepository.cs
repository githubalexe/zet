﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class FilmRepository : IFilmRepository
    {
        private UnitOfWork _unitOfWork;

        public FilmRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateFilmAsync(Film film)
        {
            await _unitOfWork.Film.AddAsync(film);
        }

        public void DeleteFilm(Film film)
        {
            _unitOfWork.Film.Remove(film);
        }

        public async Task<IEnumerable<Film>> FilmsListAsync(IQueryable<Film> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Include(l => l.Language)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Include(l => l.Language)
                                  .ToListAsync();
            }
        }

        public IQueryable<Film> FilmsQuery()
        {
            IQueryable<Film> filmsQuery = _unitOfWork.Film;
            return filmsQuery;
        }

        public async Task<Film> GetFilmAsync(int filmId)
        {
            return await _unitOfWork.Film.Include(l => l.Language)
                                         .FirstOrDefaultAsync(f => f.FilmId == filmId);
        }

        public async Task<bool> LanguageExistsAsync(int languageId)
        {
            return await _unitOfWork.Language.AnyAsync(l => l.LanguageId == languageId);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
