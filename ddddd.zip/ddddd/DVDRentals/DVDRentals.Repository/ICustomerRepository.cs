﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICustomerRepository
    {
        IQueryable<Customer> CustomersQuery();
        Task<IEnumerable<Customer>> CustomersListAsync(IQueryable<Customer> query, int storeId, bool asNoTracking = false);
        Task<Customer> GetCustomerAsync(int storeId, int customerId);
    
        Task CreateCustomerAsync(Customer customer);
        void DeleteCustomer(Customer customer);
        Task SaveChangesAsync();
    }
}
//Task<IEnumerable<Customer>> GetCustomersAsync(int storeId);
//Task<Customer> GetCustomerAsync(int storeId, int customerId);
//Task<bool> ExistCustomerAsync(int customerId);
//Task<bool> HasCustomerAddressAsync(int addressId);
//void AddCustomer(Customer customer);
//void DeleteCustomer(Customer customer);
//void SaveChanges();