﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IStoreRepository
    {
        IQueryable<Store> StoresQuery();
        Task<IEnumerable<Store>> StoresListAsync(IQueryable<Store> query, bool asNoTracking = false);
        Task<Store> GetStoreAsync(int storeId);
        Task<bool> StaffExistsAsync(int storeId, int staffId);
        Task<bool> AddressExistsAsync(int addressId);
        Task SaveChangesAsync();
    }
}
