﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Rental;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class RentalsController : Controller
    {
        private IRentalRepository _rentalRepository;
        private IInventoryRepository _inventoryRepository;
        private ICustomerRepository _customerRepository;
        private IStaffRepository _staffRepository;
        public RentalsController(IRentalRepository rentalRepository, IInventoryRepository inventoryRepository, ICustomerRepository customerRepository, IStaffRepository staffRepository)
        {
            _rentalRepository = rentalRepository;
            _inventoryRepository = inventoryRepository;
            _customerRepository = customerRepository;
            _staffRepository = staffRepository;
        }

        [HttpGet("rentals/{rentalId}", Name = "GetRentalAsync")]
        public async Task<IActionResult> GetRentalAsync(int rentalId)
        {
            ErrorMessage errorMessage = new ErrorMessage(); 
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental == null)
            {
                errorMessage.Message = RentalMessages.NoRentalResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            RentalResponse rentalResponse = rental.ToRentalResponse();

            return Ok(rentalResponse);
        }

        [HttpPost("rentals")]
        public async Task<IActionResult> CreateRentalAsync([FromBody] RentalCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = RentalMessages.InvalidRentaRequest.GetDescription();

                return BadRequest(errorMessage);
            }

           // bool customer = await _customerRepository.ExistCustomerAsync(request.CustomerId);
            bool staff = await _staffRepository.ExistStaffAync(request.StaffId);
            bool inventory = await _inventoryRepository.ExistInventoryAsync(request.InventoryId);

            //if (customer == false)
            //{
            //    errorList.Add("The " + request.CustomerId + " property is null!");
            //}
            if (inventory == false)
            {
                errorList.Add("The " + request.InventoryId + " property is null!");
            }

            if (staff == false)
            {
                errorList.Add("The " + request.StaffId + " property is null!");
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            Rental rental = request.ToRentalModel();
            _rentalRepository.AddRental(rental);
            _rentalRepository.SaveChanges();
            RentalResponse rentalResponse = rental.ToRentalResponse();

            return CreatedAtRoute("GetRentalAsync", new { rentalId = rental.RentalId }, rentalResponse);
        }

        [HttpPut("rentals/{rentalId}")]
        public async Task<IActionResult> UpdateRentalAsync([FromBody]RentalUpdateRequest request, int rentalId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            //bool customer = await _customerRepository.ExistCustomerAsync(request.CustomerId);
            bool inventory = await _inventoryRepository.ExistInventoryAsync(request.InventoryId);
            bool staff = await _staffRepository.ExistStaffAync(request.StaffId);

            List<string> errorList = new List<string>();

            if (rental == null)
            {
                errorMessage.Message = RentalMessages.NoRentalResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            //if (customer == false)
            //{
            //    errorList.Add("The " + request.CustomerId + " property is null!");
            //}
            if (inventory == false)
            {
                errorList.Add("The " + request.InventoryId + " property is null!");
            }

            if (staff == false)
            {
                errorList.Add("The " + request.StaffId + " property is null!");
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            rental = request.ModifyRental(rental);
            _rentalRepository.UpdateRental(rental);
            _rentalRepository.SaveChanges();
            RentalResponse rentalResponse = rental.ToRentalResponse();

            return Ok(rentalResponse);
        }

        [HttpDelete("rentals/{rentalId}")]
        public async Task<IActionResult> DeleteRentalAsync(int rentalId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental == null)
            {
                errorMessage.Message = RentalMessages.NoRentalResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            _rentalRepository.DeleteRental(rental);
            _rentalRepository.SaveChanges();

            return Ok();
        }
    }
}