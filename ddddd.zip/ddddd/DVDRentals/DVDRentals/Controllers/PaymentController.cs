﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class PaymentController : Controller
    {
        private IPaymentRepository _paymentRepository;
        private IStaffRepository _staffRepository;
        private IStoreRepository _storeRepository;
        private ICustomerRepository _customerRepository;
        private IRentalRepository _rentalRepository;

        public PaymentController(IPaymentRepository paymentRepository, IStaffRepository staffRepository, IStoreRepository storeRepository, ICustomerRepository customerRepository, IRentalRepository rentalRepository)
        {
            _paymentRepository = paymentRepository;
            _staffRepository = staffRepository;
            _customerRepository = customerRepository;
            _rentalRepository = rentalRepository;
            _storeRepository = storeRepository;
        }

        [HttpGet("stores/{storeId}/payments")]
        public async Task<IActionResult> GetStorePaymentsAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StorePaymentsResponse> paymentResponseList = new List<StorePaymentsResponse>();

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staffList.Count() == 0)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentList.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (Staff staff in staffList)
            {
                IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staff.StaffId);
                foreach (Payment payment in paymentList)
                {
                    paymentResponseList.Add(payment.ToStorePaymentResponse());
                }
            }

            return Ok(paymentResponseList);
        }

        [HttpGet("stores/{storeId}/payments/{paymentId}")]
        public async Task<IActionResult> GetStorePaymentAsync(int storeId, int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StorePaymentsResponse> paymentResponseList = new List<StorePaymentsResponse>();

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (Staff staff in staffList)
            {
                Payment payment = await _paymentRepository.GetStaffPaymentAsync(staff.StaffId, paymentId);
                if (payment != null)
                {
                    paymentResponseList.Add(payment.ToStorePaymentResponse());
                }
            }

            if (paymentResponseList.Count() == 0)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentList.GetDescription();

                return BadRequest(errorMessage);
            }

            return Ok(paymentResponseList);
        }

        [HttpGet("payments/{paymentId}", Name = "GetPaymentAsync")]
        public async Task<IActionResult> GetPaymentAsync(int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);

            if (payment == null)
            {
                errorMessage.Message = PaymentMessages.NoPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            PaymentResponse paymentResponse = payment.ToPaymentResponse();

            return Ok(paymentResponse);
        }

        [HttpPost("payments")]
        public async Task<IActionResult> CreatePaymentAsync([FromBody] PaymentCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            //bool customer = await _customerRepository.ExistCustomerAsync(request.CustomerId);
            bool staff = await _staffRepository.ExistStaffAync(request.StaffId);
            bool rental = await _rentalRepository.GetRentalValidationAsync(request.RentalId);

            //if (customer == false)
            //{
            //    errorList.Add("The " + request.CustomerId + " property is null!");
            //}

            if (staff == false)
            {
                errorList.Add("The " + request.StaffId + " property is null!");
            }

            if (rental == false)
            {
                errorList.Add("The " + request.RentalId + " property is null!");
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            Payment payment = request.ToPaymentModel();
            _paymentRepository.AddPayment(payment);
            _paymentRepository.SaveChanges();
            PaymentResponse paymentResponse = payment.ToPaymentResponse();

            return CreatedAtRoute("GetPaymentAsync", new { paymentId = paymentResponse.PaymentId }, paymentResponse);
        }

        [HttpPut("payments/{paymentId}")]
        public async Task<IActionResult> UpdatePaymentAsync([FromBody] PaymentUpdateRequest request, int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);
            List<string> errorList = new List<string>();

            if (payment == null)
            {
                errorMessage.Message = PaymentMessages.NoPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentRequest.GetDescription();

                return BadRequest(errorMessage);
            }

           // bool customer = await _customerRepository.ExistCustomerAsync(request.CustomerId);
            bool staff = await _staffRepository.ExistStaffAync(request.StaffId);
            bool rental = await _rentalRepository.GetRentalValidationAsync(request.RentalId);

            //if (customer == false)
            //{
            //    errorList.Add("The " + request.CustomerId + " property is null!");
            //}

            if (staff == false)
            {
                errorList.Add("The " + request.StaffId + " property is null!");
            }

            if (rental == false)
            {
                errorList.Add("The " + request.RentalId + " property is null!");
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }


            payment = request.ToPaymentModel(payment);
            _paymentRepository.UpdatePayment(payment);
            _paymentRepository.SaveChanges();
            PaymentResponse paymentResponse = payment.ToPaymentResponse();

            return Ok(paymentResponse);
        }

        [HttpDelete("payments/{paymentId}")]
        public async Task<IActionResult> DeletePaymentAsync(int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);

            if (payment == null)
            {
                errorMessage.Message = PaymentMessages.NoPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            _paymentRepository.DeletePayment(payment);
            _paymentRepository.SaveChanges();

            return Ok();
        }
    }
}