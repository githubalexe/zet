﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StoresController : Controller
    {
        private IStoreRepository _storeRepository;

        public StoresController(IStoreRepository storeRepository)
        {
            _storeRepository = storeRepository;
        }

        [HttpGet("stores")]
        public async Task<IActionResult> GetStoresAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Store> storesQuery = _storeRepository.StoresQuery();

            storesQuery = storesQuery.OrderBy(store => store.StoreId);

            IEnumerable<Store> stores = await _storeRepository.StoresListAsync(storesQuery, true);

            if (stores.Count() == 0)
            {
                errorMessage.Message = StoreMessages.InvalidStoresList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<StoreResponseLite> response = stores.Select(store => store.ToStoreResponseLite());

                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}")]
        public async Task<IActionResult> GetStoreAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            StoreResponseLite storeResponse = store.ToStoreResponseLite();

            return Ok(storeResponse);
        }

        [HttpPut("stores/{storeId}")]
        public async Task<IActionResult> UpdateStoreAsync([FromBody] StoreUpdateRequest request, int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = StoreMessages.InvalidStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isStaff = await _storeRepository.StaffExistsAsync(storeId, request.ManagerStaffId);

            if (isStaff == false)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isAddress = await _storeRepository.AddressExistsAsync(request.AddressId);

            if (isAddress == false)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                store = request.ToStoreModel(store);

                await _storeRepository.SaveChangesAsync();

                StoreResponse response = store.ToStoreResponse();

                return Ok(response);
            }
        }
    }
}