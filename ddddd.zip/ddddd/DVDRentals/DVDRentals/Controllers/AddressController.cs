﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Address;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class AddressController : Controller
    {
        private IAddressRepository _addressRepository;

        public AddressController(IAddressRepository addressRepository)
        {
            _addressRepository = addressRepository;
        }

        [HttpGet("addresses")]
        public async Task<IActionResult> GetAddressesAsync(int addressId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Address> addressesQuery = _addressRepository.AddressesQuery();

            addressesQuery = addressesQuery.OrderBy(address => address.AddressId);

            IEnumerable<Address> addresses = await _addressRepository.AddressesListAsync(addressesQuery, true);

            if (addresses.Count() == 0)
            {
                errorMessage.Message = AddressMessages.InvalidAddressesList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<AddressResponseLite> response = addresses.Select(address => address.ToAddressResponseLite());

                return Ok(response);
            }
        }

        [HttpGet("addresses/{addressId}", Name = "GetAddressAsync")]
        public async Task<IActionResult> GetAddressAsync(int addressId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address == null)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                AddressResponseLite response = address.ToAddressResponseLite();

                return Ok(response);
            }
        }

        [HttpPost("addresses")]
        public async Task<IActionResult> CreateAddress([FromBody] AddressCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = AddressMessages.InvalidAddressRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCity = await _addressRepository.CityExistsAsync(request.CityId);

            if (isCity == false)
            {
                errorMessage.Message = CityMessages.NoCityResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Address address = request.ToAddressModel();

                await _addressRepository.CreateAddressAsync(address);
                await _addressRepository.SaveChangesAsync();

                AddressResponse response = address.ToAddressResponse();

                return CreatedAtRoute("GetAddressAsync", new { addressId = address.AddressId }, response);
            }
        }

        [HttpPut("addresses/{addressId}")]
        public async Task<IActionResult> UpdateAddress([FromBody] AddressUpdateRequest request, int addressId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (request == null)
            {
                errorMessage.Message = AddressMessages.InvalidAddressRequest.GetDescription();

                return BadRequest(errorMessage);
            }


            if (address == null)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCity = await _addressRepository.CityExistsAsync(request.CityId);

            if (isCity == false)
            {
                errorMessage.Message = CityMessages.NoCityResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                address = request.ToAddressModel(address);

                await _addressRepository.SaveChangesAsync();

                AddressResponse response = address.ToAddressResponse();

                return Ok(response);
            }
        }

        [HttpDelete("addresses/{addressId}")]
        public async Task<IActionResult> DeleteAddress(int addressId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address == null)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isStoreAddress = await _addressRepository.StaffAddressExistsAsync(address.AddressId);
            bool isStaffAddress = await _addressRepository.StoreAddressExistsAsync(address.AddressId);
            bool isCustomerAddress = await _addressRepository.CustomerAddressExistsAsync(address.AddressId);

            if (isStoreAddress == true || isStaffAddress == true || isCustomerAddress == true)
            {
                errorMessage.Message = AddressMessages.DeleteAddressFalid.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _addressRepository.DeleteAddress(address);

                await _addressRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}
