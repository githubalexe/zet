﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.DeleteRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class CustomersController : Controller
    {
        private ICustomerRepository _customerRepository;
        private IPaymentRepository _paymentRepository;
        private IPaymentService _paymentService;
        private IRentalService _rentalService;
        private IStoreRepository _storeRepository;
        private IAddressRepository _addressRepository;

        public CustomersController(ICustomerRepository customerRepository, IPaymentRepository paymentRepository, IPaymentService paymentService, IRentalService rentalService, IStoreRepository storeRepository, IAddressRepository addressRepository)
        {
            _customerRepository = customerRepository;
            _paymentRepository = paymentRepository;
            _paymentService = paymentService;
            _rentalService = rentalService;
            _storeRepository = storeRepository;
            _addressRepository = addressRepository;
        }

        [HttpGet("stores/{storeId}/customers")]
        public async Task<IActionResult> GetCustomersAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<Customer> customersQuery = _customerRepository.CustomersQuery();

            customersQuery = customersQuery.OrderBy(customer => customer.CustomerId);

            IEnumerable<Customer> customers = await _customerRepository.CustomersListAsync(customersQuery, storeId, true);

            if (customers.Count() == 0)
            {
                errorMessage.Message = CustomerMessages.InvalidCustomerList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<CustomerResponseLite> response = customers.Select(customer => customer.ToCustomerResponseLite());
                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}/customers/{customerId}", Name = "GetCustomerAsync")]
        public async Task<IActionResult> GetCustomerAsync(int storeId, int customerId)
        {
            //put the address if u want
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (customer == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                CustomerResponseLite customerResponse = customer.ToCustomerResponseLite();

                return Ok(customerResponse);
            }
        }

        [HttpGet("stores/{storeId}/customers/{customerId}/payments")]
        public async Task<IActionResult> GetCustomerPaymentsAsync(int storeId, int customerId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            IEnumerable<Payment> paymentList = await _paymentRepository.GetCustomerPaymentsAsync(customerId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (customer == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (paymentList == null)
            {
                errorMessage.Message = CustomerMessages.InvalidCustomerPayments.GetDescription();

                return BadRequest(errorMessage);
            }

            List<CustomerPaymentsResponse> paymentResponseList = paymentList.ToCustomerPaymentsResponse();
            CostomerPaymentsResponseLite customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

            return Ok(customerResponse);

        }

        [HttpGet("stores/{storeId}/customers/{customerId}/payments/{paymentId}")]
        public async Task<IActionResult> GetCustomerPaymentAsync(int storeId, int customerId, int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Payment payment = await _paymentRepository.GetCustomerPaymentAsync(customerId, paymentId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (customer == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (payment == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            CustomerPaymentsResponse paymentResponse = payment.ToCustomerPaymentResponse();
            List<CustomerPaymentsResponse> paymentResponseList = new List<CustomerPaymentsResponse>();
            paymentResponseList.Add(paymentResponse);
            CostomerPaymentsResponseLite customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

            return Ok(customerResponse);
        }

        [HttpPost("stores/{storeId}/customers")]
        public async Task<IActionResult> CreateCustomerAsync([FromBody] CustomerCreateRequest request, int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = CustomerMessages.InvalidCustomerRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool IsAddress = await _addressRepository.AddressExistsAsync(request.AddressId);

            if (IsAddress == false)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Customer customer = request.ToCustomerModel(storeId);

                await _customerRepository.CreateCustomerAsync(customer);
                await _customerRepository.SaveChangesAsync();

                CustomerResponse response = customer.ToCustomerResponse();

                return CreatedAtRoute("GetCustomerAsync", new { customerId = customer.CustomerId }, response);
            }
        }

        [HttpPut("stores/{storeId}/customers/{customerId}")]
        public async Task<IActionResult> UpdateCustomerAsync([FromBody] CustomerUpdateRequest request, int storeId, int customerId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (request == null)
            {
                errorMessage.Message = CustomerMessages.InvalidCustomerRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (customer == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isAddress = await _addressRepository.AddressExistsAsync(request.AddressId);

            if (isAddress == false)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                customer = request.ToCustomerModel(customer, storeId);

                await _customerRepository.SaveChangesAsync();

                CustomerResponse response = customer.ToCustomerResponse();

                return Ok(response);
            }
        }

        [HttpDelete("stores/{storeId}/customers/{customerId}")]
        public async Task<IActionResult> DeleteCustomerAsync(int storeId, int customerId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (customer == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                await _paymentService.DeleteCustomerPaymentsAsync(customer.CustomerId);
                await _rentalService.DeleteCustomerRentalsAsync(customer.CustomerId);

                _customerRepository.DeleteCustomer(customer);

                await _customerRepository.SaveChangesAsync();

                return Ok();
            }
        }

        [HttpDelete("stores/{storeId}/customers")]
        public async Task<IActionResult> DeleteCustomersAsync([FromBody] CustomerDeleteRequest request, int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            List<string> errorList = new List<string>();

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = CustomerMessages.InvalidCustomerRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (string customerId in request.CustomerIds)
            {
                int id = Int32.Parse(customerId);
                Customer customer = await _customerRepository.GetCustomerAsync(storeId, id);

                if (customer == null)
                {
                    errorList.Add("The customer with id " + customerId + " doesn't exist!");
                }
                else
                {
                    await _paymentService.DeleteCustomerPaymentsAsync(customer.CustomerId);
                    await _rentalService.DeleteCustomerRentalsAsync(customer.CustomerId);
                    _customerRepository.DeleteCustomer(customer);
                }
            }

            if (errorList.Count == 0)
            {
                await _customerRepository.SaveChangesAsync();

                return Ok();
            }
            else
            {
                return BadRequest(errorList);
            }
        }
    }
}