﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffRepository _staffRepository;
        private IStoreRepository _storeRepository;
        private IPaymentRepository _paymentRepository;
        private IPaymentService _paymentService;
        private IRentalService _rentalService;
        private IAddressRepository _addressRepository;

        public StaffsController(IStaffRepository staffRepository, IPaymentRepository paymentRepository, IPaymentService paymentService, IRentalService rentalService, IStoreRepository storeRepository, IAddressRepository addressRepository)
        {
            _staffRepository = staffRepository;
            _paymentRepository = paymentRepository;
            _paymentService = paymentService;
            _storeRepository = storeRepository;
            _rentalService = rentalService;
            _addressRepository = addressRepository;
        }

        [HttpGet("stores/{storeId}/Staffs")]
        public async Task<IActionResult> GetStaffsAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staffList.Count() == 0)
            {
                errorMessage.Message = StaffMessages.InvalidStaffList.GetDescription();

                return BadRequest(errorMessage);
            }

            List<StaffResponseLite> staffResponseList = staffList.ToStaffResponseList();

            return Ok(staffResponseList);
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}", Name = "GetStaffAsync")]
        public async Task<IActionResult> GetStaffAsync(int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            StaffResponseLite staffResponse = staff.ToStaffResponseLite();

            return Ok(staffResponse);

        }

        [HttpGet("stores/{storeId}/staffs/{staffId}/payments")]
        public async Task<IActionResult> GetStaffPayments(int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staffId);

            if (paymentList.Count() == 0)
            {
                errorMessage.Message = StaffMessages.InvalidStaffPayments.GetDescription();

                return BadRequest(errorMessage);
            }

            List<StaffPaymentsResponse> paymentResponseList = paymentList.ToStaffPaymentsResponse();

            return Ok(paymentResponseList);
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}/payments/{paymentId}")]
        public async Task<IActionResult> GetStaffPaymentAsync(int storeId, int staffId, int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Payment payment = await _paymentRepository.GetStaffPaymentAsync(staffId, paymentId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (payment == null)
            {
                errorMessage.Message = StaffMessages.NoStaffPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            List<StaffPaymentsResponse> paymentResponseList = new List<StaffPaymentsResponse>();
            StaffPaymentsResponse paymentResponse = payment.ToStaffPaymentResponse();
            paymentResponseList.Add(paymentResponse);

            return Ok(paymentResponseList);
        }

        [HttpPost("stores/{storeId}/staffs")]
        public async Task<IActionResult> CreateStaffAsync([FromBody] StaffCreateRequest request, int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = StaffMessages.InvalidStaffRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool address = await _addressRepository.AddressExistsAsync(request.AddressId);

            if (address == false)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            Staff staff = request.ToStaffModel(storeId);
            _staffRepository.AddStaff(staff);
            _staffRepository.SaveChanges();
            StaffResponse staffResponse = staff.ToStaffResponse();

            return CreatedAtRoute("GetStaffAsync", new { staffId = staff.StaffId }, staffResponse);
        }

        [HttpPut("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> UpdateStaffAsync([FromBody] StaffUpdateRequest request, int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (request == null)
            {
                errorMessage.Message = StaffMessages.InvalidStaffRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isAddress = await _addressRepository.AddressExistsAsync(request.AddressId);

            if (isAddress == false)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            staff = request.ToStaffModel(staff, storeId);
            _staffRepository.UpdateStaff(staff);
            _staffRepository.SaveChanges();
            StaffResponse staffResponse = staff.ToStaffResponse();

            return Ok(staffResponse);
        }

        [HttpDelete("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> DeleteCustomerAsync(int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
           // Store store = await _storeRepository.GetManagerAsync(storeId);

            //if (store == null)
            //{
            //    errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

            //    return BadRequest(errorMessage);
            //}

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            //if (store.ManagerStaff != null)
            //{
            //    errorMessage.Message = StaffMessages.DeleteStaffFailed.GetDescription();

            //    return BadRequest(errorMessage);
            //}

            //await _paymentService.DeleteStaffPaymentsAsync(staff.StaffId);
            //await _rentalService.DeleteStaffRentalsAsync(staffId);

            //_staffRepository.DeleteStaff(staff);
            //_staffRepository.SaveChanges();

            return Ok();
        }
    }
}