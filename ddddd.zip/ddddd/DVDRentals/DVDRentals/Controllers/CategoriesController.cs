﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.Domain;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;
using DVDRentals.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;
using DVDRentals.Services;
using DVDRentals.API.Request.DeleteRequest;
using System;
using System.Linq;
using DVDRentals.API.Response.Messages;

namespace DVDRentals.Controllers
{
    public class CategoriesController : Controller
    {
        private ICategoryRepository _categoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmCategoryService _filmCategoryService;
        public CategoriesController(ICategoryRepository categoryRepository, IFilmCategoryRepository filmCategoryRepository, IFilmCategoryService filmCategoryService)
        {
            _categoryRepository = categoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _filmCategoryService = filmCategoryService;
        }
        [HttpGet("categories")]
        public async Task<IActionResult> GetCategoriesAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Category> caregoriesQuery = _categoryRepository.CategoriesQuery();

            caregoriesQuery = caregoriesQuery.OrderBy(category => category.CategoryId);

            IEnumerable<Category> categories = await _categoryRepository.CategoriesListAsync(caregoriesQuery, true);

            if (categories.Count() == 0)
            {
                errorMessage.Message = CategoryMessages.InvalidCategoryList.GetDescription();

                return BadRequest(errorMessage);
            }

            IEnumerable<CategoryResponse> response = categories.Select(category => category.ToCategoryResponse());

            return Ok(response);
        }

        [HttpGet("categories/{categoryId}/films")]
        public async Task<IActionResult> GetFilmsCategoryAsync(int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<FilmCategory> categoriesQuery = _filmCategoryRepository.CategoriesQuery();

            categoriesQuery = categoriesQuery.OrderBy(film => film.FilmId);

            IEnumerable<FilmCategory> films = await _filmCategoryRepository.FilmsListAsync(categoriesQuery, categoryId, true);

            if (films.Count() == 0)
            {
                errorMessage.Message = CategoryMessages.InvalidFilmCategoryList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                List<FilmTitleResponse> response = new List<FilmTitleResponse>();

                foreach (FilmCategory filmCategory in films)
                {
                    response.Add(filmCategory.Film.ToFilmTitleResponse());
                }

                return Ok(response);
            }
        }

        [HttpGet("categories/{categoryId}", Name = "GetCategoryAsync")]
        public async Task<IActionResult> GetCategoryAsync(int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                CategoryResponse categoryResponse = category.ToCategoryResponse();

                return Ok(categoryResponse);
            }
        }

        [HttpPost("categories")]
        public async Task<IActionResult> CreateCategoryAsync([FromBody] CategoryCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = CategoryMessages.InvalidCategoryRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Category category = request.ToCategoryModel();

                await _categoryRepository.CreateCategoryAsync(category);
                await _categoryRepository.SaveChangesAsync();

                CategoryResponse response = category.ToCategoryResponse();

                return CreatedAtRoute("GetCategoryAsync", new { categoryId = category.CategoryId }, response);
            }

        }

        [HttpDelete("categories/{categoryId}")]
        public async Task<IActionResult> DeleteCategoryAsync(int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                await _filmCategoryService.DeleteFilmCategoryAsync(categoryId);

                _categoryRepository.DeleteCategory(category);

                await _categoryRepository.SaveChangesAsync();

                return Ok();
            }
        }

        [HttpDelete("categories")]
        public async Task<IActionResult> DeleteCategoriesAsync([FromBody] CategoryDeleteRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = CategoryMessages.InvalidCategoryRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (string categoryId in request.CategoryIds)
            {
                int id = Int32.Parse(categoryId);
                Category category = await _categoryRepository.GetCategoryAsync(id);

                if (category == null)
                {
                    errorList.Add(String.Format("The actor with id {0} doesn't exist!", categoryId));
                }
                else
                {
                    await _filmCategoryService.DeleteFilmCategoryAsync(id);
                    _categoryRepository.DeleteCategory(category);
                }
            }

            if (errorList.Count != 0)
            {
                return BadRequest(errorList);
            }
            else
            {
                await _categoryRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}