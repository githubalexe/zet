﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Inventory;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class InventoriesController : Controller
    {
        private IInventoryRepository _inventoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IRentalRepository _rentalRepository;
        private IRentalService _rentalService;
        private IStoreRepository _storeRepository;
        private IFilmRepository _filmRepository;
        public InventoriesController(IInventoryRepository inventoryRepository, IFilmCategoryRepository filmCategoryRepository, IRentalRepository rentalRepository, IRentalService rentalService, IStoreRepository storeRepository, IFilmRepository filmRepository)
        {
            _inventoryRepository = inventoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _rentalRepository = rentalRepository;
            _rentalService = rentalService;
            _storeRepository = storeRepository;
            _filmRepository = filmRepository;
        }

        [HttpGet("stores/{storeId}/inventories")]
        public async Task<IActionResult> GetInventoriesAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<Inventory> inventoriesQuery = _inventoryRepository.InventoriesQuery();

            inventoriesQuery = inventoriesQuery.OrderBy(inventory => inventory.FilmId);

            IEnumerable<Inventory> inventories = await _inventoryRepository.ListStoreInventoriesAsync(inventoriesQuery, storeId, true);
            List<InventoryResponseLite> response = new List<InventoryResponseLite>();

            if (inventories.Count() == 0)
            {
                errorMessage.Message = InventoryMessages.InvalidInventoryList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                foreach (Inventory inventory in inventories)
                {
                    FilmTitleResponse film = inventory.Film.ToFilmTitleResponse();
                    response.Add(inventory.ToInventoryResponseLite(film));
                }

                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}/inventories/{filmId}", Name = "GetInventoryAsync")]
        public async Task<IActionResult> GetInventoryAsync(int storeId, int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<Inventory> inventoriesQuery = _inventoryRepository.InventoriesQuery();

            inventoriesQuery = inventoriesQuery.OrderBy(inventory => inventory.FilmId);

            IEnumerable<Inventory> inventories = await _inventoryRepository.ListInventoriesAsync(inventoriesQuery, storeId, filmId, true);
            List<InventoryResponseLite> response = new List<InventoryResponseLite>();

            foreach (Inventory inventory in inventories)
            {
                FilmTitleResponse filmResponse = inventory.Film.ToFilmTitleResponse();
                response.Add(inventory.ToInventoryResponseLite(filmResponse));
            }

            if (response.Count() == 0)
            {
                errorMessage.Message = InventoryMessages.InvalidInventoryList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                return Ok(response);
            }
        }

        [HttpPost("stores/{storeId}/inventories")]
        public async Task<IActionResult> CreateInventoryAsync([FromBody] InventoryCreateRequest request, int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (request == null)
            {
                errorMessage.Message = InventoryMessages.InvalidInventoryRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            Film film = await _filmRepository.GetFilmAsync(request.FilmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Inventory inventory = request.ToInventoryModel(storeId);

                await _inventoryRepository.CreateInventoryAsync(inventory);
                await _inventoryRepository.SaveChangesAsync();

                InventoryResponse response = inventory.ToInventoryResponse();

                return CreatedAtRoute("GetInventoryAsync", new { storeId = inventory.StoreId, filmId = inventory.FilmId }, response);
            }
        }

        [HttpDelete("stores/{storeId}/inventories/{inventoryId}")]
        public async Task<IActionResult> DeleteInventoryAsync(int storeId, int inventoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Inventory inventory = await _inventoryRepository.GetInventoryAsync(storeId, inventoryId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (inventory == null)
            {
                errorMessage.Message = InventoryMessages.NoInventoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            int id = inventory.InventoryId;
            await _rentalService.DeleteRentalsAsync(id);

            _inventoryRepository.DeleteInventory(inventory);
            await _inventoryRepository.SaveChangesAsync();

            return Ok();
        }
    }
}