﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class FilmCategoryService: IFilmCategoryService
    {
        private IFilmCategoryRepository _filmCategoryRepository;

        public FilmCategoryService(IFilmCategoryRepository filmCategoryRepository)
        {
            _filmCategoryRepository = filmCategoryRepository;
        }

        public async Task DeleteFilmCategoryAsync(int categoryId)
        {
            IQueryable<FilmCategory> categoriesQuery = _filmCategoryRepository.CategoriesQuery();

            categoriesQuery = categoriesQuery.OrderBy(category => category.CategoryId);

            IEnumerable<FilmCategory> categories = await _filmCategoryRepository.FilmsListAsync(categoriesQuery, categoryId, true);

            if (categories != null)
            {
                foreach (FilmCategory filmCategory in categories)
                {
                    _filmCategoryRepository.DeleteCategoryAsync(filmCategory);
                }
            }
        }
    }
}
