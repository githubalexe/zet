﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class FilmActorService: IFilmActorService
    {
        private IFilmActorRepository _filmActorRepository;

        public FilmActorService(IFilmActorRepository filmActorRepository)
        {
            _filmActorRepository = filmActorRepository;
        }

        public async Task DeleteFilmActorAsync(int actorId)
        {
            IQueryable<FilmActor> actorsQuery = _filmActorRepository.ActorsQuery();

            actorsQuery = actorsQuery.OrderBy(actor => actor.ActorId);

            IEnumerable<FilmActor> films = await _filmActorRepository.FilmsListAsync(actorsQuery, actorId, true);

            if (films != null)
            {
                foreach (FilmActor filmActor in films)
                {
                    _filmActorRepository.DeleteActor(filmActor);
                }
            }
        }
    }
}
