﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Language;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class LanguageExtensionMethods
    {
        public static LanguageResponse ToLanguageResponse(this Language language)
        {
            return new LanguageResponse()
            {
                LanguageId = language.LanguageId,
                Name = language.Name,
                LastUpdate = language.LastUpdate
            };

        }

        public static Language ToLanguageModel(this LanguageCreateRequest request)
        {
            return new Language()
            {
                Name = request.Name
            };

        }
    }
}
