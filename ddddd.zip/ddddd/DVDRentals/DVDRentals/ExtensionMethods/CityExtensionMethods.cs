﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.City;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CityExtensionMethods
    {
        public static CityResponseLite ToCityResponseLite(this City city)
        {
            return new CityResponseLite()
            {
                CityId = city.CityId,
                CountryId = city.CountryId,
                Name = city.Name,
                LastUpdate = city.LastUpdate,
                Country = city.Country.ToCountryResponse()
            };
        }
        public static CityResponse ToCityResponse(this City city)
        {
            return new CityResponse()
            {
                CityId = city.CityId,
                CountryId = city.CountryId,
                Name = city.Name,
                LastUpdate = city.LastUpdate,
            };
        }
        public static City ToCityModel(this CityCreateRequest request)
        {
            return new City()
            {
                Name = request.Name,
                CountryId = request.CountryId
            };
        }

        public static City ToCityModel(this CityUpdateRequest request, City city)
        {
            city.Name = request.Name;
            city.CountryId = request.CountryId;

            return city;
        }
    }
}
