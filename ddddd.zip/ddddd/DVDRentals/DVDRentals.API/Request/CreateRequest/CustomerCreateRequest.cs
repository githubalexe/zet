﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DVDRentals.API.Request.CreateRequest
{
    public class CustomerCreateRequest
    {
        [Required(ErrorMessage = "FirstName is required.")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "LastName is required.")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Email is required.")]
        public string Email { get; set; }
        [Required(ErrorMessage = "AddressId is required.")]
        public int AddressId { get; set; }
        [Required(ErrorMessage = "Active is required.")]
        public bool Active { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
