﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum CityMessages
    {
        [Description("The city doesn't exist!")]
        NoCityResponse,
        [Description("The city list is empty!")]
        InvalidCitiesList,
        [Description("The city request is NULL!")]
        InvalidCityRequest,
    }
}
