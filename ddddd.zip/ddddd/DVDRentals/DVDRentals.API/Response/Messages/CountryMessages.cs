﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum CountryMessages
    {
        [Description("The country doesn't exist!")]
        NoCountryResponse,
        [Description("The countries list is empty!")]
        InvalidCountriesList,
        [Description("The country request is NULL!")]
        InvalidCountryRequest,
    }
}
