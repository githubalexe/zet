﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum CategoryMessages
    {
        [Description("The category doesn't exist!")]
        NoCategoryResponse,
        [Description("The category list is empty!")]
        InvalidCategoryList,
        [Description("Neither a film doesn't contain this category!")]
        InvalidFilmCategoryList,
        [Description("The film already has this category!")]
        AddCategoryFailed,
        [Description("The category request is NULL!")]
        InvalidCategoryRequest,

    }
}
