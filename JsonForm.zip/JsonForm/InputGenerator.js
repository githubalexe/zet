define(["jquery", "bootstrap", "knockout"], function($) {

    function InputGenerator(options) {

        this.$generateButton = options.$generateButton;
        this.$textInput = options.$textInput;
        this.$inputsContainer = options.$inputsContainer;
        this.$clearButton = options.$clearButton;
    }

    InputGenerator.prototype.bindEvents = function() {

        var self = this;
        var nr = 1;

        $generateButton.on("click", function() {

            var text = self.$textInput.val();
            var isJson = self.isJson(text);

            if (isJson === true) {
                var obj = JSON.parse(text);
                var object = {};

                if (obj.input === "textbox") {

                    object.label = obj.textbox.label;
                    object.type = obj.textbox.type;
                    object.placeholder = obj.textbox.placeholder;

                    generateTextBox(object);
                }

                if (obj.input === "dropDownList") {
                    object.label = obj.dropDownList.label;
                    object.items = obj.dropDownList.items;

                    generateDropDownList(object, nr);
                }
                nr++;
            }
        })
    }

    InputGenerator.prototype.generateTextBox = function(text) {

        var textbox = `<div class="form-grup">
                            <label>${options.label}</label>
                            <input type=${options.type} placeholder=${options.placeholder} class="form-control">
                        </div>`;

        $inputsContainer.append(textbox);
    }

    InputGenerator.prototype.generateDropDownList = function(text) {

    }

    InputGenerator.prototype.isJson = function(text) {
        try {
            JSON.parse(text);
        } catch (e) {
            return false;
        }
        return true;
    }

});