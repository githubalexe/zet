define(["jquery", "InputGenerator", "CodeMirror", "bootstrap"], function($, InputGenerator, CodeMirror) {

    var $textInput = $("#textInput");
    var $clearButton = $("#clearButton");
    var $generateButton = $("#generateButton");
    var $inputsContainer = $("#inputsContainer");
    var $itemTemplate = $("#itemTemplate");

    function initializeInputGenerator() {

        var options = {
            $generateButton: $generateButton,
            $textInput: $textInput,
            $inputsContainer: $inputsContainer,
            $clearButton: $clearButton,
            $itemTemplate: $itemTemplate,
            onBindButtons: function() {
                return addSettings();
            },
            onSetValue: function() {
                setValue();
            },
            onGetValue: function() {
                getValue();
            }
        }

        return options;
    }



    //trebuie sa scoti butonul afara pentru generate

    getSucces();

    function getSucces() {

        var options = initializeInputGenerator();

        var $input = new InputGenerator(options);

        console.log($input.greeting());
    }


    function addSettings() {

        var settingsContainer = $("<div/>", {
            class: "settings-container"
        });

        var setButton = $("<button/>", {
            class: "btn btn-primary button",
            html: "Set Value",
            click: function() {
                setValue();
            }
        });

        var getButton = $("<button/>", {
            class: "btn btn-success button",
            html: "Get Value"
        });

        var input = $("<input/>");

        var removeButton = $("<button/>", {
            class: "btn btn-danger remove-button",
            html: "Remove",
        });

        settingsContainer.append(setButton, getButton, input, removeButton);

        return settingsContainer;
    };

    function setValue() {

        console.log("set value");

    };


    function getValue() {

        console.log("get value");

    };


});