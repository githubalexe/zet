define(["jquery", "knockout", "InputHelper"], function($, ko, InputHelper) {

    var _index = null;

    function generateInputId() {

        return "input-" + _index;
    }

    function generateContainerInputId() {

        return "input-" + _index + "-container";
    }

    function generateNewId() {
        _index = InputHelper.CreateGuid();
    }

    function Control() {

        generateNewId();

        this.inputId = generateInputId();
        this.containerId = generateContainerInputId();

        this.BuildHtml = function(container, template, options) {

            ko.applyBindingsToNode(container[0], {
                template: {
                    name: template,
                    data: options
                }
            });
            container.find("[data-bind]").removeAttr("data-bind");
        };

        this.GetInputId = function() {

            var $inputId = $("#" + this.inputId);

            return $inputId;
        };

        this.GetContainerId = function() {

            var $containerId = $("#" + this.containerId);

            return $containerId;
        };

        //here a callback
        this.SetValue = function(value) {

            var $inputId = this.GetInputId();

            $inputId.val(value);
        };

        this.GetValue = function() {

            var $inputId = this.GetInputId();

            return $inputId.val();

        };

        this.DeleteInput = function() {

        };
    };

    return Control;

});