define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function TextBoxInput(options) {

        var self = this;

        this.mainContainer = options.mainContainer;
        this.templateContainer = options.templateContainer;
        this.jsonOptions = options.jsonOptions;

        Control.call(this);

        this.BuildHtml(
            self.templateContainer,
            Templates.TextBoxTemplate,
            textboxOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label,
                placeholder: self.jsonOptions.inputOptions.placeholder
            }
        );

    };

    return TextBoxInput;

});