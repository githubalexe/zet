define([], function() {

    var InputsType = {
        TextBox: "textbox",
        DropDownList: "dropDownList"
    }

    return InputsType;

});