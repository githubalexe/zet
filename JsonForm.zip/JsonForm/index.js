define(["jquery", "bootstrap"], function($) {

    var $textInput = $("#textInput");
    var $clearButton = $("#clearButton");
    var $generateButton = $("#generateButton");
    var $inputsContainer = $("#inputsContainer");

    function initializeInputGenerator() {

        var options = {
            $generateButton: $generateButton,
            $textInput: $textInput,
            $inputsContainer: $inputsContainer,
            $clearButton: $clearButton
        }

        new InputGenerator(options);
    }

    bindEvents();

    function bindEvents() {

        var nr = 1;

        $generateButton.on("click", function() {

            var text = $textInput.val();
            var isJson = verifyText(text);

            if (isJson === true) {
                var obj = JSON.parse(text);
                var object = {};

                if (obj.input === "textbox") {

                    object.label = obj.textbox.label;
                    object.type = obj.textbox.type;
                    object.placeholder = obj.textbox.placeholder;
                    console.log("textbox bla bla");
                    generateTextBox(object);

                } else if (obj.input === "dropDownList") {
                    object.label = obj.dropDownList.label;
                    object.items = obj.dropDownList.items;
                    console.log("dropDownList");
                    generateDropDownList(object, nr);
                }
                nr++;
            }
        })
    }

    function generateTextBox(options) {

        var placeholder = options.placeholder;

        console.log(placeholder);

        var textbox = `<div class="form-grup">
                            <label>${options.label}</label>
                            <input type=${options.type} placeholder=${placeholder} class="form-control">
                        </div>`;

        $inputsContainer.append(textbox);
    }

    function generateDropDownList(options, nr) {

        var items = options.items;

        var dropDownList = `<div class="form-grup">
                               <label>${options.label}</label>
                               <select class="form-control" id="selectId${nr}"></select>
                            </div>`;

        $inputsContainer.append(dropDownList);

        var $select = $("#selectId" + nr.toString());

        for (i = 0; i < items.length; i++) {
            var option = `<option>${items[i]}</option>`;
            $select.append(option);
        }
    }

    function verifyText(str) {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    }

});