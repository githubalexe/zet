﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.DeleteRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class ActorsController : Controller
    {
        private IActorRepository _actorRepository;
        private IFilmActorService _filmActorService;
        public ActorsController(IActorRepository actorRepository, IFilmActorService filmActorService)
        {
            _actorRepository = actorRepository;
            _filmActorService = filmActorService;
        }

        [HttpGet("actors")]
        public async Task<IActionResult> GetActorsAsync()
        {
            IEnumerable<Actor> actorList = await _actorRepository.GetActorsAsync();
            List<ActorResponse> actorResposesList = actorList.ToActorResponseList();

            return Ok(actorResposesList);
        }

        [HttpGet("actors/{actorId}", Name = "GetActorsAsync")]
        public async Task<IActionResult> GetActorsAsync(int actorId)
        {
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                return NotFound("The actor doesn't exist!");
            }

            ActorResponse actorResposes = actor.ToActorResponse();

            return Ok(actorResposes);
        }

        [HttpPost("actors")]
        public IActionResult CreateActorAsync([FromBody]ActorCreateRequest request)
        {
            Actor actor = request.ToActorModel();
            _actorRepository.AddActor(actor);
            _actorRepository.SaveChanges();
            ActorResponse actorResponse = actor.ToActorResponse();

            return CreatedAtRoute("GetActorsAsync", new { actorId = actor.ActorId }, actorResponse);
        }

        [HttpPut("actors/{actorId}")]
        public async Task<IActionResult> UpdateActorAsync([FromBody]ActorUpdateRequest request, int actorId)
        {
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                return NotFound("The actor doesn't exist!");
            }

            actor = request.ToActorModel(actor);
            _actorRepository.UpdateActor(actor);
            _actorRepository.SaveChanges();
            ActorResponse actorResponse = actor.ToActorResponse();

            return Ok(actorResponse);
        }

        [HttpDelete("actors/{actorId}")]
        public async Task<IActionResult> DeleteActorAsync(int actorId)
        {
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                return NotFound("The actor doesn't exist!");
            }

            await _filmActorService.DeleteFilmActorAsync(actorId);
            _actorRepository.DeleteActor(actor);
            _actorRepository.SaveChanges();

            return Ok("The actor has been deleted!");
        }

        [HttpDelete("actors")]
        public async Task<IActionResult> DeleteActorsAsync([FromBody] ActorDeleteRequest request)
        {
            List<string> errorList = new List<string>();

            foreach (string actorId in request.ActorIds)
            {
                int id = Int32.Parse(actorId);
                Actor actor = await _actorRepository.GetActorAsync(id);

                if (actor == null)
                {
                    errorList.Add("The actor with id " + actorId + " doesn't exist!");
                }
                else
                {
                    await _filmActorService.DeleteFilmActorAsync(id);
                    _actorRepository.DeleteActor(actor);
                }
            }

            if (errorList.Count == 0)
            {
                _actorRepository.SaveChanges();

                return Ok("The actors have been deleted!");
            }

            return BadRequest(errorList);
        }
    }
}