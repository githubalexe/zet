﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Inventory;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class InventoriesController : Controller
    {
        private IInventoryRepository _inventoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IRentalRepository _rentalRepository;
        private IRentalService _rentalService;
        public InventoriesController(IInventoryRepository inventoryRepository, IFilmCategoryRepository filmCategoryRepository, IRentalRepository rentalRepository, IRentalService rentalService)
        {
            _inventoryRepository = inventoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _rentalRepository = rentalRepository;
            _rentalService = rentalService;
        }

        [HttpGet("stores/{storeId}/inventories")]
        public async Task<IActionResult> GetInventoriesAsync(int storeId)
        {
            IEnumerable<Inventory> inventoryList = await _inventoryRepository.GetFilmsAsync(storeId);
            List<InventoryResponseLite> inventoryResponseLite = new List<InventoryResponseLite>();

            foreach (Inventory inventory in inventoryList)
            {

                FilmTitleResponse film = inventory.Film.ToFilmTitleResponse();
                inventoryResponseLite.Add(inventory.ToInventoryResponseLite(film));
            }

            return Ok(inventoryResponseLite);
        }

        [HttpGet("stores/{storeId}/inventories/{filmId}", Name = "GetInventoryAsync")]
        public async Task<IActionResult> GetInventoryAsync(int storeId, int filmId)
        {
            IEnumerable<Inventory> inventoryList = await _inventoryRepository.GetInventoriesAsync(storeId, filmId);

            List<InventoryResponseLite> inventoryResponseLite = new List<InventoryResponseLite>();

            foreach (Inventory inventory in inventoryList)
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(inventory.Film.FilmId);

                FilmTitleResponse film = inventory.Film.ToFilmTitleResponse();
                inventoryResponseLite.Add(inventory.ToInventoryResponseLite(film));
            }

            return Ok(inventoryResponseLite);
        }

        [HttpPost("stores/{storeId}/inventories")]
        public IActionResult CreateInventoryAsync([FromBody] InventoryCreateRequest request, int storeId)
        {
            Inventory inventory = request.ToInventoryModel(storeId);
            _inventoryRepository.AddInventory(inventory);
            _inventoryRepository.SaveChanges();
            InventoryResponse inventoryResponse = inventory.ToInventoryResponse();

            return CreatedAtRoute("GetInventoryAsync", new { storeId = inventory.StoreId, filmId = inventory.FilmId }, inventoryResponse);
        }

        [HttpDelete("stores/{storeId}/inventories/{inventoryId}")]
        public async Task<IActionResult> DeleteInventoryAsync(int storeId, int inventoryId)
        {
            Inventory inventory = await _inventoryRepository.GetInventoryAsync(storeId, inventoryId);
            if (inventory != null)
            {
                int id = inventory.InventoryId;
                await _rentalService.DeleteRentalsAsync(id);

                _inventoryRepository.DeleteInventory(inventory);
                _inventoryRepository.SaveChanges();

                return Ok("The inventory has been deleted!");
            }

            return NotFound("The inventory doesn't exist!");
        }
    }
}