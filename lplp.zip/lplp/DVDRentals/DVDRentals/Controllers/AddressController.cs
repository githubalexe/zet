﻿using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Address;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class AddressController : Controller
    {
        private IAddressRepository _addressRepository;

        public AddressController(IAddressRepository addressRepository)
        {
            _addressRepository = addressRepository;
        }

        [HttpGet("address/{addressId}", Name = "GetAddressAsync")]
        public async Task<IActionResult> GetAddressAsync(int addressId)
        {
            Address address = await _addressRepository.GetAddressAsync(addressId);
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }

        [HttpPost("address")]
        public IActionResult CreateAddress([FromBody] AddressCreateRequest request)
        {
            Address address = request.ToAddressModel();
            _addressRepository.AddAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return CreatedAtRoute("GetAddressAsync", new { addressId = address.AddressId }, addressResponse);
        }

        [HttpPut("address/{addressId}")]
        public async Task<IActionResult> UpdateAddress([FromBody] AddressUpdateRequest request, int addressId)
        {
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address == null)
            {
                return NotFound("The address doesn't exist!");
            }

            address = request.ToAddressModel(address);
            _addressRepository.UpdateAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }

        [HttpDelete("address/{addressId}")]
        public async Task<IActionResult> DeleteAddress(int addressId)
        {
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address == null)
            {
                return NotFound("The address doesn't exist!");
            }
            _addressRepository.DeleteAddress(address);
            _addressRepository.SaveChanges();

            return Ok("The address has been deleted!");

        }
    }
}