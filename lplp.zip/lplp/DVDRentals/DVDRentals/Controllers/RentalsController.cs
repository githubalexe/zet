﻿using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Rental;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class RentalsController : Controller
    {
        private IRentalRepository _rentalRepository;
        public RentalsController(IRentalRepository rentalRepository)
        {
            _rentalRepository = rentalRepository;
        }

        [HttpGet("rentals/{rentalId}", Name = "GetRentalAsync")]
        public async Task<IActionResult> GetRentalAsync(int rentalId)
        {
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);
            if (rental != null)
            {
                RentalResponse rentalResponse = rental.ToRentalResponse();

                return Ok(rentalResponse);
            }

            return NotFound("The rental doesn't exist");
        }

        [HttpPost("rentals")]
        public IActionResult CreateRentalAsync([FromBody] RentalCreateRequest request)
        {
            Rental rental = request.ToRentalModel();
            _rentalRepository.AddRental(rental);
            _rentalRepository.SaveChanges();
            RentalResponse rentalResponse = rental.ToRentalResponse();

            return CreatedAtRoute("GetRentalAsync", new { rentalId = rental.RentalId }, rentalResponse);
        }
        //doesn't work
        [HttpPut("rentals/{rentalId}")]
        public async Task<IActionResult> UpdateRentalAsync([FromBody]RentalUpdateRequest request, int rentalId)
        {
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);
            if (rental != null)
            {
                rental = request.ModifyRental(rental);
                _rentalRepository.UpdateRental(rental);
                _rentalRepository.SaveChanges();
                RentalResponse rentalResponse = rental.ToRentalResponse();

                return Ok(rentalResponse);
            }

            return NotFound("The rental doesn't exist!");
        }

        [HttpDelete("rentals/{rentalId}")]
        public async Task<IActionResult> DeleteRentalAsync(int rentalId)
        {
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental != null)
            {
                _rentalRepository.DeleteRental(rental);
                _rentalRepository.SaveChanges();

                return Ok("The rental has been deleted!");
            }

            return NotFound("The rental doesn't exist!");
        }
    }
}