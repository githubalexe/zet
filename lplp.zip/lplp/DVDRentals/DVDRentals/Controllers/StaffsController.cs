﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffRepository _staffRepository;
        private IStoreRepository _storeRepository;
        private IPaymentRepository _paymentRepository;
        private IPaymentService _paymentService;
        private IRentalService _rentalService;

        public StaffsController(IStaffRepository staffRepository, IPaymentRepository paymentRepository, IPaymentService paymentService, IRentalService rentalService, IStoreRepository storeRepository)
        {
            _staffRepository = staffRepository;
            _paymentRepository = paymentRepository;
            _paymentService = paymentService;
            _storeRepository = storeRepository;
            _rentalService = rentalService;
        }

        [HttpGet("stores/{storeId}/Staffs")]
        public async Task<IActionResult> GetStaffsAsync(int storeId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StaffResponseLite> staffResponseList = staffList.ToStaffResponseList();

            return Ok(staffResponseList);
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}", Name = "GetStaffAsync")]
        public async Task<IActionResult> GetStaffAsync(int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (staff != null)
            {
                StaffResponseLite staffResponse = staff.ToStaffResponseLite();

                return Ok(staffResponse);
            }

            return NotFound("The staff doesn't exist!");
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}/payments")]
        public async Task<IActionResult> GetStaffPayments(int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (staff != null)
            {
                IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staffId);
                List<PaymentForStaffResponse> paymentResponseList = paymentList.ToStaffPaymentsResponse();

                return Ok(paymentResponseList);
            }

            return NotFound("The staff doesn't exist!");
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}/payments/{paymentId}")]
        public async Task<IActionResult> GetStaffPaymentAsync(int storeId, int staffId, int paymentId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Payment payment = await _paymentRepository.GetStaffPaymentAsync(staffId, paymentId);

            if (staff == null)
            {
                return NotFound("The staff doesn't exist!");
            }
            if (payment != null)
            {
                List<PaymentForStaffResponse> paymentResponseList = new List<PaymentForStaffResponse>();
                PaymentForStaffResponse paymentResponse = payment.ToStaffPaymentResponse();
                paymentResponseList.Add(paymentResponse);

                return Ok(paymentResponseList);
            }

            return NotFound("The payment doesn't exist!");
        }

        [HttpPost("stores/{storeId}/staffs")]
        public IActionResult CreateStaffAsync([FromBody] StaffCreateRequest request, int storeId)
        {
            Staff staff = request.ToStaffModel(storeId);
            _staffRepository.AddStaff(staff);
            _staffRepository.SaveChanges();
            StaffResponse staffResponse = staff.ToStaffResponse();

            return CreatedAtRoute("GetStaffAsync", new { staffId = staff.StaffId }, staffResponse);
        }

        [HttpPut("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> UpdateStaffAsync([FromBody] StaffUpdateRequest request, int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            if (staff != null)
            {
                staff = request.ToStaffModel(staff, storeId);
                _staffRepository.UpdateStaff(staff);
                _staffRepository.SaveChanges();
                StaffResponse staffResponse = staff.ToStaffResponse();
                return Ok(staffResponse);

            }

            return NotFound("The film doesn't exist!");
        }

        [HttpDelete("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> DeleteCustomerAsync(int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Store store = await _storeRepository.GetManagerAsync(staffId);
            if (staff != null)
            {
                if (store.ManagerStaff == null)
                {
                    await _paymentService.DeleteStaffPaymentsAsync(staff.StaffId);
                    await _rentalService.DeleteStaffRentalsAsync(staffId);

                    _staffRepository.DeleteStaff(staff);
                    _staffRepository.SaveChanges();

                    return Ok("The staff has been deleted!");
                }

                return Ok("You cannot delete a staff if it is a manager!");
            }

            return NotFound("The staff doesn't exist!");
        }
    }
}