﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class RentalService : IRentalService
    {
        private IRentalRepository _rentalRepository;

        public RentalService(IRentalRepository rentalRepository)
        {
            _rentalRepository = rentalRepository;
        }
        public async Task DeleteRentalsAsync(int inventoryId)
        {
            IEnumerable<Rental> rentalList = await _rentalRepository.GetInventoryRentalsAsync(inventoryId);

            if (rentalList != null)
            {
                foreach (Rental rental in rentalList)
                {
                    _rentalRepository.DeleteRental(rental);
                }
            }
        }

        public async Task DeleteCustomerRentalsAsync(int customerId)
        {
            IEnumerable<Rental> rentalList = await _rentalRepository.GetCustomerRentalsAsync(customerId);

            if (rentalList != null)
            {
                foreach (Rental rental in rentalList)
                {
                    _rentalRepository.DeleteRental(rental);
                }
            }
        }

        public async Task DeleteStaffRentalsAsync(int staffId)
        {
            IEnumerable<Rental> rentalList = await _rentalRepository.GetStaffRentalsAsync(staffId);

            if (rentalList != null)
            {
                foreach (Rental rental in rentalList)
                {
                    _rentalRepository.DeleteRental(rental);
                }
            }
        }
    }
}
