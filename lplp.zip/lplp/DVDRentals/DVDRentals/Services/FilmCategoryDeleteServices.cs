﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class FilmCategoryDeleteServices : IFilmCategoryDeleteServices
    {
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmActorRepository _filmActorRepository;
        private IInventoryRepository _inventoryRepository;
        private IRentalService _rentalService;

        public FilmCategoryDeleteServices(IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository, IInventoryRepository inventoryRepository, IRentalService rentalService)
        {
            _filmCategoryRepository = filmCategoryRepository;
            _filmActorRepository = filmActorRepository;
            _inventoryRepository = inventoryRepository;
            _rentalService = rentalService;
        }

        public async Task DeleteFilmCategoryAsync(int filmId)
        {
            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmCategoriesAsync(filmId);

            if (filmCategoryList != null)
            {
                foreach (FilmCategory filmCategory in filmCategoryList)
                {
                    _filmCategoryRepository.DeleteFilmCategory(filmCategory);
                }
            }
        }

        public async Task DeleteFilmActorAsync(int filmId)
        {
            IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetActorsAsync(filmId);

            if (filmActorList != null)
            {
                foreach (FilmActor filmActor in filmActorList)
                {
                    _filmActorRepository.DeleteFilmActor(filmActor);
                }
            }
        }

        public async Task DeleteFilmInventoryAsync(int filmId)
        {
            IEnumerable<Inventory> inventoryList = await _inventoryRepository.GetInventoriesAsync(filmId);

            if (inventoryList != null)
            {
                foreach (Inventory inventory in inventoryList)
                {
                    int id = inventory.InventoryId;
                    _inventoryRepository.DeleteInventory(inventory);
                   await _rentalService.DeleteRentalsAsync(id);
                }
            }
        }

    }
}
