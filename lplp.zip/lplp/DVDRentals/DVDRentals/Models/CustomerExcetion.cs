﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Models
{
    public  class CustomerExcetion:Exception
    {
        public bool isValid { get; set; }
        public string errorMessage { get; set; }

    


    }
    }
