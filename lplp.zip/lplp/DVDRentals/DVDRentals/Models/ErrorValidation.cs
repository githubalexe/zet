﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Models
{
    public class ErrorValidation
    {
        public Messages Messages { get; set; }
        public string Message { get; set; }

        public string GetMessage()
        {
            string message = null;
            switch (Messages)
            {
                case Messages.InvalidCustomer:
                    {
                        message = "Customer doesn't exist!";
                        break;
                    }
                case Messages.DeleteCustomer:
                    {
                        message = "Customer has been deleted!";
                        break;
                    }
                case Messages.DeleteCustomers:
                    {
                        message = "Customers have been deleted!";
                        break;
                    }
                case Messages.InvalidRequest:
                    {
                        message = "The request object is empty!";
                        break;
                    }
            }

            return message;
        }
    }
}
