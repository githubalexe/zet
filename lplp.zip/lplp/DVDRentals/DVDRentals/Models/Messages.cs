﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Models
{
    public enum Messages
    {
        InvalidCustomer,
        DeleteCustomer,
        DeleteCustomers,
        InvalidStaff,
        DeleteStaff,
        InvalidRequest,
        InvalidCustomersList,
    }
}
