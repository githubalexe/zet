﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IActorRepository
    {
        Task<Actor> GetActorAsync(int actorId);
        Task<IEnumerable<Actor>> GetActorsAsync();
        Task<IEnumerable<Actor>> GetActorsAsync(int actorId);
        void AddActor(Actor actor);
        void UpdateActor(Actor actor);
        void DeleteActor(Actor actor);
        void SaveChanges();
    }
}
