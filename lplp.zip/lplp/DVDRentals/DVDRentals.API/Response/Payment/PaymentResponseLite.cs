﻿using DVDRentals.API.Response.Rental;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Payment
{
    public class PaymentResponseLite
    {
        public int PaymentId { get; set; }
        public int CustomerId { get; set; }
        public int StaffId { get; set; }
        public int? RentalId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
        public DateTime LastUpdate { get; set; }
        public virtual RentalResponseLite Rental { get; set; }
    }
}
