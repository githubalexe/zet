﻿
using DVDRentals.API.Response.Address;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Store
{
    public class StoreResponseLite
    {
        public int StoreId { get; set; }
        public int ManagerStaffId { get; set; }
        public int AddressId { get; set; }
        public virtual AddressResponseLite Address { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
