﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StoresController : Controller
    {
        private IStoreService _storeService;
        public StoresController(IStoreService storeService)
        {
            _storeService = storeService;
        }

        [HttpGet("Stores")]
        public async Task<IActionResult> GetAllStoresAsync()
        {
            List<StoreResponse> storeResponseList = new List<StoreResponse>();
            storeResponseList = await _storeService.GetAllStoresAsync();

            return Ok(storeResponseList);
        }

        [HttpGet("Stores/{storeId}")]
        public async Task<IActionResult> GetStoreAsync(int storeId)
        {
            StoreResponse storeResponse = new StoreResponse();
            storeResponse = await _storeService.GetStoreAsync(storeId);

            return Ok(storeResponse);
        }
    }
}