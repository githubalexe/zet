﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.CreateResponse;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Repository.MySql;
using DVDRentals.Services.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class AddressController : Controller
    {
        private IAddressService _addressService;
        private UnitOfWork _context;
        public AddressController(IAddressService addressService, UnitOfWork context)
        {
            _addressService = addressService;
            _context = context;
        }
        [HttpPost("Address")]
        public async Task<IActionResult> Create([FromBody]AddressCreateRequest request)
        {
            Address address  = new Address();
            address = await _addressService.AddAddress(request);
            _context.SaveChanges();

            AddressCreateResponse addressResponse = new AddressCreateResponse();
            //addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }
    }
}