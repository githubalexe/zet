﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using DVDRentals.Services.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class CustomersController : Controller
    {
        private ICustomerRepository _customerRepository;
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;
        private IPaymentRepository _paymentRepository;
        private IRentalRepository _rentalRepository;
        private IInventoryRepository _inventoryRepository;
        private IFilmRepository _filmRepository;
        public CustomersController(ICustomerRepository customerRepository, IAddressRepository addressRepository, ICityRepository cityRepository, ICountryRepository countryRepository, IPaymentRepository paymentRepository, IRentalRepository rentalRepository, IInventoryRepository inventoryRepository, IFilmRepository filmRepository)
        {
            _customerRepository = customerRepository;
            _addressRepository = addressRepository;
            _cityRepository = cityRepository;
            _countryRepository = countryRepository;
            _paymentRepository = paymentRepository;
            _rentalRepository = rentalRepository;
            _inventoryRepository = inventoryRepository;
            _filmRepository = filmRepository;
        }

        [HttpGet("Stores/{storeId}/Customers")]
        public async Task<IActionResult> GetAllCustomersAsync(int storeId)
        {
            IEnumerable<Customer> customerList = await _customerRepository.GetAllAsync(storeId);
            List<CustomerResponse> customerResponseList = customerList.ToCustomerResponseList();

            return Ok(customerResponseList);
        }

        [HttpGet("Stores/{storeId}/Customers/{customerId}")]
        public async Task<IActionResult> GetOnCustomerAsync(int storeId, int customerId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);
            CustomerResponse customerResponse = customer.ToCustomerResponse();

            return Ok(customerResponse);
        }

        [HttpGet("Stores/{storeId}/Customers/{customerId}/Payments")]
        public async Task<IActionResult> GetCustomerPaymentsAsync(int storeId, int customerId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);
            IEnumerable<Payment> paymentList = await _paymentRepository.GetCustomerPayments(customerId);
            List<PaymentForCustomerResponse> paymentResponseList = paymentList.ToCustomerPaymentResponse();
            CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

            return Ok(customerResponse);
        }

        //[HttpGet("Stores/{storeId}/Customers/{customerId}/Payments/{paymentId}")]
        //public async Task<IActionResult> GetCustomerPaymentAsync(int storeId, int customerId, int paymentId)
        //{
        //    CostomerPaymentsResponse customerResponse = new CostomerPaymentsResponse();
        //    customerResponse = await _customerService.GetCustomerPaymentAsync(storeId, customerId, paymentId);

        //    return Ok(customerResponse);
        //}
    }
}