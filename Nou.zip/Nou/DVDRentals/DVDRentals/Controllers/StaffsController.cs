﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using DVDRentals.Services.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffService _staffService;
        public StaffsController(IStaffService staffService)
        {
            _staffService = staffService;
        }

        [HttpGet("Stores/{storeId}/Staffs")]
        public async Task<IActionResult> GetAllStaffsAsync(int storeId)
        {
            List<StaffResponse> staffResponseList = new List<StaffResponse>();
            staffResponseList = await _staffService.GetAllStaffsAsync(storeId);

            return Ok(staffResponseList);
        }

        [HttpGet("Stores/{storeId}/Staffs/{staffId}")]
        public async Task<IActionResult> GetStaffAsync(int storeId,int staffId)
        {
            StaffResponse staffResponse = new StaffResponse();
            staffResponse = await _staffService.GetOneStaffAsync(storeId, staffId);

            return Ok(staffResponse);
        }

        [HttpGet("Stores/{storeId}/Staffs/{staffId}/Payments")]
        public async Task<IActionResult> GetStaffPayments(int storeId, int staffId)
        {
            StaffPaymentsResponse staffResponse = new StaffPaymentsResponse();
            staffResponse =await _staffService.GetStaffPaymentsAsync(storeId, staffId);

            return Ok(staffResponse);
        }

        [HttpGet("Stores/{storeId}/Staffs/{staffId}/Payments/{paymentId}")]
        public async Task<IActionResult> GetCustomerPaymentAsync(int storeId, int staffId, int paymentId)
        {
            StaffPaymentsResponse staffResponse = await _staffService.GetStaffPaymentAsync(storeId, staffId, paymentId);

            return Ok(staffResponse);
        }
    }
}