﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class FilmsController : Controller
    {
        private IInventoryService _filmService;
        public FilmsController(IInventoryService filmService)
        {
            _filmService = filmService;
        }

        [HttpGet("Stores/{storeId}/Films")]
        public async Task<IActionResult> GetAllFilmsAsync(int storeId)
        {
            List<FilmResponse> filmResponseList = new List<FilmResponse>();
            filmResponseList = await _filmService.GetAllFilmsAsync(storeId);

            return Ok(filmResponseList);
        }

        [HttpGet("Stores/{storeId}/Films/{filmId}")]
        public async Task<IActionResult> GetOneFilmAsync(int storeId, int filmId)
        {
            FilmResponse filmResponse = new FilmResponse();
            filmResponse = await _filmService.GetOneFilmAsync(storeId, filmId);

            return Ok(filmResponse);
        }

        [HttpGet("Stores/{storeId}/Films/{filmId}/Actors")]
        public async Task<IActionResult> GetFilmActorsAsync(int storeId, int filmId)
        {
            FilmActorsResponse filmResponse = new FilmActorsResponse();
            filmResponse = await _filmService.GetFilmActorsAsync(storeId,filmId);

            return Ok(filmResponse);
        }

        [HttpGet("Stores/{storeId}/Films/{filmId}/Actors/{actorId}")]
        public async Task<IActionResult> GetFilmActorAsync(int storeId, int filmId, int actorId)
        {
            FilmActorsResponse filmResponse = new FilmActorsResponse();
            filmResponse = await _filmService.GetFilmActorAsync(storeId, filmId, actorId);

            return Ok(filmResponse);
        }
    }
}