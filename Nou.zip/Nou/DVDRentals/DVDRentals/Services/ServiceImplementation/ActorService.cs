﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class ActorService: IActorService
    {
        private IActorRepository _actorRepository;
        private IFilmActorRepository _filmActorRepository;

        public ActorService(IActorRepository actorRepository, IFilmActorRepository filmActorRepository)
        {
            _actorRepository = actorRepository;
            _filmActorRepository = filmActorRepository;
        }

        public async Task<ActorResponse> GetFilmActorAsync(int filmId, int actorId)
        {
            FilmActor filmActor = await _filmActorRepository.GetOneActorAsync(filmId, actorId);
            Actor actor = await _actorRepository.GetAsync(filmActor.ActorId);
            ActorResponse actorResponse = actor.ToActorResponse();

            return actorResponse;
        }

        public async Task<List<ActorResponse>> GetFilmActorsAsync(int filmId)
        {
            IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetAllActorsAsync(filmId);
            List<ActorResponse> actorResponseList = new List<ActorResponse>();

            foreach (FilmActor filmActor in filmActorList)
            {
                ActorResponse actorResponse = new ActorResponse();
                actorResponse = await GetFilmActorAsync(filmId, filmActor.ActorId);
                actorResponseList.Add(actorResponse);
            }

            return actorResponseList;
        }
    }
}
