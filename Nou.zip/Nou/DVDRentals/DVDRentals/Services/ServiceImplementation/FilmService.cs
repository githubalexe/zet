﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class FilmService: IFilmService
    {
        private IFilmRepository _filmRepository;
        private ILanguageService _languageService;
        private IActorService _actorService;
        private ICategoryService _categoryService;

        public FilmService(IFilmRepository filmRepository, ILanguageService languageService, IActorService actorService, ICategoryService categoryService)
        {
            _filmRepository = filmRepository;
            _languageService = languageService;
            _actorService = actorService;
            _categoryService = categoryService;
        }

        public async Task<FilmResponse> GetFilmAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            LanguageResponse language = await _languageService.GetLanguage(film.LanguageId);
            CategoryResponse category = await _categoryService.GetCategoryAsync(film.FilmId);
            FilmResponse filmResponse = film.ToFilmActorsResponse(language, category);

            return filmResponse;
        }

        public async Task<FilmActorsResponse> GetFilmActorAsync(int filmId, int actorId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            ActorResponse actor = await _actorService.GetFilmActorAsync(filmId, actorId);
            FilmActorsResponse filmResponse = film.ToActorResponse(actor);

            return filmResponse;
        }
        public async Task<FilmActorsResponse> GetFilmActorsAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            List<ActorResponse> actorList = await _actorService.GetFilmActorsAsync(filmId);
            FilmActorsResponse filmResponse = film.ToActorsResponse(actorList);

            return filmResponse;
        }

        public async Task<FilmText> GetFilmTextAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            FilmText filmText = film.ToFilmTextResponse();

            return filmText;
        }
    }
}
