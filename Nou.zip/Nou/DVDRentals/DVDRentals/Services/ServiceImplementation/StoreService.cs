﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class StoreService : IStoreService
    {
        private IStoreRepository _storeRepository;
        private IAddressService _addressService;

        public StoreService(IStoreRepository storeRepository, IAddressService addressService)
        {
            _storeRepository = storeRepository;
            _addressService = addressService;
        }
        public async Task<List<StoreResponse>> GetAllStoresAsync()
        {
            IEnumerable<Store> storeList = await _storeRepository.GetAllAsync();
            List<StoreResponse> storeResponseList = new List<StoreResponse>();

            foreach (Store store in storeList)
            {
                AddressResponse address = await _addressService.GetAddress(store.AddressId);
                StoreResponse storeResponse = store.ToStoreResponse(address);

                storeResponseList.Add(storeResponse);
            }

            return storeResponseList;
        }

        public async Task<StoreResponse> GetStoreAsync(int storeId)
        {
            Store store = await _storeRepository.GetAsync(storeId);
            AddressResponse address = await _addressService.GetAddress(store.AddressId);
            StoreResponse storeResponse = store.ToStoreResponse(address);

            return storeResponse;
        }
    }
}
