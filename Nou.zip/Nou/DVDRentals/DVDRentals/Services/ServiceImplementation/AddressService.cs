﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class AddressService:IAddressService
    {
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;

        public AddressService(IAddressRepository addressRepository, ICityRepository cityRepository, ICountryRepository countryRepository)
        {
            _addressRepository = addressRepository;
            _cityRepository = cityRepository;
            _countryRepository = countryRepository;
        }

        public async Task<AddressResponse> GetAddress(int addressId)
        {
            Address address = await _addressRepository.GetAsync(addressId);
            City city = await _cityRepository.GetCityAsync(address.CityId);
            Country country = await _countryRepository.GetCountryAsync(city.CountryId);
            AddressResponse addressResponse = address.ToAddressResponse();

            return addressResponse;
        }

        public async Task<Address> AddAddress(AddressCreateRequest request)
        {
            Address address = new Address();
            address = request.ToAddressEntity();
            _addressRepository.AddAddress(address);

            return address;
        }

    }
}
