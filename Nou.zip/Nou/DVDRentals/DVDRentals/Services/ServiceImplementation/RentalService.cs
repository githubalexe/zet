﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class RentalService: IRentalService
    {
        private IRentalRepository _rentalRepository;
        private IInventoryService _invetoryService;
        public RentalService(IRentalRepository rentalRepository, IInventoryService invetoryService)
        {
            _rentalRepository = rentalRepository;
            _invetoryService = invetoryService;
        }

        public async Task<RentalResponse> GetRentalAsync(int? rentalId)
        {
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental != null)
            {
                FilmText film = await _invetoryService.GetFilmTextAsync(rental.InventoryId);
                RentalResponse rentalResponse = rental.ToRentalResponse(film);

                return rentalResponse;
            }

            return null;
        }
    }
}
