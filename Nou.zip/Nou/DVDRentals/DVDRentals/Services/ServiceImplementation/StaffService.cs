﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class StaffService:IStaffService
    {
        private IStaffRepository _staffRepository;
        private IPaymentService _paymentService;
        private IAddressService _addressService;
        public StaffService(IStaffRepository staffRepository, IAddressService addressService, IPaymentService paymentService)
        {
            _staffRepository = staffRepository;
            _addressService = addressService;
            _paymentService = paymentService;
        }

        public async Task<List<StaffResponse>> GetAllStaffsAsync(int storeId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetAllAsync(storeId);
            List<StaffResponse> staffResponseList = new List<StaffResponse>();

            foreach (Staff staff in staffList)
            {
                AddressResponse address = await _addressService.GetAddress(staff.AddressId);
                StaffResponse staffResponse = staff.ToStaffResponse(address);

                staffResponseList.Add(staffResponse);
            }

            return staffResponseList;
        }
        public async Task<StaffResponse> GetOneStaffAsync(int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetAync(storeId, staffId);
            AddressResponse address = await _addressService.GetAddress(staff.AddressId);
            StaffResponse staffResponse = staff.ToStaffResponse(address);

            return staffResponse;
        }
        public async Task<StaffPaymentsResponse> GetStaffPaymentsAsync(int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetAync(storeId, staffId);
            List<PaymentForStaffResponse> paymentResponseList = await _paymentService.GetStaffPayments(storeId, staffId);
            StaffPaymentsResponse staffResponse = staff.ToStaffPaymentListResponse(paymentResponseList);

            return staffResponse;
        }

        public async Task<StaffPaymentsResponse> GetStaffPaymentAsync(int storeId, int staffId, int paymentId)
        {
            Staff staff = await _staffRepository.GetAync(storeId, staffId);

            List<PaymentForStaffResponse> paymentResponseList = new List<PaymentForStaffResponse>();
            PaymentForStaffResponse paymentResponse = await _paymentService.GetStaffPayment(storeId,staffId, paymentId);
            paymentResponseList.Add(paymentResponse);

            StaffPaymentsResponse staffResponse = staff.ToStaffPaymentListResponse(paymentResponseList);

            return staffResponse;
        }
    }
}
