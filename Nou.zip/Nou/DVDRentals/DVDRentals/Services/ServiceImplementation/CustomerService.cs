﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class CustomerService:ICustomerService
    {
        private ICustomerRepository _customerRepository;
        private IAddressService _addressService;
        private IPaymentService _paymentService;

        public CustomerService(ICustomerRepository customerRepository, IAddressService addressService, IPaymentService paymentService)
        {
            _addressService = addressService;
            _customerRepository = customerRepository;
            _paymentService = paymentService;
        }

        public async Task<List<CustomerResponse>> GetAllCustomersAsync(int storeId)
        {
            IEnumerable<Customer> customerList = await _customerRepository.GetAllAsync(storeId);
            List<CustomerResponse> customerResponseList = new List<CustomerResponse>();

            foreach (Customer customer in customerList)
            {
                AddressResponse address = await _addressService.GetAddress(customer.AddressId);
                CustomerResponse customerResponse = customer.ToCustomerResponse(address);

                customerResponseList.Add(customerResponse);
            }

            return customerResponseList;
        }

        public async Task<CustomerResponse> GetOneCustomerAsync(int storeId, int customerId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);
            AddressResponse address = await _addressService.GetAddress(customer.AddressId);
            CustomerResponse customerResponse = customer.ToCustomerResponse(address);

            return customerResponse;
        }
        public async Task<CostomerPaymentsResponse> GetCustomerPaymentsAsync(int storeId, int customerId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);
            List<PaymentForCustomerResponse> paymentResponseList = await _paymentService.GetCustomerPayments(storeId, customerId);
            CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

            return customerResponse;
        }

        public async Task<CostomerPaymentsResponse> GetCustomerPaymentAsync(int storeId, int customerId, int paymentId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);
            List<PaymentForCustomerResponse> paymentResponseList = new List<PaymentForCustomerResponse>();
            PaymentForCustomerResponse paymentResponse = await _paymentService.GetCustomerPayment(storeId, customerId, paymentId);
            paymentResponseList.Add(paymentResponse);
            CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

            return customerResponse;
        }
        //add
        public Staff AddStaff(StaffCreateRequest request)
        {
            Staff staff = new Staff();
            staff = request.ToStaffEntity();

            return staff;
        }
    }
}
