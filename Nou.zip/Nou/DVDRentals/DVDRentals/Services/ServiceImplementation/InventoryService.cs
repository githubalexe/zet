﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class InventoryService : IInventoryService
    {
        private IInventoryRepository _inventoryRepository;
        private IFilmService _filmService;

        public InventoryService(IInventoryRepository inventoryRepository, IFilmService filmService)
        {
            _inventoryRepository = inventoryRepository;
            _filmService = filmService;
        }
        public async Task<List<FilmResponse>> GetAllFilmsAsync(int storeId)
        {
            IEnumerable<Inventory> inventoryFilmList = await _inventoryRepository.GetAllFilmsAsync(storeId);
            List<FilmResponse> filmResponseList = new List<FilmResponse>();

            int id = 0;
            foreach (Inventory inventory in inventoryFilmList)
            {
                int inventoryId = inventory.FilmId;
                if (inventoryId != id)
                {
                    FilmResponse filmResponse = await _filmService.GetFilmAsync(inventoryId);
                    filmResponseList.Add(filmResponse);
                }
                id = inventoryId;
            }

            return filmResponseList;
        }
        public async Task<FilmResponse> GetOneFilmAsync(int storeId, int filmId)
        {
            Inventory inventoryFilm = await _inventoryRepository.GetFilmAsync(storeId, filmId);
            FilmResponse filmResponse = await _filmService.GetFilmAsync(inventoryFilm.FilmId);

            return filmResponse;
        }
        public async Task<FilmText> GetFilmTextAsync(int inventoryId)
        {
            Inventory inventoryFilm = await _inventoryRepository.GetInventoryAsync(inventoryId);
            FilmText film = await _filmService.GetFilmTextAsync(inventoryFilm.FilmId);

            return film;
        }
        public async Task<FilmActorsResponse> GetFilmActorAsync(int storeId, int filmId, int actorId)
        {
            Inventory inventoryFilm = await _inventoryRepository.GetFilmAsync(storeId, filmId);
            FilmActorsResponse filmResponse = await _filmService.GetFilmActorAsync(inventoryFilm.FilmId, actorId);

            return filmResponse;
        }
        public async Task<FilmActorsResponse> GetFilmActorsAsync(int storeId, int filmId)
        {
            Inventory inventoryFilm = await _inventoryRepository.GetFilmAsync(storeId, filmId);
            FilmActorsResponse filmResponse = await _filmService.GetFilmActorsAsync(inventoryFilm.FilmId);

            return filmResponse;
        }
    }
}
