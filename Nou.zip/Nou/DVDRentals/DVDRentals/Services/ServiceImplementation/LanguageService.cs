﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class LanguageService: ILanguageService
    {
        private ILanguageRepository _languageRepository;
        public LanguageService(ILanguageRepository languageRepository)
        {
            _languageRepository = languageRepository;
        }
        public async Task<LanguageResponse> GetLanguage(int languageId)
        {
            Language language = await _languageRepository.GetAsync(languageId);
            LanguageResponse languageResponse = language.ToLanguageResponse();

            return languageResponse;
        }
    }
}
