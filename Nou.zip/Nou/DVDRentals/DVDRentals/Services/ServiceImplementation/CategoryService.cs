﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class CategoryService: ICategoryService
    {
        private ICategoryRepository _categoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        public CategoryService(ICategoryRepository categoryRepository, IFilmCategoryRepository filmCategoryRepository)
        {
            _categoryRepository = categoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
        }

        public async Task<CategoryResponse> GetCategoryAsync(int filmId)
        {
            FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(filmId);
            Category category = await _categoryRepository.GetCategoryAsync(filmCategory.CategoryId);
            CategoryResponse categoryResponse = category.ToCategoryResponse();

            return categoryResponse;
        }
    }
}
