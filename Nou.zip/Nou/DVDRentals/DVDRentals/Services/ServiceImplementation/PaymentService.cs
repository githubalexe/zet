﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceImplementation
{
    public class PaymentService: IPaymentService
    {
        private IPaymentRepository _paymentRepository;
        private ICustomerRepository _customerRepository;
        private IStaffRepository _staffRepository;
        private IRentalService _rentalService;

        public PaymentService(IPaymentRepository paymentRepository, ICustomerRepository customerRepository, IStaffRepository staffRepository, IRentalService rentalService)
        {
            _paymentRepository = paymentRepository;
            _customerRepository = customerRepository;
            _staffRepository = staffRepository;
            _rentalService = rentalService;
        }
        public async Task<PaymentForCustomerResponse> GetCustomerPayment(int storeId, int customerId, int paymentId)
        {
            Payment payment = await _paymentRepository.GetCustomerPayment(customerId, paymentId);
            RentalResponse rental = await _rentalService.GetRentalAsync(payment.RentalId);
            Staff staff = await _staffRepository.GetAync(storeId, rental.StaffId);
            StaffPaymentResponse staffResponse = staff.ToStaffPaymentResponse();
            PaymentForCustomerResponse paymentResponse = payment.ToCustomerPaymentResponse(rental, staffResponse);

            return paymentResponse;
        }
        public async Task<List<PaymentForCustomerResponse>> GetCustomerPayments(int storeId, int customerId)
        {
            IEnumerable<Payment> paymentList = await _paymentRepository.GetCustomerPayments(customerId);
            List<PaymentForCustomerResponse> paymentResponseList = new List<PaymentForCustomerResponse>();

            foreach (Payment payment in paymentList)
            {
                PaymentForCustomerResponse paymentResponse = await GetCustomerPayment(storeId, customerId, payment.PaymentId);

                if (paymentResponse.Staff != null)
                {
                    paymentResponseList.Add(paymentResponse);
                }
            }

            return paymentResponseList;
        }
        public async Task<PaymentForStaffResponse> GetStaffPayment(int storeId, int staffId, int paymentId)
        {
            Payment payment = await _paymentRepository.GetStaffPayment(staffId, paymentId);
            RentalResponse rental = await _rentalService.GetRentalAsync(payment.RentalId);
            Customer customer = await _customerRepository.GetAsync(storeId, payment.CustomerId);
            CustomerPaymentResponse customerResponse = customer.ToCustomerPaymentResponse();

            PaymentForStaffResponse paymentResponse = payment.ToStaffPaymentResponse(rental, customerResponse);

            return paymentResponse;
        }
        public async Task<List<PaymentForStaffResponse>> GetStaffPayments(int storeId, int staffId)
        {
            IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPayments(staffId);
            List<PaymentForStaffResponse> paymentResponseList = new List<PaymentForStaffResponse>();

            foreach (Payment payment in paymentList)
            {
                PaymentForStaffResponse paymentResponse = await GetStaffPayment(storeId, staffId, payment.PaymentId);

                if (payment.RentalId != null && payment.Customer != null)
                {
                    paymentResponseList.Add(paymentResponse);
                }
            }

            return paymentResponseList;
        }
        public async Task<StorePaymentsResponse> GetStorePayment(int storeId, int staffId, int paymentId)
        {
            Payment payment = await _paymentRepository.GetStaffPayment(staffId, paymentId);
            RentalResponse rental = await _rentalService.GetRentalAsync(payment.RentalId);
            Staff staff = await _staffRepository.GetAync(storeId, staffId);
            Customer customer = await _customerRepository.GetAsync(storeId, payment.CustomerId);
            StaffPaymentResponse staffResponse = staff.ToStaffPaymentResponse();
            CustomerPaymentResponse customerResponse = customer.ToCustomerPaymentResponse();

            StorePaymentsResponse paymentResponse = payment.ToStorePaymentsResponse(rental,staffResponse, customerResponse);

            return paymentResponse;
        }
        public async Task<List<StorePaymentsResponse>> GetStorePayments(int storeId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetAllAsync(storeId);
            List<StorePaymentsResponse> paymentResponseList = new List<StorePaymentsResponse>();

            foreach (Staff staff in staffList)
            {
                IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPayments(staff.StaffId);

                foreach (Payment payment in paymentList)
                {
                    StorePaymentsResponse paymentResponse = await GetStorePayment(storeId, payment.StaffId, payment.PaymentId);
                    if (paymentResponse.Customer != null && paymentResponse.Rental != null)
                    {
                        paymentResponseList.Add(paymentResponse);
                    }
                }
            }

            return paymentResponseList;
        }
    }
}
