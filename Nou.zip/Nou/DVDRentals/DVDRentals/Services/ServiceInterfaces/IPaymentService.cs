﻿using DVDRentals.API.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceInterfaces
{
    public interface IPaymentService
    {
        Task<List<PaymentForStaffResponse>> GetStaffPayments(int storeId, int staffId);
        Task<List<PaymentForCustomerResponse>> GetCustomerPayments(int storeId, int customerId);
        Task<PaymentForCustomerResponse> GetCustomerPayment(int storeId, int customerId, int paymentId);
        Task<PaymentForStaffResponse> GetStaffPayment(int storeId, int staffId, int paymentId);
        Task<List<StorePaymentsResponse>> GetStorePayments(int storeId);
    }
}
