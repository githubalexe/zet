﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceInterfaces
{
    public interface IAddressService
    {
        Task<AddressResponse> GetAddress(int addressId);
        Task<Address> AddAddress(AddressCreateRequest address);
    }
}
