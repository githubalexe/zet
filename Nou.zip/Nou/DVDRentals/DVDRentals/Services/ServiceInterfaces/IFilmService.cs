﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceInterfaces
{
    public interface IFilmService
    {
        Task<FilmResponse> GetFilmAsync(int filmId);
        Task<FilmActorsResponse> GetFilmActorAsync(int filmId, int actorId);
        Task<FilmActorsResponse> GetFilmActorsAsync(int filmId);
        Task<FilmText> GetFilmTextAsync(int filmId);
    }
}
