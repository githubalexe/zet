﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceInterfaces
{
    public interface IInventoryService
    {
        Task<List<FilmResponse>> GetAllFilmsAsync(int storeId);
        Task<FilmResponse> GetOneFilmAsync(int storeId, int filmId);
        Task<FilmActorsResponse> GetFilmActorsAsync(int storeId, int filmId);
        Task<FilmActorsResponse> GetFilmActorAsync(int storeId, int filmId, int actorId);
        Task<FilmText> GetFilmTextAsync(int inventoryId);
    }
}
