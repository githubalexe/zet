﻿using DVDRentals.API.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceInterfaces
{
    public interface IStaffService
    {
        Task<List<StaffResponse>> GetAllStaffsAsync(int storeId);
        Task<StaffResponse> GetOneStaffAsync(int storeId, int staffId);
        Task<StaffPaymentsResponse> GetStaffPaymentsAsync(int storeId, int staffId);
        Task<StaffPaymentsResponse> GetStaffPaymentAsync(int storeId, int staffId, int paymentId);
    }
}
