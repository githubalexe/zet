﻿using DVDRentals.API.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services.ServiceInterfaces
{
    public interface IRentalService
    {
        Task<RentalResponse> GetRentalAsync(int? rentalId);
    }
}
