﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerResponse ToCustomerResponse(this Customer customer, AddressResponse address)
        {
            CustomerResponse customerResponse = new CustomerResponse();
            customerResponse.Address = new AddressResponse();

            customerResponse.CustomerId = customer.CustomerId;
            customerResponse.StoreId = customer.StoreId;
            customerResponse.FirstName = customer.FirstName;
            customerResponse.LastName = customer.LastName;
            customerResponse.Email = customer.Email;
            customerResponse.AddressId = customer.AddressId;
            customerResponse.Active = customer.Active;
            customerResponse.CreateDate = customer.CreateDate;
            customerResponse.LastUpdate = customer.LastUpdate;
            customerResponse.Address = address;
            
            return customerResponse;
        }

        public static CustomerResponse ToCustomerResponseLite(this Customer customer)
        {
            CustomerResponse customerResponse = new CustomerResponse();

            customerResponse.CustomerId = customer.CustomerId;
            customerResponse.StoreId = customer.StoreId;
            customerResponse.FirstName = customer.FirstName;
            customerResponse.LastName = customer.LastName;
            customerResponse.Email = customer.Email;
            customerResponse.AddressId = customer.AddressId;
            customerResponse.Active = customer.Active;
            customerResponse.CreateDate = customer.CreateDate;
            customerResponse.LastUpdate = customer.LastUpdate;

            return customerResponse;
        }

        public static CustomerResponse ToCustomerResponse(this Customer customer)
        {
            CustomerResponse customerResponse = new CustomerResponse();
            customerResponse = customer.ToCustomerResponseLite();
            customerResponse.Address = customer.Address.ToAddressResponse();
            customerResponse.Address.City = customer.Address.City.ToCityResponse();
            customerResponse.Address.City.Country = customer.Address.City.Country.ToCountryResponse();

            return customerResponse;
        }
        public static List<CustomerResponse> ToCustomerResponseList(this IEnumerable<Customer> customerList)
        {
            List<CustomerResponse> customerResponseList = new List<CustomerResponse>();

            foreach (Customer customer in customerList)
            {
            
                CustomerResponse customerResponse = new CustomerResponse();
                customerResponse = customer.ToCustomerResponse();

                customerResponseList.Add(customerResponse);
            }

            return customerResponseList;
        }
        //public static CustomerResponse ToCustomerResponse(this Customer customer)
        //{
        //    CustomerResponse customerResponse = new CustomerResponse
        //    {
        //        Active = customer.Active,
        //        Address = new AddressResponse
        //        {
        //            City = new CityResponse
        //            {
        //                Country = new CountryResponse
        //                {
        //                    Country1 = customer.Address.City.Country.Country1
        //                }
        //            }
        //        }
        //    };

        //    return customerResponse;
        //}
    }
}
