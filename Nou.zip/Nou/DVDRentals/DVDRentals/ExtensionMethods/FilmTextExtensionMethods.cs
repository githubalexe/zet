﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmTextExtensionMethods
    {
        public static FilmText ToFilmTextResponse(this Film film)
        {
            FilmText filmText = new FilmText();
            filmText.FilmId = film.FilmId;
            filmText.Title = film.Title;
            filmText.Description = film.Description;

            return filmText;
        }

        public static List<FilmText> ToFilmTextListResponse(this IEnumerable<Film> filmList)
        {
            List<FilmText> filmTextList = new List<FilmText>();

            foreach (Film film in filmList)
            {
                FilmText filmText = new FilmText();
                filmText = film.ToFilmTextResponse();
                filmTextList.Add(filmText);
            }

            return filmTextList;
        }
    }
}
