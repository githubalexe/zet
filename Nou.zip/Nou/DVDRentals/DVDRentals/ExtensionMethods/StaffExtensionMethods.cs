﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.CreateResponse;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static StaffResponse ToStaffResponse(this Staff staff, AddressResponse address)
        {
            StaffResponse staffResponse = new StaffResponse();
            staffResponse.Address = new AddressResponse();

            staffResponse.StaffId = staff.StaffId;
            staffResponse.FirstName = staff.FirstName;
            staffResponse.LastName = staff.LastName;
            staffResponse.AddressId = staff.AddressId;
            staffResponse.Picture = staff.Picture;
            staffResponse.Email = staff.Email;
            staffResponse.StoreId = staff.StoreId;
            staffResponse.Active = staff.Active;
            staffResponse.Username = staff.Username;
            staffResponse.LastUpdate = staff.LastUpdate;
            staffResponse.Address = address;

            return staffResponse;
        }

        public static Staff ToStaffEntity(this StaffCreateRequest request)
        {
            Staff staff = new Staff();

            staff.FirstName = request.FirstName;
            staff.LastName = request.LastName;
            staff.AddressId = request.AddressId;
            staff.Picture = request.Picture;
            staff.Email = request.Email;
            staff.StoreId = request.StoreId;
            staff.Active = request.Active;
            staff.Username = request.Username;
            staff.LastUpdate = request.LastUpdate;
 
            return staff;
        }
    }
}
