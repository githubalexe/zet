﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StorePaymentsExtensionMethods
    {
        public static StorePaymentsResponse ToStorePaymentsResponse(this Payment payment, RentalResponse rental, StaffPaymentResponse staffResponse, CustomerPaymentResponse customerResponse)
        {
            StorePaymentsResponse paymentReponse = new StorePaymentsResponse();
            paymentReponse.Rental = new RentalResponse();
            paymentReponse.Staff = new StaffPaymentResponse();
            paymentReponse.Customer = new CustomerPaymentResponse();

            paymentReponse.PaymentId = payment.PaymentId;
            paymentReponse.CustomerId = payment.CustomerId;
            paymentReponse.StaffId = payment.StaffId;
            paymentReponse.RentalId = payment.RentalId;
            paymentReponse.Amount = payment.Amount;
            paymentReponse.Rental = rental;
            paymentReponse.Staff = staffResponse;
            paymentReponse.Customer = customerResponse;

            return paymentReponse;
        }
    }
}
