﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CityExtensionMethods
    {
        public static CityResponse ToCityResponse(this City city)
        {
            CityResponse cityResponse = new CityResponse();

            cityResponse.CityId = city.CityId;
            cityResponse.CountryId = city.CountryId;
            cityResponse.City1 = city.City1;
            cityResponse.LastUpdate = city.LastUpdate;

            return cityResponse;
        }
    }
}
