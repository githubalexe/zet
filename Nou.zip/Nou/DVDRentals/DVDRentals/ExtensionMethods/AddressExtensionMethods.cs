﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.CreateResponse;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class AddressExtensionMethods
    {
        public static AddressResponse ToAddressResponse(this Address address)
        {
            AddressResponse addressResponse = new AddressResponse();

            addressResponse.AddressId = address.AddressId;
            addressResponse.Address1 = address.Address1;
            addressResponse.Address2 = address.Address2;
            addressResponse.District = address.District;
            addressResponse.CityId = address.CityId;
            addressResponse.PostalCode = address.PostalCode;
            addressResponse.Phone = address.Phone;
            addressResponse.LastUpdate = address.LastUpdate;

            return addressResponse;
        }
        public static Address ToAddressEntity(this AddressCreateRequest request)
        {
            Address address = new Address();

            address.Address1 = request.Address1;
            address.Address2 = request.Address2;
            address.District = request.District;
            address.CityId = request.CityId;
            address.PostalCode = request.PostalCode;
            address.Phone = request.Phone;
            address.LastUpdate = request.LastUpdate;

            return address;
        }

        public static AddressCreateResponse ToAddresssResponse(this Address address)
        {
            AddressCreateResponse addressResponse = new AddressCreateResponse();

            addressResponse.AddressId = address.AddressId;
            addressResponse.Address1 = address.Address1;
            addressResponse.Address2 = address.Address2;
            addressResponse.District = address.District;
            addressResponse.CityId = address.CityId;
            addressResponse.PostalCode = address.PostalCode;
            addressResponse.Phone = address.Phone;
            addressResponse.LastUpdate = address.LastUpdate;

            return addressResponse;
        }
    }
}

