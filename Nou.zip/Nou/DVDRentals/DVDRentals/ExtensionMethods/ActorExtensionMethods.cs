﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static ActorResponse ToActorResponse(this Actor actor)
        {
            ActorResponse actorResponse = new ActorResponse();

            actorResponse.ActorId = actor.ActorId;
            actorResponse.FirstName = actor.FirstName;
            actorResponse.LastName = actor.LastName;
            actorResponse.LastUpdate = actor.LastUpdate;

            return actorResponse;
        }
    }
}
