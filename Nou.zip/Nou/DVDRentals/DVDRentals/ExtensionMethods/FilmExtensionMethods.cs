﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static FilmResponse ToFilmActorsResponse(this Film film, LanguageResponse language, CategoryResponse category)
        {
            FilmResponse filmResponse = new FilmResponse();
            filmResponse.Language = new LanguageResponse();

            filmResponse.FilmId = film.FilmId;
            filmResponse.Title = film.Title;
            filmResponse.Description = film.Description;
            filmResponse.ReleaseYear = film.ReleaseYear;
            filmResponse.LanguageId = film.LanguageId;
            filmResponse.OriginalLanguageId = film.OriginalLanguageId;
            filmResponse.RentalDuration = film.RentalDuration;
            filmResponse.RentalRate = film.RentalRate;
            filmResponse.Length = film.Length;
            filmResponse.ReplacementCost = film.ReplacementCost;
            filmResponse.LastUpdate = film.LastUpdate;
            filmResponse.Language = language;
            filmResponse.Rating = film.Rating;
            filmResponse.SpecialFeatures = film.SpecialFeatures;
            filmResponse.Category = category;

            return filmResponse;
        }
    }
}
