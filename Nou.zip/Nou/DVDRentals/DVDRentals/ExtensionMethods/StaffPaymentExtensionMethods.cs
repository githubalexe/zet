﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StaffPaymentExtensionMethods
    {
        public static StaffPaymentResponse ToStaffPaymentResponse(this Staff staff)
        {
            StaffPaymentResponse staffPaymentResponse = new StaffPaymentResponse();

            if(staff!=null)
            {
                staffPaymentResponse.StaffId = staff.StaffId;
                staffPaymentResponse.FirstName = staff.FirstName;
                staffPaymentResponse.LastName = staff.LastName;

                return staffPaymentResponse;
            }

            return null;
        }
    }
}
