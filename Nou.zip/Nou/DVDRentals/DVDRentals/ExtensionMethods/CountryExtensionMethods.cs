﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CountryExtensionMethods
    {
        public static CountryResponse ToCountryResponse(this Country country)
        {
            CountryResponse countryResponse = new CountryResponse();
            countryResponse.CountryId = country.CountryId;
            countryResponse.Country1 = country.Country1;
            countryResponse.LastUpdate = country.LastUpdate;

            return countryResponse;
        }
    }
}
