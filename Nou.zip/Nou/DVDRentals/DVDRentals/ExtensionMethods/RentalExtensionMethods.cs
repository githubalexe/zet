﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static RentalResponse ToRentalResponse (this Rental rental, FilmText film)
        {
            RentalResponse rentalResponse = new RentalResponse();

            rentalResponse.RentalId = rental.RentalId;
            rentalResponse.RentalDate = rental.RentalDate;
            rentalResponse.InventoryId = rental.InventoryId;
            rentalResponse.CustomerId = rental.CustomerId;
            rentalResponse.ReturnDate = rental.ReturnDate;
            rentalResponse.StaffId = rental.StaffId;
            rentalResponse.Film = film;
            rentalResponse.LastUpdate = rental.LastUpdate;
         
            return rentalResponse;
        }

        public static RentalResponse ToRentalResponse(this Rental rental)
        {
            RentalResponse rentalResponse = new RentalResponse();

            rentalResponse.RentalId = rental.RentalId;
            rentalResponse.RentalDate = rental.RentalDate;
            rentalResponse.InventoryId = rental.InventoryId;
            rentalResponse.CustomerId = rental.CustomerId;
            rentalResponse.ReturnDate = rental.ReturnDate;
            rentalResponse.StaffId = rental.StaffId;
            rentalResponse.LastUpdate = rental.LastUpdate;
            rentalResponse.Film = rental.Inventory.Film.ToFilmTextResponse();

            return rentalResponse;
        }
    }
}
