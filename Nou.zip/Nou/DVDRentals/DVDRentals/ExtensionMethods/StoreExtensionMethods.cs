﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreResponse ToStoreResponse(this Store store, AddressResponse address)
        {
            StoreResponse storeResponse = new StoreResponse();
            storeResponse.Address = new AddressResponse();
           
            storeResponse.StoreId = store.StoreId;
            storeResponse.ManagerStaffId = store.ManagerStaffId;
            storeResponse.AddressId = store.AddressId;
            storeResponse.LastUpdate = store.LastUpdate;
            storeResponse.Address = address;
        
            return storeResponse;
        }
    }
}
