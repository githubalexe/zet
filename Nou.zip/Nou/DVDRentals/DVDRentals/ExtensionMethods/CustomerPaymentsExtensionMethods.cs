﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerPaymentsExtensionMethods
    {
        public static CostomerPaymentsResponse ToCustomerPaymentsResponse(this Customer customer)
        {
            CostomerPaymentsResponse customerResponse = new CostomerPaymentsResponse();

            customerResponse.CustomerId = customer.CustomerId;
            customerResponse.FirstName = customer.FirstName;
            customerResponse.LastName = customer.LastName;

            return customerResponse;
        }
        public static CostomerPaymentsResponse ToCustomerPaymentListResponse(this Customer customer, List<PaymentForCustomerResponse> paymentResponseList)
        {
            CostomerPaymentsResponse customerResponse = new CostomerPaymentsResponse();
            customerResponse.Payments = new List<PaymentForCustomerResponse>();
            customerResponse = customer.ToCustomerPaymentsResponse();
            customerResponse.Payments = paymentResponseList;

            return customerResponse;
        }

    }
}
