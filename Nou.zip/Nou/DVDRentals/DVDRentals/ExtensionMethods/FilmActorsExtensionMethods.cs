﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmActorsExtensionMethods
    {
        public static FilmActorsResponse ToActorsResponse(this Film film, List<ActorResponse> actorList)
        {
            FilmActorsResponse filmResponse = new FilmActorsResponse();
            filmResponse.FilmActors = new List<ActorResponse>();

            filmResponse.FilmId = film.FilmId;
            filmResponse.Title = film.Title;
            filmResponse.FilmActors = actorList;

            return filmResponse;
        }

        public static FilmActorsResponse ToActorResponse(this Film film, ActorResponse actor)
        {
            FilmActorsResponse filmResponse = new FilmActorsResponse();
            List<ActorResponse> actorList = new List<ActorResponse>();
            actorList.Add(actor);

            filmResponse = film.ToActorsResponse(actorList);

            return filmResponse;
        }
    }
}
