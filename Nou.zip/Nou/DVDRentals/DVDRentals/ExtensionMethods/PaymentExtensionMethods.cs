﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class PaymentExtensionMethods
    {
        public static PaymentResponse ToPaymentResponse(this Payment payment, RentalResponse rental)
        {
            PaymentResponse paymentReponse = new PaymentResponse();
            paymentReponse.Rental = new RentalResponse();

            paymentReponse.PaymentId = payment.PaymentId;
            paymentReponse.CustomerId = payment.CustomerId;
            paymentReponse.StaffId = payment.StaffId;
            paymentReponse.RentalId = payment.RentalId;
            paymentReponse.Amount = payment.Amount;
            paymentReponse.Rental = rental;

            return paymentReponse;
        }

        public static PaymentForCustomerResponse ToCustomerPaymentResponse(this Payment payment, RentalResponse rental, StaffPaymentResponse staff)
        {
            PaymentForCustomerResponse paymentReponse = new PaymentForCustomerResponse();
            paymentReponse.Rental = new RentalResponse();
            paymentReponse.Staff = new StaffPaymentResponse();

            paymentReponse.PaymentId = payment.PaymentId;
            paymentReponse.CustomerId = payment.CustomerId;
            paymentReponse.StaffId = payment.StaffId;
            paymentReponse.RentalId = payment.RentalId;
            paymentReponse.Amount = payment.Amount;
            paymentReponse.Rental = rental;
            paymentReponse.Staff = staff;

            return paymentReponse;
        }

        public static PaymentForStaffResponse ToStaffPaymentResponse(this Payment payment, RentalResponse rental, CustomerPaymentResponse customer)
        {
            PaymentForStaffResponse paymentReponse = new PaymentForStaffResponse();
            paymentReponse.Rental = new RentalResponse();
            paymentReponse.Customer = new CustomerPaymentResponse();

            paymentReponse.PaymentId = payment.PaymentId;
            paymentReponse.CustomerId = payment.CustomerId;
            paymentReponse.StaffId = payment.StaffId;
            paymentReponse.RentalId = payment.RentalId;
            paymentReponse.Amount = payment.Amount;
            paymentReponse.Rental = rental;
            paymentReponse.Customer = customer;

            return paymentReponse;
        }
        public static List<PaymentForCustomerResponse> ToCustomerPaymentResponse(this IEnumerable<Payment> paymentList)
        {
            List<PaymentForCustomerResponse> paymentReponseList = new List<PaymentForCustomerResponse>();

            foreach (Payment payment in paymentList)
            {
                PaymentForCustomerResponse paymentReponse = new PaymentForCustomerResponse();
                paymentReponse.PaymentId = payment.PaymentId;
                paymentReponse.CustomerId = payment.CustomerId;
                paymentReponse.StaffId = payment.StaffId;
                paymentReponse.RentalId = payment.RentalId;
                paymentReponse.Amount = payment.Amount;
                paymentReponse.Rental = payment.Rental.ToRentalResponse();
                paymentReponse.Staff = payment.Staff.ToStaffPaymentResponse();
                paymentReponseList.Add(paymentReponse);
            }

            return paymentReponseList;
        }
    }
}
