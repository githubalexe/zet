﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CustomerRepository : ICustomerRepository
    {
        private UnitOfWork _context;

        public CustomerRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Customer>> GetAllAsync(int storeId)
        {
            return await _context.Customer.Where(c => c.StoreId == storeId)
                                          .Include(a => a.Address)
                                          .ThenInclude(c => c.City)
                                          .ThenInclude(c => c.Country)
                                          .ToListAsync();
        }

        public async Task<Customer> GetAsync(int storeId, int customerId)
        {
            return await _context.Customer.Where(c => c.StoreId == storeId)
                                          .Include(a => a.Address)
                                          .ThenInclude(c => c.City)
                                          .ThenInclude(c => c.Country)
                                          .FirstOrDefaultAsync(c => c.CustomerId == customerId);
        }
    }
}
