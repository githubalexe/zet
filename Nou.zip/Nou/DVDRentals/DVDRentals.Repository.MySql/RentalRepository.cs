﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class RentalRepository : IRentalRepository
    {
        private UnitOfWork _context;
        public RentalRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Rental>> GetAllRentalsAsync(int id)
        {
            return await _context.Rental.Where(r => r.CustomerId == id)
                                        .Include(i => i.Inventory)
                                        .ThenInclude(f => f.Film)
                                        .ToListAsync();
        }
        public async Task<Rental> GetRentalAsync(int? rentalId)
        {
            return await _context.Rental.Include(i => i.Inventory)
                                        .ThenInclude(f => f.Film)
                                        .FirstOrDefaultAsync(r => r.RentalId == rentalId);
        }

    }
}
