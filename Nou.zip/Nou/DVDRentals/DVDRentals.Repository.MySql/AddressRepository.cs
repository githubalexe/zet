﻿using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository.MySql
{
    public class AddressRepository : IAddressRepository
    {
        private UnitOfWork _context;
        public AddressRepository(UnitOfWork context)
        {
            _context = context;
        }
        public void AddAddress(Address address)
        {
            _context.Address.Add(address);
        }
        public async Task<Address> GetAsync(int id)
        {
            return await _context.Address.Include(a=>a.City).ThenInclude(c=>c.Country)
                                         .FirstOrDefaultAsync(a => a.AddressId == id);
        }
    }
}
