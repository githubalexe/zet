﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class PaymentRepository : IPaymentRepository
    {
        private UnitOfWork _context;

        public PaymentRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<Payment> GetCustomerPayment(int customerId, int paymentId)
        {
            return await _context.Payment.Include(r=>r.Rental)
                                         .ThenInclude(i => i.Inventory)
                                         .ThenInclude(f=>f.Film)
                                         .Include(s => s.Staff)
                                         .FirstOrDefaultAsync(p => p.CustomerId == customerId && p.PaymentId == paymentId);
        }
        public async Task<Payment> GetStaffPayment(int staffId, int paymentId)
        {
            return await _context.Payment.Include("Rental")
                                         .Include("Customer")
                                         .Include("Staff")
                                         .FirstAsync(p => p.PaymentId == paymentId && p.StaffId == staffId);
        }
        public async Task<IEnumerable<Payment>> GetCustomerPayments(int customerId)
        {
            return await _context.Payment.Where(p => p.CustomerId == customerId)
                                         .Include(r => r.Rental)
                                         .ThenInclude(i => i.Inventory)
                                         .ThenInclude(f => f.Film)
                                         .Include(s => s.Staff)
                                         .ToListAsync();
        }
        public async Task<IEnumerable<Payment>> GetStaffPayments(int staffId)
        {
            return await _context.Payment.Where(p => p.StaffId == staffId)
                                         .Include("Customer")
                                         .Include("Staff")
                                         .Include("Rental")
                                         .ToListAsync();
        } 
    }
}
