﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class InventoryRepository : IInventoryRepository
    {
        private UnitOfWork _context;

        public InventoryRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Inventory>> GetAllFilmsAsync(int id)
        {
            return await _context.Inventory.Where(i => i.StoreId == id)
                                           .Include(f => f.Film)
                                           .ToListAsync();

        }
        public async Task<Inventory> GetFilmAsync(int storeId, int filmId)
        {
            return await _context.Inventory.Where(i => i.StoreId == storeId)
                                           .Include(f => f.Film)
                                           .FirstAsync(f => f.FilmId == filmId);
        }

        public async Task<Inventory> GetInventoryAsync(int inventoryId)
        {
            return await _context.Inventory.Include(f => f.Film)
                                           .FirstOrDefaultAsync(i => i.InventoryId == inventoryId);
        }
    }
}
