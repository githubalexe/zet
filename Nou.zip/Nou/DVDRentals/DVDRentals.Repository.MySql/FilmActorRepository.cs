﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;


namespace DVDRentals.Repository.MySql
{
    public class FilmActorRepository:IFilmActorRepository
    {
        private UnitOfWork _context;

        public FilmActorRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<List<FilmActor>> GetAllActorsAsync(int filmId)
        {
            return await _context.FilmActor.Where(f => f.FilmId == filmId).Include("Actor")
                                           .OrderBy(a => a.ActorId)
                                           .ToListAsync();
        }

        public async Task<FilmActor> GetOneActorAsync(int filmId, int actorId)
        {
            return await _context.FilmActor.Include("Actor")
                                           .FirstAsync(f => f.FilmId == filmId && f.ActorId == actorId);
        }
    }
}
