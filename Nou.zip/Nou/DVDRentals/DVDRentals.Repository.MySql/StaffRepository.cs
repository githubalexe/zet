﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class StaffRepository : IStaffRepository
    {
        private UnitOfWork _context;
        public StaffRepository(UnitOfWork context)
        {
            _context = context;
        }

        public void AddStaff(Staff staff)
        {
            _context.Add(staff);
        }

        public async Task<IEnumerable<Staff>> GetAllAsync(int storeId)
        {
            return await _context.Staff.Where(s => s.StoreId == storeId)
                                       .OrderBy(s => s.StaffId)
                                       .ToListAsync();
        }
        public async Task<Staff> GetAync(int storeId, int staffId)
        {
            return await _context.Staff.Where(s => s.StoreId == storeId)
                                       .FirstOrDefaultAsync(s => s.StaffId == staffId);
        }
    }
}
