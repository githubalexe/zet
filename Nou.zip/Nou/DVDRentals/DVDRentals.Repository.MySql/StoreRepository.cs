﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class StoreRepository : IStoreRepository
    {
        private UnitOfWork _context;
        public StoreRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<Store> GetAsync(int storeId)
        {
            return await _context.Store.FirstAsync(s => s.StoreId == storeId);
        }

        public async Task<IEnumerable<Store>> GetAllAsync()
        {
          return await _context.Store.OrderBy(s => s.StoreId)
                                     .ToListAsync();
        }
    }
}
