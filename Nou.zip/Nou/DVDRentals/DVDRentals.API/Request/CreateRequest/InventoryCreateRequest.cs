﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class InventoryCreateRequest
    {
        [Required(ErrorMessage = "FilmId is required.")]
        public int FilmId { get; set; }
        [Required(ErrorMessage = "StoreId is required.")]
        public int StoreId { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
