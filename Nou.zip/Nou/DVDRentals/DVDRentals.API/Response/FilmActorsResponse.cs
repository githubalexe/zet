﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    public class FilmActorsResponse
    {
        public int FilmId { get; set; }
        public string Title { get; set; }
        public virtual List<ActorResponse> FilmActors { get; set; }
    }
}

