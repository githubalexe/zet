﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    public class ActorResponse
    {
        public int ActorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
