﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    class FilmTextReponse
    {
    }
}
