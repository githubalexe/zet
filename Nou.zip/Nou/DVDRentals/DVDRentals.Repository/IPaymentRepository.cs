﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IPaymentRepository
    {
        Task<Payment> GetCustomerPayment(int customerId, int paymentId);
        Task<Payment> GetStaffPayment(int staffId, int paymentId);
        Task<IEnumerable<Payment>> GetCustomerPayments(int customerId);
        Task<IEnumerable<Payment>> GetStaffPayments(int staffId);
    }
}
