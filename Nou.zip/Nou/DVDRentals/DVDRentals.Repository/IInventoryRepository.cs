﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IInventoryRepository
    {
        Task<IEnumerable<Inventory>> GetAllFilmsAsync(int id);
        Task<Inventory> GetFilmAsync(int storeId, int filmId);
        Task<Inventory> GetInventoryAsync(int inventoryId);
    }
}
