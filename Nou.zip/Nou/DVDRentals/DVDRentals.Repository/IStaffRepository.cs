﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IStaffRepository
    {
        Task<IEnumerable<Staff>> GetAllAsync(int storeId);
        Task<Staff> GetAync(int storeId, int staffId);
        void AddStaff(Staff staff);
    }
}
