﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Models;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class FilmsController : Controller
    {
        private IFilmRepository _filmRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private ICategoryRepository _categoryRepository;
        private IActorRepository _actorRepository;
        private IFilmActorRepository _filmActorRepository;
        private IFilmCategoryDeleteServices _filmCategoryService;
        private IInventoryRepository _inventoryRepository;

        public FilmsController(IFilmRepository filmRepository, IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository, IActorRepository actorRepository, ICategoryRepository categoryRepository, IFilmCategoryDeleteServices filmCategoryService, IInventoryRepository inventoryRepository)
        {
            _filmRepository = filmRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _actorRepository = actorRepository;
            _filmActorRepository = filmActorRepository;
            _categoryRepository = categoryRepository;
            _filmCategoryService = filmCategoryService;
            _inventoryRepository = inventoryRepository;
        }
        [HttpGet("films")]
        public async Task<IActionResult> GetFilmsAsync()
        {
            ErrorValidation errorValidation = new ErrorValidation();
            IEnumerable<Film> filmList = await _filmRepository.GetFilmsAsync();
            List<FilmResponseLite> filmResponseList = new List<FilmResponseLite>();

            if (filmList.Count() == 0)
            {
                errorValidation.Message = Messages.InvalidFilmList.GetDescription();

                return BadRequest(errorValidation);
            }


            foreach (Film film in filmList)
            {
                IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmCategoriesAsync(film.FilmId);

                if (filmCategoryList == null)
                {
                    filmResponseList.Add(film.ToFilmResponseLite());
                }
                else
                {
                    List<CategoryResponse> categoryList = new List<CategoryResponse>();
                    foreach (FilmCategory filmCategory in filmCategoryList)
                    {
                        categoryList.Add(filmCategory.Category.ToCategoryResponse());
                    }

                    filmResponseList.Add(film.ToFilmResponseLite(categoryList));
                }
            }

            return Ok(filmResponseList);
        }

        [HttpGet("films/{filmId}", Name = "GetFilmAsync")]
        public async Task<IActionResult> GetFilmAsync(int filmId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmCategoriesAsync(filmId);

            if (filmCategoryList == null)
            {
                FilmResponseLite filmResponse = film.ToFilmResponseLite();

                return Ok(filmResponse);
            }
            else
            {
                List<CategoryResponse> categoryList = new List<CategoryResponse>();
                foreach (FilmCategory filmCategory in filmCategoryList)
                {
                    categoryList.Add(filmCategory.Category.ToCategoryResponse());
                }
                FilmResponseLite filmResponse = film.ToFilmResponseLite(categoryList);

                return Ok(filmResponse);
            }
        }

        [HttpPost("films")]
        public IActionResult CreateFilmAsync([FromBody]FilmCreateRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            Film film = request.ToFilmModel();
            _filmRepository.AddFilm(film);
            _filmRepository.SaveChanges();
            FilmResponse filmResponse = film.ToFilmResponse();

            return CreatedAtRoute("GetFilmAsync", new { filmId = film.FilmId }, filmResponse);
        }

        [HttpGet("films/{filmId}/actors")]
        public async Task<IActionResult> GetFilmActorsAsync(int filmId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetFilmsAsync(filmId);

            if (filmActorList.Count() == 0)
            {
                errorValidation.Message = Messages.InvalidActorList.GetDescription();

                return BadRequest(errorValidation);
            }

            List<ActorResponse> actorList = filmActorList.ToActorResponseList();
            FilmActorsResponseLite filmResponse = film.ToActorsResponse(actorList);

            return Ok(filmResponse);

        }

        [HttpGet("films/{filmId}/actors/{actorId}", Name = "GetFilmActorAsync")]
        public async Task<IActionResult> GetFilmActorAsync(int filmId, int actorId)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Film film = await _filmRepository.GetFilmAsync(filmId);
            FilmActor filmActor = await _filmActorRepository.GetFilmActorAsync(filmId, actorId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidActor.GetDescription();

                return BadRequest(errorValidation);
            }

            ActorResponse actorResponse = filmActor.Actor.ToActorResponse();
            FilmActorResponseLite filmResponse = film.ToActorResponseLite(actorResponse);

            return Ok(filmResponse);

        }

        [HttpGet("films/{filmId}/category/{categoryId}", Name = "GetFilmCategoryAsync")]
        public async Task<IActionResult> GetFilmCategoryAsync(int filmId, int categoryId)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Film film = await _filmRepository.GetFilmAsync(filmId);
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            if (category == null)
            {
                errorValidation.Message = Messages.InvalidCategory.GetDescription();

                return BadRequest(errorValidation);
            }

            FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(filmId, categoryId);
            FilmCategoryResponse filmCategoryResponse = filmCategory.ToFilmCategoryResponse();

            return Ok(filmCategoryResponse);
        }

        [HttpPost("filmCategories")]
        public async Task<IActionResult> AddFilmCategoryAsync([FromBody] FilmCategoryCreateRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            Film film = await _filmRepository.GetFilmAsync(request.FilmId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            Category category = await _categoryRepository.GetCategoryAsync(request.CategoryId);

            if (category == null)
            {
                errorValidation.Message = Messages.InvalidCategory.GetDescription();

                return BadRequest(errorValidation);
            }

            FilmCategory filmCategoryValidation = await _filmCategoryRepository.GetFilmCategoryAsync(request.FilmId, request.CategoryId);

            if (filmCategoryValidation != null)
            {
                errorValidation.Message = Messages.HasCategory.GetDescription();

                return BadRequest(errorValidation);
            }

            FilmCategory filmCategory = request.ToFilmCategoryModel();
            _filmCategoryRepository.AddFilmCategory(filmCategory);
            _filmCategoryRepository.SaveChanges();
            FilmCategoryResponse filmCategoryResponse = filmCategory.ToFilmCategoryResponse();

            return CreatedAtRoute("GetFilmCategoryAsync", new { filmId = film.FilmId, categoryId = category.CategoryId }, filmCategoryResponse);
        }

        [HttpPost("filmActors")]
        public async Task<IActionResult> AddFilmActorAsync([FromBody] FilmActorCreateRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Film film = await _filmRepository.GetFilmAsync(request.FilmId);
            Actor actor = await _actorRepository.GetActorAsync(request.ActorId);

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            if (actor == null)
            {
                errorValidation.Message = Messages.InvalidActor.GetDescription();

                return BadRequest(errorValidation);
            }

            FilmActor filmActorValidation = await _filmActorRepository.GetFilmActorAsync(request.FilmId, request.ActorId);

            if (filmActorValidation != null)
            {
                errorValidation.Message = Messages.HasActor.GetDescription();

                return BadRequest(errorValidation);
            }

            FilmActor filmActor = request.ToFilmActorModel();
            _filmActorRepository.AddFilmActor(filmActor);
            _filmActorRepository.SaveChanges();
            FilmActorResponse filmActorResponse = filmActor.ToFilmActorResponse();

            return CreatedAtRoute("GetFilmActorAsync", new { filmId = film.FilmId, actorId = actor.ActorId }, filmActorResponse);
        }

        [HttpDelete("films/{filmId}/filmActors/{actorId}")]
        public async Task<IActionResult> DeleteFilmActorAsync(int filmId, int actorId)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Film film = await _filmRepository.GetFilmAsync(filmId);
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            if (actor == null)
            {
                errorValidation.Message = Messages.InvalidActor.GetDescription();

                return BadRequest(errorValidation);
            }

            FilmActor filmActor = await _filmActorRepository.GetFilmActorAsync(filmId, actorId);
            if (filmActor == null)
            {
                errorValidation.Message = Messages.InvalidActorFilm.GetDescription();

                return BadRequest(errorValidation);
            }
            _filmActorRepository.DeleteFilmActor(filmActor);
            _filmActorRepository.SaveChanges();

            errorValidation.Message = Messages.DeleteFilmActor.GetDescription();

            return Ok(errorValidation);
        }

        [HttpPut("films/{filmId}")]
        public async Task<IActionResult> UpdateFilmAsync([FromBody]FilmUpdateRequest request, [FromRoute]int filmId)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            film = request.ToFilmModel(film);
            _filmRepository.UpdateFilm(film);
            _filmRepository.SaveChanges();
            FilmResponse filmResponse = film.ToFilmResponse();

            return Ok(filmResponse);
        }

        [HttpDelete("films/{filmId}")]
        public async Task<IActionResult> DeleteFilmAsync(int filmId)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorValidation.Message = Messages.InvalidFilm.GetDescription();

                return BadRequest(errorValidation);
            }

            int id = film.FilmId;
            await _filmCategoryService.DeleteFilmActorAsync(id);
            await _filmCategoryService.DeleteFilmCategoryAsync(id);
            await _filmCategoryService.DeleteFilmInventoryAsync(id);

            _filmRepository.DeleteFilm(film);

            _filmRepository.SaveChanges();

            errorValidation.Message = Messages.DeleteFilm.GetDescription();

            return Ok(errorValidation);
        }
    }
}