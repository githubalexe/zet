﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.DeleteRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Models;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class ActorsController : Controller
    {
        private IActorRepository _actorRepository;
        private IFilmActorService _filmActorService;
        public ActorsController(IActorRepository actorRepository, IFilmActorService filmActorService)
        {
            _actorRepository = actorRepository;
            _filmActorService = filmActorService;
        }

        [HttpGet("actors")]
        public async Task<IActionResult> GetActorsAsync()
        {
            ErrorValidation errorValidation = new ErrorValidation();
            IEnumerable<Actor> actorList = await _actorRepository.GetActorsAsync();

            if (actorList == null)
            {
                errorValidation.Message = Messages.InvalidActorList.GetDescription();

                return BadRequest(errorValidation);
            }

            List<ActorResponse> actorResposesList = actorList.ToActorResponseList();

            return Ok(actorResposesList);
        }

        [HttpGet("actors/{actorId}", Name = "GetActorsAsync")]
        public async Task<IActionResult> GetActorsAsync(int actorId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                errorValidation.Message = Messages.InvalidActor.GetDescription();

                return BadRequest(errorValidation);
            }

            ActorResponse actorResposes = actor.ToActorResponse();

            return Ok(actorResposes);
        }

        [HttpPost("actors")]
        public IActionResult CreateActorAsync([FromBody]ActorCreateRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            Actor actor = request.ToActorModel();
            _actorRepository.AddActor(actor);
            _actorRepository.SaveChanges();
            ActorResponse actorResponse = actor.ToActorResponse();

            return CreatedAtRoute("GetActorsAsync", new { actorId = actor.ActorId }, actorResponse);
        }

        [HttpPut("actors/{actorId}")]
        public async Task<IActionResult> UpdateActorAsync([FromBody]ActorUpdateRequest request, int actorId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                errorValidation.Message = Messages.InvalidActor.GetDescription();

                return BadRequest(errorValidation);
            }

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            actor = request.ToActorModel(actor);
            _actorRepository.UpdateActor(actor);
            _actorRepository.SaveChanges();
            ActorResponse actorResponse = actor.ToActorResponse();

            return Ok(actorResponse);
        }

        [HttpDelete("actors/{actorId}")]
        public async Task<IActionResult> DeleteActorAsync(int actorId)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                errorValidation.Message = Messages.InvalidActor.GetDescription();

                return BadRequest(errorValidation);
            }

            await _filmActorService.DeleteFilmActorAsync(actorId);
            _actorRepository.DeleteActor(actor);
            _actorRepository.SaveChanges();

            errorValidation.Message = Messages.DeleteActor.GetDescription();

            return Ok(errorValidation);
        }

        [HttpDelete("actors")]
        public async Task<IActionResult> DeleteActorsAsync([FromBody] ActorDeleteRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            foreach (string actorId in request.ActorIds)
            {
                int id = Int32.Parse(actorId);
                Actor actor = await _actorRepository.GetActorAsync(id);

                if (actor == null)
                {
                    errorList.Add("The actor with id " + actorId + " doesn't exist!");
                }
                else
                {
                    await _filmActorService.DeleteFilmActorAsync(id);
                    _actorRepository.DeleteActor(actor);
                }
            }

            if (errorList.Count != 0)
            {
                return BadRequest(errorList);
            }

            _actorRepository.SaveChanges();
            errorValidation.Message = Messages.DeleteActors.GetDescription();

            return Ok(errorValidation);
        }
    }
}