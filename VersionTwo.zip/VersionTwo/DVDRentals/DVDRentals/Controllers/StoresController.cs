﻿using System.Threading.Tasks;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Models;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StoresController : Controller
    {
        private IStoreRepository _storeRepository;
        private IStaffRepository _staffRepository;
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;

        public StoresController(IStoreRepository storeRepository, IStaffRepository staffRepository, IAddressRepository addressRepository, ICityRepository cityRepository, ICountryRepository countryRepository)
        {
            _storeRepository = storeRepository;
            _staffRepository = staffRepository;
            _addressRepository = addressRepository;
            _cityRepository = cityRepository;
            _countryRepository = countryRepository;
        }

        [HttpGet("stores/{storeId}")]
        public async Task<IActionResult> GetStoreAsync(int storeId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }
            Address address = await _addressRepository.GetAddressAsync(store.AddressId);
            City city = await _cityRepository.GetCityAsync(address.CityId);
            Country country = await _countryRepository.GetCountryAsync(city.CountryId);
            StoreResponseLite storeResponse = store.ToStoreResponseLite(address, city, country);

            return Ok(storeResponse);
        }

        [HttpPut("stores/{storeId}")]
        public async Task<IActionResult> UpdateStoreAsync([FromBody] StoreUpdateRequest request, int storeId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            Staff staff = await _staffRepository.GetStaffAync(storeId, request.ManagerStaffId);

            if (staff == null)
            {
                errorValidation.Message = Messages.InvalidStaff.GetDescription();

                return BadRequest(errorValidation);
            }

            Address address = await _addressRepository.GetAddressAsync(request.AddressId);

            if (address == null)
            {
                errorValidation.Message = Messages.InvalidAddress.GetDescription();

                return BadRequest(errorValidation);
            }

            store = request.ToStoreModel(store);
            _storeRepository.UpdateStore(store);
            _storeRepository.SaveChanges();
            StoreResponse storeResponse = store.ToStoreResponse();

            return Ok(storeResponse);
        }
    }
}