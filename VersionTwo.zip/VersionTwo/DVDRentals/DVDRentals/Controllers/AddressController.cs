﻿using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Address;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Models;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class AddressController : Controller
    {
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;

        public AddressController(IAddressRepository addressRepository, ICityRepository cityRepository)
        {
            _addressRepository = addressRepository;
            _cityRepository = cityRepository;
        }

        [HttpGet("address/{addressId}", Name = "GetAddressAsync")]
        public async Task<IActionResult> GetAddressAsync(int addressId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if(address==null)
            {
                errorValidation.Message = Messages.InvalidAddress.GetDescription();

                return BadRequest(errorValidation);
            }
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }

        [HttpPost("address")]
        public async Task<IActionResult> CreateAddress([FromBody] AddressCreateRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            bool city = await _cityRepository.GetCityValidAsync(request.CityId);

            if(city==false)
            {
                errorValidation.Message = Messages.InvalidCity.GetDescription();

                return BadRequest(errorValidation);
            }

            Address address = request.ToAddressModel();
            _addressRepository.AddAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return CreatedAtRoute("GetAddressAsync", new { addressId = address.AddressId }, addressResponse);
        }

        [HttpPut("address/{addressId}")]
        public async Task<IActionResult> UpdateAddress([FromBody] AddressUpdateRequest request, int addressId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Address address = await _addressRepository.GetAddressAsync(addressId);
            bool city = await _cityRepository.GetCityValidAsync(request.CityId);

            if (address == null)
            {
                errorValidation.Message = Messages.InvalidAddress.GetDescription();

                return BadRequest(errorValidation);
            }

            if (city == false)
            {
                errorValidation.Message = Messages.InvalidCity.GetDescription();

                return BadRequest(errorValidation);
            }

            address = request.ToAddressModel(address);
            _addressRepository.UpdateAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }

        [HttpDelete("address/{addressId}")]
        public async Task<IActionResult> DeleteAddress(int addressId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address == null)
            {
                errorValidation.Message = Messages.InvalidAddress.GetDescription();

                return BadRequest(errorValidation);
            }

            _addressRepository.DeleteAddress(address);
            _addressRepository.SaveChanges();

            return Ok("The address has been deleted!");

        }
    }
}
//cannot delete an address that someone has