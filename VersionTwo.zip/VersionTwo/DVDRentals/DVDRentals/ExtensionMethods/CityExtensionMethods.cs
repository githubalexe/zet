﻿using DVDRentals.API.Response;
using DVDRentals.API.Response.City;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CityExtensionMethods
    {
        public static CityResponse ToCityResponse(this City city, Country country)
        {
            CityResponse cityResponse = new CityResponse()
            {
                CityId = city.CityId,
                CountryId = city.CountryId,
                City1 = city.City1,
                Country = country.ToCountryResponse(),
                LastUpdate = city.LastUpdate
            };

            return cityResponse;
        }
    }
}
