﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerResponseLite ToCustomerResponseLite(this Customer customer, Address address, City city, Country country)
        {
            CustomerResponseLite customerResponse = new CustomerResponseLite()
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                Address = address.ToAddressResponseLite(city, country),
                LastUpdate = customer.LastUpdate
            };

            return customerResponse;
        }

        public static Customer ToCustomerModel(this CustomerCreateRequest request, int storeId)
        {
            Customer customer = new Customer()
            {
                StoreId = storeId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                AddressId = request.AddressId,
                Active = request.Active,
                CreateDate = request.CreateDate
            };

            return customer;
        }
        public static Customer ToCustomerModel(this CustomerUpdateRequest request, Customer customer, int storeId)
        {
            customer.StoreId = storeId;
            customer.FirstName = request.FirstName;
            customer.LastName = request.LastName;
            customer.Email = request.Email;
            customer.AddressId = request.AddressId;
            customer.Active = request.Active;
            customer.CreateDate = request.CreateDate;

            return customer;
        }
        public static CustomerResponse ToCustomerResponse(this Customer customer)
        {
            CustomerResponse customerResponse = new CustomerResponse()
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                LastUpdate = customer.LastUpdate
            };

            return customerResponse;
        }
        public static CustomerPaymentResponse ToCustomerPaymentResponse(this Customer customer)
        {
            CustomerPaymentResponse customerPaymentResponse = new CustomerPaymentResponse()
            {
                CustomerId = customer.CustomerId,
                FirstName = customer.FirstName,
                LastName = customer.LastName
            };

            return customerPaymentResponse;
        }
        public static CostomerPaymentsResponse ToCustomerPaymentsResponse(this Customer customer)
        {
            CostomerPaymentsResponse customerResponse = new CostomerPaymentsResponse()
            {
                CustomerId = customer.CustomerId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
            };

            return customerResponse;
        }
        public static CostomerPaymentsResponse ToCustomerPaymentListResponse(this Customer customer, List<PaymentForCustomerResponse> paymentResponseList)
        {
            CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentsResponse();
            customerResponse.Payments = paymentResponseList;

            return customerResponse;
        }
        //public static CustomerResponse ToCustomerResponse(this Customer customer, Address address)
        //{
        //    CustomerResponse customerResponse = new CustomerResponse
        //    {
        //        Active = customer.Active,
        //        Address = new AddressResponse
        //        {
        //            City = new CityResponse
        //            {
        //                Country = new CountryResponse
        //                {
        //                    Country1 = address.City.Country.Country1
        //                }
        //            }
        //        }
        //    };

        //    return customerResponse;
        //}
    }
}
