﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Models
{
    public enum Messages
    {
        [Description("The customer doesn't exist!")]
        InvalidCustomer,
        [Description("The customer has been deleted!")]
        DeleteCustomer,
        [Description("The customers have been deleted!")]
        DeleteCustomers,
        [Description("The staff doesn't exist!")]
        InvalidStaff,
        [Description("The staff has been deleted!")]
        DeleteStaff,
        [Description("The request object is empty!")]
        InvalidRequest,
        [Description("The store doesn't exist!")]
        InvalidStore,
        [Description("The customer payments list object is empty!")]
        InvalidCustomerPayments,
        [Description("The customer payment doesn't exist!")]
        InvalidCustomerPayment,
        [Description("The customer list is empty!")]
        InvalidCustomerList,
        [Description("The actor list is empty!")]
        InvalidActorList,
        [Description("The actor doesn't exist!")]
        InvalidActor,
        [Description("The actor has been deleted!")]
        DeleteActor,
        [Description("The actors have been deleted!")]
        DeleteActors,
        [Description("The category doesn't exist!")]
        InvalidCategory,
        [Description("The category list is empty!")]
        InvalidCategoryList,
        [Description("Neither a film doesn't contain this category!")]
        InvalidFilmCategoryList,
        [Description("The category has been deleted!")]
        DeleteCategory,
        [Description("The categories have been deleted!")]
        DeleteCategories,
        [Description("The rental doesn't exist!")]
        InvalidRental,
        [Description("The rental has been deleted!")]
        DeleteRental,
        [Description("The inventory list is empty!")]
        InvalidInventoryList,
        [Description("The film doesn't exist!")]
        InvalidFilm,
        [Description("The inventory doesn't exist!")]
        InvalidInventory,
        [Description("The inventory has been deleted!")]
        DeleteInventory,
        [Description("The address doesn't exist!")]
        InvalidAddress,
        [Description("The staff list is empty!")]
        InvalidStaffList,
        [Description("The staff payments list object is empty!")]
        InvalidStaffPayments,
        [Description("The staff payment doesn't exist!")]
        InvalidStaffPayment,
        [Description("You cannot delete a staff if it is a manager!")]
        DeleteManager,
        [Description("The store payments list object is empty!")]
        InvalidStorePayments,
        [Description("The store payment doesn't exist!")]
        InvalidStorePayment,
        [Description("The payment doesn't exist!")]
        InvalidPayment,
        [Description("The payment has been deleted!")]
        DeletePayment,
        [Description("The city doesn't exist!")]
        InvalidCity,
        [Description("The film list is empty!")]
        InvalidFilmList,
        [Description("The film already has this category!")]
        HasCategory,
        [Description("The film already has this actor!")]
        HasActor,
        [Description("The actor doesn't exist in this film!")]
        InvalidActorFilm,
        [Description("The film has been deleted!")]
        DeleteFilm,
        [Description("The actor has been deleted from film!")]
        DeleteFilmActor,
        [Description("The list is empty!")]
        FilmInventoryList,
    }
}