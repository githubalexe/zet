﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class FilmCategoryService: IFilmCategoryService
    {
        private IFilmCategoryRepository _filmCategoryRepository;

        public FilmCategoryService(IFilmCategoryRepository filmCategoryRepository)
        {
            _filmCategoryRepository = filmCategoryRepository;
        }

        public async Task DeleteFilmCategoryAsync(int categoryId)
        {
            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmsCategoryAsync(categoryId);

            if(filmCategoryList!=null)
            {
                foreach (FilmCategory filmCategory in filmCategoryList)
                {
                    _filmCategoryRepository.DeleteFilmCategory(filmCategory);
                }
            }
        }
    }
}
