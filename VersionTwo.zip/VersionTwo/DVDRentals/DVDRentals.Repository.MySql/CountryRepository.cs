﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CountryRepository : ICountryRepository
    {
        private UnitOfWork _context;
        public CountryRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<Country> GetCountryAsync(int id)
        {
            return await _context.Country.FirstAsync(c => c.CountryId == id);
        }
    }
}
