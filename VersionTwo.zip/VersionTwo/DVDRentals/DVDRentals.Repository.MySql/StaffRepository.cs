﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class StaffRepository : IStaffRepository
    {
        private UnitOfWork _context;
        public StaffRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Staff>> GetStaffsAsync(int storeId)
        {
            return await _context.Staff.Where(s => s.StoreId == storeId)
                                       .Include(a => a.Address)
                                       .ThenInclude(c => c.City)
                                       .ThenInclude(c => c.Country)
                                       .ToListAsync();
        }
        public async Task<Staff> GetStaffAync(int storeId, int staffId)
        {
            return await _context.Staff.Where(s => s.StoreId == storeId)
                                       .Include(a => a.Address)
                                       .ThenInclude(c => c.City)
                                       .ThenInclude(c => c.Country)
                                       .FirstOrDefaultAsync(s => s.StaffId == staffId);
        }
        public async Task<Staff> GetStaffAync(int staffId)
        {
            return await _context.Staff.FirstOrDefaultAsync(s => s.StaffId == staffId);
        }
        public async Task<bool> GetStaffValidationAync(int staffId)
        {
            return await _context.Staff.AnyAsync(s => s.StaffId == staffId);
        }

        public void AddStaff(Staff staff)
        {
            _context.Add(staff);
        }

        public void UpdateStaff(Staff staff)
        {
            _context.Update(staff);
        }

        public void DeleteStaff(Staff staff)
        {
            _context.Remove(staff);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
