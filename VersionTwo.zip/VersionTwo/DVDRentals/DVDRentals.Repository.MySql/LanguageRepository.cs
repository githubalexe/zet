﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class LanguageRepository : ILanguageRepository
    {
        private UnitOfWork _context;
        public LanguageRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<Language> GetAsync(int languageId)
        {
            return await _context.Language.FirstAsync(l => l.LanguageId == languageId);
        }
    }
}
