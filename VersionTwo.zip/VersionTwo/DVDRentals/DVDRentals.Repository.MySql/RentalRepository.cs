﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class RentalRepository : IRentalRepository
    {
        private UnitOfWork _context;
        public RentalRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Rental>> GetAllRentalsAsync(int id)
        {
            return await _context.Rental.Where(r => r.CustomerId == id)
                                        .Include(i => i.Inventory)
                                        .ThenInclude(f => f.Film)
                                        .ToListAsync();
        }
        public async Task<Rental> GetRentalAsync(int? rentalId)
        {
            return await _context.Rental.Include(i => i.Inventory)
                                        .ThenInclude(f => f.Film)
                                        .FirstOrDefaultAsync(r => r.RentalId == rentalId);
        }
        public async Task<bool> GetRentalValidationAsync(int? rentalId)
        {
            return await _context.Rental.AnyAsync(r => r.RentalId == rentalId);
        }
        public async Task<IEnumerable<Rental>> GetInventoryRentalsAsync(int inventoryId)
        {
            return await _context.Rental.Where(r => r.InventoryId == inventoryId)
                                        .ToListAsync();
        }
        public async Task<IEnumerable<Rental>> GetCustomerRentalsAsync(int customerId)
        {
            return await _context.Rental.Where(r => r.CustomerId == customerId)
                                        .ToListAsync();
        }
        public async Task<IEnumerable<Rental>> GetStaffRentalsAsync(int staffId)
        {
            return await _context.Rental.Where(r => r.StaffId == staffId)
                                        .ToListAsync();
        }
        public void AddRental(Rental rental)
        {
            _context.Rental.Add(rental);
        }

        public void UpdateRental(Rental rental)
        {
            _context.Rental.Update(rental);
        }

        public void DeleteRental(Rental rental)
        {
            _context.Rental.Remove(rental);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
