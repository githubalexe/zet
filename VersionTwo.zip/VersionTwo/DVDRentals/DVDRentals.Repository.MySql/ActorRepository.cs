﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class ActorRepository : IActorRepository
    {
        private UnitOfWork _context;

        public ActorRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Actor>> GetActorsAsync()
        {
            return await _context.Actor.ToListAsync();
        }
        public async Task<IEnumerable<Actor>> GetActorsAsync(int actorId)
        {
            return await _context.Actor.Where(a => a.ActorId == actorId)
                                       .ToListAsync();
        }
        public async Task<Actor> GetActorAsync(int actorId)
        {
            return await _context.Actor.FirstOrDefaultAsync(a => a.ActorId == actorId);
        }
        public void AddActor(Actor actor)
        {
            _context.Actor.Add(actor);
        }

        public void UpdateActor(Actor actor)
        {
            _context.Actor.Update(actor);
        }

        public void DeleteActor(Actor actor)
        {
            _context.Actor.Remove(actor);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
