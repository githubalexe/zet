﻿using DVDRentals.API.Response.Payment;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    public class StaffPaymentsResponse
    {
        public int StaffId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public virtual List<PaymentForStaffResponse> Payments { get; set; }
        
    }
}
