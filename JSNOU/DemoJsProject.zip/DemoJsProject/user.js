class User {
    constructor(firstName, lastName, gender, birthDate, image, role) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.birthDate = birthDate;
        this.image = image;
        this.role = role;
    }

    static validateFirstName(firstNameArg) {
        return _commonRulesValidationForName(firstNameArg);
    };

    static validateLasttName(lastNameArg) {
        return _commonRulesValidationForName(lastNameArg);
    };

    static _commonRulesValidationForName (name){
        var errorMessage = "";
        
        if (firstNameArg.length < 3)
            errorMessage = "error message";

        return errorMessage;
    }

    displayUser() {
        console.log(this.firstName, this.lastName);
    }

    getAllValidationErrors() {
        var errorMessages = [];
        var errorMessage = "";
        //1. validate firstname
        errorMessage = User.validateFirstName(this.firstName);
        if(errorMessage){
            errorMessages.push(errorMessage);
            errorMessage = "";
        }
        
        //2. validate lastname
        errorMessage = User.validateFirstName(this.lastName);
        if(errorMessage){
            errorMessages.push(errorMessage);
            errorMessage = "";
        }
        ////......////

        return errorMessages;
    }
}