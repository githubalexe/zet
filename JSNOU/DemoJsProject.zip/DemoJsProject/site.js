(function () {
    var firstName = document.getElementById("firstName");
    var firstNameErrorMessageElement = document.getElementById("firstNameErrorMessage");
    var allErrors = document.getElementById("allErrors");

    var lastName = document.getElementById("lastName");
    //...........//....rest of them

    //validate firstName
    firstName.addEventListener("focusout", function(){
        var erroMessage = User.validateFirstName(firstName.value);
        console.log(erroMessage);
        if(erroMessage)
            firstNameErrorMessageElement.innerHTML= erroMessage;
            else
            firstNameErrorMessageElement.innerHTML= "";
    });

   
    buttonSave.addEventListener("click", function() {
        
        var user = new User({
           firstName: firstName.value,
           lastName: lastName.value
        });

        var errorMessages = user.getAllValidationErrors();
        
        if(errorMessages.length > 0){
            allErrors.innerHTML = errorMessages[0];
        } else {
            user.displayUser();
            alert("User saved in console log");
        }

    });

})();
