class User {
    constructor(firstName, lastName,gender,birthDate,image, role) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.gender=gender;
    this.birthDate=birthDate;
    this.image=image;
    this.role = role;
    }
}

var gender;
function check(answer) 
{
    gender=answer;
}

function displayUser() 
{
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var birthDate = document.getElementById("birthDate").value;
    if(document.getElementById('fileDisplayArea').children[0]!=null)
    {
        var image = document.getElementById("fileInput").files[0].name;
    }
    var role = document.getElementById("role").value;
    if(checkMessages()==true)
    {
        var user = new User(firstName, lastName,gender,birthDate,image,role);
        console.log(user);
    }
}

function checkMessages ()
{
    var ok=true;
    var firstName = document.getElementById("firstNameMessage").innerHTML;
    var lastName =document.getElementById("lastNameMessage").innerHTML;
    var birthDate = document.getElementById("birthDateMessage").innerHTML;
    var image =document.getElementById("pictureMessage").innerHTML;
    var role =document.getElementById("roleMessage").innerHTML;
    var gender=document.getElementById("genderMessage").innerHTML;
    var listOfId=[firstName,lastName,birthDate,image,role,gender];
    for(var i=0;i<listOfId.length;i++)
    {
        if(listOfId[i]!="")
        ok=false;
    }
    return ok;
}