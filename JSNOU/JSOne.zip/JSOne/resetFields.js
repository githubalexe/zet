function resetFields() {

    if (confirm('Are you sure you want to cancel?'))
    {
        document.getElementById("firstName").value="";
        document.getElementById("lastName").value="";
        document.getElementById("birthDate").value="";
        document.getElementById("role").value="";
        document.getElementById("fileInput").value="";
        document.getElementById("male").checked=false;
        document.getElementById("female").checked=false;
        document.getElementById("firstNameMessage").innerHTML ="";
        document.getElementById("lastNameMessage").innerHTML="";
        document.getElementById("birthDateMessage").innerHTML="";
        document.getElementById("roleMessage").innerHTML="";
        document.getElementById("pictureMessage").innerHTML="";
        document.getElementById("genderMessage").innerHTML="";
        document.getElementById("fileDisplayArea").innerHTML="";
        document.getElementById('pictureContainer').style.display="table";
    
        if(document.getElementById('fileDisplayArea').children[0]!=null)
        {
            document.getElementById('fileDisplayArea').children[0].remove();
        }
    } 


}

function formValidation() 
{
    firstNameMethod();
    lastNameMethod();
    birthDateMethod();
    genderMethod();
    roleMethod();
    fileInputMethod();   
}

function firstNameMethod()
{
    var firstName=document.getElementById("firstName").value;
    if(firstName=="")
    {
        document.getElementById("firstNameMessage").innerHTML ="First Name is required!";   
    }
    if(firstName!="")
    {
        caracters(firstName,"firstNameMessage",30);
    }
}

function lastNameMethod()
{
    var lastName=document.getElementById("lastName").value;
    if(lastName=="")
    {
        document.getElementById("lastNameMessage").innerHTML="Last Name is required!";
    }
    if(lastName!="")
    {
        caracters(lastName,"lastNameMessage",50);
    }
}

function birthDateMethod()
{
    var birthDate=document.getElementById("birthDate").value;
    if(birthDate=="")
    {
        document.getElementById("birthDateMessage").innerHTML="Birth Date is required!";
    }
    else  if(birthDate!="")
    {
        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth()+1;
        var yyyy = today.getFullYear();
        if(dd<10) {
        dd = '0'+dd
        } 
        if(mm<10) {
        mm = '0'+mm
        } 
        today = mm + '/' + dd + '/' + yyyy;
        var birthYear = new Date(birthDate);
        var year = birthYear.getFullYear();
        var difference=yyyy-year;
        if(difference<=18)
        {
            document.getElementById("birthDateMessage").innerHTML="The minimum age is 18 years!";
        }
        else
        if(difference>=45)
        {
            document.getElementById("birthDateMessage").innerHTML="The maximum age is 45 years!";
        }
        else
        if(difference>=18 &&difference<=45)
        {
            document.getElementById("birthDateMessage").innerHTML="";
        }
    }
}

function genderMethod()
{
    if(document.getElementById("male").checked==false && document.getElementById("female").checked==false)
    {
        document.getElementById("genderMessage").innerHTML="Select a gender!";
    }
    else
    {
        document.getElementById("genderMessage").innerHTML="";
    }
}

function roleMethod()
{
    var role=document.getElementById("role").value;
    if(role=="")
    {
        document.getElementById("roleMessage").innerHTML="Role is required!";
    }
    else
    {
        document.getElementById("roleMessage").innerHTML="";
    }
}

function fileInputMethod()
{
    var fileInput=document.getElementById("fileInput").value;
    if(fileInput=="")
    {
        document.getElementById("pictureMessage").innerHTML="Image is required!";
    }
    else
    {
        document.getElementById("pictureMessage").innerHTML="";
    }
}

function caracters(id,message,len)
{
    var str=id.length;
    var ch=String(id);
    if(str!=0)
    {
        if((/[0-9]/.test(ch)))
        {
            document.getElementById(message).innerHTML="Only alpha characters are allowed!";
        }
        else
        if(str<=2)
        {
            document.getElementById(message).innerHTML ="Minimum required characters is 3!";
        }
        else
        if(str>=len)
        {
            document.getElementById(message).innerHTML="Maximum allowed characters is "+len+"!";
        }
        else
        if(str>=2 && str<len && !(/[0-9]/.test(ch)) )
        {
            document.getElementById(message).innerHTML="";
        }

    }
}

function clearText()
{
    if(document.getElementById("fileInput").value!="")
    {
        document.getElementById('pictureContainer').style.display="none";
    }

}

function sizeValidation(file) {
    var _validFileExtensions = [".png", ".jpg", ".jpeg", ".bmp"];
    if (file.type == "file") {
        var sFileName = file.value;
         if (sFileName.length > 0) {
            var blnValid = false;
            for (var j = 0; j < _validFileExtensions.length; j++) {
                var sCurExtension = _validFileExtensions[j];
                if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                    blnValid = true;
                    break;
                }
            }
            if (!blnValid) {
                document.getElementById("pictureMessage").innerHTML="Supported extensions are .png, .jpg, .jpeg, .bmp!";
                oInput.value = "";
                return false;
            }
        }
    }

    if (file.files[0].size > 50*1024) {
        document.getElementById("fileDisplayArea").innerHTML="";
        document.getElementById("pictureMessage").innerHTML="Maximum required is 50 Kb!";
        document.getElementById("fileInput").value="";
        document.getElementById('pictureContainer').style.display="table";
    } 
}