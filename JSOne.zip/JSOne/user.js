class User {
    constructor(options) {
        this.firstName = options.firstName;
        this.lastName = options.lastName;
        this.gender = options.gender;
        this.birthDate = options.birthDate;
        this.role = options.role;
        this.fileInput = options.fileInput;
    }

    displayUser() {
        console.log(this.firstName, this.lastName, this.gender, this.birthDate, this.role, this.fileInput);
    }

    getAllValidationErrors() {
        var errorMessages = [];
        var contor = 0;
        var errorMessage = "";

        errorMessage = User.validateFirstName(this.firstName, 30);

        if (errorMessage !== "") {
            errorMessages[contor] = errorMessage;
            contor++;
            errorMessage = "";

        }
        errorMessage = User.validateLastName(this.lastName, 30);

        if (errorMessage !== "") {
            errorMessages[contor] = errorMessage;
            contor++;
            errorMessage = "";
        }

        errorMessage = User.validateBirthDate(this.birthDate);

        if (errorMessage !== "") {
            errorMessages[contor] = errorMessage;
            contor++;
            errorMessage = "";
        }

        errorMessage = User.validateRole(this.role);

        if (errorMessage !== "") {
            errorMessages[contor] = errorMessage;
            contor++;
            errorMessage = "";
        }
        errorMessage = User.validateGender(this.gender,this.gender);

        if (errorMessage !== "") {
            errorMessages[contor] = errorMessage;
            contor++;
            errorMessage = "";
        }
        errorMessage = User.validatefilleInput(this.image);

        if (errorMessage !== "") {
            errorMessages[contor] = errorMessage;
            contor++;
            errorMessage = "";
        }
     
        return errorMessages;
    }

    static validateFirstName(nameArg, len) {
        return User._commonRulesValidationForName(nameArg, len);
    }
    static validateLastName(nameArg, len) {
        return User._commonRulesValidationForName(nameArg, len);
    }
    static _commonRulesValidationForName(name, len) {
        var errorMessage = "";
        var str;
        if (name === "") {
            str = 0;
        }
        else {
            str = name.length;
        }

        var ch = String(name);

        if ((/[0-9]/.test(ch))) {
            errorMessage = "Only alpha characters are allowed!";
        }
        else
            if (str <= 2) {
                errorMessage = "Minimum required characters is 3!";
            }
            else
                if (str >= len) {
                    errorMessage = "Maximum allowed characters is " + len + "!";
                }
                else
                    if (str >= 2 && str < len && !(/[0-9]/.test(ch))) {
                        errorMessage = "";
                    }

        return errorMessage;
    }
    static validateBirthDate(birthDateArg) {

        var errorMessage = "";
        if (birthDateArg == "") {
            var errorMessage = "Birth Date is required!";
        }
        else if (birthDateArg != "") {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1;
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = '0' + dd
            }
            if (mm < 10) {
                mm = '0' + mm
            }
            today = mm + '/' + dd + '/' + yyyy;
            var birthYear = new Date(birthDateArg);
            var year = birthYear.getFullYear();
            var difference = yyyy - year;
            if (difference <= 18) {
                errorMessage = "The minimum age is 18 years!";
            }
            else
                if (difference >= 45) {
                    errorMessage = "The maximum age is 45 years!";
                }
                else
                    if (difference >= 18 && difference <= 45) {
                        errorMessage = "";
                    }
        }
        return errorMessage;
    }

    static validateGender(genderArg) {
    
        var errorMessage = "";
        if (genderArg.checked === false ) {
            errorMessage = "Select a gender!";
        }
        else {
            errorMessage = "";
        }
        return errorMessage;
    }
    static validateRole(roleArg) {
        var errorMessage = "";
        if (roleArg == "") {
            errorMessage = "Role is required!";
        }
        else {
            errorMessage = "";
        }

        return errorMessage;
    }
    static validatefilleInput(fileInputArg) {
        var errorMessage = "";
        if (fileInputArg == "") {
            errorMessage = "Image is required!";
        }
        else {
            errorMessage = "";
        }

        return errorMessage;
    }

}