
    class User {
        constructor(firstName, lastName,birthDate,image, role) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.birthDate=birthDate;
            this.image=image;
            this.role = role;
        }
    }

    function displayUser() {
        var firstName = document.getElementById("firstName").value;
        var lastName = document.getElementById("lastName").value;
        var birthDate=document.getElementById("birthDate").value;
        var image =document.getElementById("fileInput").value;
        var role = document.getElementById("role").value;

        var user = new User(firstName, lastName,birthDate,image,role);
        console.log(user);
    }
