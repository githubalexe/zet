(function () {
    var firstName = document.getElementById("firstName");
    var lastName = document.getElementById("lastName");
    var role = document.getElementById("role");
    var fileInput = document.getElementById("fileInput");
    var male = document.getElementById("male");
    var female = document.getElementById("female");
    var fileDisplayArea = document.getElementById("fileDisplayArea");
    var pictureContainer = document.getElementById("pictureContainer");
    var firstNameErrorMessage = document.getElementById("firstNameMessage");
    var genderErrorMessage = document.getElementById("genderMessage");
    var lastNameErrorMessage = document.getElementById("lastNameMessage");
    var birthDateErrorMessage = document.getElementById("birthDateMessage");
    var roleErrorMessage = document.getElementById("roleMessage");
    var pictureErrorMessage = document.getElementById("pictureMessage");
    var saveButton = document.getElementById("save");
    var cancelButton = document.getElementById("cancel");
    var gender = document.querySelector('input[name="genderS"]:checked');

    firstName.addEventListener("focusout", function () {
        setFirstNameError();
    });

    lastName.addEventListener("focusout", function () {
        setLastNameMessage();
    });
    role.addEventListener("focusout", function () {
        setRoleMessage();
    });

    birthDate.addEventListener("focusout", function () {
        setBirthDateMessage();
    });

    male.addEventListener("focusout", function () {
        setGenderMessage();
    });

    female.addEventListener("focusout", function () {
        setGenderMessage();
    });

    fileInput.addEventListener("focusout", function () {
        setFileInputMessage();
    });

    function setFirstNameError() {
        var errorMessage = User.validateFirstName(firstName.value, 30);
        firstNameErrorMessage.innerHTML = errorMessage;
    }
    function setLastNameMessage() {
        var errorMessage = User.validateLastName(lastName.value, 50);
        lastNameErrorMessage.innerHTML = errorMessage;
    }
    function setRoleMessage() {
        var errorMessage = User.validateRole(role.value);
        roleErrorMessage.innerHTML = errorMessage;
    }
    function setBirthDateMessage() {
        var errorMessage = User.validateBirthDate(birthDate.value);
        birthDateErrorMessage.innerHTML = errorMessage;
    }
    function setGenderMessage() {
        errorMessage = User.validateGender(male.value);
        genderErrorMessage.innerHTML = errorMessage;
    }
    function setFileInputMessage() {
        var errorMessage = User.validatefilleInput(fileInput.value);
        pictureErrorMessage.innerHTML = errorMessage;
    }
   
    saveButton.addEventListener("click", function () {
        setFirstNameError();
        setLastNameMessage();
        setGenderMessage();
        setBirthDateMessage();
        setRoleMessage();
        setFileInputMessage();
        
        var options = {
            firstName: firstName.value,
            lastName: lastName.value,
            gender: gender.value,
            birthDate: birthDate.value,
            role: role.value,
            fileInput: fileInput.value
        };
        var user = new User(options);
        user.displayUser();
       var errorMessages = user.getAllValidationErrors();


       
         console.log("errorMessages", errorMessages);

        if (errorMessages.length > 0) {
            alert("Complete all the fields!");
        } else {
            user.displayUser();
         alert("User saved in console log");
         }
    });
    cancelButton.addEventListener("click", function () {
        firstName.value = "";
        lastName.value = "";
        birthDate.value = "";
        role.value = "";
        fileInput.value = "";
        male.checked = false;
        female.checked = false;
        pictureContainer.style.display = "table";
        if (fileDisplayArea.children[0] != null) {
            fileDisplayArea.children[0].remove();
        }
    });

})();
