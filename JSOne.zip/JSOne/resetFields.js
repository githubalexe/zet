function resetFields() {
    document.getElementById("firstName").value="";
    document.getElementById("lastName").value="";
    document.getElementById("birthDate").value="";
    document.getElementById("role").value="";
    document.getElementById("fileInput").value="";
    document.getElementById('fileDisplayArea').children[0].remove();
}

function validateForm() {
    var firstName=document.getElementById("firstName").value;
    var lastName=document.getElementById("lastName").value;
    var birthDate=document.getElementById("birthDate").value;
    var role=document.getElementById("role").value;
    var fileInput=document.getElementById("fileInput").value;
    s
    if(firstName=="")
    {
        alert("First Name must be filled out!")
    }
    if(lastName=="")
    {
        alert("Last Name must be filled out!")
    }
    if(birthDate=="")
    {
        alert("Birth Date must be filled out!")
    }

    if(role=="")
    {
        alert("Role must be filled out!")
    }
    if(fileInput=="")
    {
        alert("Image must be filled out!")
    }
}