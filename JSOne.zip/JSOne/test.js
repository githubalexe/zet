function User(name){

    this.firstName = firstName;
    this.lastName = lastName;
    this.birthDate=birthDate;
    this.image=image;
    this.role = role;
}

User.prototype.GetName = function(){
    return this.firstName;    
}

User.prototype.GetName = function(){
    return this.lastName;    
}
User.prototype.GetName = function(){
    return this.birthDate;    
}
User.prototype.GetName = function(){
    return this.image;    
}
User.prototype.GetName = function(){
    return this.role;    
}

function displayUser() {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var birthDate=document.getElementById("birthDate").value;
    var image =document.getElementById("fileInput").value;
    var role = document.getElementById("role").value;

    var user = new User(firstName, lastName,birthDate,image,role);
    console.log(user);
}
