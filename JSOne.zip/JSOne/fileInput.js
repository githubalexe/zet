window.onload = function() {

    var fileInput = document.getElementById('fileInput');
    var fileDisplayArea = document.getElementById('fileDisplayArea');
    var pictureContainer = document.getElementById("pictureContainer");

    fileInput.addEventListener('change', function(e) {
        var file = fileInput.files[0];
        var imageType = /image.*/;
        validateExtensions(file);
        sizeValidation(file);

            if(sizeValidation(file)===true)
            {
                if (file.type.match(imageType)) {
     
                    var reader = new FileReader();
              
                    reader.onload = function(e) {
                        fileDisplayArea.innerHTML = "";
        
                        var img = new Image();
                        img.src = reader.result;
                       
                        fileDisplayArea.appendChild(img);
                       
                            pictureContainer.style.display = "none";
                    }
                    reader.readAsDataURL(file);	
                
                } else {
                    fileDisplayArea.innerHTML = "File not supported!"
                    document.getElementById("pictureMessage").innerHTML="Supported extensions are .png, .jpg, .jpeg, .bmp!";
                }
            }
        
    });

    function validateExtensions(file)
    {
        var _validFileExtensions = [".png", ".jpg", ".jpeg", ".bmp"];
        var ok=true;
        if (file.type == "file") {
            var sFileName = file.value;
             if (sFileName.length > 0) {
                var blnValid = false;
                for (var j = 0; j < _validFileExtensions.length; j++) {
                    var sCurExtension = _validFileExtensions[j];
                    if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                        blnValid = true;
                        break;
                    }
                }
                if (!blnValid) {
                    document.getElementById("pictureMessage").innerHTML="Supported extensions are .png, .jpg, .jpeg, .bmp!";
                    oInput.value = "";
                    ok=false;
                    return false;
                }
            }
        }
        return ok;
    }

    function sizeValidation(file) {
        var ok=true;
            if (file.size > 50*1024) {
                document.getElementById("fileDisplayArea").innerHTML="";
                document.getElementById("pictureMessage").innerHTML="Maximum required is 50 Kb!";
                document.getElementById("fileInput").value="";
                document.getElementById('pictureContainer').style.display="table";
                ok=false;
            } 
        return ok;
    }
};