requirejs.config({
    paths: {
        jquery: "node_modules/jquery/dist/jquery.min",
        bootstrap: "node_modules/bootstrap/dist/js/bootstrap.bundle.min",
        knockout: "node_modules/knockout/build/output/knockout-latest",
        Cities: "js/Plugins/Cities",
        DeleteButton: "js/Plugins/DeleteButton",
        DeleteModal: "js/Plugins/DeleteModal",
        EntityGrid: "js/Plugins/EntityGrid",
        KendoValidation: "js/Plugins/KendoValidation",
        NumericField: "js/Plugins/NumericField",
        SearchLabel: "js/Plugins/SearchLabel",
        SortKendoGrid: "js/Plugins/SortKendoGrid",
        StatusModal: "js/Plugins/StatusModal",
    }
})