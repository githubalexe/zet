﻿define(["jquery", "DeleteModal", "bootstrap"], function($, DeleteModal) {

    var $customerId = $("#customerId");
    var $customerName = $("#customerName");
    var $deleteButton = $("#deleteCustomerButton");
    var $customerModalContainer = $("#customerModalContainer");

    $deleteButton.on("click", function() {
        var options = {
            title: "Delete",
            $container: $customerModalContainer,
            modelName: $customerName.text(),
            entity: "Customer",
            idsLength: 1,
            url: "/Customer/Delete",
            dataJson: {
                customersIds: $customerId.text()
            },
            onCancel: function() {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function() {
                window.location.href = "/Customer/Index";
            },
            onFail: function() {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        };

        new DeleteModal(options);

        $("#generalModal").modal("show");
    });
});