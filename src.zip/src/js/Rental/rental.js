﻿define(["jquery", "DeleteButton", "EntityGrid", "DeleteModal", "SearchLabel", "SortKendoGrid", "bootstrap"], function($, DeleteButton, EntityGrid, DeleteModal, SearchLabel, SortKendoGrid) {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $deleteRental = $("#deleteRental");
    var $rentalDeleteContainer = $("#rentalDeleteContainer");
    var $searchRentalContainer = $("#rentalSearchContainer");
    var $rentalsGrid = $("#rentalsGrid");
    var $toggleButton = $(".toggle-button");

    $activeform.on("change", function() {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");
    });

    setSearchItems();
    setDeleteButton();

    function setDeleteButton() {

        var options = {
            $deleteButton: $deleteRental,
            $toggleDeleteButton: $toggleButton,
            $grid: $rentalsGrid,
            messageForOne: "Delete Rental",
            messageForMany: "Delete Rentals"
        }

        new DeleteButton(options);
    };

    $deleteRental.on("click", function() {
        var optionsGrid = {
            grid: "rentalsGrid",
            id: "RentalId",
            name: "RentalId"
        }
        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();
        var options = {
            title: "Delete",
            $container: $rentalDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Rental",
            idsLength: numberOfIds.length,
            url: "/Rental/Delete",
            dataJson: {
                rentalsIds: numberOfIds
            },
            onCancel: function() {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function() {
                entityGrid.refreshGrid();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function() {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        }

        if (numberOfIds.length > 0) {
            new DeleteModal(options);

            $deleteRental.addClass("item-color");
            $deleteRental.prop("disabled", false);

            $("#generalModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {
            $container: $searchRentalContainer,
            $kendoGrid: $("#rentalsGrid"),
            filterButton: false,
            buttonFilters: [{
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "ReleaseYear"
                },
                {
                    field: "ReleaseYear",
                    operator: "eq",
                    value: 2010,
                    display: "2010"
                },

            ],
            orFilters: [{
                logic: "or",
                filters: [{
                        field: "RentalId",
                        operator: "eq",
                        value: 0
                    },
                    {
                        field: "Customer",
                        operator: "contains",
                        value: ""
                    },
                    {
                        field: "FilmTitle",
                        operator: "contains",
                        value: ""
                    },
                    {
                        field: "RentalDate",
                        operator: "contains",
                        value: "",
                    }
                ],
            }]
        }

        new SearchLabel(options);
    }

    setSortKendoGrid();

    function setSortKendoGrid() {
        var options = {
            $kendoGrid: $rentalsGrid,
            kendoGridField: "StoreRentalsGridField",
            kendoGridFieldDir: "StoreRentalsGridDir",
        };

        new SortKendoGrid(options);
    };
});