﻿define(["jquery", "DeleteButton", "EntityGrid", "DeleteModal", "SearchLabel", "SortKendoGrid", "bootstrap"], function($, DeleteButton, EntityGrid, DeleteModal, SearchLabel, SortKendoGrid) {

    var $deleteInventory = $("#deleteInventory");
    var $inventoryDeleteContainer = $("#inventoryDeleteContainer");
    var $inventorySearchContainer = $("#inventorySearchContainer");
    var $inventoriesGrid = $("#inventoriesGrid");
    var $toggleButton = $(".toggle-button");

    setSearchItems();
    setDeleteButton();

    function setDeleteButton() {
        var options = {
            $deleteButton: $deleteInventory,
            $toggleDeleteButton: $toggleButton,
            $grid: $inventoriesGrid,
            messageForOne: "Delete Inventory",
            messageForMany: "Delete Inventories"
        }

        new DeleteButton(options);
    };

    $deleteInventory.on("click", function() {
        var optionsGrid = {
            grid: "inventoriesGrid",
            id: "InventoryId",
            name: "InventoryId"
        }
        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();
        var options = {
            title: "Delete",
            $container: $inventoryDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Inventory",
            idsLength: numberOfIds.length,
            url: "/Inventory/Delete",
            dataJson: {
                inventoriesIds: numberOfIds
            },
            onCancel: function() {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function() {
                entityGrid.refreshGrid();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function() {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#generalModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {
            $container: $inventorySearchContainer,
            $kendoGrid: $inventoriesGrid,
            buttonFilters: [{
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "Release Year"
                },
                {
                    field: "ReleaseYear",
                    operator: "lte",
                    value: 2010,
                    display: "<= 2010",
                },
                {
                    field: "titleField",
                    display: "Rating"
                },
                {
                    field: "Rating",
                    operator: "eq",
                    value: "PG-13",
                    display: "PG-13"
                },
            ],
            orFilters: [{
                logic: "or",
                filters: [{
                        field: "Rating",
                        operator: "contains",
                        value: ""
                    },
                    {
                        field: "FilmTitle",
                        operator: "contains",
                        value: ""
                    },
                    {
                        field: "Rating",
                        operator: "contains",
                        value: 0,
                    },
                    {
                        field: "InventoryId",
                        operator: "eq",
                        value: 0,
                    }
                ],
            }]
        }
        new SearchLabel(options);
    }

    setSortKendoGrid();

    function setSortKendoGrid() {
        var options = {
            $kendoGrid: $inventoriesGrid,
            kendoGridField: "InventoriesGridField",
            kendoGridFieldDir: "InventoriesGridDir",
        };

        new SortKendoGrid(options);
    };
});