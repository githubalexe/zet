﻿define(["jquery", "KendoValidation", "NumericField", "bootstrap"], function($, KendoValidation, NumericField) {

    var $form = $("#inventoryAddForm");
    var $copiesInput = $("#copiesInput");
    var kendoFields = [{
            id: "filmComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "copiesInput",
            kendoType: "kendoNumericTextBox"
        }
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {
        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);
    };

    setInputNumber();

    function setInputNumber() {
        var options = {
            $input: $copiesInput,
            isArrows: true,
            type: "int",
            maxValue: 100

        }

        new NumericField(options);
    }
});