﻿define(["jquery", "bootstrap"], function($) {

    //var $userLoginButton = $("#userLoginButton");
    //var $username = $("#username");
    //var $password = $("#password");


    //$userLoginButton.on("click", function () {

    //    lll();
    //});

    //function lll() {
    //    var model = {

    //        username : $username.val(),
    //        password : $password.val()
    //    };
    //    alert("merge");

    //    return $.ajax({
    //        type: "POST",
    //        url: "/Login/GetStaff",
    //        data: JSON.stringify(model),
    //        contentType: "application/json; charset=utf-8",
    //    })
    //        .done(function () {
    //            alert("merge")
    //        })
    //        .fail(function () {
    //            alert("nu merge")
    //        })
    //}
});