﻿define(["jquery", "knockout", "bootstrap"], function($, ko) {

    function StatusModal(options) {
        this.options = $.extend({}, true, StatusModal.options, options);
        this.buildBody();
        this.onEditStatus();
        this.cancelEvent();
    };

    StatusModal.prototype.buildBody = function() {
        var StatusViewModel = function(title, message, cancelBtn, deleteBtn) {
            this.modalTitle = ko.observable(title);
            this.warningMessage = ko.observable(message);
            this.cancelButton = ko.observable(cancelBtn);
            this.acceptButton = ko.observable(deleteBtn);
        };
        var title = `${this.options.titlePartOne} ${this.options.entity} ${this.options.titlePartTwo} `;
        var message = `${this.options.warningMessagePartOne}
                       ${this.options.name}
                       ${this.options.warningMessagePartTwo}  
                       ${this.options.status} 
                       ${this.options.warningMessagePartThree}`

        ko.applyBindings(new StatusViewModel(title, message, this.options.cancelButton, this.options.acceptButton),
            this.options.$container[0]);
        ko.cleanNode(this.options.$container[0]);
    };

    StatusModal.prototype.cancelEvent = function() {
        var self = this;

        $("#cancelButton").on("click", function() {
            self.options.onCancel();
        });
    };

    StatusModal.prototype.onEditStatus = function() {
        var self = this;

        $("#deleteButton").on("click", function() {
            self.editStatus();
        });
    };

    StatusModal.prototype.editStatus = function() {
        var self = this;
        return $.ajax({
                type: "POST",
                url: this.options.url,
                data: this.options.dataJson,
            })
            .done(function() {
                self.options.onSucces();
            })
            .fail(function() {
                self.options.onFail();
            })
    };

    StatusModal.options = {
        $container: $({}),
        entity: $({}),
        status: $({}),
        name: $({}),
        url: $({}),
        dataJson: $({}),
        onCancel: $({}),
        onSucces: $({}),
        onFail: $({}),
        titlePartOne: $({}),
        titlePartTwo: $({}),
        cancelButton: $({}),
        acceptButton: $({}),
        warningMessagePartOne: $({}),
        warningMessagePartTwo: $({}),
        warningMessagePartThree: $({}),
    };

    return StatusModal;
});