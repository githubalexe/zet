﻿define(["jquery", "bootstrap"], function($) {

    function SortKendoGrid(options) {
        this.options = $.extend({}, true, DeleteModal.options, options);
        this.getSortFromLocalStorage();
        this.setSortLocalStorage();
    };

    SortKendoGrid.prototype.setSortLocalStorage = function() {
        var self = this;
        var $grid = this.options.$kendoGrid.data("kendoGrid");
        var curentSort = {};

        $grid.bind("sort", function(e) {
            curentSort.field = e.sort.field;
            curentSort.dir = e.sort.dir;
            localStorage.setItem(self.options.kendoGridField, curentSort.field);
            localStorage.setItem(self.options.kendoGridFieldDir, curentSort.dir);
        });
    };

    SortKendoGrid.prototype.getSortFromLocalStorage = function() {
        var fieldLocalStorage = localStorage.getItem(this.options.kendoGridField);
        var dirLocalStorage = localStorage.getItem(this.options.kendoGridFieldDir);

        if (dirLocalStorage !== "undefined") {
            this.options.$kendoGrid.data("kendoGrid").dataSource.sort({
                field: fieldLocalStorage,
                dir: dirLocalStorage
            });
        }
    };

    SortKendoGrid.options = {
        $kendoGrid: $({}),
        kendoGridField: $({}),
        kendoGridFieldDir: $({}),
    };

    return SortKendoGrid;
});