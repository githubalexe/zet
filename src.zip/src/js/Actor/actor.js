﻿define(["jquery", "DeleteButton", "EntityGrid", "DeleteModal", "SearchLabel", "SortKendoGrid", "bootstrap"], function($, DeleteButton, EntityGrid, DeleteModal, SearchLabel, SortKendoGrid) {

    var $containerForm = $(".container-form");
    var $actorNameContainer = $("#actorNameContainer");
    var $deleteActor = $("#deleteActor");
    var $actorDeleteContainer = $("#actorDeleteContainer");
    var $filmId = $("#filmId");
    var $filmTitle = $("#filmTitle");
    var $deleteButton = $("#deleteFilmButton");
    var $actorActiveCombobox = $("#actorActiveCombobox");
    var $actorsSearchContainer = $("#actorsSearchContainer");
    var $actorsGrid = $("#actorsGrid");
    var $toggleButton = $(".toggle-button");
    setSearchItems();
    setDeleteButton();

    function setDeleteButton() {
        var options = {
            $deleteButton: $deleteActor,
            $toggleDeleteButton: $toggleButton,
            $grid: $actorsGrid,
            messageForOne: "Delete Actor",
            messageForMany: "Delete Actors"
        }
        new DeleteButton(options);
    }

    $actorActiveCombobox.on("change", function() {
        $containerForm.slideToggle("slow");
        $actorNameContainer.toggleClass("display-none");
    });

    $deleteActor.on("click", function() {
        var optionsGrid = {
            grid: "actorsGrid",
            id: "ActorId",
            name: "Name"
        }
        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();
        var options = {
            title: "Delete",
            $container: $actorDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Actor",
            idsLength: numberOfIds.length,
            url: "/Film/DeleteActor",
            dataJson: {
                filmId: $filmId.text(),
                actorIds: numberOfIds
            },
            onCancel: function() {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function() {
                entityGrid.refreshGrid();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function() {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#generalModal").modal("show");
        }
    });

    $deleteButton.on("click", function() {
        var options = {
            title: "Delete",
            $container: $actorDeleteContainer,
            modelName: $filmTitle.text(),
            entity: "Film",
            idsLength: 1,
            url: "/Film/Delete",
            dataJson: {
                filmsIds: $filmId.text()
            },
            onCancel: function() {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function() {
                window.location.href = "/Film/Index";
            },
            onFail: function() {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        };

        new DeleteModal(options);

        $("#generalModal").modal("show");
    });

    function setSearchItems() {
        var options = {
            $container: $actorsSearchContainer,
            $kendoGrid: $("#actorsGrid"),
            filterButton: false,
            buttonFilters: [],
            orFilters: [{
                logic: "or",
                filters: [{
                    field: "Name",
                    operator: "contains",
                    value: ""
                }],
            }]
        }
        new SearchLabel(options);
    }

    setSortKendoGrid();

    function setSortKendoGrid() {
        var options = {
            $kendoGrid: $actorsGrid,
            kendoGridField: "ActorsGridField",
            kendoGridFieldDir: "ActorsGridDir",
        };

        new SortKendoGrid(options);
    };
});