﻿define(["jquery", "KendoValidation", "NumericField", "bootstrap"], function($, KendoValidation, NumericField) {

    var $form = $('#createFilmForm');
    var $kListFilter = $(".k-list-filter");
    var $rentalRateInput = $("#rentalRateInput");
    var $replacementCostInput = $("#replacementCostInput");


    $kListFilter.addClass("d-none");

    var kendoFields = [{
            id: "languageId",
            kendoType: "kendoComboBox"
        },
        {
            id: "categoryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "ratingId",
            kendoType: "kendoComboBox"
        },
        {
            id: "specialFeaturesId",
            kendoType: "kendoComboBox"
        },
        {
            id: "rentalRateId",
            kendoType: "kendoNumericTextBox"
        },
        {
            id: "replacementCostId",
            kendoType: "kendoNumericTextBox"
        },
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {
        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);
    };

    $(".k-numeric-wrap span:eq(0)").remove();
    setInputNumber();

    function setInputNumber() {
        var optionsRentalRate = {

            $input: $rentalRateInput,
            isArrows: true,
            type: "decimal"

        }
        var optionsReplacementCost = {

            $input: $replacementCostInput,

            type: "decimal"

        }
        new NumericField(optionsRentalRate);
        new NumericField(optionsReplacementCost);
    };
});