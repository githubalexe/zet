﻿define(["jquery", "DeleteButton", "EntityGrid", "DeleteModal", "SearchLabel", "SortKendoGrid", "bootstrap"], function($, DeleteButton, EntityGrid, DeleteModal, SearchLabel, SortKendoGrid) {

    var $deleteStaff = $("#deleteStaff");
    var $staffDeleteContainer = $("#staffModalContainer");
    var $staffsGrid = $("#staffsGrid");
    var $searchStaffsContainer = $("#staffsSearchContainer");
    var $toggleButton = $(".toggle-button");
    var $staffsGrid = $("#staffsGrid");

    setSearchItems();
    setDeleteButton();

    function setDeleteButton() {
        var options = {
            $deleteButton: $deleteStaff,
            $toggleDeleteButton: $toggleButton,
            $grid: $staffsGrid,
            messageForOne: "Delete Staff",
            messageForMany: "Delete Staffs"
        }

        new DeleteButton(options);
    };

    $deleteStaff.on("click", function() {
        var optionsGrid = {
            grid: "staffsGrid",
            id: "StaffId",
            name: "Name"
        }
        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();
        var options = {
            title: "Delete",
            $container: $staffDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Staff",
            idsLength: numberOfIds.length,
            url: "/Staff/Delete",
            dataJson: {
                staffsIds: numberOfIds
            },
            onCancel: function() {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function() {
                entityGrid.refreshGrid();
            },
            onFail: function() {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        }

        if (numberOfIds.length > 0) {
            new DeleteModal(options);
            $("#generalModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {
            $container: $searchStaffsContainer,
            $kendoGrid: $staffsGrid,
            buttonFilters: [{
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "Status"
                },
                {
                    field: "Status",
                    operator: "eq",
                    value: "Active",
                    display: "Active"
                },
                {
                    field: "Status",
                    operator: "eq",
                    value: "Inactive",
                    display: "Inactive"
                },
            ],
            orFilters: [{
                logic: "or",
                filters: [{
                        field: "Name",
                        operator: "contains",
                        value: ""
                    },
                    {
                        field: "Email",
                        operator: "contains",
                        value: ""
                    },
                    {
                        field: "Status",
                        operator: "contains",
                        value: "",
                    },
                    {
                        field: "City",
                        operator: "contains",
                        value: "",
                    },
                    {
                        field: "Country",
                        operator: "contains",
                        value: "",
                    }
                ],
            }]
        }
        new SearchLabel(options);
    }

    setSortKendoGrid();

    function setSortKendoGrid() {
        var options = {
            $kendoGrid: $staffsGrid,
            kendoGridField: "StafsGridField",
            kendoGridFieldDir: "StafsGridDir",
        };
        new SortKendoGrid(options);
    };
});