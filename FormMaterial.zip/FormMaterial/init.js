requirejs.config({
    paths: {
        jquery: "node_modules/jquery/dist/jquery.min",
        bootstrap: "node_modules/bootstrap/dist/js/bootstrap.bundle.min",
        knockout: "node_modules/knockout/build/output/knockout-latest",
        CodeMirror: "node_modules/codeMirror/lib/codemirror",
        Dropdown: "node_modules/bootstrap-select/js/bootstrap-select",
        DateTimePicker: "node_modules/bootstrap-datetime-picker/js/bootstrap-datetimepicker.min",
        ControlInput: "Form/InputGenerator/Control/Control",
        InputGenerator: "Form/InputGenerator/Main/InputGenerator",
        Templates: "Form/Dictionary/Templates",
        Type: "Form/InputGenerator/Dictionary/InputsType",
        InputHelper: "Form/InputGenerator/Helpers/InputHelper",
        TextBoxInput: "Form/InputGenerator/Inputs/TextBoxInput",
        DeleteButton: "Form/InputGenerator/Inputs/DeleteButton",
        DropDownListInput: "Form/InputGenerator/Inputs/DropDownListInput",
        Label: "Form/InputGenerator/Inputs/Label",
        DateTimeInput: "Form/InputGenerator/Inputs/DateTimeInput",
        CheckBoxInput: "Form/InputGenerator/Inputs/CheckBoxInput",
        Factory: "Form/InputGenerator/Factory/InputFactory",
        JsonSchemaValidation: "Form/JsonSchemaValidation/Main/JsonSchemaValidation",
        JsonHelper: "Form/JsonSchemaValidation/Helpers/JsonHelper",
        InputsType: "Form/JsonSchemaValidation/Dictionary/InputsType",
        InputErrorMessages: "Form/JsonSchemaValidation/Dictionary/InputErrorMessages",
        DataTypes: "Form/JsonSchemaValidation/Dictionary/DataTypes",
        InputFactory: "Form/JsonSchemaValidation/Factory/InputFactory",
        Control: "Form/JsonSchemaValidation/Control/Control",
        TextboxInput: "Form/JsonSchemaValidation/Inputs/TextboxInput",
        DropdownListInput: "Form/JsonSchemaValidation/Inputs/DropdownListInput",
        DatetimeInput: "Form/JsonSchemaValidation/Inputs/DateTimeInput",
        CheckboxInput: "Form/JsonSchemaValidation/Inputs/CheckBoxInput",
        InputValidations: "Form/InputValidations/InputValidations",
        FormGenerator: "Form/FormGenerator/main/FormGenerator",
        Form: "Form/FormGenerator/main/Form",
        FormControl: "Form/FormGenerator/Control/FormControl",
        FormHelper: "Form/FormGenerator/Helpers/FormHelper",
        mdc: "node_modules/material-components-web/dist/material-components-web.min"
    }
});

(function() {
    var load = requirejs.load;
    requirejs.load = function(context, moduleId, url) {
        if (moduleId && moduleId.startsWith("kendo.")) {
            // if moduleId starts with "kendo.", we overwrite the url path to the kendo library location
            url = url.substring(url.lastIndexOf("/") + 1);
            url = "./node_modules/kendo-ui/js/" + url;
        }
        load.apply(this, arguments);
    };
}());