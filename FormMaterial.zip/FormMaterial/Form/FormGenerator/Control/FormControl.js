define(["jquery", "knockout", "FormHelper"], function($, ko, FormHelper) {

    var _index = null;

    function FormControl() {
        _generateNewId();

        this.formId = _generateFormId();
        this.containerId = _generateContainerFormId();
        this.wrapperFormId = _generateWrapperFormId();
        this.headerTableContainerId = _generateHeaderTableContainerId();
        this.inputsContainerId = _generateInputsContainerId();
        this.addNewButtonId = _generateAddNewButtonId();

        this.BuildHtml = function(container, template, options) {
            ko.applyBindingsToNode(container[0], {
                template: {
                    name: template,
                    data: options
                }
            });
            container.find("[data-bind]").removeAttr("data-bind");
        };
    };

    function _generateFormId() {
        return _index;
    };

    function _generateAddNewButtonId() {
        return "add-button-" + _index;
    };

    function _generateContainerFormId() {
        return "form-container-" + _index;
    };

    function _generateWrapperFormId() {
        return "form-wrapper-" + _index;
    };

    function _generateInputsContainerId() {
        return "form-inputs-" + _index;
    };

    function _generateHeaderTableContainerId() {
        return "header-table-" + _index;
    };

    function _generateNewId() {
        _index = FormHelper.GenerateNewGuid();
    };

    return FormControl;
});