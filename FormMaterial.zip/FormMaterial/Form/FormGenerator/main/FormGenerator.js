define(["jquery", "Form", "InputValidations"], function($, Form, InputValidations) {

    function FormGenerator(options) {
        this.options = $.extend({}, true, FormGenerator.defaultOptions, options);
        this.$formsContainer = this.options.$formsContainer;
        this.formOptions = this.options.formOptions;
        this.validations = this.options.validations;
        this.onCreateControl = this.options.onCreateControl;
        this.copy = null;
        this.inputsForm = [];
    };

    FormGenerator.prototype.CreateForm = function() {
        var self = this;
        var $wrapperFormId = self._createWrapper();
        var options = {
            $wrapperFormId: $wrapperFormId,
            formOptions: self.formOptions
        };

        var control = new Form(options);
        self._setIdWrapper(control);
        self._createInputs(control);
    };

    FormGenerator.prototype._createInputs = function(controlForm) {
        var self = this;
        var options = {
            $inputsContainer: $("#" + controlForm.inputsContainerId),
            onErrorMessages: function(errorMessage) {}
        }

        var inputValidations = new InputValidations(options);
        self.copy = inputValidations;
        inputValidations.CreateInputGenerator(self.formOptions.inputs);
        self.inputsForm = [...self.formOptions.inputs];
        self._bindFormEvents(controlForm, inputValidations);
    };

    FormGenerator.prototype._bindFormEvents = function(controlForm, inputValidations) {
        var self = this;
        var $formSubmitButton = $(`#${controlForm.addNewButtonId}`);
        $formSubmitButton.on("click", function() {

            self.copy.CreateInputGenerator(self.inputsForm);
        })
    };

    FormGenerator.prototype._validateInputs = function(inputValidations) {
        var self = this;
        inputValidations.ValidateInputs(self.validations);
    };

    FormGenerator.prototype._setIdWrapper = function(control) {
        control.options.$wrapperFormId.attr("id", control.wrapperFormId);
    };

    FormGenerator.prototype._createWrapper = function() {
        var $wrapperForm = $("<div/>");
        this.$formsContainer.append($wrapperForm);

        return $wrapperForm;
    };

    FormGenerator.defaultOptions = {
        $formsContainer: $({}),
        formOptions: {},
        validations: {}
    };

    return FormGenerator;
});