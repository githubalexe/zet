define(["jquery", "Form", "InputGenerator", "mdc"], function($, Form, InputGenerator, mdc) {

    function FormGenerator(options) {
        this.options = $.extend({}, true, FormGenerator.defaultOptions, options);
        this.$formsContainer = this.options.$formsContainer;
        this.formOptions = this.options.formOptions;
        this.validations = this.options.validations;
        this.onCreateControl = this.options.onCreateControl;
        this.$inputsContainer = null;
        this.inputsForm = [];
    };

    FormGenerator.prototype.CreateForm = function() {
        var self = this;
        var $wrapperFormId = self._createWrapper();
        var options = {
            $wrapperFormId: $wrapperFormId,
            formOptions: self.formOptions
        };

        var control = new Form(options);
        self.inputsForm = [...self.formOptions.inputs];
        self.$inputsContainer = $("#" + control.inputsContainerId)

        self._setIdWrapper(control);
        self._createInputs(control);
    };

    FormGenerator.prototype._createInputs = function(controlForm) {
        var self = this;
        self._createInputGenerator();
        self._bindFormEvents(controlForm);
    };

    FormGenerator.prototype._bindFormEvents = function(controlForm) {
        var self = this;
        var $formSubmitButton = $(`#${controlForm.addNewButtonId}`);
        $formSubmitButton.on("click", function() {

            self._createInputGenerator();

        })
    };

    FormGenerator.prototype._createInputGenerator = function() {
        var self = this;
        var options = {
            $inputsContainer: self.$inputsContainer,
            onControlCreate: function(control) {
                // self._createControl(control);
            }
        }

        var inputGenerator = new InputGenerator(options);
        inputGenerator.createByJsonValue(self.formOptions.inputs);
    };

    FormGenerator.prototype._validateInputs = function(inputValidations) {
        var self = this;
        inputValidations.ValidateInputs(self.validations);
    };

    FormGenerator.prototype._setIdWrapper = function(control) {
        control.options.$wrapperFormId.attr("id", control.wrapperFormId);
    };

    FormGenerator.prototype._createWrapper = function() {
        var $wrapperForm = $("<div/>");
        this.$formsContainer.append($wrapperForm);

        return $wrapperForm;
    };

    FormGenerator.defaultOptions = {
        $formsContainer: $({}),
        formOptions: {},
        validations: {}
    };

    return FormGenerator;
});