define(["FormControl", "Templates"], function(FormControl, Templates) {

    function Form(options) {
        var self = this;
        this.options = $.extend({}, true, Form.defaultOptions, options);
        this.$wrapperFormId = this.options.$wrapperFormId;
        this.formOptions = this.options.formOptions;

        FormControl.call(this);

        this.BuildHtml(
            self.$wrapperFormId,
            Templates.FormTemplate,
            formOptions = {
                formId: self.formId,
                containerId: self.containerId,
                inputsContainerId: self.inputsContainerId,
                headerTableContainerId: self.headerTableContainerId,
                titleForm: self.formOptions.titleForm,
                addButtonId: self.addNewButtonId,
                addButton: self.formOptions.addButton
            }
        );
    };

    Form.defaultOptions = {
        $formsContainer: $({}),
        formOptions: {}
    };

    return Form;
});