define(["jquery"], function($) {

    var JsonHelper = {};

    JsonHelper.IsJson = function(textInput) {
        try {
            JSON.parse(textInput);
        } catch (e) {
            return false;
        }
        return true;
    };

    return JsonHelper;
});