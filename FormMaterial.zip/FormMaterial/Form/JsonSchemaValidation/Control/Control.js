define(["DataTypes", "InputErrorMessages", "InputsType"], function(DataTypes, InputErrorMessages, InputsType) {

    function Control() {

        this.GetValueErrorMessage = function(inputType, controlValue, dataTypeValidation, minValidation, maxValidatiton) {
            var value = _getValue(controlValue, dataTypeValidation);
            if (!((value <= maxValidatiton) && (value >= minValidation))) {
                return _getValueErrorMessage(inputType, value, dataTypeValidation, minValidation, maxValidatiton);
            }
        };

        this.GetErrorMessageForDataType = function(controlValueDataType, dataTypeValidation) {
            if (controlValueDataType !== dataTypeValidation) {
                return InputErrorMessages.GetErrorMessageForDataType(dataTypeValidation);
            }
        };

        this.GetErrorMessageForRegex = function(controlValue, regex) {
            if (regex) {
                if (_getRegexResult(controlValue, regex) === false) {
                    return InputErrorMessages.GetErrorMessageForRegex();
                }
            }
        };

        this.GetErrorMessageForRequired = function(controlValue, isControlRequired) {
            if ((controlValue === null) && (isControlRequired)) {
                return InputErrorMessages.GetErrorMessageForRequired();
            }
        };
    };

    function _getRegexResult(value, regex) {
        var regexp = new RegExp("^" + regex + "*$");
        if (regexp.test(value) === false) {
            return false;
        }

        return true;
    };

    function _getValueErrorMessage(inputType, value, dataType, min, max) {
        switch (dataType) {
            case DataTypes.Number:
                {
                    if (inputType === InputsType.CheckBox || inputType === InputsType.Dropdown) {
                        return _getErrorMessageByInputType(value, min, max);
                    } else {
                        if ((min === undefined) || (max === undefined)) {
                            return _getMinMaxErrorMessages(dataType, value, min, max)
                        } else {
                            return InputErrorMessages.GetErrorMessageForNumberValue(min, max);
                        }
                    }

                }
            case DataTypes.String:
                {
                    if ((min === undefined) || (max === undefined)) {
                        return _getMinMaxErrorMessages(dataType, value, min, max)
                    } else {
                        return InputErrorMessages.GetErrorMessageForStringValue(min, max);
                    }
                }
            case DataTypes.Date:
                {
                    if ((min === undefined) || (max === undefined)) {
                        return _getMinMaxErrorMessages(dataType, value, min, max)
                    } else {
                        return InputErrorMessages.GetErrorMessageForDateValue(min, max);
                    }
                }
            case DataTypes.Null:
                {
                    break;
                }
            default:
                {
                    console.log("something went wrong");
                }
        }
    };

    function _getMinMaxErrorMessages(dataType, value, min, max) {
        if ((max === undefined) && (min != undefined)) {
            if (value < min) {
                if (dataType === DataTypes.Number) {
                    return InputErrorMessages.GetErrorMessageForNumberMinValue(min);
                }
                if (dataType === DataTypes.String) {
                    return InputErrorMessages.GetErrorMessageForStringMinValue(min);
                }
                if (dataType === DataTypes.Date) {
                    return InputErrorMessages.GetErrorMessageForDateMinValue(min);
                }
            }
        }

        if ((min === undefined) && (max != undefined)) {
            if (value > max) {
                if (dataType === DataTypes.Number) {
                    return InputErrorMessages.GetErrorMessageForNumberMaxValue(max);
                }
                if (dataType === DataTypes.String) {
                    return InputErrorMessages.GetErrorMessageForStringMaxValue(max);
                }
                if (dataType === DataTypes.Date) {
                    return InputErrorMessages.GetErrorMessageForDateMaxValue(max);
                }
            }
        }
    };

    function _getErrorMessageByInputType(value, min, max) {
        if ((min !== undefined) && (max != undefined)) {
            if (!((value <= max) && (value >= min))) {
                return InputErrorMessages.GetErrorMessageForOptionsValue(min, max);
            }
        } else {
            if (min === undefined) {
                if (value > max) {
                    return InputErrorMessages.GetErrorMessageForOptionsMaxValue(max)
                }
            }
            if (max === undefined) {
                if (value < min) {
                    return InputErrorMessages.GetErrorMessageForOptionsMinValue(min)
                }
            }
        }
    };

    function _getValue(value, dataType) {
        if (value !== null && value !== undefined) {
            switch (dataType) {
                case DataTypes.Number:
                    {
                        return value;
                    }
                case DataTypes.String:
                    {
                        return value.length;
                    }
                case DataTypes.Date:
                    {
                        return new Date(value);
                    }
                default:
                    {
                        console.log("something went wrong");
                    }
            }
        }
    };


    return Control;
});