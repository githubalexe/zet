define(["Control"], function(Control) {

    function CheckBoxInput(options) {
        this.options = $.extend({}, CheckBoxInput.defaultOptions, true, options);
        this.inputName = this.options.inputName;
        this.inputType = this.options.inputType;
        this.dataType = this.options.dataType;
        this.validations = this.options.validations;
        this.value = this.options.value;
        this.items = this.options.items;

        Control.call(this);
    };

    CheckBoxInput.defaultOptions = {
        inputType: null,
        inputName: null,
        dataType: null,
        value: null,
        validations: {},
    }

    return CheckBoxInput;
})