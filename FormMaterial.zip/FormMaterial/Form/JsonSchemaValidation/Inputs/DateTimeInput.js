define(["Control"], function(Control) {

    function DateTimeInput(options) {
        this.options = $.extend({}, DateTimeInput.defaultOptions, true, options);
        this.inputName = this.options.inputName;
        this.inputType = this.options.inputType;
        this.dataType = this.options.dataType;
        this.validations = this.options.validations;
        this.value = this.options.value;
        Control.call(this);
    };

    DateTimeInput.defaultOptions = {
        inputType: null,
        inputName: null,
        dataType: null,
        value: null,
        validations: {},
    }

    return DateTimeInput;
})