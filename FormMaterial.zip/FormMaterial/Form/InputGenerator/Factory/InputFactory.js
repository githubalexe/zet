define(["Type"], function(Type) {

    var InputFactory = {};

    InputFactory.CreateControl = function(options, callback) {
        var inputType = options.jsonOptions.type;
        switch (inputType) {
            case Type.TextBox:
                {
                    require(["TextBoxInput"], function(TextBoxInput) {
                        var control = new TextBoxInput(options);
                        callback(control);
                    })
                }
                break;
            case Type.DropDownList:
                {
                    require(["DropDownListInput"], function(DropDownListInput) {

                        var control = new DropDownListInput(options);
                        callback(control);
                    })
                }
                break;
            case Type.DateTime:
                {
                    require(["DateTimeInput"], function(DateTimeInput) {

                        var control = new DateTimeInput(options);
                        callback(control);
                    })
                }
                break;
            case Type.CheckBox:
                {
                    require(["CheckBoxInput"], function(CheckBoxInput) {

                        var control = new CheckBoxInput(options);
                        callback(control);
                    })
                }
                break;
            case Type.Label:
                {
                    require(["Label"], function(Label) {
                        var control = new Label(options);
                        callback(control);
                    })
                }
                break;
            case Type.DeleteButton:
                {
                    require(["DeleteButton"], function(DeleteButton) {
                        var control = new DeleteButton(options);
                        callback(control);
                    })
                }
                break;
            default:
                {
                    console.log("something wrong");
                }
        }
    };

    return InputFactory;
});