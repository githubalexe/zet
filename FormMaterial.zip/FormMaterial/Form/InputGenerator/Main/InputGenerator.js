define(["jquery", "InputHelper", "Factory", "Type", "mdc", "bootstrap"], function($, InputHelper, Factory, Type, mdc) {

    function InputGenerator(options) {
        this.options = $.extend({}, true, InputGenerator.defaultOptions, options);
        this.$inputsContainer = this.options.$inputsContainer;
        this.onControlCreate = this.options.onControlCreate;
        this.$tr = $("<tr/>");
        this.controls = [];
    };

    InputGenerator.prototype.createByJsonValue = function(inputs) {
        if (InputHelper.IsJson(inputs)) {
            var generatorInputs = JSON.parse(inputs);
            this.createInput(generatorInputs);
        } else {
            var generatorInputs = inputs;
            this.createInput(generatorInputs);
        }
    };

    InputGenerator.prototype.createInput = function(generatorInputs) {
        var self = this;
        if (InputHelper.IsArray(generatorInputs)) {

            generatorInputs.forEach(function(input) {
                var $wrapperInput = self.createWrapper();

                var jsonObject = {
                    $wrapperInput: $wrapperInput,
                    jsonOptions: input
                };

                Factory.CreateControl(jsonObject, function(control) {
                    self.controls.push(control);
                    self.onControlCreate(control);
                    _setControlsForMaterialDesign(control);
                });
            });

            var $hr = $("<hr/>");
            this.$inputsContainer.append(self.$tr, $hr);
        }
    };

    function _setControlsForMaterialDesign(control) {
        var textField = [].map.call($(".mdc-text-field"), function(el) {
            mdc.textField.MDCTextField.attachTo(el);
        });
        var select = [].map.call($(".mdc-select"), function(el) {
            mdc.select.MDCSelect.attachTo(el);
        });
    };

    InputGenerator.prototype.deleteControl = function(inputId) {
        var self = this;
        self.controls.forEach(function(control) {
            if (control.inputId == inputId) {
                self.controls.splice(self.controls.indexOf(self.controls[i]), 1);
            }
        });
    };

    InputGenerator.prototype.createWrapper = function() {
        var $td = $("<td/>");
        this.$tr.append($td);

        return $td;
    };

    InputGenerator.defaultOptions = {
        $inputsContainer: $({}),
        onControlCreate: null,
    };

    return InputGenerator;
});