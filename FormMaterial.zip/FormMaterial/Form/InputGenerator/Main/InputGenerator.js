define(["jquery", "InputHelper", "Factory", "Type", "mdc", "bootstrap"], function($, InputHelper, Factory, Type, mdc) {

    function InputGenerator(options) {
        this.options = $.extend({}, true, InputGenerator.defaultOptions, options);
        this.$inputsContainer = this.options.$inputsContainer;
        this.onControlCreate = this.options.onControlCreate;
        this.$tr = $("<tr/>");
        this.controls = [];
    };

    InputGenerator.prototype.createByJsonValue = function(inputs) {
        if (InputHelper.IsJson(inputs)) {
            var generatorInputs = JSON.parse(inputs);
            this.createInput(generatorInputs);
        } else {
            var generatorInputs = inputs;
            this.createInput(generatorInputs);
        }
    };

    InputGenerator.prototype.createInput = function(generatorInputs) {
        var self = this;
        if (InputHelper.IsArray(generatorInputs)) {

            generatorInputs.forEach(function(input) {
                var $wrapperInput = self.createWrapper();

                var jsonObject = {
                    $wrapperInput: $wrapperInput,
                    jsonOptions: input
                };

                Factory.CreateControl(jsonObject, function(control) {
                    self.controls.push(control);
                    self.onControlCreate(control);
                    _deleteRowFromForm(control);
                    _setControlsForMaterialDesign(control);
                });
            });

            var $hr = $("<hr/>");
            this.$tr.append($hr);
            this.$inputsContainer.append(self.$tr, $hr);
        }
    };

    function _deleteRowFromForm(control) {
        if (control.jsonOptions.type === Type.DeleteButton) {
            $("#" + control.inputId).on("click", function() {
                $(this).closest("tr").find('hr').remove();
                $(this).closest("tr").remove();
            })
        }
    };

    function _setControlsForMaterialDesign(control) {

        if (control.jsonOptions.type === Type.DropDownList) {
            const select2 = [].map.call($("#" + control.containerId), function(el) {
                mdc.select.MDCSelect.attachTo(el);
            });
        }
        const textField = [].map.call($('.mdc-text-field'), function(el) {
            mdc.textField.MDCTextField.attachTo(el);
        });
        const ripple = [].map.call($(".mdc-line-ripple"), function(el) {
            mdc.ripple.MDCRipple.attachTo(el);
        });
        const ripple2 = [].map.call($(".mdc-button"), function(el) {
            mdc.ripple.MDCRipple.attachTo(el);
        });
        const floating = [].map.call($(".mdc-floating-label"), function(el) {
            mdc.floatingLabel.MDCFloatingLabel.attachTo(el);
        });
        const icon = [].map.call($(".mdc-text-field-icon"), function(el) {
            mdc.textFieldIcon.MDCTextFieldIcon.attachTo(el);
        });

    };

    InputGenerator.prototype.deleteControl = function(inputId) {
        var self = this;
        self.controls.forEach(function(control) {
            if (control.inputId == inputId) {
                self.controls.splice(self.controls.indexOf(self.controls[i]), 1);
            }
        });
    };

    InputGenerator.prototype.createWrapper = function() {
        var $td = $("<td/>", {
            class: "mdc-data-table__header-row"
        });
        this.$tr.append($td);

        return $td;
    };

    InputGenerator.defaultOptions = {
        $inputsContainer: $({}),
        onControlCreate: null,
    };

    return InputGenerator;
});