define(["jquery", "knockout", "InputHelper"], function($, ko, InputHelper) {

    var _index = null;

    function _generateInputId() {
        return "input-" + _index;
    }

    function _generateContainerInputId() {
        return "container-" + _index;
    }

    function _generateWrapperContainerId() {
        return "wrapper-" + _index;
    }

    function _generateErrorMessageId() {
        return "error-" + _index;
    }

    function _generateNewId() {
        _index = InputHelper.GenerateNewGuid();
    }

    function Control() {
        _generateNewId();

        this.inputId = _generateInputId();
        this.containerId = _generateContainerInputId();
        this.wrapperId = _generateWrapperContainerId();
        this.errorMessageId = _generateErrorMessageId();
        this.BuildHtml = function(container, template, options) {
            ko.applyBindingsToNode(container[0], {
                template: {
                    name: template,
                    data: options
                }
            });
            container.find("[data-bind]").removeAttr("data-bind");
        };

        this.GetInputDomElement = function() {
            var $inputId = $("#" + this.inputId);

            return $inputId;
        };

        this.GetContainerDomElement = function() {
            var $containerId = $("#" + this.containerId);

            return $containerId;
        };

        this.GetInputNameCheckedDomElement = function(name) {
            var $nameValue = $("input[name='" + name + "']:checked");

            return $nameValue;
        };

        this.GetWrapperDomElement = function() {
            var $containerId = $("#" + this.wrapperId);

            return $containerId;
        };

        this.SetInputValue = function(value) {
            var $inputId = this.GetInputDomElement();

            $inputId.val(value);
        };

        this.GetInputValue = function() {
            var $inputId = this.GetInputDomElement();

            return $inputId.val();
        };

        this.DestroyContainer = function() {

            this.GetWrapperDomElement().remove();
        };
    };

    return Control;

});