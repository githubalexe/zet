define(["jquery", "ControlInput", "Templates"], function($, ControlInput, Templates) {

    function Button(options) {
        var self = this;
        this.options = $.extend({}, Button.defaultOptions, true, options);
        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        ControlInput.call(this);
        this.BuildHtml(
            self.$wrapperInput,
            Templates.ButtonTemplate,
            textboxOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                name: self.jsonOptions.inputOptions.name,
                type: self.jsonOptions.inputOptions.type
            }
        );
    };

    Button.defaultOptions = {
        $wrapperInput: $({}),
        jsonOptions: {}
    }

    return Button;
});