define(["jquery", "ControlInput", "Templates"], function($, ControlInput, Templates) {

    function DeleteButton(options) {
        var self = this;
        this.options = $.extend({}, DeleteButton.defaultOptions, true, options);
        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        ControlInput.call(this);
        this.BuildHtml(
            self.$wrapperInput,
            Templates.DeleteButtonTemplate,
            textboxOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                name: self.jsonOptions.inputOptions.name,
                type: self.jsonOptions.inputOptions.type
            }
        );
    };

    DeleteButton.defaultOptions = {
        $wrapperInput: $({}),
        jsonOptions: {}
    }

    return DeleteButton;
});