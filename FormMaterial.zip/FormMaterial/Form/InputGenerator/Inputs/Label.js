define(["jquery", "ControlInput", "Templates"], function($, ControlInput, Templates) {

    function Label(options) {
        var self = this;
        this.options = $.extend({}, Label.defaultOptions, true, options);
        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        ControlInput.call(this);

        this.BuildHtml(
            self.$wrapperInput,
            Templates.LabelTemplate,
            textboxOptios = {
                type: self.jsonOptions.type,
                label: self.jsonOptions.name
            }
        );
    };

    Label.defaultOptions = {
        $wrapperInput: $({}),
        jsonOptions: {}
    }

    return Label;
});