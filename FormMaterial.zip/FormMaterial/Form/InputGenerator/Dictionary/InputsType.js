define([], function() {

    var InputsType = {
        TextBox: "textbox",
        DropDownList: "dropdown",
        DateTime: "dateTime",
        CheckBox: "checkBox",
        Label: "label"
    }

    return InputsType;
});