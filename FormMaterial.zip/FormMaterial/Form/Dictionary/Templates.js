define([], function() {

    var Templates = {
        TextBoxTemplate: "textboxTemplate",
        DropDownListTemplate: "dropDownListTemplate",
        DataTimeTemplate: "dateTimeTemplate",
        CheckBoxTemplate: "checkBoxTemplate",
        FormTemplate: "formTemplate",
        DeleteButtonTemplate: "deleteButtonTemplate"
    }

    return Templates;
});