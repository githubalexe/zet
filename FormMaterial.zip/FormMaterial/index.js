define(["jquery", "FormGenerator"], function($, FormGenerator) {

    var index = {};

    var $generateForm = $("#generateForm");
    var $formsContainer = $("#formsContainer");
    var $formJsonSchema = $("#formJsonSchema");
    var $validationsJsonSchema = $("#validationsJsonSchema");

    index.generateForm = function(form, validations) {
        createForm(form, validations);
    };

    $formJsonSchema.val(`
    {  
        "type":"form",     
        "name":"form1",
        "titleForm":"Applicants",
        "addButton":"Add New Applicant",
        "inputs":
        [  
            {  
                "type":"dropdown",
                "inputOptions":{  
                   "name":"nameTitle",
                   "label":"Name Title",
                   "ariaHaspopup ":"listbox ",
                   "type":"number",
                   "items":[  
                    {  
                        "text":"",
                        "value":""
                     },
                      {  
                         "text":"Mr",
                         "value":"1"
                      },
                      {  
                         "text":"Mrs",
                         "value":"2"
                      }
                   ]
                }
             },
             {  
                "type":"textbox",
                "inputOptions":{  
                   "name":"firstName",
                   "label":"First Name",
                   "type":"string"
                }
             },
             {  
                "type":"textbox",
                "inputOptions":{  
                   "name":"surmane",
                   "label":"Last Name",
                   "type":"string"
                }
             },
            {  
               "type":"dropdown",
               "inputOptions":{  
                  "name":"houseHold",
                  "type":"number",
                  "label":"No of Dependants",
                  "items":[  
                    {  
                        "text":"",
                        "value":""
                     },
                     {  
                        "text":"One",
                        "value":"1"
                     },
                     {  
                        "text":"Two",
                        "value":"2"
                     },
                     {  
                        "text":"Three",
                        "value":"3"
                     }
                  ]
               }
            },
            {  
                "type":"dropdown",
                "inputOptions":{  
                   "name":"noOfDependants",
                   "type":"number",
                   "label":"No of Adults",
                   "items":[  
                    {  
                        "text":"",
                        "value":"",
                        "disabled":true
                     },
                      {  
                         "text":"1",
                         "value":"1"
                      },
                      {  
                         "text":"2",
                         "value":"2"
                      },
                      {  
                         "text":"3",
                         "value":"3"
                      }
                   ]
                }
             },
            {
                "type": "checkBox",
                "inputOptions": {
                    "label": "Leader Staff",
                    "name": "checkBox1",
                    "type": "number",
                    "multiselect": false,
                    "items": [{
                        "text": "Leader Staff",
                        "name": "leaderStaff",
                        "value": "1"
                    }]
                }
            },
            {
                "type": "checkBox",
                "inputOptions": {
                    "label": "Existing Customer",
                    "name": "checkBox1",
                    "type": "number",
                    "multiselect": false,
                    "items": [{
                        "text": "Existing Customer",
                        "name": "existingCustomer",
                        "value": "1"
                    }]
                }
            },

            {  
                "type":"textbox",
                "inputOptions":{  
                   "name":"accountNumber",
                   "label":"Account Number",
                   "type":"string"
                }
             },
            {  
                "type":"deleteButton",
                "inputOptions":{  
                   "name":"deleteButton",
                   "textButton":"",
                   "type":"button"
                }
             }
         ]
     }
    `)

    $validationsJsonSchema.val(`[{"test":"test"}]`);
    bindEvents();

    function bindEvents() {
        $generateForm.on("click", function() {
            var form = JSON.parse($formJsonSchema.val());
            var validations = JSON.parse($validationsJsonSchema.val())
            createForm(form, validations);
        })
    };

    function createForm(form, validations) {
        var options = {
            $formsContainer: $formsContainer,
            formOptions: form,
            validations: validations,
        }
        var formGenerator = new FormGenerator(options);
        formGenerator.CreateForm();
    };

    return index;
});