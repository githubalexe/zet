define(["jquery", "FormGenerator"], function($, FormGenerator) {

    var index = {};

    var $generateForm = $("#generateForm");
    var $formsContainer = $("#formsContainer");
    var $formJsonSchema = $("#formJsonSchema");
    var $validationsJsonSchema = $("#validationsJsonSchema");

    index.generateForm = function(form, validations) {
        createForm(form, validations);
    };

    $formJsonSchema.val(`
    {  
        "type":"form",     
        "name":"form1",
        "titleForm":"Applicants",
        "addButton":"Add New Applicant",

        "headerTable":
        [{
            "type": "label",
            "name": "Name Title"
        }, {
            "type": "label",
            "name": "First Name"
        }, {
            "type": "label",
            "name": "Surname"
        }, {
            "type": "label",
            "name": "HouseHold"
        }, {
            "type": "label",
            "name": "No of Dependants"
        }, {
            "type": "label",
            "name": "No of Adults"
        }, {
            "type": "label",
            "name": "Lender Staff"
        }, {
            "type": "label",
            "name": "Existing Customer"
        }, {
            "type": "label",
            "name": "Account Number"
        }],
        "inputs":
        [  
            {  
                "type":"dropdown",
                "inputOptions":{  
                   "name":"nameTitle",
                   "type":"number",
                   "items":[  
                      {  
                         "text":"Mr",
                         "value":"1"
                      },
                      {  
                         "text":"Mrs",
                         "value":"2"
                      }
                   ]
                }
             },
             {  
                "type":"textbox",
                "inputOptions":{  
                   "name":"firstName",
                   "label":"Number",
                   "type":"string"
                }
             },
             {  
                "type":"textbox",
                "inputOptions":{  
                   "name":"surmane",
                   "label":"Number",
                   "type":"string"
                }
             },
            {  
               "type":"dropdown",
               "inputOptions":{  
                  "name":"houseHold",
                  "type":"number",
                  "label":"Colors",
                  "items":[  
                     {  
                        "text":"One",
                        "value":"1"
                     },
                     {  
                        "text":"Two",
                        "value":"2"
                     },
                     {  
                        "text":"Three",
                        "value":"3"
                     }
                  ]
               }
            },
            {  
                "type":"dropdown",
                "inputOptions":{  
                   "name":"noOfDependants",
                   "type":"number",
                   "items":[  
                      {  
                         "text":"1",
                         "value":"1"
                      },
                      {  
                         "text":"2",
                         "value":"2"
                      },
                      {  
                         "text":"3",
                         "value":"3"
                      }
                   ]
                }
             },
             {  
                "type":"dropdown",
                "inputOptions":{  
                   "name":"noOfAdults",
                   "type":"number",
                   "items":[  
                      {  
                         "text":"0",
                         "value":"1"
                      },
                      {  
                         "text":"1",
                         "value":"2"
                      },
                      {  
                         "text":"2",
                         "value":"3"
                      }
                   ]
                }
             },
            {
                "type": "checkBox",
                "inputOptions": {
                    "label": "Gender",
                    "name": "checkBox1",
                    "type": "number",
                    "multiselect": false,
                    "items": [{
                        "text": "",
                        "name": "leaderStaff",
                        "value": "1"
                    }]
                }
            },
            {
                "type": "checkBox",
                "inputOptions": {
                    "label": "Gender",
                    "name": "checkBox1",
                    "type": "number",
                    "multiselect": false,
                    "items": [{
                        "text": "",
                        "name": "existingCustomer",
                        "value": "1"
                    }]
                }
            },

            {  
                "type":"textbox",
                "inputOptions":{  
                   "name":"accountNumber",
                   "type":"string"
                }
             }
         ]
     }
    `)

    $validationsJsonSchema.val(`[{"test":"test"}]`);
    bindEvents();

    function bindEvents() {
        $generateForm.on("click", function() {
            var form = JSON.parse($formJsonSchema.val());
            var validations = JSON.parse($validationsJsonSchema.val())
            createForm(form, validations);
        })
    };

    function createForm(form, validations) {
        var options = {
            $formsContainer: $formsContainer,
            formOptions: form,
            validations: validations,
        }
        var formGenerator = new FormGenerator(options);
        formGenerator.CreateForm();
    };

    return index;
});