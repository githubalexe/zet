﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using familiarize.DTO;

namespace familiarize.Models
{
    public class InventoryItem
    {
        public int Id { get; set; }
        public string ItemName { get; set; }
        public double Price { get; set; }

        public string MyFUnction(string myParam)
        {
            return ItemName + Price.ToString();
        }

        //wrong because the DTO won't be in the same project
        //public InventoryItemDTO ToDTO()
        //{
        //    return new InventoryItemDTO
        //    {
        //        Name = ItemName
        //    };
        //}
    }
}
