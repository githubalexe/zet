﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using familiarize.Models;
using familiarize.Repository;

namespace familiarize.Services
{
    public class InventoryServices : IInventoryServices
    {
        //used for business rules implementation
        private readonly Dictionary<string, InventoryItem> _inventoryItems;

        private readonly IInventoryItemsRepository myRepo;


        //repositories most probably will be used inside and be given to the constructor of the service
        public InventoryServices(IInventoryItemsRepository repo)
        {
            myRepo = repo;

            _inventoryItems = new Dictionary<string, InventoryItem>();
        }

        public async Task<InventoryItem> AddInventoryItemsAsync(InventoryItem items)
        {
            InventoryItem myItem = await myRepo.GetAsync(Guid.NewGuid());

            //myItem is not yet obtained


            _inventoryItems.Add(items.ItemName, items);

            return items;
        }
    }
}
