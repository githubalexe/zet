﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using familiarize.Models;

namespace familiarize.Repository
{
    public interface IInventoryItemsRepository
    {
        //CRUD operations
        //start with the GET
        Task<InventoryItem> GetAsync(Guid id);
    }
}
