﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using familiarize.DTO;
using familiarize.Models;

namespace familiarize.ExtensionMethods
{
    public static class InventoryItemExtensionMethods
    {
        private readonly static double PINumber = 3.14;

        public static InventoryItemDTO ToDTO(this InventoryItem item)
        {
            return new InventoryItemDTO
            {
                Name = item.ItemName
            };
        }
    }
}
