﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using familiarize.DTO;
using familiarize.Models;
using familiarize.Repository;
using familiarize.Services;
using Microsoft.AspNetCore.Mvc;
using familiarize.ExtensionMethods;

namespace familiarize.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InventoryController : ControllerBase
    {
        private readonly InventoryServices _services;
        private readonly IInventoryItemsRepository _inventoryItemsRepository;

        public InventoryController(InventoryServices services, IInventoryItemsRepository inventoryItemsRepository)
        {
            _services = services;
            _inventoryItemsRepository = inventoryItemsRepository;
        }

        [HttpPost]
        public ActionResult<InventoryItemDTO> AddInventoryItems(InventoryItem items)
        {
            var inventoryItems = _services.AddInventoryItems(items);

            if (inventoryItems == null) return NotFound();

            InventoryItem myDBItem = new InventoryItem();

            InventoryItemDTO result = myDBItem.ToDTO();

            return Ok(result);
        }

        [HttpGet]
        public ActionResult<Dictionary<string, InventoryItemDTO>> GetInventoryItems()
        {

        }

    //// GET api/values
        //[HttpGet]
        //public ActionResult<IEnumerable<string>> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        //// GET api/values/5
        //[HttpGet("{id}")]
        //public ActionResult<string> Get(int id)
        //{
        //    return "value";
        //}

        //// POST api/values
        //[HttpPost]
        //public void Post([FromBody] string value)
        //{
        //}

        //// PUT api/values/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        //// DELETE api/values/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
    }
}
