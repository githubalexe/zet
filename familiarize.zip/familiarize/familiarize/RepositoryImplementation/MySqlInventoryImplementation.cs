﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using familiarize.Models;
using familiarize.Repository;

namespace familiarize.RepositoryImplementation
{
    public class MySqlInventoryImplementation:IInventoryItemsRepository
    {
        //db context from entity framework

        public Task<InventoryItem> GetAsync(Guid id)
        {
            throw new NotImplementedException();
        }
    }
}
