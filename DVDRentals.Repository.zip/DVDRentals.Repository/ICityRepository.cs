﻿using DVDRentals.Domain;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICityRepository
    {
        IQueryable<City> CitiesQuery();
        Task<IEnumerable<City>> ListActorAsync(IQueryable<City> query, bool asNoTracking = false);
        Task<City> GetCityAsync(int cityId);
        Task<bool> CityExistsAsync(int cityId);
        Task CreateCityAsync(City filmActor);
        void DeleteCity(City filmActor);
    }
}
