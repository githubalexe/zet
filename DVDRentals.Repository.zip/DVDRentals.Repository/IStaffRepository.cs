﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IStaffRepository
    {
        IQueryable<Staff> RentalsQuery();
        Task<IEnumerable<Staff>> ListStaffsAsync(IQueryable<Staff> query, bool asNoTracking = false);
        Task<Staff> GetStaffAsync(int storeId, int staffId);//ai in vedere ca este pus id de store/cred ca ar trebui sa fie pus in store
        Task<bool> StaffExistsAsync(int staffId);
        Task<bool> AddressExistsAync(int addressId);
        Task CreateStaffAsync(Staff staff); 
        void DeleteStaff(Staff staff);
        Task SaveChangesAsync();
    }
}
       // Task<IEnumerable<Staff>> GetStaffsAsync(int storeId); in store
