﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IInventoryRepository
    {
        IQueryable<Inventory> InventoriesQuery();
        Task<IEnumerable<Inventory>> ListInventoriesAsync(IQueryable<Inventory> query, bool asNoTracking = false);
        Task<Inventory> GetInventoryAsync(int inventoryId);
        Task<bool> InventoryExistsAsync(int inventoryId);
        Task CreateInventoryAsync(Inventory inventory);
        void DeleteInventory(Inventory inventory);
        Task SaveChangesAsync();
    }
}
       // Task<IEnumerable<Inventory>> GetFilmsAsync(int storeId);//added in film
        //Task<IEnumerable<Inventory>> GetInventoriesAsync(int filmId);//it added in filmrepository
