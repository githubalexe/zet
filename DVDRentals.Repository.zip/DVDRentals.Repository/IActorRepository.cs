﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IActorRepository
    {
        IQueryable<Actor> ActorsQuery();
        Task<IEnumerable<Actor>> ListActorsAsync(IQueryable<Actor> query, bool asNoTracking = false);
        Task<Actor> GetActorAsync(int actorId);
        Task CreateActorAsync(Actor actor);
        void DeleteActor(Actor actor);

        IQueryable<FilmActor> FilmsQuery();
        Task<IEnumerable<FilmActor>> ListFilmsAsync(IQueryable<FilmActor> query, int actorId, bool asNoTracking = false);

        Task SaveChangesAsync();
    }
}
