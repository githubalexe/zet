﻿using DVDRentals.Domain;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICountryRepository
    {
        IQueryable<Country> CountriesQuery();
        Task<IEnumerable<Country>> ListCountriesAsync(IQueryable<Country> query, bool asNoTracking = false);
        Task<Country> GetCountryAsync(int countryId);
        Task CreateCountryAsync(Country country);
        void DeleteCountry(Country country);
        Task SaveChangesAsync();
    }
}
