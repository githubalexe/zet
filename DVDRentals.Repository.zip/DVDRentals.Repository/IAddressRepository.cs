﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IAddressRepository
    {
        IQueryable<Address> AddressesQuery();
        Task<IEnumerable<Address>> ListAddressesAsync(IQueryable<Address> query, bool asNoTracking = false);
        Task<Address> GetAddressAsync(int addressId);
        Task<bool> AddressExistsAsync(int addressId);
        Task CreateAddressAsync(Address address);
        void DeleteAddress(Address address);
        Task SaveChangesAsync();
    }
}
