﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IRentalRepository
    {
        IQueryable<Rental> RentalsQuery();
        Task<IEnumerable<Rental>> ListActorAsync(IQueryable<Rental> query, bool asNoTracking = false);
        Task<Rental> GetRentalAsync(int? rentalId);
        Task<bool> RentalExistsAsync(int? rentalId);
        Task CreateRentalAsync(Rental rental);
        void DeleteRental(Rental rental);
        Task SaveChangesAsync();
    }
}
     //   Task<IEnumerable<Rental>> GetInventoryRentalsAsync(int inventoryId); in inventory
      //  Task<IEnumerable<Rental>> GetCustomerRentalsAsync(int customerId); in customer
      //  Task<IEnumerable<Rental>> GetStaffRentalsAsync(int staffId); in staff
