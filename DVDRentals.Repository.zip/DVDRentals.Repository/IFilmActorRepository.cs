﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmActorRepository
    {
        Task<FilmActor> GetFilmActorAsync(int filmId, int actorId);//add in film
        Task<IEnumerable<FilmActor>> GetActorsAsync(int actorId);//add in actor
        Task<IEnumerable<FilmActor>> GetFilmsAsync(int filmId);//add in film
        void AddFilmActor(FilmActor filmActor);//add in film
        void UpdateFilmActor(FilmActor filmActor);//add in film
        void DeleteFilmActor(FilmActor filmActor);//add in film
        void SaveChanges();
    }
}
