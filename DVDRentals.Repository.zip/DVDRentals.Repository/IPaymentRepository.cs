﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IPaymentRepository
    {
        IQueryable<Payment> PaymentsQuery();
        Task<IEnumerable<Payment>> ListPaymentsAsync(IQueryable<Payment> query, bool asNoTracking = false);
        Task<Payment> GetPaymentAsync(int paymentId);
        Task CreatePaymenAsynct(Payment payment);
        void DeletePayment(Payment payment);
        Task SaveChangesAsync();
    }
}
// Task<Payment> GetStaffPaymentAsync(int staffId, int paymentId);//put in staff
// Task<Payment> GetCustomerPaymentAsync(int customerId, int paymentId);//put in customer
//Task<IEnumerable<Payment>> GetCustomerPaymentsAsync(int customerId); in customer
//Task<IEnumerable<Payment>> GetStaffPaymentsAsync(int staffId); in staff
