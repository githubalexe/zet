﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICustomerRepository
    {
        IQueryable<Customer> CustomersQuery();
        Task<IEnumerable<Customer>> ListCustomersAsync(IQueryable<Customer> query, bool asNoTracking = false);
        Task<Customer> GetCustomerAsync(int customerId);
        Task<bool> CustomerExistsAsync(int customerId);
        Task<bool> AddressExistsAsync(int addressId);
        void CreateCustomerAsync(Customer customer);
        void DeleteCustomer(Customer customer);
        Task SaveChangesAsync();
    }
}
        //Task<IEnumerable<Customer>> GetCustomersAsync(int storeId);//add in store
