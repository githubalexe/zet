function ColorPicker(options) {
    this.container = options.$container;
    this.target = options.$colorPicker;
    this.width = options.firstWidth;
    this.height = options.firstHeight;
    this.target.width = options.secondWidth;
    this.target.height = options.secondHeight;
    this.context = this.target[0].getContext("2d");
    this.pickerCircle = { x: 10, y: 10, width: 10, height: 0 };
    options.$container.append(this.buildBody());
    this.addDefaultFirstColors();
    this.addDefaultLastColors();
    this.addDefaultPaletteColors();
    this.draw();
    this.build();
    this.getPickedColor();
    this.listenForEvents();
};

ColorPicker.prototype.defaultPaletteColors = [
    '#F2F2F2', '#7F7F7F', '#D0CECE', '#D6DCE4', '#D9E2F3', '#FBE5D5', '#EDEDED', '#FFF2CC', '#DEEBF6', '#E2EFD9', '#D8D8D8', '#595959', '#AEABAB', '#ADB9CA', '#B4C6E7', '#F7CBAC', '#DBDBDB', '#FEE599', '#BDD7EE', '#C5E0B3', '#BFBFBF', '#3F3F3F', '#757070', '#8496B0', '#8EAADB', '#F4B183', '#C9C9C9', '#FFD965', '#9CC3E5', '#A8D08D', '#A5A5A5', '#262626', '#3A3838', '#323F4F', '#2F5496', '#C55A11', '#7B7B7B', '#BF9000', '#2E75B5', '#538135', '#7F7F7F', '#0C0C0C', '#171616', '#222A35', '#1F3864', '#833C0B', '#525252', '#7F6000', '#1E4E79', '#375623',
];

ColorPicker.prototype.defaultFirstColors = [
    '#FFFFFF', '#000000', '#E7E6E6', '#E7E6E6', '#4472C4', '#ED7D31', '#A5A5A5', '#FFC000', '#5B9BD5', '#70AD47',
];

ColorPicker.prototype.defaultLastColors = [
    '#C00000', '#FF0000', '#FFC000', '#FFFF00', '#92D050', '#00B050', '#00B0F0', '#0070C0', '#002060', '#7030A0',
];

ColorPicker.prototype.buildBody = function () {
    var $boxColors = $("<div/>", {
        class: 'box-colors',
    });
    var $clear = $("<div/>", {
        class: 'row',
    }).appendTo($boxColors);
    var $colorPicker = $("<div/>", {
        class: 'colorPick',
    }).appendTo($boxColors);
    var $row1 = $("<div/>", {
        class: 'row',
    }).appendTo($colorPicker);
    var $themeColors = $("<p/>", {
        class: 'title',
        html: 'Theme Colors'
    }).appendTo($row1);
    var $firstColorRow = $("<div/>", {
        class: "colors-row",
        id: "firstColorRow"
    }).appendTo($colorPicker);
    var $defaultFirstColors = $("<div/>", {
        class: "colors default-first-colors",
    }).appendTo($firstColorRow);
    var $defaultPaletteRow = $("<div/>", {
        class: "colors-row",
    }).appendTo($colorPicker);
    var $defaultFirstColors = $("<div/>", {
        class: "colors default-palette-colors",
    }).appendTo($defaultPaletteRow);
    var $row2 = $("<div/>", {
        class: 'row',
    }).appendTo($colorPicker);
    var $standardColors = $("<p/>", {
        class: 'title',
        html: 'Standard Colors'
    }).appendTo($row2);
    var $lastColorRow = $("<div/>", {
        class: "colors-row",
        id: "lastColorRow"
    }).appendTo($colorPicker);
    var $defaultLastColors = $("<div/>", {
        class: "colors default-last-colors",
    }).appendTo($lastColorRow);
    var $defaultLastColors = $("<hr/>", {
    }).appendTo($colorPicker);
    var $moreColorsButton = $("<button>", {
        type: 'submit',
        id: "moreColors",
        
    }).appendTo($colorPicker);
    var $icon = $("<i/>", {
        class: 'fas fa-palette',
        html: 'More colors'
    }).appendTo($moreColorsButton);

    var $canvasArea = $("<div/>", {
        class: "more-colors-area"
    }).appendTo($boxColors);

    var $canvas = $("<canvas>", {
        id: "color-picker"
    }).appendTo($canvasArea);

    $clear.appendTo($colorPicker);
    return $boxColors;
}

function createColors(target, color) {
    var swatch = document.createElement('div');
    swatch.classList.add('color-button');
    swatch.setAttribute('title', color);
    swatch.style.backgroundColor = color;
    swatch.addEventListener('click', function () {
        var color = $(this).css('backgroundColor');
        $('.picker').css('background-color', color);
    });
    target.appendChild(swatch);
};

ColorPicker.prototype.addDefaultPaletteColors = function () {
    for (var i = 0; i < this.defaultPaletteColors.length; ++i) {
        createColors($('.default-palette-colors')[0], this.defaultPaletteColors[i]);
    }
}

ColorPicker.prototype.addDefaultFirstColors = function () {
    for (var i = 0; i < this.defaultFirstColors.length; ++i) {
        createColors($('.default-first-colors')[0], this.defaultFirstColors[i]);
    }
}

ColorPicker.prototype.addDefaultLastColors = function () {
    for (var i = 0; i < this.defaultLastColors.length; ++i) {
        createColors($('.default-last-colors')[0], this.defaultLastColors[i]);
    }
}
function hexc(colorval) {
    var parts = colorval.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
    delete (parts[0]);
    for (var i = 1; i <= 3; ++i) {
        parts[i] = parseInt(parts[i]).toString(16);
        if (parts[i].length == 1) parts[i] = '0' + parts[i];
    }
    color = '#' + parts.join('');
}

ColorPicker.prototype.draw = function () {
    this.build();
}

ColorPicker.prototype.build = function () {
    let gradient = this.context.createLinearGradient(0, 0, this.width, 0);
    gradient.addColorStop(0, "rgb(255, 0, 0)");
    gradient.addColorStop(0.15, "rgb(255, 0, 255)");
    gradient.addColorStop(0.33, "rgb(0, 0, 255)");
    gradient.addColorStop(0.49, "rgb(0, 255, 255)");
    gradient.addColorStop(0.67, "rgb(0, 255, 0)");
    gradient.addColorStop(0.84, "rgb(255, 255, 0)");
    gradient.addColorStop(1, "rgb(255, 0, 0)");
    this.context.fillStyle = gradient;
    this.context.fillRect(0, 0, this.width, this.height);
    gradient = this.context.createLinearGradient(0, 0, 0, this.height);
    gradient.addColorStop(0, "rgba(255, 255, 255, 1)");
    gradient.addColorStop(0.5, "rgba(255, 255, 255, 0)");
    gradient.addColorStop(0.5, "rgba(0, 0, 0, 0)");
    gradient.addColorStop(1, "rgba(0, 0, 0, 1)");
    this.context.fillStyle = gradient;
    this.context.fillRect(0, 0, this.width, this.height);
    this.context.beginPath();
    this.context.arc(this.pickerCircle.x, this.pickerCircle.y, this.pickerCircle.width, 0, Math.PI * 2);
    this.context.strokeStyle = "black";
    this.context.stroke();
    this.context.closePath();
}

ColorPicker.prototype.listenForEvents = function () {
    let isMouseDown = false;
    const onMouseDown = (e) => {
        let currentX = e.clientX - this.target.offsetLeft;

        let currentY = e.clientY - this.target.offsetTop;
        if (currentY > this.pickerCircle.y && currentY < this.pickerCircle.y + this.pickerCircle.width && currentX > this.pickerCircle.x && currentX < this.pickerCircle.x + this.pickerCircle.width) {
            isMouseDown = true;
        } else {
            this.pickerCircle.x = currentX;
            this.pickerCircle.y = currentY;
        }
    }

    const onMouseMove = (e) => {
        if (isMouseDown) {
            let currentX = e.clientX - this.target.offsetLeft;
            let currentY = e.clientY - this.target.offsetTop;
            this.pickerCircle.x = currentX;
            this.pickerCircle.y = currentY;
        }
    }

    const onMouseUp = () => {
        isMouseDown = false;
    }

    this.target.on("mousedown", onMouseDown)
    this.target.on("mousemove", onMouseMove)
    this.target.on("mousemove", () => this.onChangeCallback(this.getPickedColor()));
    document.addEventListener("mouseup", onMouseUp);
}

ColorPicker.prototype.getPickedColor = function () {
    let imageData = this.context.getImageData(this.pickerCircle.x, this.pickerCircle.y, 1, 1);
    return { r: imageData.data[0], g: imageData.data[1], b: imageData.data[2] };
}

ColorPicker.prototype.onChange = function (callback) {
    this.onChangeCallback = callback;
}