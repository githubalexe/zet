
$('.picker').one('click', function () {

    var options = {
        $container: $(".container"),
        $colorPicker: $('#color-picker'),
        firstWidth: 250,
        firstHeight: 220,
        secondWidth: 250,
        secondHeight: 220
    }

    var picker = new ColorPicker(options);
    setInterval(() => picker.draw(), 1);
    picker.onChange((color) => {
        var selected = $("picker")[0];
        selected.style.backgroundColor = `rgb(${color.r}, ${color.g}, ${color.b})`;
    });
});


$('#moreColors').click(function () {
    $('.more-colors-area').css('display', 'table');
});
