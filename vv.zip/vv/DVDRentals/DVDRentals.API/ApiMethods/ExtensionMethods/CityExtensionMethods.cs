﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class CityExtensionMethods
    {
        public static CityCreateRequest ToCityCreateObject(this CustomerFormRequest model, int countryId)
        {
            return new CityCreateRequest
            {
                Name = model.City,
                CountryId = countryId
            };
        }

        public static CityUpdateRequest ToFormCityUpdate(this CustomerFormRequest model, int countryId)
        {
            return new CityUpdateRequest
            {
                Name = model.City,
                CountryId = countryId
            };
        }
    }
}
