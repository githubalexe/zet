﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public  static class CountryExtensionMethods
    {
        public static CountryCreateRequest ToCountryCreateObject(this CustomerFormRequest model)
        {
            return new CountryCreateRequest
            {
                //Country = model.Country
            };
        }

    }
}
