﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class AddressExtensionMethods
    {
        public static AddressCreateRequest ToAddressCreateObject(this CustomerFormRequest model, int cityId)
        {
            return new AddressCreateRequest
            {
                Address1 = model.Address,
                Address2 = model.Address2,
                District = model.Distrinct,
                CityId = cityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }

        public static AddressUpdateRequest ToAddressUpdate(this CustomerFormRequest model, int cityId)
        {
            return new AddressUpdateRequest
            {
                Address1 = model.Address,
                Address2 = model.Address2,
                District = model.Distrinct,
                CityId = cityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }
    }
}
