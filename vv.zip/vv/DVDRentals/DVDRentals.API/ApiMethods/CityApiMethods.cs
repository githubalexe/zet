﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.City;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class CityApiMethods
    {
        public static async Task<IEnumerable<CityResponse>> GetCitiesAsync()
        {
            IEnumerable<CityResponse> cities = new List<CityResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}cities", uri);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    cities = JsonConvert.DeserializeObject<List<CityResponse>>(dataJson);
                }
            }

            return cities;
        }

        public static async Task<CityResponseLite> UpdateCityAsync(CityUpdateRequest request, int cityId)
        {
            CityResponseLite city = new CityResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}cities/{1}", uri, cityId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                city = JsonConvert.DeserializeObject<CityResponseLite>(dataJson);
            }

            return city;
        }

        public static async Task<CityResponseLite> CreateCityAsync(CityCreateRequest request)
        {
            CityResponseLite city = new CityResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/cities", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                city = JsonConvert.DeserializeObject<CityResponseLite>(dataJson);
            }

            return city;
        }
    }
}
