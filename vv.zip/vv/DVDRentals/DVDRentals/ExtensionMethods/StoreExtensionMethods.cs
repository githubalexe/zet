﻿using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;

namespace DVDRentals.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreResponse ToStoreResponseLite(this Store store)
        {
            StoreResponse storeResponse = new StoreResponse()
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                LastUpdate = store.LastUpdate,
            };
            storeResponse.Address = store.Address.ToAddressResponse();
            storeResponse.Address.City = store.Address.City.ToCityResponse();
            storeResponse.Address.City.Country = store.Address.City.Country.ToCountryResponseLite();

            return storeResponse;
        }
        public static StoreResponseLite ToStoreResponse(this Store store)
        {
            return new StoreResponseLite()
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                LastUpdate = store.LastUpdate,
            };
        }

        public static Store ToStoreModel(this StoreUpdateRequest request, Store store)
        {
            store.ManagerStaffId = request.ManagerStaffId;
            store.AddressId = request.AddressId;

            return store;
        }
    }
}
