﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IActorRepository
    {
        IQueryable<Actor> ActorsQuery();
        Task<IEnumerable<Actor>> ActorsListAsync(IQueryable<Actor> query, bool asNoTracking = false);
        Task<Actor> GetActorAsync(int actorId);
        Task CreateActorAsync(Actor actor);
        void DeleteActor(Actor actor);
        Task SaveChangesAsync();
    }
}
