﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CityRepository : ICityRepository
    {
        private UnitOfWork _unitOfWork;
        public CityRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<City> CitiesQuery()
        {
            IQueryable<City> citiesQuery = _unitOfWork.City;
            return citiesQuery;
        }

        public async Task<IEnumerable<City>> CitiesListAsync(IQueryable<City> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Include(c => c.Country)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public async Task<bool> AddressExistsAsync(int cityId)
        {
            return await _unitOfWork.Address.AnyAsync(a => a.CityId == cityId);
        }

        public async Task<bool> CountryExistsAsync(int countryId)
        {
            return await _unitOfWork.Country.AnyAsync(c => c.CountryId == countryId);
        }

        public async Task<City> GetCityAsync(int cityId)
        {
            return await _unitOfWork.City.Include(c => c.Country)
                                         .FirstOrDefaultAsync(c => c.CityId == cityId);
        }

        public async Task CreateCityAsync(City city)
        {
            await _unitOfWork.City.AddAsync(city);
        }

        public void DeleteCity(City city)
        {
            _unitOfWork.City.Remove(city);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
