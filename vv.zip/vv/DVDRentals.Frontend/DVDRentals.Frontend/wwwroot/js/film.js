﻿$(document).ready(function () {

    var $options = {
        $container: $("#filmDeleteContainer"),
        $kendoGrid: "filmsGrid",
    }

    $("#deleteFilm").on("click", function () {
        new DeleteModal($options);
        $("#deleteModal").modal("show");
    });


    //$("#deleteFilm").on("click", function () {

    //    var $grid = $("#filmsGrid tr.k-state-selected"),
    //        $kendoGridData = $("#filmsGrid").data("kendoGrid");

    //    var selectedItems = [];
    //    for (var i = 0; i < $grid.length; i++) {
    //        var item = $kendoGridData.dataItem($grid[i]);
    //        selectedItems.push(item);
    //    }

    //    for (var i = 0; i < selectedItems.length; i++) {

    //        deleteFilm(selectedItems[i].FilmId);
    //        console.log(selectedItems[i].Title);
    //    }

    //});


    //function deleteFilm(filmId) {
    //    $.ajax({
    //        type: "DELETE",
    //        url: "/Film/Delete/" + filmId,
    //    })
    //        .done(function () {
    //            $("#filmsGrid").data("kendoGrid").refresh();
    //            $("#filmsGrid").data("kendoGrid").dataSource.read();
    //        })
    //        .fail(function () {
    //            console.log("Esti bou!");
    //        })
    //}

});