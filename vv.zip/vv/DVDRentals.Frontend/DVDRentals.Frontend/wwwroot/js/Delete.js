﻿$(function () {

    DeleteModal = function (options) {
        var self = this;

        self.$container = options.$container;
        self.kendoGrid = options.kendoGrid;

        self.buildBody();
        self.getClickedItems();
    }

    DeleteModal.prototype.buildBody = function () {
        var self = this;

        var modalBody =
            `<div class="container">
                <div id="deleteModal" role="dialog" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Delete ${this.$container.val()}</h5>
                            </div>
                            <div class="modal-body">
                                <p class="selected-items">WARNING: Entity
                                will be deleted.There is no way to recover the ${this.entity} after delition.</p>
                            </div>
                            <div class="modal-footer">
                                <div class="container text-right px-3 pb-4">
                                    <hr />
                                    <button type="button" data-dismiss="modal" class="btn modal-button cancel">Cancel</button>
                                    <button type="submit" form="customerCreateForm" class="btn modal-button submit create">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`

        this.$container.append(modalBody);
    }

    DeleteModal.prototype.getClickedItems = function () {
        var title = "";
        var $grid = $("#filmsGrid tr.k-state-selected"),
            $kendoGridData = $("#filmsGrid").data("kendoGrid");

        for (var i = 0; i < $grid.length; i++) {
            var item = $kendoGridData.dataItem($grid[i]);

            //selectedItems.push(item);
            title = "<p>" + item.Title + "</p>";

            console.log(title);

            $(".selected-items").append(title);
        }

        console.log("intra");
            //$("#" + this.kendoGrid).val(item);
    }



    //DeleteModal.prototype.deleteItem = function (id) {

    //    $.ajax({
    //        type: "DELETE",
    //        url: "/Film/Delete/" + id,
    //    })
    //        .done(function () {
    //            $("#filmsGrid").data("kendoGrid").refresh();
    //            $("#filmsGrid").data("kendoGrid").dataSource.read();
    //        })
    //        .fail(function () {
    //            console.log("Esti bou!");
    //        })
    //}

}());