
function resetFields()
{
    document.getElementById("firstName").value='';
    document.getElementById("lastName").value='';
    document.getElementById("gender").value='';
    document.getElementById("birthDate").value='';
    document.getElementById("role").value='';
}


function validateForm() {
    var x = document.getElementById("firstName","lastName","gender","birthDate","role").value;
    if (x == "") {
        alert("Field must be filled out");
        return false;
    }
}
