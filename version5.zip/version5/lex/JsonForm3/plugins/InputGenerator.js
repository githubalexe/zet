define(["InputHelper", "InputFactory", "bootstrap"], function(InputHelper, InputFactory) {

    function InputGenerator(options) {

        this.$generateButton = options.$generateButton;
        this.$textInput = options.$textInput;
        this.$inputsContainer = options.$inputsContainer;
        this.$clearButton = options.$clearButton;
        this.$itemTemplate = options.$itemTemplate;
        this.jsonOptions = {};
        this.onInputAppended = null;

        this.bindEvents();
    };

    InputGenerator.prototype.bindEvents = function() {

        var self = this;

        self.$generateButton.on("click", function() {

            var value = self.$textInput.val();

            self.getJsonFromValue(value);

        });
    };

    InputGenerator.prototype.getJsonFromValue = function(value) {

        if (InputHelper.IsJson(value)) {

            this.jsonOptions = JSON.parse(value);

            this.createInput();

        } else {
            //error
        }
    };

    InputGenerator.prototype.createInput = function() {

        var self = this;

        if (InputHelper.IsArray(self.jsonOptions)) {

            var inputs = [...self.jsonOptions];

            for (i = 0; i < inputs.length; i++) {

                var containers = self.createContainer();

                var jsonObject = {
                    mainContainer: containers.mainContainer,
                    templateContainer: containers.templateContainer,
                    jsonOptions: inputs[i]
                };

                InputFactory.LoadFileInput(jsonObject, function() {
                    self.onInputAppended(jsonObject);
                });

            }
        } else {

            var containers = self.createContainer();

            var jsonObject = {
                mainContainer: containers.mainContainer,
                templateContainer: containers.templateContainer,
                jsonOptions: self.jsonOptions
            };

            InputFactory.LoadFileInput(jsonObject);
        }
    };

    InputGenerator.prototype.createContainer = function() {

        var $mainContainer = $("<div/>", {
            id: InputHelper.CreateGuid(),
            class: "form-grup"
        });

        var $templateContainer = $("<div/>", {
            class: "template"
        });

        var $settingsContainer = this.addSettings();

        $mainContainer.append($templateContainer, $settingsContainer);

        this.$inputsContainer.append($mainContainer);

        var containers = {
            mainContainer: $mainContainer,
            templateContainer: $templateContainer
        }

        return containers;
    };

    InputGenerator.prototype.addSettings = function() {

        var $settingsContainer = $("<div/>", {
            class: "settings-container"
        });

        var $setButton = $("<button/>", {
            class: "btn btn-primary button",
            html: "Set Value",
            name: "setValue"
        });

        var $getButton = $("<button/>", {
            class: "btn btn-success button",
            html: "Get Value",
            name: "getValue"
        });

        var $input = $("<input/>", {
            name: "input"
        });

        var $removeButton = $("<button/>", {
            class: "btn btn-danger remove-button",
            html: "Remove",
            name: "remove"
        });

        $settingsContainer.append($setButton, $getButton, $input, $removeButton);

        return $settingsContainer;
    };


    return InputGenerator;
});