define(["jquery", "InputGenerator", "CodeMirror", "bootstrap"], function($, InputGenerator, CodeMirror) {

    var $textInput = $("#textInput");
    var $clearButton = $("#clearButton");
    var $generateButton = $("#generateButton");
    var $inputsContainer = $("#inputsContainer");
    var $itemTemplate = $("#itemTemplate");

    function initializeInputGenerator() {

        var options = {
            $generateButton: $generateButton,
            $textInput: $textInput,
            $inputsContainer: $inputsContainer,
            $clearButton: $clearButton,
            $itemTemplate: $itemTemplate,

            onAddingSettings: function(control) {

                addSettings(control)
            }
        }

        return options;
    }

    getSucces();

    function getSucces() {

        var options = initializeInputGenerator();

        new InputGenerator(options);
    }

    function addSettings(control) {

        var $settingsContainer = $("<div/>", {
            class: "settings-container"
        });

        var $setButton = $("<button/>", {
            class: "btn btn-primary button",
            html: "Set Value",
            id: "setValue-" + control.inputId
        });

        var $getButton = $("<button/>", {
            class: "btn btn-success button",
            html: "Get Value",
            id: "getValue-" + control.inputId
        });

        var $input = $("<input/>", {
            id: "second-" + control.inputId
        });

        var $removeButton = $("<button/>", {
            class: "btn btn-danger remove-button",
            html: "Remove",
        });

        $settingsContainer.append($setButton, $getButton, $input, $removeButton);

        control.GetContainerId().append($settingsContainer);
    };


    function setValue(control) {

        console.log(control);
    };

    function getValue() {

        console.log("get value");

    };
});