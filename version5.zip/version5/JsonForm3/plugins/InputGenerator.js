define(["InputHelper", "InputFactory", "bootstrap"], function(InputHelper, InputFactory) {

    function InputGenerator(options) {

        this.options = $.extend({}, true, InputGenerator.defaultOptions, options);

        this.$generateButton = this.options.$generateButton;
        this.$textInput = this.options.$textInput;
        this.$inputsContainer = this.options.$inputsContainer;
        this.$clearButton = this.options.$clearButton;
        this.$itemTemplate = this.options.$itemTemplate;
        this.onAddingSettings = this.options.onAddingSettings;

        this.jsonOptions = {};

        this.controls = [];

        this.bindEvents();
    };

    InputGenerator.prototype.bindEvents = function() {

        var self = this;

        self.$generateButton.on("click", function() {

            var value = self.$textInput.val();

            self.getJsonFromValue(value);

        });
    };

    InputGenerator.prototype.getJsonFromValue = function(value) {

        if (InputHelper.IsJson(value)) {

            this.jsonOptions = JSON.parse(value);

            this.createInput();

        } else {
            //error
        }
    };

    InputGenerator.prototype.createInput = function() {

        var self = this;

        if (InputHelper.IsArray(self.jsonOptions)) {

            var inputs = [...self.jsonOptions];

            for (i = 0; i < inputs.length; i++) {

                var $templateContainer = self.createTemplateContainer();

                var jsonObject = {
                    $templateContainer: $templateContainer,
                    jsonOptions: inputs[i]
                };

                InputFactory.LoadFileInput(jsonObject, function(control) {
                    self.controls.push(control);
                    self.onAddingSettings(control);

                });
            }
        } else {

            var containers = {};

            var jsonObject = {
                $templateContainer: containers.$templateContainer,
                jsonOptions: self.jsonOptions
            };

            InputFactory.LoadFileInput(jsonObject, self.getInputControl);
        }
    };

    InputGenerator.prototype.getDomElementByID = function(control) {

        this.controls.push(control);
    };

    InputGenerator.prototype.getControlById = function(control) {


    };

    InputGenerator.prototype.createTemplateContainer = function() {

        var $templateContainer = $("<div/>", {
            class: "template-container"
        });

        this.$inputsContainer.append($templateContainer);

        return $templateContainer;
    };

    InputGenerator.defaultOptions = {

        $generateButton: $({}),
        $textInput: $({}),
        $inputsContainer: $({}),
        $clearButton: $({}),
        $itemTemplate: $({}),
        onAddingSettings: null,
    };

    return InputGenerator;
});