define(["InputsType"], function(InputsType) {

    var InputFactory = {};

    InputFactory.LoadFileInput = function(options, callback) {

        var inputType = options.jsonOptions.type;

        switch (inputType) {
            case InputsType.TextBox:
                {
                    require(["TextBoxInput"], function(TextBoxInput) {

                        var textboxInput = new TextBoxInput(options);
                        callback(textboxInput);
                    })
                }
                break;

            case InputsType.DropDownList:
                {
                    require(["DropDownListInput"], function(DropDownListInput) {

                        new DropDownListInput(options);
                    })
                }
                break;

            default:
                // code block
        }
    };

    return InputFactory;
});