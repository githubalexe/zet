var PhotoEditor = (function () {

    function PhotoEditor(options) {

        var self = this;
        self.$container = options.$container;
        self.brightness = 100;
        self.contrast = 100;
        self.saturate = 100;
        self.sepia = 0;
        self.gray = 0;
        self.invert = 0;
        self.hueRotate = 0;
        self.blur = 0;

        self.buildBody();
        self.convertImageToCanvas();
        self.setFilters();
        editFilters(self);
    }

    PhotoEditor.prototype.buildBody = function () {

        var self = this;
        var $editorContainer = $('<div/>', {
            class: 'editor-container'
        });
        var $filtersTitle = $('<p/>', {
            class: 'title'
        });
        $filtersTitle.text('Edit');
        var $efectsTitle = $('<p/>', {
            class: 'title'
        });
        $efectsTitle.text('Filters');
        var filters = document.createElement('div');
        filters.classList.add('filters');
        var $filters = $('<div/>', {
            class: 'filters'
        });
        var $effects = $('<div/>', {
            class: 'effects'
        });
        var $submitButtons = $('<div/>', {
            class: 'submit-buttons'
        });
        var $imageContainer = $('<canvas/>', {
            id: 'imageCanvas'
        });

        var $brightnessContainer = $('<div/>', {
            class: 'button-container'
        });
        var $brightnessLabel = $('<label/>', {
            class: 'label'
        });
        $brightnessLabel.text('Brightness');
        var $minusBrightnessButton = $('<button/>', {
            id: 'minusBrightnessButton',
            class: 'minus-button button',
        });
        $minusBrightnessButton.text('-');
        var $plusBrightnessButton = $('<button/>', {
            id: 'plusBrightnessButton',
            class: 'plus-button button',
        });
        $plusBrightnessButton.text('+');

        var $brightnessFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'brightnessFilterValue'
        });

        $brightnessFilterValue.text('100%');

        var $contrastFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'contrastFilterValue'
        });
        $contrastFilterValue.text('100%');

        var $saturateFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'saturateFilterValue'
        });
        $saturateFilterValue.text('100%');

        var $sepiaFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'sepiaFilterValue'
        });
        $sepiaFilterValue.text('0%');

        var $grayFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'grayFilterValue'
        });
        $grayFilterValue.text('0%');

        var $invertFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'invertFilterValue'
        });
        $invertFilterValue.text('0%');

        var $hueRotateFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'hueRotateFilterValue'
        });
        $hueRotateFilterValue.text('0deg');

        var $blurFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'blurFilterValue'
        });
        $blurFilterValue.text('0px');

        var $contrastContainer = $('<div/>', {
            class: 'button-container'
        });
        var $contrastLabel = $('<label/>', {
            class: 'label'
        });
        $contrastLabel.text('Contrast');
        var $minusContrastButton = $('<button/>', {
            id: 'minusContrastButton',
            class: 'minus-button button',
        });
        $minusContrastButton.text('-');
        var $plusContrastButton = $('<button/>', {
            id: 'plusContrastButton',
            class: 'plus-button button',
        });
        $plusContrastButton.text('+');

        var $saturationContainer = $('<div/>', {
            class: 'button-container'
        });
        var $saturationLabel = $('<label/>', {
            class: 'label'
        });
        $saturationLabel.text('Saturate');
        var $minusSaturateButton = $('<button/>', {
            id: 'minusSaturateButton',
            class: 'minus-button button',
        });
        $minusSaturateButton.text('-');
        var $plusSaturateButton = $('<button/>', {
            id: 'plusSaturateButton',
            class: 'plus-button button',
        });
        $plusSaturateButton.text('+');

        var $sepiaContainer = $('<div/>', {
            class: 'button-container'
        });
        var $sepiaLabel = $('<label/>', {
            class: 'label'
        });
        $sepiaLabel.text('Sepia');
        var $minusSepiaButton = $('<button/>', {
            id: 'minusSepiaButton',
            class: 'minus-button button',
        });
        $minusSepiaButton.text('-');
        var $plusSepiaButton = $('<button/>', {
            id: 'plusSepiaButton',
            class: 'plus-button button',
        });
        $plusSepiaButton.text('+');

        var $grayContainer = $('<div/>', {
            class: 'button-container'
        });
        var $grayLabel = $('<label/>', {
            class: 'label'
        });
        $grayLabel.text('Grayscale');
        var $minusGrayButton = $('<button/>', {
            id: 'minusGrayButton',
            class: 'minus-button button',
        });
        $minusGrayButton.text('-');
        var $plusGrayButton = $('<button/>', {
            id: 'plusGrayButton',
            class: 'plus-button button',
        });
        $plusGrayButton.text('+');

        var $invertContainer = $('<div/>', {
            class: 'button-container'
        });
        var $invertLabel = $('<label/>', {
            class: 'label'
        });
        $invertLabel.text('Invert');
        var $minusInvertButton = $('<button/>', {
            id: 'minusInvertButton',
            class: 'minus-button button',
        });
        $minusInvertButton.text('-');
        var $plusInvertButton = $('<button/>', {
            id: 'plusInvertButton',
            class: 'plus-button button',
        });
        $plusInvertButton.text('+');

        var $hueRotateContainer = $('<div/>', {
            class: 'button-container'
        });
        var $hueRotateLabel = $('<label/>', {
            class: 'label'
        });
        $hueRotateLabel.text('Hue Rotate');
        var $minusHueRotateButton = $('<button/>', {
            id: 'minusHueRotateButton',
            class: 'minus-button button',
        });
        $minusHueRotateButton.text('-');
        var $plusHueRotateButton = $('<button/>', {
            id: 'plusHueRotateButton',
            class: 'plus-button button',
        });
        $plusHueRotateButton.text('+');

        var $blurContainer = $('<div/>', {
            class: 'button-container'
        });
        var $blurLabel = $('<label/>', {
            class: 'label'
        });
        $blurLabel.text('Blur');
        var $minusBlurButton = $('<button/>', {
            id: 'minusBlurButton',
            class: 'minus-button button',
        });
        $minusBlurButton.text('-');
        var $plusBlurButton = $('<button/>', {
            id: 'plusBlurButton',
            class: 'plus-button button',
        });
        $plusBlurButton.text('+');

        var $adenEfectButton = $('<button/>', {
            id: 'adenEfectButton',
            class: 'effect-button',
        });
        $adenEfectButton.text('Aden');

        var $amaroEffectButton = $('<button/>', {
            id: 'amaroEffectButton',
            class: 'effect-button',
        });
        $amaroEffectButton.text('Amaro');

        var $inkwellEffectButton = $('<button/>', {
            id: 'inkwellEffectButton',
            class: 'effect-button',
        });
        $inkwellEffectButton.text('Inkwell');

        var $reyesbirdEffectButton = $('<button/>', {
            id: 'reyesbirdEffectButton',
            class: 'effect-button',
        });
        $reyesbirdEffectButton.text('Reyes');

        var $saveButton = $('<button/>', {
            id: 'saveButton',
            class: 'effect-button',
        });
        $saveButton.text('Save');
        var $removeEffectsButton = $('<button/>', {
            id: 'removeEffectsButton',
            class: 'effect-button',
        });
        $removeEffectsButton.text('Remove Filters');

        $brightnessContainer.append($minusBrightnessButton, $brightnessLabel, $plusBrightnessButton, $brightnessFilterValue);
        $contrastContainer.append($minusContrastButton, $contrastLabel, $plusContrastButton, $contrastFilterValue);
        $saturationContainer.append($minusSaturateButton, $saturationLabel, $plusSaturateButton, $saturateFilterValue);
        $sepiaContainer.append($minusSepiaButton, $sepiaLabel, $plusSepiaButton, $sepiaFilterValue);
        $grayContainer.append($minusGrayButton, $grayLabel, $plusGrayButton, $grayFilterValue);
        $invertContainer.append($minusInvertButton, $invertLabel, $plusInvertButton, $invertFilterValue);
        $hueRotateContainer.append($minusHueRotateButton, $hueRotateLabel, $plusHueRotateButton, $hueRotateFilterValue);
        $blurContainer.append($minusBlurButton, $blurLabel, $plusBlurButton, $blurFilterValue);
        $filters.append($brightnessContainer, $contrastContainer, $saturationContainer, $sepiaContainer, $grayContainer, $invertContainer, $hueRotateContainer, $blurContainer);
        $effects.append($adenEfectButton, $amaroEffectButton, $inkwellEffectButton, $reyesbirdEffectButton);
        $submitButtons.append($removeEffectsButton, $saveButton);
        $editorContainer.append($imageContainer, $filtersTitle, $filters, $efectsTitle, $effects, $submitButtons);
        self.$container.append($editorContainer);
    }

    PhotoEditor.prototype.decreaseBrightness = function () {
        var self = this;
        self.brightness = self.brightness - 10;
        if (self.brightness < 10) {
            self.brightness = 10;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseBrightness = function () {
        var self = this;
        self.brightness = self.brightness + 10;
        if (self.brightness > 300) {
            self.brightness = 300;
        }
        self.getImage();
    }

    PhotoEditor.prototype.decreaseContrast = function () {
        var self = this;
        self.contrast = self.contrast - 10;
        if (self.contrast < 10) {
            self.contrast = 10;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseContrast = function () {
        var self = this;
        self.contrast = self.contrast + 10;
        if (self.contrast > 300) {
            self.contrast = 300;
        }
        self.getImage();
    }

    PhotoEditor.prototype.decreaseSaturate = function () {
        var self = this;
        self.saturate = self.saturate - 10;
        if (self.saturate < 10) {
            self.saturate = 10;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseSaturate = function () {
        var self = this;
        self.saturate = self.saturate + 10;
        if (self.saturate > 300) {
            self.saturate = 300;
        }
        self.getImage();
    }

    PhotoEditor.prototype.decreaseSepia = function () {
        var self = this;
        self.sepia = self.sepia - 10;
        if (self.sepia < 0) {
            self.sepia = 0;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseSepia = function () {
        var self = this;
        self.sepia = self.sepia + 10;
        if (self.sepia > 300) {
            self.sepia = 300;
        }
        self.getImage();
    }

    PhotoEditor.prototype.decreaseGrayscale = function () {
        var self = this;
        self.gray = self.gray - 10;
        if (self.gray < 0) {
            self.gray = 0;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseGrayscale = function () {
        var self = this;
        self.gray = self.gray + 10;
        if (self.gray > 100) {
            self.gray = 100;
        }
        self.getImage();
    }

    PhotoEditor.prototype.decreaseInvert = function () {
        var self = this;
        self.invert = self.invert - 10;
        if (self.invert < 0) {
            self.invert = 0;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseInvert = function () {
        var self = this;
        self.invert = self.invert + 10;
        if (self.invert > 100) {
            self.invert = 100;
        }
        self.getImage();
    }

    PhotoEditor.prototype.decreaseHueRotate = function () {
        var self = this;
        self.hueRotate = self.hueRotate - 10;
        if (self.hueRotate < 0) {
            self.hueRotate = 0;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseHueRotate = function () {
        var self = this;
        self.hueRotate = self.hueRotate + 10;
        if (self.blur > 10) {
            self.blur = 10;
        }
        self.getImage();
    }

    PhotoEditor.prototype.decreaseBlur = function () {
        var self = this;
        self.blur = self.blur - 1;
        if (self.blur < 0) {
            self.blur = 0;
        }
        self.getImage();
    }

    PhotoEditor.prototype.increaseBlur = function () {
        var self = this;
        self.blur = self.blur + 1;
        if (self.blur > 10) {
            self.blur = 10;
        }
        self.getImage();
    }

    function editFilters(self) {

        self.$container.on('click', '#minusBrightnessButton', function () {
            self.decreaseBrightness();
        });

        self.$container.on('click', '#plusBrightnessButton', function () {
            self.increaseBrightness();
        });

        self.$container.on('click', '#minusContrastButton', function () {
            self.decreaseContrast();
        });

        self.$container.on('click', '#plusContrastButton', function () {
            self.increaseContrast();
        });

        self.$container.on('click', '#minusSaturateButton', function () {
            self.decreaseSaturate();
        });

        self.$container.on('click', '#plusSaturateButton', function () {
            self.increaseSaturate();
        });

        self.$container.on('click', '#minusSepiaButton', function () {
            self.decreaseSepia();
        });

        self.$container.on('click', '#plusSepiaButton', function () {
            self.increaseSepia();
        });

        self.$container.on('click', '#minusGrayButton', function () {
            self.decreaseGrayscale();
        });

        self.$container.on('click', '#plusGrayButton', function () {
            self.increaseGrayscale();
        });

        self.$container.on('click', '#minusInvertButton', function () {
            self.decreaseInvert();
        });

        self.$container.on('click', '#plusInvertButton', function () {
            self.increaseInvert();
        });

        self.$container.on('click', '#minusHueRotateButton', function () {
            self.decreaseHueRotate();
        });

        self.$container.on('click', '#plusHueRotateButton', function () {
            self.increaseHueRotate();
        });

        self.$container.on('click', '#minusBlurButton', function () {
            self.decreaseBlur();
        });

        self.$container.on('click', '#plusBlurButton', function () {
            self.increaseBlur();
        });

        self.$container.on('click', '#removeEffectsButton', function () {
            self.resetFilters(100, 100, 100, 0, 0, 0, 0, 0);
        });

        self.$container.on('click', '#saveButton', function () {

            localStorage.setItem('imageSrc', self.getImage());
            window.close();
        });
    }

    PhotoEditor.prototype.resetFilters = function (brightness, contrast, saturate, sepia, gray, invert, hueRotate, blur) {
        var self = this;

        self.brightness = brightness;
        self.contrast = contrast;
        self.saturate = saturate;
        self.sepia = sepia;
        self.gray = gray;
        self.invert = invert;
        self.hueRotate = hueRotate;
        self.blur = blur;
        self.getImage();
    }

    PhotoEditor.prototype.setFilters = function () {

        var self = this;

        self.$container.on('click', '#adenEfectButton', function () {
            self.resetFilters(120, 90, 80, 0, 0, 0, 20, 0);
        });

        self.$container.on('click', '#amaroEffectButton', function () {
            self.resetFilters(110, 90, 150, 0, 0, 0, 0, 0);
        });

        self.$container.on('click', '#inkwellEffectButton', function () {
            self.resetFilters(110, 110, 100, 30, 100, 0, 0, 0);
        });

        self.$container.on('click', '#reyesbirdEffectButton', function () {
            self.resetFilters(110, 90, 80, 20, 0, 0, 0, 0);
        });
    }

    PhotoEditor.prototype.getImage = function () {
        var self = this;
        var srcValue = localStorage.getItem('imageSrc');
        var $canvas = $('#imageCanvas', self.$container)[0];
        var ctx = $canvas.getContext('2d');
        var image = new Image();

        image.src = srcValue;
        $canvas.width = image.width;
        $canvas.height = image.height;
        ctx.filter = 'brightness(' + self.brightness + '%' + ') contrast(' + self.contrast + '%' + ') saturate(' + self.saturate + '%' + ') sepia(' + self.sepia + '%' + ') grayscale(' + self.gray + '%' + ') invert(' + self.invert + '%' + ') hue-rotate(' + self.hueRotate + 'deg' + ') blur(' + self.blur + 'px' + ')';
        ctx.drawImage(image, 0, 0, $canvas.width, $canvas.height);
        var data = $canvas.toDataURL(image.src);

        self.displayFilters();
        return data;
    }

    PhotoEditor.prototype.displayFilters = function () {
        var self = this;
        var $brightnessFilterValue = $('#brightnessFilterValue', self.$container);
        var $contrastFilterValue = $('#contrastFilterValue', self.$container);
        var $saturateFilterValue = $('#saturateFilterValue', self.$container);
        var $sepiaFilterValue = $('#sepiaFilterValue', self.$container);
        var $grayFilterValue = $('#grayFilterValue', self.$container);
        var $hueRotateFilterValue = $('#hueRotateFilterValue', self.$container);
        var $invertFilterValue = $('#invertFilterValue', self.$container);
        var $blurFilterValue = $('#blurFilterValue', self.$container);

        $brightnessFilterValue.html(self.brightness + '%');
        $contrastFilterValue.html(self.contrast + '%');
        $saturateFilterValue.html(self.saturate + '%');
        $sepiaFilterValue.html(self.sepia + '%');
        $grayFilterValue.html(self.gray + '%');
        $invertFilterValue.html(self.invert + '%');
        $hueRotateFilterValue.html(self.hueRotate + 'deg');
        $blurFilterValue.html(self.blur + 'px');
    }

    PhotoEditor.prototype.convertImageToCanvas = function () {

        var self = this;
        var srcValue = localStorage.getItem('imageSrc');
        var $canvas = $('#imageCanvas', self.$container)[0];
        var ctx = $canvas.getContext('2d');
        var image = new Image();

        image.src = srcValue;
        image.onload = function () {
            $canvas.width = image.width;
            $canvas.height = image.height;
            ctx.drawImage(image, 0, 0, $canvas.width, $canvas.height);
        };
    }
    return PhotoEditor;
}());