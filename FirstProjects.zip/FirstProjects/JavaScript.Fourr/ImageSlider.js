
var ImageSlider = (function () {

    function ImageSlider(options) {
        var self = this;
        self.$container = options.$container;
        self.imagesLength = 0;
        self.buildBody();
        self.addImages();
        createEvents(self);
    }

    ImageSlider.prototype.buildBody = function () {
        var self = this;

        var $pluginWrapper = $('<div/>', {
            class: 'image-slider',
        });
        var $sliderTitle = $('<label/>', {
            class: 'title',
        });
        $sliderTitle.text('Images Slider');

        var $slider = $('<div/>', {
            class: 'slider',
        });
        var $numerator = $('<label/>', {
            class: 'numerator',
        });
        var $imageNumber = $('<label/>', {
            class: 'number',
            id: 'imageNumber'
        });
        var $imagesLength = $('<label/>', {
            class: 'number',
            id: 'imagesLength'
        });
        var $imagesContainer = $('<output/>', {
            id: 'imagesContainer',
        });
        var $imagesInput = $('<input/>', {
            id: 'imagesInput',
            type: 'file',
            multiple: true,
            hidden: true
        });
        var $addPhotoButton = $('<input/>', {
            id: 'addButton',
            type: 'button',
            value: 'AddPhoto',
        });
        var $prevButton = $('<a/>', {
            id: 'prevButton',
            html: '&#10094;',
        });
        var $nextButton = $('<a/>', {
            id: 'nextButton',
            html: '&#10095;',
        });
        $imagesLength.text('/' + self.imagesLength);
        $imageNumber.text('0');
        $numerator.append($imageNumber, $imagesLength);
        $slider.append($numerator, $imagesContainer, $prevButton, $nextButton)
        $pluginWrapper.append($sliderTitle, $slider, $addPhotoButton, $imagesInput);
        self.$container.append($pluginWrapper);
        localStorage.clear();
    }

    ImageSlider.prototype.addImages = function () {
        var self = this;

        var $imagesInput = $('#imagesInput', self.$container);
        var $imagesContainer = $('#imagesContainer', self.$container);
        var $imagesLength = $('#imagesLength', self.$container);
        var $imageNumber = $('#imageNumber', self.$container);

        function removeActive() {
            $imagesInput.each(function () {
                $('.image-container', self.$container).removeClass('active');
            });
        }

        $imagesInput.on('change', function (event) {
            var files = event.target.files;
            var imageNumber = 0;
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var reader = new FileReader();
                $(reader).on('load', function (e) {
                    if (imageNumber === 0) {
                        removeActive();
                        var $imageContainer = $('<div/>', {
                            class: 'image-container active'
                        });
                        var $close = $('<span/>', {
                            class: 'remove'
                        })
                        var $image = $('<img/>', {
                            class: 'image ',
                            src: e.target.result
                        });
                        $imageContainer.append($close);
                        $imageContainer.append($image);
                    }
                    else {
                        var $imageContainer = $('<div/>', {
                            class: 'image-container '
                        });
                        var $close = $('<span/>', {
                            class: 'remove'
                        })
                        var $image = $('<img/>', {
                            class: 'image ',
                            src: e.target.result
                        });
                        $imageContainer.append($close);
                        $imageContainer.append($image);
                    }
                    $imagesContainer.append($imageContainer);
                    imageNumber++;
                });
                reader.readAsDataURL(file);
            }
            self.imagesLength = self.imagesLength + files.length;
            $imagesLength.text('/' + self.imagesLength);
            $imageNumber.text(self.imagesLength - files.length + 1);
        });
    }

    ImageSlider.prototype.slideLeft = function () {
        var self = this;
        var $imageNumber = $('#imageNumber', self.$container);
        var currentImg = $('.active', self.$container);
        var prevImg = currentImg.prev();

        if (prevImg.length) {
            currentImg.removeClass('active', self.$container).css('z-index', -10);
            prevImg.addClass('active', self.$container).css('z-index', 10);
        }
        $imageNumber.text($('.active').index() + 1);
    }

    ImageSlider.prototype.slideRight = function () {
        var self = this;
        var $imageNumber = $('#imageNumber', self.$container);
        var currentImg = $('.active', self.$container);
        var nextImg = currentImg.next();

        if (nextImg.length) {
            currentImg.removeClass('active').css('z-index', -10);
            nextImg.addClass('active').css('z-index', 10);
        }
        $imageNumber.text($('.active').index() + 1);
    }

    ImageSlider.prototype.deleteImage = function ($element) {
        var self = this;
        var $prevButton = $('#prevButton', self.$container);
        var $nextButton = $('#nextButton', self.$container);
        var $imagesLength = $('#imagesLength', self.$container);
        var $imageNumber = $('#imageNumber', self.$container);

        if ($($element).parent().is(':first-child') === true) {
            $nextButton.click();
            $($element).parent().remove();
            $imageNumber.text($('.active').index() + 1);
        }
        else {
            $prevButton.click();
            $($element).parent().remove();
        }
        self.imagesLength = self.imagesLength - 1;
        $imagesLength.text('/' + self.imagesLength);
    }

    $(window).on('focus', function () {
        var self = this;
        var initialImage = localStorage.getItem('initialImage');
        var srcValue = localStorage.getItem('imageSrc');
        $('.image', self.$container).each(function () {
            if (initialImage === this.src) {
                $(this).attr('src', srcValue);
            }
        });
    });

    function createEvents(self) {

        var $addPhotoButton = $('#addButton', self.$container);
        var $imagesInput = $('#imagesInput', self.$container);
        var $prevButton = $('#prevButton', self.$container);
        var $nextButton = $('#nextButton', self.$container);

        $addPhotoButton.on('click', function () {
            $imagesInput.click();
        });

        $nextButton.on('click', function () {
            self.slideRight();
        });

        $prevButton.on('click', function () {
            self.slideLeft();
        });

        self.$container.on('click', '.image', function () {
            var srcValue = this.src;
            var image = new Image();
            image.src = srcValue;
            localStorage.setItem('imageSrc', srcValue);
            localStorage.setItem('initialImage', srcValue);

            window.open('PhotoEditor.html', 'photoEditor', 'width=1024,height=800');

        });

        self.$container.on('click', '.remove', function () {
            self.deleteImage(this);
        });
    }
    return ImageSlider;
}());