var options = {
    $container: $('#ImageSlider1')
}
var plugin1 = new ImageSlider(options);

