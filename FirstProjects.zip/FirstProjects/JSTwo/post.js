class Post
{
    constructor(options) {
        var todayDate = new Date();
        var time = todayDate.toLocaleTimeString();
        var date = todayDate.toLocaleDateString();
        this.firstName = options.firstName;
        this.lastName = options.lastName;
        this.postDate = date;
        this.postTime = time;
        this.textPost = options.textPost;
        this.fileInput = options.fileInput;
    }
    setPost(firstName,lastName,textPost,file){
    var templatePost= 
    '<div class="new-post content-atributes">'+
       '<div class="input-content full-size">'+
            '<div id="userAvatar"></div>'+
            '<div id="userName">'+
                 '<label  for="firstName" class="colorUserDetails" id="firstName">'+firstName+'</label>'+
                 '<label  for="lastName" class="colorUserDetails text-margin" id="lastName">'+lastName+'</label><br>'+
                 '<label  class="colorUserDetails smallFont">Posted on: </label>'+
                 '<label  for="postDate" class="colorUserDetails smallFont" id="postDate">'+this.postDate+'</label>'+
                 '<label  for="postTime" class="colorUserDetails smallFont text-margin" id="postTime">'+this.postTime+'</label>'+
            '</div>'+
            '<div class="clear"></div>'+
        '</div>'+
        '<div class="input-content full-size">'+
             '<hr class="line" id="postLine">'+
             '<div class="input-content full-size" id="thePost">'+
                 '<label  for="textPost" class="colorUserDetails" id="textPost">'+textPost+'</label>'+
                 '<div class="main-post">'+
                    '<div class="slider-outer">'+
                        '<img src="images/arrow-left.png" class="prev" alt="Prev">'+
                            '<div class="slider-inner">'+file+'</div>'+
                        '<img src="images/arrow-right.png" class="next" alt="Next">'+
                     '</div>'+
                     '<div class="clear"></div>'+
                 '</div>'+
             '</div>'+
        '</div>'+
        '<div class="clear"></div>'+
     '</div>'+
     '<div class="content-atributes" id="margin-bottom"></div>';
     return templatePost;
    }
  //  static validateFields(this.textPost)
   // {

   // }
}