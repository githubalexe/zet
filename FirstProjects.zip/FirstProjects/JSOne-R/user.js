class User {
    constructor(options) {
        this.firstName = options.firstName;
        this.lastName = options.lastName;
        this.gender = options.gender;
        this.birthDate = options.birthDate;
        this.role = options.role;
        this.fileInput = options.fileInput;
    }

    displayUser() {

        console.log(
            "First Name:" + this.firstName,
            "Last Name:" + this.lastName,
            "Gender:" + this.gender,
            "Birth Date:" + this.birthDate,
            "Role:" + this.role,
            "Photo:" + this.fileInput);
    }

    getAllValidationErrors() {
        var errorMessages = [];
        var errorMessage = "";

        errorMessage = User.validateFirstName(this.firstName, 30);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";

        }
        errorMessage = User.validateLastName(this.lastName, 50);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }

        errorMessage = User.validateBirthDate(this.birthDate);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }

        errorMessage = User.validateRole(this.role);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }
        errorMessage = User.validateGender(this.gender);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }
        errorMessage = User.validatefilleInput(this.fileInput);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }

        return errorMessages;
    }

    static validateFirstName(name, lengthAllowed) {
        return User._commonRulesValidationForName(name, lengthAllowed);
    }
    static validateLastName(name, lengthAllowed) {
        return User._commonRulesValidationForName(name, lengthAllowed);
    }
    static _commonRulesValidationForName(name, lengthAllowed) {
        var errorMessage = "";
        var lengthWord;
        if (name === "") {
            lengthWord = 0;
        }
        else {
            lengthWord = name.length;
        }
        var characters = String(name);

        if ((/[0-9]/.test(characters))) {
            errorMessage = "Only alpha characters are allowed!";
        }
        else
            if (lengthWord <= 2) {
                errorMessage = "Minimum required characters is 3!";
            }
            else
                if (lengthWord >= lengthAllowed) {
                    errorMessage = "Maximum allowed characters is " + lengthAllowed + "!";
                }
                else
                    if (lengthWord >= 2 && lengthWord < lengthAllowed && !(/[0-9]/.test(characters))) {
                        errorMessage = "";
                    }

        return errorMessage;
    }
    static validateBirthDate(birthDate) {

        var errorMessage = "";
        if (birthDate === "") {
            var errorMessage = "Birth Date is required!";
        }
        else if (birthDate != "") {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1;
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = '0' + dd
            }
            if (mm < 10) {
                mm = '0' + mm
            }
            today = mm + '/' + dd + '/' + yyyy;
            var birthYear = new Date(birthDate);
            var year = birthYear.getFullYear();
            var difference = yyyy - year;
            if (difference < 0) {
                errorMessage = "Future date is not allowed!";
            }
            else
                if (difference < 19) {
                    errorMessage = "The minimum age is 18 years!";
                }
                else
                    if (difference >= 45) {
                        errorMessage = "The maximum age is 45 years!";
                    }
                    else
                        if (difference >= 18 && difference <= 45) {
                            errorMessage = "";
                        }
        }
        return errorMessage;
    }

    static validateGender(gender) {

        var errorMessage = "";
        if (gender === "") {
            errorMessage = "Select a gender!";
        }
        else {
            errorMessage = "";
        }
        return errorMessage;
    }
    static validateRole(role) {
        var errorMessage = "";
        if (role === "") {
            errorMessage = "Role is required!";
        }
        else {
            errorMessage = "";
        }

        return errorMessage;
    }
    static validatefilleInput(fileInput) {
        var errorMessage = "";
        if (fileInput === "") {
            errorMessage = "Image is required!";
        }
        else {
            errorMessage = "";
        }

        return errorMessage;
    }
}