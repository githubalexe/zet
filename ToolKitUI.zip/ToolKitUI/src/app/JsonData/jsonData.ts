export const Modal = {
    form: {
        modalTitle: "Income",
        closeButton: {
            label: "Close",
            visibility: true
        }
    },
    controls: [
        {
            controlType: "dropdown",
            label: "Name Title",
            options: [
                "Mr",
                "Mrs"
            ],
            floatingLabel: "never",
            width: "100%",
            dataModelName: "nameTitle"
        },
        {
            controlType: "dropdown",
            label: "Colors",
            options: [
                "Black",
                "Green",
                "Blue",
                "Red"
            ],
            floatingLabel: "",
            width: "100%",
            dataModelName: "nameTitle"
        },
        {
            controlType: "input-float-label",
            label: "First Name",
            width: "100%",
            dataModelName: "firstName"
        },
        {
            controlType: "input-float-label",
            label: "Last Name",
            width: "100%",
            dataModelName: "lastName"
        },
        {
            controlType: "dropdown",
            label: "Applicant Type",
            width: "100%",
            dataModelName: "applicantType"
        },
        {
            controlType: "checkbox",
            checkboxOption: "Male",
            width: "30%",
            dataModelName: "applicantType"
        },
        {
            controlType: "checkbox",
            checkboxOption: "Female",
            width: "30%",
            dataModelName: "applicantType"
        },
        {
            controlType: "radiobox",
            radioboxOption: "Radio box ",
            width: "30%",
            dataModelName: "applicantType"
        },
        {
            controlType: "datepicker",
            width: "100%",
            dataModelName: "applicantType"
        },
        {
            controlType: "subtitle",
            subtitle: "Subtitle"
        },
        {
            controlType: "tabs",
            noAnimation: false,
            arrayTabs: [
                {
                    tabName: "YTD",
                    content: [
                        {
                            controlType: "dropdown",
                            label: "Test after test",
                            width: "100%",
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "checkbox",
                            checkboxOption: "Male",
                            width: "30%",
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "checkbox",
                            checkboxOption: "Female",
                            width: "30%",
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "radiobox",
                            radioboxOption: "Radio box ",
                            width: "30%",
                            dataModelName: "applicantType"
                        }
                    ]
                },
                {
                    tabName: "2018/2019",
                    content: [
                        {
                            controlType: "dropdown",
                            label: "Applicant Type",
                            width: "100%",
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "checkbox",
                            checkboxOption: "Male",
                            width: "30%",
                            dataModelName: "applicantType"
                        }
                    ]
                },
                {
                    tabName: "2017/2018",
                    content: [
                        {
                            controlType: "checkbox",
                            checkboxOption: "Male",
                            width: "30%",
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "checkbox",
                            checkboxOption: "Female",
                            width: "30%",
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "radiobox",
                            radioboxOption: "Radio box ",
                            width: "30%",
                            dataModelName: "applicantType"
                        }
                    ]
                },
                {
                    tabName: "2016/2017",
                    content: [
                        {
                            controlType: "dropdown",
                            label: "Name Title",
                            options: [
                                "Mr",
                                "Mrs"
                            ],
                            floatingLabel: "never",
                            width: "100%",
                            dataModelName: "nameTitle"
                        },
                        {
                            controlType: "dropdown",
                            label: "Colors",
                            options: [
                                "Black",
                                "Green",
                                "Blue",
                                "Red"
                            ],
                            floatingLabel: "",
                            width: "100%",
                            dataModelName: "nameTitle"
                        },
                        {
                            controlType: "input-float-label",
                            label: "First Name",
                            width: "100%",
                            dataModelName: "firstName"
                        },
                    ]
                },

            ]
        },
        {
            controlType: "left-label-input",
            label: "Childcare",
            containerWidth: "100%",
            labelWidth: "50%",
            textboxWidth: "50%",
            dataModelName: "applicantType"
        },
        {
            controlType: "left-label-input",
            label: "Clothing and Personal Care",
            containerWidth: "100%",
            labelWidth: "30%",
            textboxWidth: "20%",
            dataModelName: "applicantType"
        },
        {
            controlType: "left-label-input",
            label: "Transport Transport Transport Transport Transport Transport",
            containerWidth: "100%",
            labelWidth: "40%",
            textboxWidth: "50%",
            dataModelName: "applicantType"
        },
        {
            controlType: "subtitle-two",
            subtitle: "ADDBACKS"
        },
        {
            controlType: "show-hide-button",
            label: "Show more Addbacks"
        },
    ]
}