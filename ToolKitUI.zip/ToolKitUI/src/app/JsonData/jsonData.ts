export class JsonData {
    floatLabelTitle: string;
    dropdownTitle: string;
    titleLabel: string;
    radioboxOption: string;
    checkboxOption: string;
    datepicker: string;
    width: string;
}

export const FloatLabelArray = [
    { floatLabelTitle: "Last Name", width: "100" },
    // { floatLabelTitle: "", floatLabelValue: 12 },
];

export const DropdownArray = [
    { dropdownTitle: "aletceva" },
];

export const TitleLabelArray = [
    { titleLabel: "Residency" },
];

export const RadioboxArray = [
    { radioboxOption: "Male" },
    { radioboxOption: "Female" },
];

export const CheckboxArray = [
    { checkboxOption: "Option 1" },
    { checkboxOption: "Option 2" },
];

export const DatepickerArray = [
    { datepicker: "" },
    { datepicker: "" },
];

export const Test = { radioboxOption: "It works, yees" };