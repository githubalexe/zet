export const HouseholdModal = {
    form: {
        modalTitle: "Household",
        closeButton: {
            label: "Close",
            visibility: true
        }
    },
    controls: [
        {
            controlType: "input-float-label",
            label: "Name",
            style: {
                width: "100%",
            },
            dataModelName: "firstName"
        },
        {
            controlType: "dropdown",
            label: "Number of Adults",
            options: [
                "1",
                "2",
                "3",
                "4",
            ],
            floatingLabel: "",
            style: {
                width: "100%",
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "dropdown",
            label: "Number of Dependants",
            id: "numberOfDependantsId",
            options: [
                "1",
                "2",
                "3",
                "4",
            ],
            floatingLabel: "",
            style: {
                width: "100%",
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "input-float-label",
            label: "Test",
            id: "testId",
            style: {
                width: "100%",
            
            },
            dataModelName: "firstName"
        },
        {
            controlType: "subtitle",
            subtitle: "Dependents Details"
        },


    ],
    groupControls: [
        {
            controlType: "group-controls",
            repeatable: "yes",
            repeatableRule: `for(let i=0;i<object.numberOFDepi++){}`,
            controls: [
                {
                    controlType: "input-float-label",
                    label: "Dependent 1 Name",
                    id: "dependentName",
                    style: {
                        width: "45%",
                        paddingRight: "10px"
                    },
                    dataModelName: "firstName"
                },
                {
                    controlType: "datepicker",
                    id: "dependentDate",
                    style: {
                        width: "35%",
                        paddingRight: "10px"
                    },
                    dataModelName: "applicantType"
                },
                {
                    controlType: "input-float-label",
                    id: "dependentAge",
                    label: "Dependent 1 Age",
                    style: {
                        width: "20%",
                    },
                    dataModelName: "firstName"
                }
            ]
        }
    ]
}