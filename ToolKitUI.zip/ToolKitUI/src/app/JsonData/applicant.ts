export const ApplicantModal = {
    form: {
        modalTitle: "Applicant",
        closeButton: {
            label: "Close",
            visibility: true
        }
    },
    controls: [
        {
            controlType: "dropdown",
            label: "Name Title",
            options: [
                "Mr",
                "Mrs"
            ],
            floatingLabel: "",
            style: {
                width: "100%"
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "input-float-label",
            label: "First Name",
            style: {
                width: "100%",
                paddingRight:"10px"
            },
            dataModelName: "firstName"
        },
        {
            controlType: "input-float-label",
            label: "Last Name",
            style: {
                width: "100%"
            },
            dataModelName: "lastName"
        },
        {
            controlType: "subtitle",
            subtitle: "Residency"
        },
        {
            controlType: "dropdown",
            label: "Residency Status",
            options: [
                "Penmanently in Australia",
                "Test 1"
            ],
            style: {
                width: "100%"
            },
            dataModelName: "residencyStatus"
        },
        {
            controlType: "dropdown",
            label: "Citizenship",
            options: [
                "Australia",
                "Test 1"
            ],
            style: {
                width: "100%"
            },
            dataModelName: "citizenship"
        },
        {
            controlType: "subtitle",
            subtitle: "Marital Status"
        },
        {
            controlType: "dropdown",
            label: "Marital Status",
            options: [
                "Married",
                "Test 2",
                "Test 3"
            ],
            style: {
                width: "100%"
            },
            dataModelName: "maritalStatus"
        },
        {
            controlType: "dropdown",
            label: "Spouse",
            options: [
                "Test 1",
                "Test 2",
                "Test 3"
            ],
            style: {
                width: "100%"
            },
            dataModelName: "Spouse"
        },
        {
            controlType: "subtitle",
            subtitle: "House Details"
        },
        {
            controlType: "dropdown",
            label: "Household",
            options: [
                "Test 1",
                "Test 2",
                "Test 3"
            ],
            style: {
                width: "100%"
            },
            dataModelName: "household"
        },
        {
            controlType: "dropdown",
            label: "Housing Status",
            options: [
                "Test 1",
                "Test 2",
                "Test 3"
            ],
            style: {
                width: "100%"
            },
            dataModelName: "housingStatus"
        },
        {
            controlType: "subtitle",
            subtitle: "Address Details"
        },
        {
            controlType: "radiobox",
            radioboxOption: "Standard",
            style: {
                width: "50%",
                paddingRight:'10px'
            },
            dataModelName: "standard"
        },
        {
            controlType: "radiobox",
            radioboxOption: "Non Standard",
            style: {
                width: "50%"
            },
            dataModelName: "nonstandard"
        },
        {
            controlType: "subtitle",
            subtitle: "Other Details"
        },
        {
            controlType: "checkbox",
            checkboxOption: "Primary Applicant",
            style: {
                width: "100%"
            },
            dataModelName: "primaryApplicant"
        },
        {
            controlType: "checkbox",
            checkboxOption: "Lender Staff",
            style: {
                width: "100%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "checkbox",
            checkboxOption: "Existing Customer",
            style: {
                width: "100%"
            },
            dataModelName: "existingCustomer"
        }
    ]
}