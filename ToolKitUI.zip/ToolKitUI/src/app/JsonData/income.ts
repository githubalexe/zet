export const IncomeModal = {
    form: {
        modalTitle: "Income",
        closeButton: {
            label: "Close",
            visibility: true
        },
    },
    controls: [
        {
            controlType: "dropdown",
            label: "Applicant",
            options: [
                "Applicant 1",
                "Applicant 2"
            ],
            floatingLabel: "",
            style: {
                width: "100%"
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "dropdown",
            label: "Income Type",
            options: [
                "Self Employed",
                "Self Employed 2"
            ],
            floatingLabel: "",
            style: {
                width: "100%"
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "subtitle",
            subtitle: "Employment Details"
        },
        {
            controlType: "dropdown",
            label: "Status",
            options: [
                "Pimary",
                "Test 2"
            ],
            floatingLabel: "",
            style: {
                width: "100%"
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "dropdown",
            label: "Basis",
            options: [
                "Full Time",
                "Test 2"
            ],
            floatingLabel: "",
            style: {
                width: "100%"
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "subtitle",
            subtitle: "Business Details"
        },
        {
            controlType: "input-float-label",
            label: "Employer Name",
            style: {
                width: "100%"
            },
            dataModelName: "firstName"
        },
        {
            controlType: "datepicker",
            style: {
                width: "100%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Business Structure",
            options: [
                "Partnership",
                "Test 2"
            ],
            floatingLabel: "",
            style: {
                width: "100%"
            },
            dataModelName: "nameTitle"
        },
        {
            controlType: "percentage-textbox",
            label: "Ownership",
            style: {
                width: "100%"
            },
            dataModelName: "firstName"
        },
        {
            controlType: "subtitle",
            subtitle: "Income Details"
        },
        {
            controlType: "tabs",
            noAnimation: false,
            arrayTabs: [
                {
                    tabName: "YTD",
                    content: [
                        {
                            controlType: "left-label-input",
                            label: "Profit(Loss) Before Tax",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px",
                                fontWeight: "bold",
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "subtitle-two",
                            subtitle: "ADDBACKS"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Depreciation",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Interest",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Lease",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Non Cash Benefits",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "No recurring Expenses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Superannuation Excess",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Carry Foward Losses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Amortization Of Goodwill",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Salary",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Allowances",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Bonus",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Car Expense",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Other Addbacks",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                    ]
                },
                {
                    tabName: "2018/2019",
                    content: [
                        {
                            controlType: "left-label-input",
                            label: "Profit(Loss) Before Tax",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px",
                                fontWeight: "bold",
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "subtitle-two",
                            subtitle: "ADDBACKS"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Depreciation",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Interest",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Lease",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Non Cash Benefits",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "No recurring Expenses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Superannuation Excess",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Carry Foward Losses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Amortization Of Goodwill",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Salary",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Allowances",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Bonus",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Car Expense",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Other Addbacks",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                    ]
                },
                {
                    tabName: "2017/2018",
                    content: [
                        {
                            controlType: "left-label-input",
                            label: "Profit(Loss) Before Tax",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px",
                                fontWeight: "bold",
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "subtitle-two",
                            subtitle: "ADDBACKS"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Depreciation",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Interest",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Lease",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Non Cash Benefits",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "No recurring Expenses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Superannuation Excess",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Carry Foward Losses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Amortization Of Goodwill",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Salary",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Allowances",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Bonus",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Car Expense",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Other Addbacks",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        }
                    ]
                },
                {
                    tabName: "2016/2017",
                    content: [
                        {
                            controlType: "left-label-input",
                            label: "Profit(Loss) Before Tax",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px",
                                fontWeight: "bold",
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "subtitle-two",
                            subtitle: "ADDBACKS"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Depreciation",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Interest",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Lease",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Non Cash Benefits",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "No recurring Expenses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Superannuation Excess",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Carry Foward Losses",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Amortization Of Goodwill",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Salary",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Allowances",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Bonus",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Car Expense",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        },
                        {
                            controlType: "left-label-input",
                            label: "Other Addbacks",
                            containerStyle: {
                                width: "100%"
                            },
                            labelStyle: {
                                width: "50%",
                                paddingRight: "10px"
                            },
                            textboxStyle: {
                                width: "50%"
                            },
                            dataModelName: "applicantType"
                        }
                    ]
                }
            ]
        }

    ]
}