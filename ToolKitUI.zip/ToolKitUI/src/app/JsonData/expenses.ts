export const ExpensesModal = {
    form: {
        modalTitle: "Expenses",
        closeButton: {
            label: "Close",
            visibility: true
        }
    },
    controls: [
        {
            controlType: "dropdown",
            label: "Household",
            options: [
                "Partnership",
                "Test 2"
            ],
            floatingLabel: "",
            dataModelName: "nameTitle",
            style: {
                width: "100%"
            }
        },
        {
            controlType: "subtitle",
            subtitle: "Living Expenses"
        },
        {
            controlType: "left-label-input",
            label: "Childcare",
            dataModelName: "applicantType",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            }
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%",
            }
        },
        {
            controlType: "left-label-input",
            label: "Clothing and Pesonal Care",
            dataModelName: "applicantType",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Education",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Groceries",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Insurance",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Investment Property Utilities",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Transport",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType",
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Medical and Health",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Recreation and Entertaiment",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Telephone, Internet, TV and more",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Owner Occupied Property and more",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "subtitle",
            subtitle: "Other Commitments"
        },
        {
            controlType: "left-label-input",
            label: "Board",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Child Maintenance",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Rent",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
        {
            controlType: "left-label-input",
            label: "Other Other Other Other Other Other Other Other Other Other Other Other Other Other Other ",
            containerStyle: {
                width: "70%",
                paddingRight:"10px"
            },
            labelStyle: {
                width: "60%"
            },
            textboxStyle: {
                width: "40%"
            },
            dataModelName: "applicantType"
        },
        {
            controlType: "dropdown",
            label: "Frequency",
            options: [
                "Monthly",
                "Test 2"
            ],
            floatingLabel: "never",
            dataModelName: "nameTitle",
            style: {
                width: "30%"
            }
        },
    ]
}