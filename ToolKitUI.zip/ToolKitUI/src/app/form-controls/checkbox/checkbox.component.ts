import { Component, Input } from '@angular/core';
import { JsonData } from 'src/app/JsonData/jsonData';

@Component({
    selector: 'checkbox',
    templateUrl: './checkbox.component.html',
    styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent {
    @Input() checkbox: JsonData;
}
