import { Component, Input } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'checkbox',
    templateUrl: './checkbox.component.html',
    styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent implements AddComponent {
    data: any;
    @Input() checkbox: any;
}
