import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LeftLabelInputComponent } from './left-label-input.component';

describe('LeftLabelInputComponent', () => {
  let component: LeftLabelInputComponent;
  let fixture: ComponentFixture<LeftLabelInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LeftLabelInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeftLabelInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
