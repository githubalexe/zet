import { Component, OnInit } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';
import * as $ from 'jquery';

@Component({
    selector: 'left-label-input',
    templateUrl: './left-label-input.component.html',
    styleUrls: ['./left-label-input.component.css']
})

export class LeftLabelInputComponent implements AddComponent {
    data: any;

    
    // ngOnInit(): void {
    //     this.id = this.generateId();
    //     this.test();
    // }
    // id: any;


    // test() {
    //     var $icon = $("#" + this.id);
    //     console.log("#" + this.id)
    //     $icon.on("click", function () {
    //         console.log("ai apasat aici deci merge!!");
    //     })
    // }

    // generateId() {

    //     var p = (Math.random().toString(16) + "000000000").substr(2, 8);
    //     return p;
    // };

    getWidth(width) {
        var lastCharacter = width.slice(-1);
        var intWidth = parseInt(width);

        if (intWidth <= 50) {
            intWidth = intWidth - 5;
        }
        console.log("intra", (intWidth + lastCharacter).toString())
        return (intWidth + lastCharacter).toString();
    }
}
