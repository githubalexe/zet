import { Component, Input } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'datepicker',
    templateUrl: './datepicker.component.html',
    styleUrls: ['./datepicker.component.css']
})
export class DatepickerComponent implements AddComponent  {
    data: any;
}
