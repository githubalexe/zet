import { Component, Input } from '@angular/core';
import { JsonData } from 'src/app/JsonData/jsonData';

@Component({
    selector: 'datepicker',
    templateUrl: './datepicker.component.html',
    styleUrls: ['./datepicker.component.css']
})
export class DatepickerComponent {
    @Input() datapicker: JsonData;
}
