import { Component, } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'subtitle',
    templateUrl: './subtitle.component.html',
    styleUrls: ['./subtitle.component.css']
})
export class SubtitleComponent implements AddComponent {
    data: any;
}
