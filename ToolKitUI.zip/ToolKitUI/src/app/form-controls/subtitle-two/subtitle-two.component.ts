import { Component } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'subtitle-two',
    templateUrl: './subtitle-two.component.html',
    styleUrls: ['./subtitle-two.component.css']
})
export class SubtitleTwoComponent implements AddComponent {
    data: any;
}
