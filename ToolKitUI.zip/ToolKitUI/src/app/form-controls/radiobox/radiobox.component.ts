import { Component, Input } from '@angular/core';
import { JsonData } from 'src/app/JsonData/jsonData';

@Component({
  selector: 'radiobox',
  templateUrl: './radiobox.component.html',
  styleUrls: ['./radiobox.component.css']
})
export class RadioboxComponent {
    @Input() radiobox: JsonData;
}
