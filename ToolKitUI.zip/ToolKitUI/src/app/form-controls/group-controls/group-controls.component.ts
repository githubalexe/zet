import { Component, OnInit } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';
import { AddGroupService } from 'src/app/group-service/group.service';
import { AddGroupItem } from 'src/app/group-service/group-item';
import { ApplicantModal } from 'src/app/JsonData/applicant';

@Component({
    selector: 'group-controls',
    templateUrl: './group-controls.component.html',
    styleUrls: ['./group-controls.component.css']
})
export class GroupControlsComponent implements OnInit, AddComponent {
    data: any;
    controls: AddGroupItem[];
    constructor(private adService: AddGroupService) { }

    ngOnInit() {

        this.controls = this.adService.getComponents(this.data.controls);
    }

    getComponents() {

    }

}
