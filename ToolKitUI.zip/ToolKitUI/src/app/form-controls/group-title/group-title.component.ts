import { Component, Input } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'group-title',
    templateUrl: './group-title.component.html',
    styleUrls: ['./group-title.component.css']
})
export class GroupTitleComponent implements AddComponent {
    data: any;
    @Input() inputFloatLabel: any;
}
