import { Component } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'show-hide-button',
    templateUrl: './show-hide-button.component.html',
    styleUrls: ['./show-hide-button.component.css']
})

export class ShowHideButtonComponent implements AddComponent {
    data: any;
}
