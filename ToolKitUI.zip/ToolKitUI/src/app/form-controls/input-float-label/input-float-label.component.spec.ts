import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputFloatLabelComponent } from './input-float-label.component';

describe('InputFloatLabelComponent', () => {
  let component: InputFloatLabelComponent;
  let fixture: ComponentFixture<InputFloatLabelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputFloatLabelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputFloatLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
