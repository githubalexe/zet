import { Component, Input } from '@angular/core';
import { JsonData } from 'src/app/JsonData/jsonData';

@Component({
  selector: 'input-float-label',
  templateUrl: './input-float-label.component.html',
  styleUrls: ['./input-float-label.component.css']
})
export class InputFloatLabelComponent  {
    @Input() inputFloatLabel: JsonData;
}
