import { Component } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';

@Component({
    selector: 'percentage-textbox',
    templateUrl: './percentage-textbox.component.html',
    styleUrls: ['./percentage-textbox.component.css']
})

export class PercentageTextboxComponent implements AddComponent {
    data: any;
}
