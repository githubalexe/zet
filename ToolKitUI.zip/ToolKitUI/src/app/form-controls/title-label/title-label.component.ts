import { Component, Input } from '@angular/core';
import { JsonData } from 'src/app/JsonData/jsonData';

@Component({
  selector: 'title-label',
  templateUrl: './title-label.component.html',
  styleUrls: ['./title-label.component.css']
})

export class TitleLabelComponent {
    @Input() titleLabel: JsonData;
}
