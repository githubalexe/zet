import { Component, Input, ViewChild, ComponentFactoryResolver, OnInit } from '@angular/core';

import { AddComponent } from 'src/app/service/add.component';

import { AddGroupItem } from 'src/app/group-service/group-item';
import { AddGroupDirective } from 'src/app/group-service/group.directive';


@Component({
    selector: 'title-label',
    templateUrl: './title-label.component.html',
    styleUrls: ['./title-label.component.css']
})

export class TitleLabelComponent implements OnInit {
    ngOnInit(): void {
        this.getControls();
    }
    data: any;
    @Input() adss: AddGroupItem[];
    @ViewChild(AddGroupDirective, { static: true }) addHost: AddGroupDirective;
    currentAdIndex = -1;

    constructor(private componentFactoryResolver: ComponentFactoryResolver) { }

    loadComponent() {
        this.currentAdIndex = (this.currentAdIndex + 1) % this.adss.length;
        const addItem = this.adss[this.currentAdIndex];
        const componentFactory = this.componentFactoryResolver.resolveComponentFactory(addItem.component);
        const viewContainerRef = this.addHost.viewContainerRef;
        const componentRef = viewContainerRef.createComponent(componentFactory);
        (<AddComponent>componentRef.instance).data = addItem.data;
    }

    getControls() {
        for (let i = 0; i < this.adss.length; i++) {
            this.loadComponent();
        }
    }
}
