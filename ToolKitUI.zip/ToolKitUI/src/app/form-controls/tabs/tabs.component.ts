import { Component, OnInit } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';
import { AddGroupService } from 'src/app/group-service/group.service';

@Component({
    selector: 'tabs',
    templateUrl: './tabs.component.html',
    styleUrls: ['./tabs.component.css']
})
export class TabsComponent implements AddComponent, OnInit {
    data: any;

    constructor(private adService: AddGroupService) { }
    
    ngOnInit(): void {

    }

    getComponents(controls) {
        var components = this.adService.getComponents(controls);
        return components;
    }
}
