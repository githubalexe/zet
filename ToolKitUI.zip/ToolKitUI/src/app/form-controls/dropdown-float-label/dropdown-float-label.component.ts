import { Component, Input, OnInit } from '@angular/core';
import { AddComponent } from 'src/app/service/add.component';


@Component({
    selector: 'dropdown-float-label',
    templateUrl: './dropdown-float-label.component.html',
    styleUrls: ['./dropdown-float-label.component.css']
})
export class DropdownFloatLabelComponent implements AddComponent, OnInit {
    data: any;
    selected: string;
    ngOnInit(): void {

    }
}
