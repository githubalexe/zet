import { Component, Input } from '@angular/core';
import { JsonData } from 'src/app/JsonData/jsonData';

@Component({
  selector: 'dropdown-float-label',
  templateUrl: './dropdown-float-label.component.html',
  styleUrls: ['./dropdown-float-label.component.css']
})
export class DropdownFloatLabelComponent {
    @Input() dropdown: JsonData;
}
