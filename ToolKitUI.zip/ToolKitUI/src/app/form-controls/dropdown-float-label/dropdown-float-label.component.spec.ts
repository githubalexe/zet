import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropdownFloatLabelComponent } from './dropdown-float-label.component';

describe('DropdownFloatLabelComponent', () => {
  let component: DropdownFloatLabelComponent;
  let fixture: ComponentFixture<DropdownFloatLabelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropdownFloatLabelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownFloatLabelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
