import { Component, AfterViewInit, ComponentFactoryResolver, ViewChild, ɵConsole } from '@angular/core';
import { AddItem } from './service/add-item';
import { AddService } from './service/add.service';
import * as $ from 'jquery';
import { Modal } from './JsonData/jsonData';
import { ApplicantModal } from './JsonData/applicant';
import { IncomeModal } from './JsonData/income';
import { ExpensesModal } from './JsonData/expenses';
import { HouseholdModal } from './JsonData/household';
import { DropdownFloatLabelComponent } from './form-controls/dropdown-float-label/dropdown-float-label.component';
import { AddComponent } from './service/add.component';
import { AddDirective } from './service/add.directive';
import { GroupControlsDirective } from './group-service/group-controls/group-controls.directive';

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
    controls: AddItem[];
    testControls: AddItem[];
    dynamicallyControlsValue = 0;
    dynamicallyControls: any;

    currentAdIndex;
    form: any;
    jsonModal = HouseholdModal;


    constructor(private addService: AddService, private componentFactoryResolver: ComponentFactoryResolver) { }

    ngAfterViewInit(): void {
        var self = this;
        var $testId = $("#testId");

        var $numberOfDependantsId = $("#numberOfDependantsId");

        $numberOfDependantsId.on("change", function () {

            console.log("this", $(this).text());
            console.log("this @", this.value);
        })


        $testId.on("change", function () {

            self.createControls(this.value);

        });

    }

    onChange(): void {
        console.log('Change made -- onChange');
    }

    ngOnInit() {
        this.form = this.jsonModal.form;
        this.controls = this.addService.getControls(this.jsonModal.controls);
    }

    createControls(value) {
        this.removeControls();

        var components = [];
        var groupControls = HouseholdModal.groupControls[0].controls;


        for (var i = 0; i < value; i++) {
            groupControls.forEach(function (control) {
                var item = { ...control };

                if (control.label !== undefined) {
                    console.log(" item.label", item.label);
                    item.label = item.label.replace("1", (i + 1).toString());
                    item.id = item.id.replace(item.id, item.id + i.toString());
                }

                components.push(item);
            })

        }
        this.controls = this.addService.getControls(components);
        this.dynamicallyControls = [...this.controls];
    }

    removeControls() {
        if (this.dynamicallyControls != undefined) {
            this.dynamicallyControls.forEach(function (control) {
                let $controlId = $("#" + control.data.id);
                $controlId.parent().parent().parent().parent().remove();
            })
        }
    }
}
