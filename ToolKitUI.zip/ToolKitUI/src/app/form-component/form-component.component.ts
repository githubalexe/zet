import { Component } from '@angular/core';
import { FloatLabelArray, DropdownArray, TitleLabelArray, RadioboxArray, CheckboxArray, DatepickerArray, Test } from '../JsonData/jsonData';

@Component({
    selector: 'form-component',
    templateUrl: './form-component.component.html',
    styleUrls: ['./form-component.component.css']
})
export class FormComponentComponent {
    floatLabelArray = FloatLabelArray;
    dropdownArray = DropdownArray;
    titleLabelArray = TitleLabelArray;
    radioboxArray = RadioboxArray;
    checkboxArray = CheckboxArray;
    datepickerArray = DatepickerArray;
    test = Test;
}
