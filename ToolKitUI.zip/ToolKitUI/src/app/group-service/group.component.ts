export interface AddGroupComponent {
    data: any;
}
