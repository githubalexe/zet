import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[add-group]',
})
export class AddGroupDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}

