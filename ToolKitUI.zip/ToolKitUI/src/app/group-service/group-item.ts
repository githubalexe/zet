import { Type } from '@angular/core';

export class AddGroupItem {
  constructor(public component: Type<any>, public data: any) {}
}
