import { Injectable } from '@angular/core';
import { DropdownFloatLabelComponent } from '../form-controls/dropdown-float-label/dropdown-float-label.component';
import { InputFloatLabelComponent } from '../form-controls/input-float-label/input-float-label.component';
import { AddItem } from './add-item';
import { CheckboxComponent } from '../form-controls/checkbox/checkbox.component';
import { RadioboxComponent } from '../form-controls/radiobox/radiobox.component';
import { DatepickerComponent } from '../form-controls/datepicker/datepicker.component';
import { SubtitleComponent } from '../form-controls/subtitle/subtitle.component';
import { ControlType } from './control-types';
import { TabsComponent } from '../form-controls/tabs/tabs.component';
import { LeftLabelInputComponent } from '../form-controls/left-label-input/left-label-input.component';
import { SubtitleTwoComponent } from '../form-controls/subtitle-two/subtitle-two.component';
import { ShowHideButtonComponent } from '../form-controls/show-hide-button/show-hide-button.component';
import { PercentageTextboxComponent } from '../form-controls/percentage-textbox/percentage-textbox.component';
import { GroupControlsComponent } from '../form-controls/group-controls/group-controls.component';


@Injectable()

export class AddService {

    getControls(controls) {
        var components = [];
        
        controls.forEach(function (input) {
            switch (input.controlType) {
                case ControlType.checkbox: {
                    let element = new AddItem(CheckboxComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.datapicker: {
                    let element = new AddItem(DatepickerComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.dropdownFloatLabel: {
                    let element = new AddItem(DropdownFloatLabelComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.inputFloatLabel: {
                    let element = new AddItem(InputFloatLabelComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.radiobox: {
                    let element = new AddItem(RadioboxComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.tabs: {
                    let element = new AddItem(TabsComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.subtitle: {
                    let element = new AddItem(SubtitleComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.leftLabelInput: {
                    let element = new AddItem(LeftLabelInputComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.subtitleTwo: {
                    let element = new AddItem(SubtitleTwoComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.showHideButton: {
                    let element = new AddItem(ShowHideButtonComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.percentageTextbox: {
                    let element = new AddItem(PercentageTextboxComponent, input);
                    components.push(element);
                    break;
                }
                case ControlType.groupControls: {

                    let element = new AddItem(GroupControlsComponent, input);
                    components.push(element);
                    
                    break;
                }
                default:
                    {
                        console.log(ControlType.default);
                    }
            }
        })

        return components;
    }
}