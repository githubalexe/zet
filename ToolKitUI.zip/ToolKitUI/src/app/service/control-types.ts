export const ControlType = {
    default: "It does't exist!",
    dropdownFloatLabel: "dropdown",
    inputFloatLabel: "input-float-label",
    radiobox: "radiobox",
    checkbox: "checkbox",
    subtitle: "subtitle",
    datapicker: "datepicker",
    tabs: "tabs",
    leftLabelInput: "left-label-input",
    subtitleTwo: "subtitle-two",
    showHideButton: "show-hide-button",
    percentageTextbox: "percentage-textbox",
    groupControls: "group-controls"
}