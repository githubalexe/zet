import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[ad-host]',
})
export class AddDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}

