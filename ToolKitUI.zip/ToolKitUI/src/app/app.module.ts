import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MaterialModule } from './material';
import { FormComponentComponent } from './form-component/form-component.component';
import { InputFloatLabelComponent } from './form-controls/input-float-label/input-float-label.component';
import { DropdownFloatLabelComponent } from './form-controls/dropdown-float-label/dropdown-float-label.component';
import { TitleLabelComponent } from './form-controls/title-label/title-label.component';
import { RadioboxComponent } from './form-controls/radiobox/radiobox.component';
import { CheckboxComponent } from './form-controls/checkbox/checkbox.component';
import { DatepickerComponent } from './form-controls/datepicker/datepicker.component';


@NgModule({
  declarations: [
    AppComponent,
    FormComponentComponent,
    InputFloatLabelComponent,
    DropdownFloatLabelComponent,
    TitleLabelComponent,
    RadioboxComponent,
    CheckboxComponent,
    DatepickerComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
