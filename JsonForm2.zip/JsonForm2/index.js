define(["jquery", "knockout", "InputGenerator", "bootstrap"], function($, ko, InputGenerator) {

    var $textInput = $("#textInput");
    var $clearButton = $("#clearButton");
    var $generateButton = $("#generateButton");
    var $inputsContainer = $("#inputsContainer");
    var $inputsContainer = $("#inputsContainer");


    initializeInputGenerator();

    function initializeInputGenerator() {

        var options = {
            $generateButton: $generateButton,
            $textInput: $textInput,
            $inputsContainer: $inputsContainer,
            $clearButton: $clearButton
        }

        new InputGenerator(options);
    }

});