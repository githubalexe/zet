define(["jquery", "knockout", "bootstrap"], function($, ko) {

    function InputGenerator(options) {

        this.$generateButton = options.$generateButton;
        this.$textInput = options.$textInput;
        this.$inputsContainer = options.$inputsContainer;
        this.$clearButton = options.$clearButton;

        this.viewModel = {};
        this.defineListModel();
    };

    InputGenerator.prototype.bindEvents = function() {

        var self = this;

        self.$textInput.on("focus", function() {

        });

    };

    InputGenerator.prototype.defineTexboxModel = function() {

        var self = this;

        self.viewModel = {
            textboxInputs: ko.observableArray([]),
            addInput: function() {

                var options = self.initializeTextbox();

                if (!$.isEmptyObject(options)) {

                    this.textboxInputs.push(new textboxInput(self.viewModel.textboxInputs, options))
                }
            }
        }

        ko.applyBindings(
            self.viewModel
        );
    };

    InputGenerator.prototype.initializeTextbox = function() {

        var text = this.$textInput.val();
        var isJson = this.isJson(text);
        var object = {};

        if (isJson === true) {

            var obj = JSON.parse(text);

            object.label = obj.textbox.label;
            object.placeholder = obj.textbox.placeholder;
        }

        return object;
    };

    //list
    InputGenerator.prototype.defineListModel = function() {

        var self = this;

        self.viewModel = {
            textboxInputs: ko.observableArray([]),
            addInput: function() {

                var options = self.initializeList();

                if (!$.isEmptyObject(options)) {

                    this.textboxInputs.push(new dropDownList(self.viewModel.textboxInputs, options))
                }
            }
        }

        ko.applyBindings(
            self.viewModel
        );
    };

    InputGenerator.prototype.initializeList = function() {

        var text = this.$textInput.val();
        var isJson = this.isJson(text);
        var object = {};

        if (isJson === true) {

            var obj = JSON.parse(text);

            object.label = obj.dropDownList.label;
            object.items = obj.dropDownList.items;
        }

        return object;
    };

    ///

    function dropDownList(textboxInputs, options) {

        var array = [];
        console.log(options.items);

        for (i = 0; i < options.items.length; i++) {

            array.push(new item(options.items[i]));
        }

        return {
            labelField: options.label,
            dropdownList: ko.observableArray([...array]),
            remove: function() {
                textboxInputs.remove(this);
            }
        };
    };

    function item(option) {
        console.log(option);
        return {
            listItemdsadsa: option,
        };
    };

    function textboxInput(textboxInputs, options) {
        return {
            labelField: options.label,
            inputPlaceholder: options.placeholder,
            remove: function() {
                textboxInputs.remove(this);
            }
        };
    };

    InputGenerator.prototype.isJson = function(text) {
        try {
            JSON.parse(text);
        } catch (e) {
            return false;
        }
        return true;
    };

    return InputGenerator;
});