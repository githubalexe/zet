﻿$(function () {

    DeleteModal = function (options) {
        var self = this;

        self.$container = options.$container
        self.kendoGrid = options.kendoGrid;
        self.name = options.name;
        self.id = options.id;
        self.url = options.url;

        self.buildBody();
    }

    DeleteModal.prototype.buildBody = function () {

        var modalBody =
            `<div class="container">
                <div id="deleteModal" role="dialog" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Delete</h5>
                            </div>
                            <div class="modal-body">
                                <div class="selected-items">WARNING: </div>
                                <label>will be deleted.There is no way to recover the ${this.entity} after delition.</label>
                            </div>
                            <div class="modal-footer">
                                <div class="container text-right px-3 pb-4">
                                    <hr />
                                    <button type="button" data-dismiss="modal" id="cancelButton" class="btn modal-button cancel">Cancel</button>
                                    <button type="submit" data-dismiss="modal" id="deleteButton" form="customerCreateForm" class="btn modal-button submit delete">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`

        this.$container.append(modalBody);
    }

    DeleteModal.prototype.getClickedItems = function () {
        var self = this;
        var title = "";
        var $grid = $("#" + self.kendoGrid + " tr.k-state-selected");
        var $kendoGridData = $("#" + self.kendoGrid).data("kendoGrid");

        self.selectedItems = [];

        for (var i = 0; i < $grid.length; i++) {
            var item = $kendoGridData.dataItem($grid[i]);

            self.selectedItems.push(item[self.id]);

            title += "<label class='active-entity'>" + item[self.name] + ",&nbsp" + "</label>";

        }
        $(".selected-items").append(title);
    }

    DeleteModal.prototype.clean = function () {
        $(".active-entity").remove();
    }

    DeleteModal.prototype.deleteItems = function () {
        var self = this;

        $("#deleteButton").on("click", function () {

            for (var item = 0; item < self.selectedItems.length; item++) {

                self.deleteItem(self.selectedItems[item]);
            }
        });
    }

    DeleteModal.prototype.cancelEvent = function () {
        var self = this;
        $kendoGridData = $("#" + self.kendoGrid).data("kendoGrid");

        $("#cancelButton").on("click", function () {
            $kendoGridData.clearSelection();
        });
    }

    DeleteModal.prototype.deleteItem = function (id) {
        var self = this;
        $.ajax({
            type: "DELETE",
            url: self.url + id,
        })
            .done(function () {
                $("#" + self.kendoGrid).data("kendoGrid").refresh();
                $("#" + self.kendoGrid).data("kendoGrid").dataSource.read();
            })
            .fail(function () {
                console.log("Something is wrong");
            })
    }

}());