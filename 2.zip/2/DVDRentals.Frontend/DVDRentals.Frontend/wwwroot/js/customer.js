﻿$(document).ready(function () {
    var $customerCreateForm = $("#customerCreateForm");
    var $createButton = $(".create");

    $createButton.on("click", function () {
        console.log($customerCreateForm);
    });

    var $deleteFilm = $("#deleteCustomer");

    var $options = {
        $container: $("#customerDeleteContainer"),
        kendoGrid: "customersGrid",
        name: "Name",
        id: "CustomerId",
        url: "/Customer/Delete/",
    }

    $deleteFilm.on("click", function () {
        var modal = new DeleteModal($options);

        modal.clean();
        modal.getClickedItems();
        modal.deleteItems();
        modal.cancelEvent();

        $("#deleteModal").modal("show");
    });

});