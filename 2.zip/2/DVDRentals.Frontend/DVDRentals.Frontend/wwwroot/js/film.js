﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteFilm");

    var $options = {
        $container: $("#filmDeleteContainer"),
        kendoGrid: "filmsGrid",
        name: "Title",
        id:"FilmId",
        url: "/Film/Delete/",
    }

    $deleteFilm.on("click", function () {
        var modal = new DeleteModal($options);

        modal.clean();
        modal.getClickedItems();
        modal.deleteItems();
        modal.cancelEvent();

        $("#deleteModal").modal("show");
    });


    $("#searchFilm").keyup(function () {
        var selecteditem = $('#searchFilm').val();
        var kgrid = $("#filmsGrid").data("kendoGrid");
        selecteditem = selecteditem.toUpperCase();
        var selectedArray = selecteditem.split(" ");
        if (selecteditem) {

            var orfilter = { logic: "or", filters: [] };
            var andfilter = { logic: "and", filters: [] };
            $.each(selectedArray, function (i, v) {
                if (v.trim() == "") {
                }
                else {
                    $.each(selectedArray, function (i, v1) {
                        if (v1.trim() == "") {
                        }
                        else {
                            orfilter.filters.push({ field: "Title", operator: "contains", value: v1 },
                                { field: "Title", operator: "contains", value: v1 });
                            andfilter.filters.push(orfilter);
                            orfilter = { logic: "or", filters: [] };
                        }

                    });
                }
            });
            kgrid.dataSource.filter(andfilter);
        }
        else {
            kgrid.dataSource.filter({});
        }

    });

});