﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Inventory;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class InventoryController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddInventory()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            List<InventoryView> list = new List<InventoryView>();

            IEnumerable<InventoryResponse> apiResult = await InventoryApiMethods.GetInventories(storeId);

            foreach (InventoryResponse inventory in apiResult)
            {
                list.Add(inventory.ToInventoryResponseView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> AdddInventory(InventoryView request)
        {
            int storeId = 1;
            InventoryResponse inventory = new InventoryResponse();
            inventory = await InventoryApiMethods.CreateCustomer(request.ToModelCreateInventory(), storeId);

            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> DeleteInventory(int storeId, int customerId)
        {
            storeId = 1;
            customerId = 11;
            await CustomerApiMethods.DeleteCustomer(storeId, customerId);

            return RedirectToAction(nameof(Index));
        }
    }
}