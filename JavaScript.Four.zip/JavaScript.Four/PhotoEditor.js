$(function () {

    PhotoEditor = function (options) {

        var self = this;
        self.$container = options.$container;
        self.buildBody();
        self.convertImageToCanvas();
        self.setFilters();
        self.setEffects();
    }

    PhotoEditor.prototype.buildBody = function () {
        //create edit page
        var self = this;
        var $editorContainer = $('<div/>', {
            class: 'editor-container'
        });
        var $filtersTitle = $('<p/>', {
            class: 'title'
        });
        $filtersTitle.text('Filters');
        var $efectsTitle = $('<p/>', {
            class: 'title'
        });
        $efectsTitle.text('Effects');
        var filters = document.createElement('div');
        filters.classList.add('filters');
        var $filters = $('<div/>', {
            class: 'filters'
        });
        var $effects = $('<div/>', {
            class: 'effects'
        });
        var $submitButtons = $('<div/>', {
            class: 'submit-buttons'
        });
        var $imageContainer = $('<canvas/>', {
            id: 'imageCanvas'
        });

        ////brightness
        var $brightnessContainer = $('<div/>', {
            class: 'button-container'
        });
        var $brightnessLabel = $('<label/>', {
            class: 'label'
        });
        $brightnessLabel.text('Brightness');
        var $minusBrightnessButton = $('<button/>', {
            id: 'minusBrightnessButton',
            class: 'minus-button button',
        });
        $minusBrightnessButton.text('-');
        var $plusBrightnessButton = $('<button/>', {
            id: 'plusBrightnessButton',
            class: 'plus-button button',
        });
        $plusBrightnessButton.text('+');

        //contrast
        var $contrastContainer = $('<div/>', {
            class: 'button-container'
        });
        var $contrastLabel = $('<label/>', {
            class: 'label'
        });
        $contrastLabel.text('Contrast');
        var $minusContrastButton = $('<button/>', {
            id: 'minusContrastButton',
            class: 'minus-button button',
        });
        $minusContrastButton.text('-');
        var $plusContrastButton = $('<button/>', {
            id: 'plusContrastButton',
            class: 'plus-button button',
        });
        $plusContrastButton.text('+');

        //saturate
        var $saturationContainer = $('<div/>', {
            class: 'button-container'
        });
        var $saturationLabel = $('<label/>', {
            class: 'label'
        });
        $saturationLabel.text('saturate');
        var $minusSaturateButton = $('<button/>', {
            id: 'minusSaturateButton',
            class: 'minus-button button',
        });
        $minusSaturateButton.text('-');
        var $plusSaturateButton = $('<button/>', {
            id: 'plusSaturateButton',
            class: 'plus-button button',
        });
        $plusSaturateButton.text('+');

        //Sepia
        var $sepiaContainer = $('<div/>', {
            class: 'button-container'
        });
        var $sepiaLabel = $('<label/>', {
            class: 'label'
        });
        $sepiaLabel.text('Sepia');
        var $minusSepiaButton = $('<button/>', {
            id: 'minusSepiaButton',
            class: 'minus-button button',
        });
        $minusSepiaButton.text('-');
        var $plusSepiaButton = $('<button/>', {
            id: 'plusSepiaButton',
            class: 'plus-button button',
        });
        $plusSepiaButton.text('+');

        ///Effects buttons
        var $vintageEfectButton = $('<button/>', {
            id: 'vintageEfectButton',
            class: 'effect-button',
        });
        $vintageEfectButton.text('Vintage');

        var $lemoEffectButton = $('<button/>', {
            id: 'lemoeffectButton',
            class: 'effect-button',
        });
        $lemoEffectButton.text('Lemo');

        var $clarityEffectButton = $('<button/>', {
            id: 'clarityEffectButton',
            class: 'effect-button',
        });
        $clarityEffectButton.text('Clarity');

        var $sinCityEffectButton = $('<button/>', {
            id: 'sinCityEffectButton',
            class: 'effect-button',
        });
        $sinCityEffectButton.text('Sin City');

        var $crossProcessEffectButton = $('<button/>', {
            id: 'crossProcessEffectButton',
            class: 'effect-button',
        });
        $crossProcessEffectButton.text('Cross Process');

        var $pinholeEffectButton = $('<button/>', {
            id: 'pinholeEffectButton',
            class: 'effect-button',
        });
        $pinholeEffectButton.text('Pinhole');

        var $nostalgiaEffectButton = $('<button/>', {
            id: 'nostalgiaEffectButton',
            class: 'effect-button',
        });
        $nostalgiaEffectButton.text('Nostalgia');

        var herMajestyEffectButton = document.createElement('button');
        herMajestyEffectButton.setAttribute('id', 'herMajestyEffectButton');
        herMajestyEffectButton.classList.add('effect-button');
        herMajestyEffectButton.innerHTML = 'Nostalgia';
        var $herMajestyEffectButton = $('<button/>', {
            id: 'herMajestyEffectButton',
            class: 'effect-button',
        });
        $herMajestyEffectButton.text('Her Majesty');
        //download and remove filters
        var $saveButton = $('<button/>', {
            id: 'saveButton',
            class: 'effect-button',
        });
        $saveButton.text('Save');
        var $removeEffectsButton = $('<button/>', {
            id: 'removeEffectsButton',
            class: 'effect-button',
        });
        $removeEffectsButton.text('Remove Filters');
        //////////
        $editorContainer.append($imageContainer);
        $brightnessContainer.append($minusBrightnessButton);
        $brightnessContainer.append($brightnessLabel);
        $brightnessContainer.append($plusBrightnessButton);
        $contrastContainer.append($minusContrastButton);
        $contrastContainer.append($contrastLabel);
        $contrastContainer.append($plusContrastButton);
        $saturationContainer.append($minusSaturateButton);
        $saturationContainer.append($saturationLabel);
        $saturationContainer.append($plusSaturateButton);
        $sepiaContainer.append($minusSepiaButton);
        $sepiaContainer.append($sepiaLabel);
        $sepiaContainer.append($plusSepiaButton);
        $filters.append($brightnessContainer);
        $filters.append($contrastContainer);
        $filters.append($saturationContainer);
        $filters.append($sepiaContainer);
        $effects.append($vintageEfectButton);
        $effects.append($lemoEffectButton);
        $effects.append($clarityEffectButton);
        $effects.append($sinCityEffectButton);
        $effects.append($crossProcessEffectButton);
        $effects.append($pinholeEffectButton);
        $effects.append($nostalgiaEffectButton);
        $effects.append($herMajestyEffectButton);
        $submitButtons.append($removeEffectsButton);
        $submitButtons.append($saveButton);
        $editorContainer.append($filtersTitle);
        $editorContainer.append($filters);
        $editorContainer.append($efectsTitle);
        $editorContainer.append($effects);
        $editorContainer.append($submitButtons);
        self.$container.append($editorContainer);
    }



    PhotoEditor.prototype.setFilters = function () {

        var self = this;


        var brightness = 1;
        var contrast = 1;
        var saturate = 1;
        var sepia = 1;

        function getBrightness(value) {
            var $canvas = $('#imageCanvas', self.$container)[0];
            var ctx = $canvas.getContext('2d');
            var imgData = ctx.getImageData(0, 0, $canvas.width, $canvas.height);
            var data = imgData.data;
            for (var i = 0, len = data.length; i < len; i += 1) {
                data[i] += value;
                data[i + 1] += value;
                data[i + 2] += value;
            }
            ctx.putImageData(imgData, 0, 0);
        }

        function get2Brightness(value) {
    
            var $canvas = $('#imageCanvas', self.$container)[0];
            var ctx = $canvas.getContext('2d');
            var imgData = ctx.getImageData(0, 0, $canvas.width, $canvas.height);
            var data = imgData.data;
            for (var i = 0, len = data.length; i < len; i += 1) {
                data[i] -= value;
                data[i + 1] -= value;
                data[i + 2] -= value;
            }
            ctx.putImageData(imgData, 0, 0);
        }

        self.$container.on('click', '#minusBrightnessButton', function () {
            // brightness = brightness - 0.1;
            // if (brightness < 0.1) {
            //     brightness = 0.1;
            // }
            // $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');
            brightness = brightness - 1;
            get2Brightness(brightness);
      
        });

        self.$container.on('click', '#plusBrightnessButton', function () {
            brightness = brightness + 1;
            getBrightness(brightness);
        
            // if (brightness > 5) {
            //     brightness = 5;
            // }
            // $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');



            //var data = $canvas.toDataURL(srcValue);//save the image
            //window.open(data);

        });

        self.$container.on('click', '#minusContrastButton', function () {
            contrast = contrast - 0.1;
            if (contrast < 0.1) {
                contrast = 0.1;
            }
            $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');
        });

        self.$container.on('click', '#plusContrastButton', function () {
            contrast = contrast + 0.1;
            if (contrast > 5) {
                contrast = 5;
            }
            $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');
        });

        self.$container.on('click', '#minusSaturateButton', function () {
            saturate = saturate - 0.1;
            if (saturate < 0.1) {
                saturate = 0.1;
            }
            $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');
        });

        self.$container.on('click', '#plusSaturateButton', function () {
            saturate = saturate + 0.1;
            if (saturate > 5) {
                saturate = 5;
            }
            $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');
        });

        self.$container.on('click', '#minusSepiaButton', function () {
            sepia = sepia - 10;
            if (sepia < 10) {
                sepia = 10;
            }
            $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');
        });

        self.$container.on('click', '#plusSepiaButton', function () {
            sepia = sepia + 10;
            if (sepia > 100) {
                sepia = 100;
            }
            $canvas.css('filter', 'brightness(' + brightness + ') contrast(' + contrast + ') saturate(' + saturate + ') sepia(' + sepia + '%' + ')');
        });

        // self.$container.on('click', '#saveButton', function () {
        //     var self = this;
        //     $canvas = $('#imageCanvas', self.$container)[0];
        //     var file = $('#imageCanvas', self.$container);
        //     var srcValue = localStorage.getItem('imageSrc');
        //     var fileName = file;
        //     const fileExtension = file;

        //     // Init new filename
        //     let newFilename;

        //     // Check image type
        //     if (fileExtension === ".jpg" || fileExtension === ".png") {
        //         // new filename
        //         newFilename = fileName.substring(0, fileName.length - 4) + "-edited.jpg";
        //     }

        //     // Call download
        //     download($canvas, newFilename);

        //     // Download
        //     function download($canvas, filename) {
        //         // Init event
        //         let e;
        //         // Create link
        //         const link = document.createElement("a");

        //         // Set props
        //         link.download = filename;
        //         link.href = $canvas.toDataURL("image/jpeg", 0.8);
        //         // New mouse event
        //         e = new MouseEvent("click");
        //         // Dispatch event
        //         link.dispatchEvent(e);
        //     }

        // });



    }

    PhotoEditor.prototype.setEffects = function () {
        var self = this;
        var $image = $('.image', self.$container);
        self.$container.on('click', '#vintageEfectButton', function () {

            $image.addClass('emboss');
        });
    }

    PhotoEditor.prototype.convertImageToCanvas = function () {
        var self = this;

        var srcValue = localStorage.getItem('imageSrc');
        var $canvas = $('#imageCanvas', self.$container)[0];
        var ctx = $canvas.getContext('2d');



        var image = new Image();
        image.src = srcValue;
        image.onload = function () {
            $canvas.width = image.width;
            $canvas.height = image.height;
            ctx.drawImage(image, 0, 0, $canvas.width, $canvas.height);
            var data = $canvas.toDataURL(image.src);//save the image
        };






        //  filter: saturate(1.5) contrast(1.3) hue-rotate(-5deg) blur(.2px) brightness(1.1); lemo
        //https://codepen.io/bradtraversy/pen/qoJZBy--efect
        //https://bennettfeely.com/image-effects/
    }


}());