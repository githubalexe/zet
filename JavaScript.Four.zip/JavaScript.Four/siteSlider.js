var options = {
    $container: $('#ImageSlider1')
}
var plugin1 = new ImageSlider(options);

var options2 = {
    $container: $('#ImageSlider2')
}
var plugin2 = new ImageSlider(options2);


