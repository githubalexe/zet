﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Rental
    {
        public int rentalId { get; set; }
        public DateTime rentalDate { get; set; }
        public Inventory invetoryId;
        public ICustomer customer { get; set; }
        public DateTime returnDate { get; set; }
        public IEmployee employee { get; set; }
    }
}
