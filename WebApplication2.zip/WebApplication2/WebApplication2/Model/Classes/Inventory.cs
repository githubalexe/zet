﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Model.Classes
{
    public class Inventory
    {
        public int inventoryId;
        public Store store;
        public Film film;

        public Inventory(Store store, Film film)
        {
            this.store = store;
            this.film = film;
        }
    }
}
