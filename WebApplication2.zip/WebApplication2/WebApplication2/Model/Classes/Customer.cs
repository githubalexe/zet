﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Customer:ICustomer//Oare are mai multi angajati care i-au facut inchirierea??? ca pana la urma poate peste 3 saptamani il prinde pe alt angajat si ii face alta inchiriere. 
    {
        public int customerId { get; set; }
        public IStore store { get; set; }//aici ar trebui store id
        public string lastName { get; set; }
        public string firstName { get; set; }
        public IAddress customerAddress { get; set; }
        public string picture { get; set; }//binary?
        public string email { get; set; }
        public bool active { get; set; }
        public DateTime createDate { get; set; }
        public DateTime lastUpdate { get; set; }
        //
        //public ObservableCollection<IRental> PersonalRentals;//trebuie sa ii dai this;

        public Customer(int customerId, Store store, string lastName, string firstName, Address customerAddress, string picture, string email, bool active, DateTime createDate, DateTime lastUpdate)
        {
            this.customerId = customerId;
            this.store = store;
            this.lastName = lastName;
            this.firstName = firstName;
            this.customerAddress = customerAddress;
            this.picture = picture;
            this.email = email;
            this.active = active;
            this.createDate = createDate;
            this.lastUpdate = lastUpdate;
        }
        public void AddRental(IRental rental)
        {

        }


    }
}
