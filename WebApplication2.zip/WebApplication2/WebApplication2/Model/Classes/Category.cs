﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Category: ICategory
    {
        public int categoryId { get; set; }
        public string name { get; set; }
        public DateTime lastUpdate { get; set; }
        public ObservableCollection<IFilm> Films;// optional

        public Category(int categoryId, string name, DateTime lastUpdate, ObservableCollection<IFilm> films)
        {
            this.categoryId = categoryId;
            this.name = name;
            this.lastUpdate = lastUpdate;
            Films = films;
        }
    }
}
