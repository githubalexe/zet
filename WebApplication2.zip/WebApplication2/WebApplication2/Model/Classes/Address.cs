﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    //Intrebare://Cu obiectul asta poate lua si tara, nu??
    public class Address:IAddress
    {
        public int addressId { get; set; }
        public string address { get; set; }
        public string address2 { get; set; }
        public string distrinct { get; set; }
        public ICity city { get; set; }
        public string postaCode { get; set; }
        public string phone { get; set; }
        public DateTime lastUpdate { get; set; }
        public string location { get; set; }
           
    }
}
