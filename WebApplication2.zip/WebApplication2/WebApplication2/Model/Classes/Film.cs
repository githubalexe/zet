﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Film:IFilm
    {
        public int filmId { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public int releaseYear { get; set; }
        public ILanguage language { get; set; }
        public ILanguage originalLanguage { get; set; }
        public IStore store { get; set; }//un film are si un store, asa cred....
        public int rentalDuration { get; set; }
        public double rentalRate { get; set; }
        public int lenghtDuration { get; set; }
        public double replacementCost { get; set; }
        public string rating { get; set; }
        public string specialFeatures { get; set; }
        public DateTime lastUpdate { get; set; }
        ////
        
        ////
        public ObservableCollection<IActor> Actors;
        public ObservableCollection<ICategory> Categories;//pe constructor i

        public Film(int filmId, string title, string description, int releaseYear, ILanguage language, ILanguage originalLanguage, IStore store, int rentalDuration, double rentalRate, int lenghtDuration, double replacementCost, string rating, string specialFeatures, DateTime lastUpdate)
        {
            this.filmId = filmId;
            this.title = title;
            this.description = description;
            this.releaseYear = releaseYear;
            this.language = language;
            this.originalLanguage = originalLanguage;
            this.store = store;
            this.rentalDuration = rentalDuration;
            this.rentalRate = rentalRate;
            this.lenghtDuration = lenghtDuration;
            this.replacementCost = replacementCost;
            this.rating = rating;
            this.specialFeatures = specialFeatures;
            this.lastUpdate = lastUpdate;
            Actors = new ObservableCollection<IActor>();
            Categories= new ObservableCollection<ICategory>();
        }
    }
}
