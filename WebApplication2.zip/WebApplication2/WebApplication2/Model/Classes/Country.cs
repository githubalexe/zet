﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Country: ICountry
    {
        public int countryId { get; set; }
        public string name { get; set; }
        public DateTime lastUpdate { get; set; }

        public Country(int countryId, string name, DateTime lastUpdate)
        {
            this.countryId = countryId;
            this.name = name;
            this.lastUpdate = lastUpdate;
        }
    }
}
