﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Language: ILanguage
    {
        public int languageyId { get; set; }
        public string name { get; set; }
        public DateTime lastUpdate { get; set; }

        public Language(int languageyId, string name, DateTime lastUpdate)
        {
            this.languageyId = languageyId;
            this.name = name;
            this.lastUpdate = lastUpdate;
        }
    }
}
