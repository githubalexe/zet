﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Store:IStore///vezi object mapper sau AUtoMapper , ORM(object relational mapper) DATA BASE FIRST.
    {
      public  int storeId { get; set; }
      public  IEmployee managerEmployeeId { get; set; }
      public  IAddress storeAddress { get; set; }
      public  DateTime lastUpdate { get; set; }
      //
      ObservableCollection<IFilm> Films;//optinal
       /// Relatie  One to many in tabela Inventary. one store mai multe filme si se inregistreaza in tabela invatar.

      ObservableCollection<IEmployee> Employees;




        //public int IStore.StoreId { get => storeId; set => storeId = value; }
        //public Employee IStore.ManagerEmployeeId { get => managerEmployeeId; set => managerEmployeeId = value; }
        //public Address IStore.StoreAddress { get => storeAddress; set => storeAddress = value; }
        //public DateTime IStore.LastUpdate { get => lastUpdate; set => lastUpdate = value; }


        //public string StoreId
        //{
        //    get
        //    {
        //        return StoreId;
        //    }

        //    set
        //    {
        //        StoreId = value;
        //    }
        //}
        //public string ManagerEmployeeId
        //{
        //    get
        //    {
        //        return ManagerEmployeeId;
        //    }

        //    set
        //    {
        //        ManagerEmployeeId = value;
        //    }
        //}
        //public string StoreAddress
        //{
        //    get
        //    {
        //        return StoreAddress;
        //    }

        //    set
        //    {
        //        StoreAddress = value;
        //    }
        //}
        //public string LastUpdate
        //{
        //    get
        //    {
        //        return LastUpdate;
        //    }

        //    set
        //    {
        //        LastUpdate = value;
        //    }
        //}

    }
}
