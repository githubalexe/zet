﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Employee:IEmployee//orice Employee este un customer doar ca are ceva in pus
    {
        public int employeeId { get; set; }
        public string lastName { get; set; }
        public string firstName { get; set; }
        public IAddress employeeAddress { get; set; }
        public string picture { get; set; }//binary?
        public string email { get; set; }
        public IStore store { get; set; }
        public bool active { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public DateTime lastUpdate { get; set; }
        //
 
        //public ObservableCollection<IPayment> Rentals;poate ma mai gandesc

        public Employee(int employeeId, string lastName, string firstName, Address employeeAddress, string picture, string email, Store store, bool active, string username, string password, DateTime lastUpdate)
        {
            this.employeeId = employeeId;
            this.lastName = lastName;
            this.firstName = firstName;
            this.employeeAddress = employeeAddress;
            this.picture = picture;
            this.email = email;
            this.store = store;
            this.active = active;
            this.username = username;
            this.password = password;
            this.lastUpdate = lastUpdate;
        }
    }
}
