﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class Actor:IActor
    {
        public int actorId { get; set; }
        public string lastName { get; set; }
        public string firstName { get; set; }
        public DateTime lastUpdate { get; set; }
     


    }
}
