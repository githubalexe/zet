﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.IEntity;

namespace WebApplication2.Model.Classes
{
    public class City:ICity
    {
        public int cityId { get; set; }
        public string name { get; set; }
        public ICountry country { get; set; }
        public DateTime lastUpdate { get; set; }

        public City(int cityId, string name, Country country, DateTime lastUpdate)
        {
            this.cityId = cityId;
            this.name = name;
            this.country = country;
            this.lastUpdate = lastUpdate;
        }
    }
}
