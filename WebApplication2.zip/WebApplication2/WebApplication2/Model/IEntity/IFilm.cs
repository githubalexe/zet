﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.Classes;

namespace WebApplication2.Model.IEntity
{
    public interface IFilm
    {
       int filmId { get; set; }
       string title { get; set; }
       string description { get; set; }
       int releaseYear { get; set; }
       ILanguage language { get; set; }
       ILanguage originalLanguage { get; set; }
       IStore store { get; set; }
       int rentalDuration { get; set; }
       double rentalRate { get; set; }
       int lenghtDuration { get; set; }
       double replacementCost { get; set; }
       string rating { get; set; }
       string specialFeatures { get; set; }
       DateTime lastUpdate { get; set; }
    }
}
