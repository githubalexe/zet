﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.Classes;

namespace WebApplication2.Model.IEntity
{
    public interface IEmployee
    {
         int employeeId { get; set; }
         string lastName { get; set; }
         string firstName { get; set; }
         IAddress employeeAddress { get; set; }
         string picture { get; set; }//binary?
         string email { get; set; }
         IStore store { get; set; }
         bool active { get; set; }
         string username { get; set; }
         string password { get; set; }
         DateTime lastUpdate { get; set; }

    }
}
