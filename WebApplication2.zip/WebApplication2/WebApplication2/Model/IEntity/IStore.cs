﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.Classes;

namespace WebApplication2.Model.IEntity
{
    public interface IStore
    {
        int storeId { get; set; }
        IEmployee managerEmployeeId { get; set; }
        IAddress storeAddress { get; set; }
        DateTime lastUpdate { get; set; }
    }
}
