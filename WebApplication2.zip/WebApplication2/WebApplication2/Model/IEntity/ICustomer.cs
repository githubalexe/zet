﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.Classes;

namespace WebApplication2.Model.IEntity
{
    public interface ICustomer
    {
        int customerId { get; set; }
        IStore store { get; set; }
        string lastName { get; set; }
        string firstName { get; set; }
        IAddress customerAddress { get; set; }
        string picture { get; set; }//binary?
        string email { get; set; }
        bool active { get; set; }
        DateTime createDate { get; set; }
        DateTime lastUpdate { get; set; }
    }
}
