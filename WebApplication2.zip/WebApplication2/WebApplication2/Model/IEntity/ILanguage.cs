﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Model.IEntity
{
    public interface ILanguage
    {
        int languageyId { get; set; }
        string name { get; set; }
        DateTime lastUpdate { get; set; }
    }
}
