﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Model.IEntity
{
    public interface IActor
    {
        int actorId { get; set; }
        string lastName { get; set; }
        string firstName { get; set; }
        DateTime lastUpdate { get; set; }
    }
}
