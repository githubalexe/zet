﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Model.IEntity
{
    public interface IRental
    {
         int rentalId { get; set; }
         DateTime rentalDate { get; set; }
         double amount { get; set; }
         DateTime paymentDate { get; set; }
         DateTime returnDate { get; set; }
         IStore store { get; set; }
         ICustomer customer { get; set; }
         IEmployee employee { get; set; }
         IFilm film { get; set; }
    }
}
