﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.Classes;

namespace WebApplication2.Model.IEntity
{
    public interface IAddress
    {
        int addressId { get; set; }
        string address { get; set; }
        string address2 { get; set; }
        string distrinct { get; set; }
        ICity city { get; set; }
        string postaCode { get; set; }
        string phone { get; set; }
        DateTime lastUpdate { get; set; }
        string location { get; set; }
    }
}
