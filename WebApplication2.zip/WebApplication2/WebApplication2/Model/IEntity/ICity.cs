﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Model.Classes;

namespace WebApplication2.Model.IEntity
{
    public interface ICity
    {
        int cityId { get; set; }
        string name { get; set; }
        ICountry country { get; set; }
        DateTime lastUpdate { get; set; }
    }
}
