define(["jquery", "InputHelper", "Factory", "Type", "bootstrap"], function($, InputHelper, Factory, Type) {

    function InputGenerator(options) {
        this.options = $.extend({}, true, InputGenerator.defaultOptions, options);
        this.$inputsContainer = this.options.$inputsContainer;
        this.onControlCreate = this.options.onControlCreate;
        this.jsonOptions = {};
        this.controls = [];
    };

    InputGenerator.prototype.createByJsonValue = function(value) {

        if (InputHelper.IsJson(value)) {
            this.jsonOptions = JSON.parse(value);
            this.createInput();
        } else {
            this.jsonOptions = value;
            this.createInput();
        }
    };

    InputGenerator.prototype.createInput = function() {
        var self = this;
        if (InputHelper.IsArray(self.jsonOptions)) {
            var inputs = [...self.jsonOptions];
            var inputsLength = inputs.length;

            for (var i = 0; i < inputsLength; i++) {

                var $wrapperInput = self.createWrapper();

                var jsonObject = {
                    $wrapperInput: $wrapperInput,
                    jsonOptions: inputs[i]
                };

                Factory.CreateControl(jsonObject, function(control) {
                    self.setIdWrapper(control);
                    self.controls.push(control);
                    self.onControlCreate(control);
                    $("select").selectpicker();
                    setControlDatatype(control);
                });
            }
        }
    };

    function setControlDatatype(control) {
        var $inputId = $("#" + control.inputId);
        if (control.jsonOptions.type === Type.DateTime) {
            $inputId.datetimepicker({
                format: "dd MM yyyy",
            });
        }

        if (control.jsonOptions.type === Type.CheckBox) {
            if (control.jsonOptions.inputOptions.multiselect === false) {
                setMultiselectFalse(control);
            } else {
                setMultiselectTrue(control);
            }
        }
    };

    function setMultiselectFalse(control) {
        $("#" + control.inputId + " input[type='checkbox']").on('change', function() {
            control.GetInputNameCheckedDomElement(this.name).not(this).prop('checked', false);
            var value = control.GetInputNameCheckedDomElement(this.name).val();
            control.SetInputValue(value);
        });
    };

    function setMultiselectTrue(control) {
        $("#" + control.inputId + " input[type='checkbox']").on('change', function() {
            control.SetInputValue(getSelectedItems(control));
        });
    };

    function getSelectedItems(control) {
        var items = [];
        var $checked = $("#" + control.inputId + " input[type='checkbox']");
        $checked.each(function(index) {
            if (index !== $checked.length)
                if ($(this).is(":checked")) {
                    items.push($(this).val());
                }
        });
        return items;
    };

    InputGenerator.prototype.setIdWrapper = function(control) {
        control.options.$wrapperInput.attr("id", control.wrapperId);
    };

    InputGenerator.prototype.deleteControl = function(inputId) {
        var self = this;
        var controlLength = self.controls.length;

        for (var i = 0; i < controlLength; i++) {
            if (self.controls[i].inputId == inputId) {
                self.controls.splice(self.controls.indexOf(self.controls[i]), 1);
                break;
            }
        }
    };

    InputGenerator.prototype.createWrapper = function() {
        var $wrapperInput = $("<div/>", {
            class: "input-field"
        });
        this.$inputsContainer.append($wrapperInput);

        return $wrapperInput;
    };

    InputGenerator.defaultOptions = {
        $inputsContainer: $({}),
        onControlCreate: null,
    };

    return InputGenerator;
});