define(["Control"], function(Control) {

    function TextboxInput(options) {
        this.options = $.extend({}, TextboxInput.defaultOptions, true, options);
        this.inputName = this.options.inputName;
        this.inputType = this.options.inputType;
        this.dataType = this.options.dataType;
        this.value = this.options.value;
        this.validations = this.options.validations;

        Control.call(this);
    };

    TextboxInput.defaultOptions = {
        inputType: null,
        inputName: null,
        dataType: null,
        value: null,
        validations: {},
    }

    return TextboxInput;
})