define([], function() {

    DataTypes = {
        Number: "number",
        String: "string",
        Date: "date",
        Null: null
    }

    return DataTypes;
});