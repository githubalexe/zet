define(["jquery", "FormGenerator", "InputValidations"], function($, FormGenerator, InputValidations) {

    var index = {};

    var $generateForm = $("#generateForm");
    var $formsContainer = $("#formsContainer");
    var $formJsonSchema = $("#formJsonSchema");
    var $validationsJsonSchema = $("#validationsJsonSchema");

    index.generateForm = function(form, validations) {
        createForm(form, validations);
    };

    $formJsonSchema.val(`
    {  
        "type":"form",     
        "name":"form1",
        "titleForm":"Test Title",
        "cancelButton":"Cancel",
        "submitButton":"Submit",
        "inputs":
        [  
            {  
               "type":"textbox",
               "inputOptions":{  
                  "name":"textbox1",
                  "label":"Number",
                  "placeholder":"Write any number",
                  "type":"number"
               }
            },
            {  
               "type":"dropdown",
               "inputOptions":{  
                  "name":"dropdown1",
                  "type":"number",
                  "label":"Colors",
                  "items":[  
                     {  
                        "text":"Red",
                        "value":"1"
                     },
                     {  
                        "text":"Black",
                        "value":"2"
                     },
                     {  
                        "text":"White",
                        "value":"3"
                     }
                  ]
               }
            },

            {
                "type": "checkBox",
                "inputOptions": {
                    "label": "Gender",
                    "name": "checkBox1",
                    "type": "number",
                    "multiselect": false,
                    "items": [{
                        "text": "Male",
                        "name": "gender",
                        "value": "1"
                    }, {
                        "text": "Female",
                        "name": "gender",
                        "value": "2"
                    }, {
                        "text": "Both",
                        "name": "gender",
                        "value": "3"
                    }]
                }
            },
            {  
               "type":"checkBox",
               "inputOptions":{  
                  "label":"Persons",
                  "name":"checkBox2",
                  "type":"number",
                  "multiselect":true,
                  "items":[  
                     {  
                        "text":"Person 1",
                        "name":"person",
                        "value":"1"
                     },
                     {  
                        "text":"Person 2",
                        "name":"person",
                        "value":"2"
                     },
                     {  
                        "text":"Person 3",
                        "name":"person",
                        "value":"3"
                     },
                     {  
                        "text":"Person 4",
                        "name":"person",
                        "value":"4"
                     }
                  ]
               }
            },
            {  
               "type":"dateTime",
               "inputOptions":{  
                  "name":"dateTime1",
                  "label":"Date Time",
                   "type":"date"
               }
            }
         ]
     }
    `)

    $validationsJsonSchema.val(`
    [
        {
            "name": "textbox1",
            "validationRules": {
                "required": true,
                "min": 2,
                "max": 10,
                "regex": ""
            }
        },
        {
            "name": "textbox2",
            "validationRules": {
                "required": true,
                "min": 2,
                "max": 10,
                "regex": "[a-zA-Z]"
            }
        },
        {
            "name": "dropdown1",
            "validationRules": {
                "required": true,
                "min": 2,
                "max": 3
            }
        },
        {
            "name": "dateTime1",
            "validationRules": {
                "required": true,
                "min": "13 december 2018",
                "max": "15 january 2019"
            }
        },
        {
            "name": "checkBox1",
            "validationRules": {
                "required": true,
                "min": 5,
                "max": 7
            }
        },
        {
            "name": "checkBox2",
            "validationRules": {
                "required": true,
                "min": 2,
                "max": 3
            }
        }
    ]
    `);


    bindEvents();

    function bindEvents() {
        $generateForm.on("click", function() {
            var form = JSON.parse($formJsonSchema.val());
            var validations = JSON.parse($validationsJsonSchema.val())
            createForm(form, validations);
        })
    };

    function createForm(form, validations) {
        var options = {
            $formsContainer: $formsContainer,
            formOptions: form,
            validations: validations,
        }
        var formGenerator = new FormGenerator(options);
        formGenerator.CreateForm();
    };

    return index;
});