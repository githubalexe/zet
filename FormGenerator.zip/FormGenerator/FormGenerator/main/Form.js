define(["FormControl", "Templates"], function(FormControl, Templates) {

    function Form(options) {
        var self = this;
        this.options = $.extend({}, true, Form.defaultOptions, options);
        this.$wrapperFormId = this.options.$wrapperFormId;
        this.formOptions = this.options.formOptions;

        FormControl.call(this);

        this.BuildHtml(
            self.$wrapperFormId,
            Templates.FormTemplate,
            formOptions = {
                formId: self.formId,
                containerId: self.containerId,
                inputsContainerId: self.inputsContainerId,
                submitButtonId: self.submitButtonId,
                titleForm: self.formOptions.titleForm,
                cancelButton: self.formOptions.cancelButton,
                submitButton: self.formOptions.submitButton
            }
        );
    };

    Form.defaultOptions = {
        $formsContainer: $({}),
        formOptions: {}
    };

    return Form;
});