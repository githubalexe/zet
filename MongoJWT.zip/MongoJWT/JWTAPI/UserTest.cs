﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JWTAPI
{
    public class UserTest
    {
        public string Message { get; set; }
    }
}
