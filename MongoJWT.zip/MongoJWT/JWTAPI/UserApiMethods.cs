﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace JWTAPI
{
    public class UserApiMethods
    {
        public readonly HttpClient _client;
        public UserApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<UserResponse> GetCustomerAsync(string userName, string password)
        {
            UserResponse user = new UserResponse();

            string uri = "https://localhost:44328/";
            string url = String.Format("{0}users/{1}/{2}", uri, userName, password);
            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                user = JsonConvert.DeserializeObject<UserResponse>(dataJson);
            }


            return user;
        }

    }
}
