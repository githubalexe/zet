﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JWTAPI
{
    public class Admin
    {
        public string Message { get; set; }
    }
}
