﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using JWTAPI;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

using MongoJWT.Data.Domain;

namespace MongoJWT.Controllers
{
    public class ApplicationUserController : Controller
    {
        private readonly UserApiMethods _userApiMethods;
        private readonly IConfiguration _configuration;
        public ApplicationUserController(UserApiMethods userApiMethods, IConfiguration configuration)
        {
            _userApiMethods = userApiMethods;
            _configuration = configuration;
        }

        [HttpPost("login")]
        public async Task<ActionResult> Login([FromBody] LoginModel model)
        {
            var user = await _userApiMethods.GetCustomerAsync(model.UserName, model.Password);


            var claim = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
                      new Claim(JwtRegisteredClaimNames.Sub, user.Id),
                        new Claim(ClaimTypes.Role, "User"),
                      new Claim(JwtRegisteredClaimNames.Sub, user.Email)
                };
            var signinKey = new SymmetricSecurityKey(
              Encoding.UTF8.GetBytes(_configuration["ApplicationSettings:JWT_Secret"]));

            int expiryInMinutes = Convert.ToInt32(_configuration["ApplicationSettings:ExpiryInMinutes"]);

            var token = new JwtSecurityToken(
              issuer: _configuration["ApplicationSettings:Site"],
              audience: _configuration["ApplicationSettings:Site"],
              claims: claim,
              expires: DateTime.UtcNow.AddMinutes(expiryInMinutes),
              signingCredentials: new SigningCredentials(signinKey, SecurityAlgorithms.HmacSha256)
            );

            return Ok(
              new
              {
                  token = new JwtSecurityTokenHandler().WriteToken(token),
                  expiration = token.ValidTo
              });

            return Unauthorized();
        }
    }
}