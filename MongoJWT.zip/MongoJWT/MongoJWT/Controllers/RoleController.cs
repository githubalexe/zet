﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;
using JWTAPI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MongoJWT.Controllers
{
    public class RoleController : Controller
    {
        private readonly UserApiMethods _userApiMethods;
        public RoleController(UserApiMethods userApiMethods)
        {
            _userApiMethods = userApiMethods;
        }

        [Authorize]
        [HttpGet("role")]
        public async Task<IActionResult> GetRole()
        {
            var jwtToken = Request.Headers["Authorization"];
            var credValue = jwtToken.ToString().Substring("Basic ".Length).Trim();
            var handler = new JwtSecurityTokenHandler();
            var tokenS = handler.ReadToken(credValue) as JwtSecurityToken;

            var role = tokenS.Claims.First(claim => claim.Type == "http://schemas.microsoft.com/ws/2008/06/identity/claims/role").Value;

            if (role == "User")
            {
                UserTest user = await _userApiMethods.GetUser(jwtToken);

                if (user != null)
                {
                    return Ok(user);
                    //return RedirectToAction(nameof(UserDetails));
                }
            }

            if (role == "Admin")
            {
                Admin admin = await _userApiMethods.GetAdmin(jwtToken);
                if (admin != null)
                {
                    return Ok(admin);
                    //return RedirectToAction(nameof(AdminDetails));
                }
            }

            return Ok();
        }
    }
}