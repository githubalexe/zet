﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JWTAPI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoJWT.Data.Domain;
using MongoJWT.Data.Repository;

using MongoJWT.Data;

namespace MongoJWT.Controllers
{
    public class UserController : Controller
    {
        private IUserRepository _userRepository;
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }


        [HttpGet("users/{userName}/{password}", Name = "GetUser")]
        public async Task<IActionResult> GetCustomer(string userName, string password)
        {
            User user = await _userRepository.GetAsync(userName, password);

            UserResponse response = user.ToUserResponse();

            if (user == null)
            {
                return BadRequest("Error");
            }

            return Ok(response);
        }

        [Authorize]
        [HttpGet("auth")]
        public async Task<IActionResult> Getceva(string userName, string password)
        {
            return Ok("Yes it work.");
        }
    }
}