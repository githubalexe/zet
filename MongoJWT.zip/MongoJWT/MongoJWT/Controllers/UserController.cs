﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JWTAPI;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MongoJWT.Data.Domain;
using MongoJWT.Data.Repository;

using MongoJWT.Data;

namespace MongoJWT.Controllers
{
    public class UserController : Controller
    {
        private IUserRepository _userRepository;
        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }


        [HttpGet("users/{userName}/{password}", Name = "GetUser")]
        public async Task<IActionResult> GetCustomer(string userName, string password)
        {
            User user = await _userRepository.GetAsync(userName, password);

            UserResponse response = user.ToUserResponse();

            if (user == null)
            {
                return BadRequest("Error");
            }

            return Ok(response);
        }


        [Authorize(Roles = "User")]
        [HttpGet("user")]
        public async Task<IActionResult> GetUser()
        {
            UserTest user = new UserTest();
            user.Message = "It is authorize for USER";

            return Ok(user);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("admin")]
        public async Task<IActionResult> Admin(string userName, string password)
        {
            Admin admin = new Admin();
            admin.Message = "It is authorize for ADMIN";

            return Ok(admin);
        }
    }
}