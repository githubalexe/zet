﻿using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using MongoJWT.Data.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoJWT.Data
{
    public class UnitOfWork
    {
        public readonly IMongoCollection<User> User;
        public UnitOfWork(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("JWTDB"));
            var database = client.GetDatabase("JWTDB");

            User = database.GetCollection<User>("User");
        }
    }
}
