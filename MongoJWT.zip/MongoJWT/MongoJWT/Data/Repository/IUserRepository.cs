﻿using MongoJWT.Data.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoJWT.Data.Repository
{
    public interface IUserRepository
    {
        Task<User> GetAsync(string id);
        Task<User> GetAsync(string username, string password);
        Task CreateAsync(User user);
        Task UpdateAsync(string id, User user);
        Task DeleteAsync(string id);
    }
}
