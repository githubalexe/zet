﻿using MongoDB.Driver;
using MongoJWT.Data.Domain;
using MongoJWT.Data.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoJWT.Data
{
    public class UserRepository : IUserRepository
    {
        private UnitOfWork _unitOfWork;
        public UserRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(User user)
        {
            await _unitOfWork.User.InsertOneAsync(user);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.User.DeleteOneAsync(c => c.Id == id);
        }

        public async Task<User> GetAsync(string id)
        {
            return await _unitOfWork.User.Find(c => c.Id == id)
                                  .FirstOrDefaultAsync();
        }

        public async Task<User> GetAsync(string userName, string password)
        {
            return await _unitOfWork.User.Find(c => c.UserName == userName && c.Password == password)
                                  .FirstOrDefaultAsync();
        }

        public async Task UpdateAsync(string id, User user)
        {
            await _unitOfWork.User.ReplaceOneAsync(a => a.Id == id, user);
        }
    }
}
