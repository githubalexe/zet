var options = {
    $container: $('#plugin1'),
    $picker: $('.picker', '#plugin1'),
    $element: $('#textareaContainer'),
    property: 'color'
}
var colorPicker1 = new ColorPicker(options);

var options2 = {
    $container: $('#plugin2'),
    $picker: $('.picker', '#plugin2'),
    $element: $('body'),
    property: 'background-color'
}
var colorPicker2 = new ColorPicker(options2);

var options3 = {
    $container: $('#plugin3'),
    $picker: $('.picker', '#plugin3'),
    $element: $('#textareaContainer'),
    property: 'background-color'
}
var colorPicker3 = new ColorPicker(options3);

