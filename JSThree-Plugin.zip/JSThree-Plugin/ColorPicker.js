$(function () {
    ColorPicker = function (options) {
        var self = this;
        self.$container = options.$container;
        self.picker = options.$picker;
        self.$element = options.$element;
        self.property = options.property;

        self.$pluginWrapper = $('<div/>').attr('class', 'color-picker');
        var $title = $('<h1/>').attr('id', 'choseTitle');
        self.$picker = $('<div/>').attr('class', 'picker');
        var $clear = $('<div/>').attr('class', 'clear');
        $title.text('Choose a color:');
        self.$pluginWrapper.append($title, self.$picker, $clear);
        self.$container.append(self.$pluginWrapper);

        self.buildBody();
        self.addDefaultFirstColors();
        self.addDefaultLastColors();
        self.addDefaultPaletteColors();

        var $colorButton = $('.color-button', self.$container);
        var $moreColorsButton = $('#moreColors', self.$container);
        self.$colorBlock = $('#color-block', self.$container);
        self.$colorStrip = $('#color-strip', self.$container);
        self.buildCanvasColorPicker();
        $moreColorsButton.on('click', function () {
            $('.more-colors-area', self.$container).slideToggle();
        });

        $colorButton.on('click', function () {
            var color = $(this).css('background-color');
            self.$picker.css('background-color', color);
            $(self.$element, self.$container).css(self.property, color);
            $('.box-colors', self.$container).slideToggle();
        });

        self.$picker.on('click ', function () {
            $('.box-colors', self.$container).slideToggle();
        });
        //wrap all events in a bind function - also prototype
    }

    ColorPicker.prototype.buildBody = function () {
        var self = this;
        var $boxColors = $('<div/>', {
            class: 'box-colors',
        });
        var $row1 = $('<div/>', {
            class: 'row',
        });
        var $themeColors = $('<p/>', {
            class: 'title',
            html: 'Theme Colors'
        });
        var $firstColorRow = $('<div/>', {
            class: 'colors-row',
            id: 'firstColorRow'
        });
        var $defaultFirstColors = $('<div/>', {
            class: 'colors default-first-colors',
        });
        var $defaultPaletteRow = $('<div/>', {
            class: 'colors-row',
        });
        var $defaultPaletteColors = $('<div/>', {
            class: 'colors default-palette-colors',
        });
        var $row2 = $('<div/>', {
            class: 'row',
        });
        var $standardColors = $('<p/>', {
            class: 'title',
            html: 'Standard Colors'
        });
        var $lastColorRow = $('<div/>', {
            class: 'colors-row',
            id: 'lastColorRow'
        });
        var $defaultLastColors = $('<div/>', {
            class: 'colors default-last-colors',
        });
        var $line = $('<hr/>', {
        });
        var $moreColorsButton = $('<button>', {
            type: 'submit',
            id: 'moreColors',
        });
        var $icon = $('<i/>', {
            class: 'fas fa-palette',
        });
        var $canvasArea = $('<div/>', {
            class: 'more-colors-area'
        });
        var $canvas1 = $('<canvas/>', {
            id: 'color-block',
        });
        var $canvas2 = $('<canvas/>', {
            id: 'color-strip',
        });
        var $clear = $('<div/>', {
            class: 'clear',
        });

        $moreColorsButton.text('More Colors');
        $row1.append($themeColors);
        $firstColorRow.append($defaultFirstColors);
        $defaultPaletteRow.append($defaultPaletteColors);
        $row2.append($standardColors);
        $lastColorRow.append($defaultLastColors);
        $moreColorsButton.prepend($icon);
        $canvasArea.append($canvas1, $canvas2);
        $boxColors.append($row1, $firstColorRow, $defaultPaletteRow, $row2, $lastColorRow, $line, $moreColorsButton, $canvasArea, $clear);
        self.$pluginWrapper.append($boxColors);
    }

    ColorPicker.prototype.createColors = function (target, color) {
        var swatch = document.createElement('div');
        swatch.classList.add('color-button');
        swatch.setAttribute('title', color);
        swatch.style.backgroundColor = color;
        target.appendChild(swatch);
    };

    ColorPicker.prototype.defaultPaletteColors = [
        '#F2F2F2', '#7F7F7F', '#D0CECE', '#D6DCE4', '#D9E2F3', '#FBE5D5', '#EDEDED', '#FFF2CC', '#DEEBF6', '#E2EFD9', '#D8D8D8', '#595959', '#AEABAB', '#ADB9CA', '#B4C6E7', '#F7CBAC', '#DBDBDB', '#FEE599', '#BDD7EE', '#C5E0B3', '#BFBFBF', '#3F3F3F', '#757070', '#8496B0', '#8EAADB', '#F4B183', '#C9C9C9', '#FFD965', '#9CC3E5', '#A8D08D', '#A5A5A5', '#262626', '#3A3838', '#323F4F', '#2F5496', '#C55A11', '#7B7B7B', '#BF9000', '#2E75B5', '#538135', '#7F7F7F', '#0C0C0C', '#171616', '#222A35', '#1F3864', '#833C0B', '#525252', '#7F6000', '#1E4E79', '#375623',
    ];

    ColorPicker.prototype.defaultFirstColors = [
        '#FFFFFF', '#000000', '#E7E6E6', '#E7E6E6', '#4472C4', '#ED7D31', '#A5A5A5', '#FFC000', '#5B9BD5', '#70AD47',
    ];

    ColorPicker.prototype.defaultLastColors = [
        '#C00000', '#FF0000', '#FFC000', '#FFFF00', '#92D050', '#00B050', '#00B0F0', '#0070C0', '#002060', '#7030A0',
    ];

    ColorPicker.prototype.addDefaultFirstColors = function () {
        var self = this;
        for (var i = 0; i < this.defaultFirstColors.length; ++i) {
            self.createColors($('.default-first-colors', self.$container)[0], this.defaultFirstColors[i]);
        }
    }

    ColorPicker.prototype.addDefaultPaletteColors = function () {
        var self = this;
        for (var i = 0; i < this.defaultPaletteColors.length; ++i) {
            self.createColors($('.default-palette-colors', self.$container)[0], this.defaultPaletteColors[i]);
        }
    }

    ColorPicker.prototype.addDefaultLastColors = function () {
        var self = this;
        for (var i = 0; i < this.defaultLastColors.length; ++i) {
            self.createColors($('.default-last-colors', self.$container)[0], this.defaultLastColors[i]);
        }
    }

    ColorPicker.prototype.buildCanvasColorPicker = function () {
        var self = this;

        var $colorBlockContext = self.$colorBlock[0].getContext('2d');
        var colorBlockWidth = self.$colorBlock.width();
        var colorBlocKHeight = self.$colorBlock.height();
        var $colorStripContext = self.$colorStrip[0].getContext('2d');
        var colorStripWidth = self.$colorStrip.width() + 300;
        var colorStripHeight = self.$colorStrip.height();

        var positionX = 0;
        var positionY = 0;

        var drag = false;
        var rgbaColor = 'rgba(255,0,0,1)';
        $colorBlockContext.rect(0, 0, colorBlockWidth, colorBlocKHeight);
        fillGradient();
        $colorStripContext.rect(0, 0, colorStripWidth, colorStripHeight);
        
        var $colorStripColorStop = $colorStripContext.createLinearGradient(0, 0, 0, colorBlocKHeight);
        $colorStripColorStop.addColorStop(0, 'rgba(255, 0, 0, 1)');
        $colorStripColorStop.addColorStop(0.17, 'rgba(255, 255, 0, 1)');
        $colorStripColorStop.addColorStop(0.34, 'rgba(0, 255, 0, 1)');
        $colorStripColorStop.addColorStop(0.51, 'rgba(0, 255, 255, 1)');
        $colorStripColorStop.addColorStop(0.68, 'rgba(0, 0, 255, 1)');
        $colorStripColorStop.addColorStop(0.85, 'rgba(255, 0, 255, 1)');
        $colorStripColorStop.addColorStop(1, 'rgba(255, 0, 0, 1)');
        $colorStripContext.fillStyle = $colorStripColorStop;
        $colorStripContext.fill();
        const click = (e) => {
            var self = this;
            positionX = e.offsetX;
            positionY = e.offsetY;
            var imageData = $colorStripContext.getImageData(positionX, positionY, 1, 1).data;
            rgbaColor = 'rgba(' + imageData[0] + ',' + imageData[1] + ',' + imageData[2] + ',1)';
            self.$picker.css('background-color', rgbaColor);
            $(self.$element, self.$container).css(self.property, rgbaColor);
            fillGradient();
        }
        function fillGradient() {
            $colorBlockContext.fillStyle = rgbaColor;
            $colorBlockContext.fillRect(0, 0, colorBlockWidth, colorBlocKHeight);
            var grdWhite = $colorStripContext.createLinearGradient(0, 0, colorBlockWidth, 0);
            grdWhite.addColorStop(0, 'rgba(255,255,255,1)');
            grdWhite.addColorStop(1, 'rgba(255,255,255,0)');
            $colorBlockContext.fillStyle = grdWhite;
            $colorBlockContext.fillRect(0, 0, colorBlockWidth, colorBlocKHeight);
            var grdBlack = $colorStripContext.createLinearGradient(0, 0, 0, colorBlocKHeight);
            grdBlack.addColorStop(0, 'rgba(0,0,0,0)');
            grdBlack.addColorStop(1, 'rgba(0,0,0,1)');
            $colorBlockContext.fillStyle = grdBlack;
            $colorBlockContext.fillRect(0, 0, colorBlockWidth, colorBlocKHeight);
        }
        const mousedown = (e) => {
            drag = true;
            changeColor(e);
        }
        const mousemove = (e) => {
            if (drag) {
                changeColor(e);
            }
        }
        const mouseup = () => {
            drag = false;
        }
        const changeColor = (e) => {
            var self = this;
            positionX = e.offsetX;
            positionY = e.offsetY;
            var imageData = $colorBlockContext.getImageData(positionX, positionY, 1, 1).data;
            rgbaColor = 'rgba(' + imageData[0] + ',' + imageData[1] + ',' + imageData[2] + ',1)';
            self.$picker.css('background-color', rgbaColor);
            $(self.$element, self.$container).css(self.property, rgbaColor);
        }
        self.$colorStrip.on('click', click);
        self.$colorBlock.on('mousedown', mousedown);
        self.$colorBlock.on('mouseup', mouseup);
        self.$colorBlock.on('mousemove', mousemove);
    }
}());
