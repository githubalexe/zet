﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.Domain
{
    public class Actor
    {
        public Actor()
        {
            FilmActor = new HashSet<FilmActor>();
        }

        public int ActorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime LastUpdate { get; set; }

        public virtual IEnumerable<FilmActor> FilmActor { get; set; }
    }
}
