﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StoresController : Controller
    {
        private IStoreRepository _storeRepository;

        public StoresController(IStoreRepository storeRepository)
        {
            _storeRepository = storeRepository;
        }

        [HttpGet("Stores/{storeId}")]
        public async Task<IActionResult> GetStoreAsync(int storeId)
        {
            Store store = await _storeRepository.GetStoreAsync(storeId);
            if (store != null)
            {
                StoreResponseLite storeResponse = store.ToStoreResponseLite();

                return Ok(storeResponse);
            }

            return NotFound("The store doesn't exist!");
        }

        [HttpPut("Stores/{storeId}")]
        public async Task<IActionResult> UpdateStoreAsync([FromBody] StoreUpdateRequest request, int storeId)
        {
            Store store = request.ToStoreModel(storeId);
            _storeRepository.UpdateStore(store);
            _storeRepository.SaveChanges();
            StoreResponse storeResponse = store.ToStoreResponse();

            return Ok(storeResponse);
        }
    }
}