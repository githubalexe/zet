﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffRepository _staffRepository;
        private IPaymentRepository _paymentRepository;

        public StaffsController(IStaffRepository staffRepository, IPaymentRepository paymentRepository)
        {
            _staffRepository = staffRepository;
            _paymentRepository = paymentRepository;
        }

        [HttpGet("Stores/{storeId}/Staffs")]
        public async Task<IActionResult> GetStaffsAsync(int storeId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StaffResponseLite> staffResponseList = staffList.ToStaffResponseList();

            return Ok(staffResponseList);
        }

        [HttpGet("Stores/{storeId}/Staffs/{staffId}", Name = "GetStaffAsync")]
        public async Task<IActionResult> GetStaffAsync(int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (staff != null)
            {
                StaffResponseLite staffResponse = staff.ToStaffResponseLite();

                return Ok(staffResponse);
            }

            return NotFound("The staff doesn't exist!");
        }

        [HttpGet("Stores/{storeId}/Staffs/{staffId}/Payments")]
        public async Task<IActionResult> GetStaffPayments(int storeId, int staffId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (staff != null)
            {
                IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staffId);
                List<PaymentForStaffResponse> paymentResponseList = paymentList.ToStaffPaymentsResponse();

                return Ok(paymentResponseList);
            }

            return NotFound("The staff doesn't exist!");
        }

        [HttpGet("Stores/{storeId}/Staffs/{staffId}/Payments/{paymentId}")]
        public async Task<IActionResult> GetStaffPaymentAsync(int storeId, int staffId, int paymentId)
        {
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Payment payment = await _paymentRepository.GetStaffPaymentAsync(staffId, paymentId);

            if (staff == null)
            {
                return NotFound("The staff doesn't exist!");
            }
            if (payment != null)
            {
                List<PaymentForStaffResponse> paymentResponseList = new List<PaymentForStaffResponse>();
                PaymentForStaffResponse paymentResponse = payment.ToStaffPaymentResponse();
                paymentResponseList.Add(paymentResponse);

                return Ok(paymentResponseList);
            }

            return NotFound("The payment doesn't exist!");
        }

        [HttpPost("Stores/{storeId}/Staffs")]
        public IActionResult AddStaffAsync([FromBody] StaffCreateRequest request, int storeId)
        {
            Staff staff = request.ToStaffModel(storeId);
            _staffRepository.AddStaff(staff);
            _staffRepository.SaveChanges();
            StaffResponse staffResponse = staff.ToStaffResponse();

            return CreatedAtRoute("GetStaffAsync", new { staffId = staff.StaffId }, staffResponse);
        }

        [HttpPut("Stores/{storeId}/Staffs/{staffId}")]
        public async Task<IActionResult> UpdateStaffAsync([FromBody] StaffUpdateRequest request, int storeId, int staffId)
        {
            Staff staff = request.ToStaffModel(storeId, staffId);
            _staffRepository.UpdateStaff(staff);
            _staffRepository.SaveChanges();
            StaffResponse staffResponse = staff.ToStaffResponse();

            return Ok(staffResponse);
        }
    }
}