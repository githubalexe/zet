﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class FilmsController : Controller
    {
        private IFilmRepository _filmRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmActorRepository _filmActorRepository;
        public FilmsController(IFilmRepository filmRepository, IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository)
        {
            _filmRepository = filmRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _filmActorRepository = filmActorRepository;
        }
        [HttpGet("Films")]
        public async Task<IActionResult> GetFilmsAsync()
        {
            IEnumerable<Film> filmList = await _filmRepository.GetFilmsAsync();
            List<FilmResponseLite> filmResponseList = new List<FilmResponseLite>();

            foreach (Film film in filmList)
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(film.FilmId);
                filmResponseList.Add(film.ToFilmResponseLite(filmCategory.Category));
            }

            return Ok(filmResponseList);
        }

        [HttpGet("Films/{filmId}", Name = "GetFilmAsync")]
        public async Task<IActionResult> GetFilmAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            if (film != null)
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(film.FilmId);
                FilmResponseLite filmResponse = film.ToFilmResponseLite(filmCategory.Category);

                return Ok(filmResponse);
            }

            return Ok("The film doesn't exist!");
        }

        [HttpPost("Films")]
        public IActionResult AddFilmAsync([FromBody]FilmCreateRequest request)
        {
            Film film = request.ToFilmModel();
            _filmRepository.AddFilm(film);
            _filmRepository.SaveChanges();
            FilmResponse filmResponse = film.ToFilmResponse();

            return CreatedAtRoute("GetFilmAsync", new { filmId = film.FilmId }, filmResponse);
        }
        [HttpGet("Films/{filmId}/Actors")]
        public async Task<IActionResult> GetFilmActorsAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetActorsAsync(filmId);
            List<ActorResponse> actorList = filmActorList.ToActorResponseList();
            FilmActorsResponse filmResponse = film.ToActorsResponse(actorList);

            return Ok(filmResponse);
        }

        [HttpGet("Films/{filmId}/Actors/{actorId}")]
        public async Task<IActionResult> GetFilmActorAsync(int storeId, int filmId, int actorId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            FilmActor filmActor = await _filmActorRepository.GetActorAsync(filmId, actorId);

            if (filmActor != null)
            {
                List<ActorResponse> actorList = new List<ActorResponse>();
                actorList.Add(filmActor.Actor.ToActorResponse());
                FilmActorsResponse filmResponse = film.ToActorsResponse(actorList);

                return Ok(filmResponse);
            }

            return NotFound("The actor doesn't exist!");
        }

        //doesn't work...
        [HttpPut("Films/{filmId}")]
        public async Task<IActionResult> UpdateFilmAsync([FromBody]FilmUpdateRequest request, int filmId)
        {
            Film film = request.ToFilmModel(filmId);
            _filmRepository.UpdateFilm(film);
            _filmRepository.SaveChanges();
            FilmResponse filmResponse = film.ToFilmResponse();

            return Ok(filmResponse);
        }

        [HttpDelete("Films/{filmId}")]
        public async Task<IActionResult> DeleteFilmAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film != null)
            {
                _filmRepository.DeleteFilm(film);
                _filmRepository.SaveChanges();
                return Ok("The film has been deleted.");
            }

            return Ok("The film doesn't exist!");
        }
    }
}