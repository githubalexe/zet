﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerPaymentExtensionMethods
    {
        public static CustomerPaymentResponse ToCustomerPaymentResponse(this Customer customer)
        {
            CustomerPaymentResponse customerPaymentResponse = new CustomerPaymentResponse()
            {
                CustomerId = customer.CustomerId,
                FirstName = customer.FirstName,
                LastName = customer.LastName
            };

            return customerPaymentResponse;
        }
    }
}
