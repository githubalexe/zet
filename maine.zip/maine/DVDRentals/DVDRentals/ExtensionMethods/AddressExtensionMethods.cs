﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class AddressExtensionMethods
    {
        public static AddressResponseLite ToAddressResponseLite(this Address address)
        {
            AddressResponseLite addressResponse = new AddressResponseLite()
            {
                AddressId = address.AddressId,
                Address1 = address.Address1,
                Address2 = address.Address2,
                District = address.District,
                CityId = address.CityId,
                PostalCode = address.PostalCode,
                Phone = address.Phone,
                LastUpdate = address.LastUpdate
            };

            return addressResponse;
        }

        public static Address ToAddressModel(this AddressCreateRequest request)
        {
            Address address = new Address()
            {
                Address1 = request.Address1,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };

            return address;
        }
        public static Address ToAddressModel(this AddressUpdateRequest request, int addressId)
        {
            Address address = new Address()
            {
                AddressId = addressId,
                Address1 = request.Address1,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };

            return address;
        }

        public static AddressResponse ToAddressResponse(this Address address)
        {
            AddressResponse addressResponse = new AddressResponse()
            {
                AddressId = address.AddressId,
                Address1 = address.Address1,
                Address2 = address.Address2,
                District = address.District,
                CityId = address.CityId,
                PostalCode = address.PostalCode,
                Phone = address.Phone,
                LastUpdate = address.LastUpdate
            };

            return addressResponse;
        }
    }
}

