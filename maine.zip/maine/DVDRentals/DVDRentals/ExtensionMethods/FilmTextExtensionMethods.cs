﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmTextExtensionMethods
    {
        public static FilmText ToFilmTextResponse(this Film film)
        {
            FilmText filmText = new FilmText()
            {
                FilmId = film.FilmId,
                Title = film.Title,
                Description = film.Description,
            };

            return filmText;
        }
    }
}
