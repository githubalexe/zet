﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerResponseLite ToCustomerResponseLite(this Customer customer)
        {
            CustomerResponseLite customerResponse = new CustomerResponseLite()
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                LastUpdate = customer.LastUpdate
            };

            customerResponse.Address = customer.Address.ToAddressResponseLite();
            customerResponse.Address.City = customer.Address.City.ToCityResponse();
            customerResponse.Address.City.Country = customer.Address.City.Country.ToCountryResponse();

            return customerResponse;
        }
        public static List<CustomerResponseLite> ToCustomerResponseList(this IEnumerable<Customer> customerList)
        {
            List<CustomerResponseLite> customerResponseList = new List<CustomerResponseLite>();

            foreach (Customer customer in customerList)
            {
                CustomerResponseLite customerResponse = new CustomerResponseLite();
                customerResponse = customer.ToCustomerResponseLite();

                customerResponseList.Add(customerResponse);
            }

            return customerResponseList;
        }
        public static Customer ToCustomerModel(this CustomerCreateRequest request, int storeId)
        {
            Customer customer = new Customer()
            {
                StoreId = storeId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                AddressId = request.AddressId,
                Active = request.Active,
                CreateDate = request.CreateDate
            };

            return customer;
        }
        public static Customer ToCustomerModel(this CustomerUpdateRequest request, int storeId,int customerId)
        {
            Customer customer = new Customer()
            {
                CustomerId = customerId,
                StoreId = storeId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                AddressId = request.AddressId,
                Active = request.Active,
                CreateDate = request.CreateDate
            };

            return customer;
        }
        public static CustomerResponse ToCustomerResponse(this Customer customer)
        {
            CustomerResponse customerResponse = new CustomerResponse()
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                LastUpdate = customer.LastUpdate
            };

            return customerResponse;
        }
        //public static CustomerResponse ToCustomerResponse(this Customer customer, Address address)
        //{
        //    CustomerResponse customerResponse = new CustomerResponse
        //    {
        //        Active = customer.Active,
        //        Address = new AddressResponse
        //        {
        //            City = new CityResponse
        //            {
        //                Country = new CountryResponse
        //                {
        //                    Country1 = address.City.Country.Country1
        //                }
        //            }
        //        }
        //    };

        //    return customerResponse;
        //}
    }
}
