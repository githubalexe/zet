﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CategoryExtensionMethods
    {
        public static CategoryResponse ToCategoryResponse(this Category category)
        {
            CategoryResponse categoryResponse = new CategoryResponse()
            {
                CategoryId = category.CategoryId,
                Name = category.Name,
                LastUpdate = category.LastUpdate
            };

            return categoryResponse;
        }
    }
}
