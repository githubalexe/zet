﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class FilmCategoryRepository : IFilmCategoryRepository
    {
        private UnitOfWork _context;
        public FilmCategoryRepository(UnitOfWork context) 
        {
            _context = context;
        }
        public async Task<FilmCategory> GetFilmCategoryAsync(int filmId)
        {
            return await _context.FilmCategory.Where(f => f.FilmId == filmId)
                                              .Include(c => c.Category)
                                              .FirstOrDefaultAsync(c => c.CategoryId == c.Category.CategoryId);
        }
    }
}
