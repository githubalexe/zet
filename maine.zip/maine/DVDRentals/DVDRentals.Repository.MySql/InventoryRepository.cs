﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class InventoryRepository : IInventoryRepository
    {
        private UnitOfWork _context;

        public InventoryRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Inventory>> GetFilmsAsync(int storeId)
        {
            return await _context.Inventory.Where(i => i.StoreId == storeId)
                                           .Include(f => f.Film)
                                           .ThenInclude(l => l.Language)
                                           .Include(f => f.Film)
                                           .ThenInclude(c => c.FilmCategory)
                                           .ThenInclude(c => c.Category)
                                           .ToListAsync();

        }
        public async Task<Inventory> GetFilmAsync(int storeId, int filmId)
        {
            return await _context.Inventory.Where(i => i.StoreId == storeId)
                                           .Include(f => f.Film)
                                           .ThenInclude(l => l.Language)
                                           .Include(f => f.Film)
                                           .ThenInclude(c => c.FilmCategory)
                                           .ThenInclude(c => c.Category)
                                           .FirstOrDefaultAsync(f => f.FilmId == filmId);
        }

        public async Task<Inventory> GetInventoryAsync(int inventoryId)
        {
            return await _context.Inventory.Include(f => f.Film)
                                           .FirstOrDefaultAsync(i => i.InventoryId == inventoryId);
        }
    }
}
