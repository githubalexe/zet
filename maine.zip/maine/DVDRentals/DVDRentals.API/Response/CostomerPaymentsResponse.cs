﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    public class CostomerPaymentsResponse
    {
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public virtual List<PaymentForCustomerResponse> Payments { get; set; }
    }
}
