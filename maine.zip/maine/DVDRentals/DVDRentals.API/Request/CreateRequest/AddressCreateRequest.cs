﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class AddressCreateRequest
    {
        [Required(ErrorMessage = "Address is required.")]
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        [Required(ErrorMessage = "District is required.")]
        public string District { get; set; }
        [Required(ErrorMessage = "CityId is required.")]
        public int CityId { get; set; }
        [Required(ErrorMessage = "PostalCode is required.")]
        public string PostalCode { get; set; }
        [Required(ErrorMessage = "Phone is required.")]
        public string Phone { get; set; }
    }
}
