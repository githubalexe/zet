﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class ActorCreateRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
