﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static ActorResponse ToActorResponse(this Actor actor)
        {
            ActorResponse actorResponse = new ActorResponse()
            {
                ActorId = actor.ActorId,
                FirstName = actor.FirstName,
                LastName = actor.LastName,
                LastUpdate = actor.LastUpdate
            };

            return actorResponse;
        }
        public static List<ActorResponse> ToActorResponseList(this IEnumerable<Actor> actorList)
        {
            List<ActorResponse> actorResponseList = new List<ActorResponse>();

            foreach (Actor actor in actorList)
            {
                actorResponseList.Add(actor.ToActorResponse());
            }

            return actorResponseList;
        }
        public static List<ActorResponse> ToActorResponseList(this IEnumerable<FilmActor> actorList)
        {
            List<ActorResponse> actorResponseList = new List<ActorResponse>();

            foreach (FilmActor filmActor in actorList)
            {
                actorResponseList.Add(filmActor.Actor.ToActorResponse());
            }

            return actorResponseList;
        }
        public static Actor ToActorModel(this ActorCreateRequest request)
        {
            Actor actorResponse = new Actor()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
            };

            return actorResponse;
        }

        public static Actor ToActorModel(this ActorUpdateRequest request, Actor actor)
        {
            actor.FirstName = request.FirstName;
            actor.LastName = request.LastName;

            return actor;
        }
    }
}
