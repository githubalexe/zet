﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static FilmResponseLite ToFilmResponseLite(this Film film, Category category)
        {
            FilmResponseLite filmResponse = new FilmResponseLite()
            {
                FilmId = film.FilmId,
                Title = film.Title,
                Description = film.Description,
                ReleaseYear = film.ReleaseYear,
                LanguageId = film.LanguageId,
                OriginalLanguageId = film.OriginalLanguageId,
                RentalDuration = film.RentalDuration,
                RentalRate = film.RentalRate,
                Length = film.Length,
                ReplacementCost = film.ReplacementCost,
                LastUpdate = film.LastUpdate,
                Rating = film.Rating,
                SpecialFeatures = film.SpecialFeatures,
                Language = film.Language.ToLanguageResponse(),
                Category = category.ToCategoryResponse()
            };

            return filmResponse;
        }
        public static FilmResponseLite ToFilmResponseLite(this Film film)
        {
            FilmResponseLite filmResponse = new FilmResponseLite()
            {
                FilmId = film.FilmId,
                Title = film.Title,
                Description = film.Description,
                ReleaseYear = film.ReleaseYear,
                LanguageId = film.LanguageId,
                OriginalLanguageId = film.OriginalLanguageId,
                RentalDuration = film.RentalDuration,
                RentalRate = film.RentalRate,
                Length = film.Length,
                ReplacementCost = film.ReplacementCost,
                LastUpdate = film.LastUpdate,
                Rating = film.Rating,
                SpecialFeatures = film.SpecialFeatures,
                Language = film.Language.ToLanguageResponse()
            };

            return filmResponse;
        }
        public static Film ToFilmModel(this FilmCreateRequest request)
        {
            Film film = new Film()
            {
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                OriginalLanguageId = request.OriginalLanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                Rating = request.Rating,
                SpecialFeatures = request.SpecialFeatures
            };

            return film;
        }

        public static Film ToFilmModel(this FilmUpdateRequest request, Film film)
        {
            film.Title = request.Title;
            film.Description = request.Description;
            film.ReleaseYear = request.ReleaseYear;
            film.LanguageId = request.LanguageId;
            film.OriginalLanguageId = request.OriginalLanguageId;
            film.RentalDuration = request.RentalDuration;
            film.RentalRate = request.RentalRate;
            film.Length = request.Length;
            film.ReplacementCost = request.ReplacementCost;
            film.Rating = request.Rating;
            film.SpecialFeatures = request.SpecialFeatures;

            return film;
        }

        public static FilmResponse ToFilmResponse(this Film film)
        {
            FilmResponse filmResponse = new FilmResponse()
            {
                FilmId = film.FilmId,
                Title = film.Title,
                Description = film.Description,
                ReleaseYear = film.ReleaseYear,
                LanguageId = film.LanguageId,
                OriginalLanguageId = film.OriginalLanguageId,
                RentalDuration = film.RentalDuration,
                RentalRate = film.RentalRate,
                Length = film.Length,
                ReplacementCost = film.ReplacementCost,
                Rating = film.Rating,
                SpecialFeatures = film.SpecialFeatures,
                LastUpdate = film.LastUpdate
            };

            return filmResponse;
        }

        public static FilmActorsResponse ToActorsResponse(this Film film, List<ActorResponse> actorList)
        {
            FilmActorsResponse filmResponse = new FilmActorsResponse()
            {
                FilmId = film.FilmId,
                Title = film.Title,
                FilmActors = actorList
            };

            return filmResponse;
        }
    }
}
