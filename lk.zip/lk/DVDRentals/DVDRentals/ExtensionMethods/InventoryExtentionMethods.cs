﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class InventoryExtentionMethods
    {
        public static Inventory ToInventoryModel(this InventoryCreateRequest request, int storeId)
        {
            Inventory inventory = new Inventory()
            {
                StoreId = storeId,
                FilmId = request.FilmId
            };

            return inventory;
        }

        public static InventoryResponse ToInventoryResponse(this Inventory inventory)
        {
            InventoryResponse inventoryResponse = new InventoryResponse()
            {
                InventoryId = inventory.InventoryId,
                StoreId = inventory.StoreId,
                FilmId = inventory.FilmId,
                LastUpdate = inventory.LastUpdate
            };

            return inventoryResponse;
        }

        public static InventoryResponseLite ToInventoryResponseLite(this Inventory inventory, FilmResponseLite filmResponseLite)
        {
            InventoryResponseLite inventoryResponseLite = new InventoryResponseLite()
            {
                InventoryId = inventory.InventoryId,
                FilmId = inventory.FilmId,
                StoreId= inventory.StoreId,
                FilmResponseLite= filmResponseLite
            };

            return inventoryResponseLite;
        }
    }
}
