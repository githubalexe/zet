﻿using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreResponseLite ToStoreResponseLite(this Store store)
        {
            StoreResponseLite storeResponse = new StoreResponseLite()
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                LastUpdate = store.LastUpdate,
            };
            storeResponse.Address = store.Address.ToAddressResponseLite();
            storeResponse.Address.City = store.Address.City.ToCityResponse();
            storeResponse.Address.City.Country = store.Address.City.Country.ToCountryResponse();

            return storeResponse;
        }
        public static StoreResponse ToStoreResponse(this Store store)
        {
            StoreResponse storeResponse = new StoreResponse()
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                LastUpdate = store.LastUpdate,
            };

            return storeResponse;
        }

        public static Store ToStoreModel(this StoreUpdateRequest request, Store store)
        {
            store.ManagerStaffId = request.ManagerStaffId;
            store.AddressId = request.AddressId;

            return store;
        }
    }
}
