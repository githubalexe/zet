﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static StaffResponseLite ToStaffResponseLite(this Staff staff)
        {
            StaffResponseLite staffResponse = new StaffResponseLite()
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                AddressId = staff.AddressId,
                Picture = staff.Picture,
                Email = staff.Email,
                StoreId = staff.StoreId,
                Active = staff.Active,
                Username = staff.Username,
                LastUpdate = staff.LastUpdate
            };

            staffResponse.Address = staff.Address.ToAddressResponseLite();
            staffResponse.Address.City = staff.Address.City.ToCityResponse();
            staffResponse.Address.City.Country = staff.Address.City.Country.ToCountryResponse();

            return staffResponse;
        }

        public static List<StaffResponseLite> ToStaffResponseList(this IEnumerable<Staff> staffList)
        {
            List<StaffResponseLite> staffResponseList = new List<StaffResponseLite>();

            foreach (Staff staff in staffList)
            {
                staffResponseList.Add(staff.ToStaffResponseLite());
            }

            return staffResponseList;
        }

        public static Staff ToStaffModel(this StaffCreateRequest request, int storeId)
        {
            Staff staff = new Staff()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                AddressId = request.AddressId,
                Picture = request.Picture,
                Email = request.Email,
                StoreId = storeId,
                Active = request.Active,
                Username = request.Username,
                Password = request.Password
            };

            return staff;
        }
        public static Staff ToStaffModel(this StaffUpdateRequest request, Staff staff, int storeId)
        {
            staff.FirstName = request.FirstName;
            staff.LastName = request.LastName;
            staff.AddressId = request.AddressId;
            staff.Picture = request.Picture;
            staff.Email = request.Email;
            staff.StoreId = storeId;
            staff.Active = request.Active;
            staff.Username = request.Username;
            staff.Password = request.Password;

            return staff;
        }

        public static StaffResponse ToStaffResponse(this Staff staff)
        {
            StaffResponse staffResponse = new StaffResponse()
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                AddressId = staff.AddressId,
                Picture = staff.Picture,
                Email = staff.Email,
                StoreId = staff.StoreId,
                Active = staff.Active,
                Username = staff.Username,
                Password = staff.Password,
                LastUpdate = staff.LastUpdate
            };

            return staffResponse;
        }
    }
}
