﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static RentalResponseLite ToRentalResponseLite(this Rental rental)
        {
            if (rental != null)
            {
                RentalResponseLite rentalResponseLite = new RentalResponseLite()
                {
                    RentalId = rental.RentalId,
                    RentalDate = rental.RentalDate,
                    InventoryId = rental.InventoryId,
                    CustomerId = rental.CustomerId,
                    ReturnDate = rental.ReturnDate,
                    StaffId = rental.StaffId,
                    LastUpdate = rental.LastUpdate,
                    Film = rental.Inventory.Film.ToFilmTextResponse()
                };

                return rentalResponseLite;
            }
            RentalResponseLite rentalResponseNull = new RentalResponseLite();

            return rentalResponseNull;
        }

        public static RentalResponse ToRentalResponse(this Rental rental)
        {
            RentalResponse rentalResponse = new RentalResponse()
            {
                RentalId = rental.RentalId,
                RentalDate = rental.RentalDate,
                InventoryId = rental.InventoryId,
                CustomerId = rental.CustomerId,
                ReturnDate = rental.ReturnDate,
                StaffId = rental.StaffId,
                LastUpdate = rental.LastUpdate,
            };

            return rentalResponse;
        }

        public static Rental ToRentalModel(this RentalCreateRequest request)
        {
            Rental rental = new Rental()
            {
                RentalDate = request.RentalDate,
                InventoryId = request.InventoryId,
                CustomerId = request.CustomerId,
                ReturnDate = request.ReturnDate,
                StaffId = request.StaffId
            };

            return rental;
        }
        public static Rental ModifyRental(this RentalUpdateRequest request, Rental rental)
        {
            rental.RentalDate = request.RentalDate;
            rental.InventoryId = request.InventoryId;
            rental.CustomerId = request.CustomerId;
            rental.ReturnDate = request.ReturnDate;
            rental.StaffId = request.StaffId;

            return rental;
        }
    }
}
