﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StaffPaymentsExtensionMethods
    {
        public static StaffPaymentsResponse ToStaffPaymentsResponse(this Staff staff)
        {
            StaffPaymentsResponse staffResponse = new StaffPaymentsResponse()
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName
            };

            return staffResponse;
        }

        public static StaffPaymentsResponse ToStaffPaymentListResponse(this Staff staff, List<PaymentForStaffResponse> paymentResponseList)
        {
            StaffPaymentsResponse staffResponse = staff.ToStaffPaymentsResponse();
            staffResponse.Payments = paymentResponseList;

            return staffResponse;
        }
    }
}
