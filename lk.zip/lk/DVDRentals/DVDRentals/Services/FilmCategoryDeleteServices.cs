﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class FilmCategoryDeleteServices : IFilmCategoryDeleteServices
    {
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmActorRepository _filmActorRepository;
        private IInventoryRepository _inventoryRepository;
        private IRentalRepository _rentalRepository;

        public FilmCategoryDeleteServices(IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository, IInventoryRepository inventoryRepository, IRentalRepository rentalRepository)
        {
            _filmCategoryRepository = filmCategoryRepository;
            _filmActorRepository = filmActorRepository;
            _inventoryRepository = inventoryRepository;
            _rentalRepository = rentalRepository;
        }

        public async void DeleteFilmCategoryAsync(int filmId)
        {
            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmCategoriesAsync(filmId);

            foreach (FilmCategory filmCategory in filmCategoryList)
            {
                _filmCategoryRepository.DeleteFilmCategory(filmCategory);
            }
        }

        public async void DeleteFilmActorAsync(int filmId)
        {
            IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetActorsAsync(filmId);

            foreach (FilmActor filmActor in filmActorList)
            {
                _filmActorRepository.DeleteFilmActor(filmActor);
            }
        }

        public async void DeleteFilmInventoryAsync(int filmId)
        {
            IEnumerable<Inventory> inventoryList = await _inventoryRepository.GetInventoriesAsync(filmId);
            if (inventoryList != null)
            {
                foreach (Inventory inventory in inventoryList)
                {
                    _inventoryRepository.DeleteInventory(inventory);
                }
            }
        }

    }
}
