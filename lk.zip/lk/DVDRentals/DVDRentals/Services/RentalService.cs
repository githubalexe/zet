﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class RentalService:IRentalService
    {
        private IRentalRepository _rentalRepository;
        public RentalService(IRentalRepository rentalRepository)
        {
            _rentalRepository = rentalRepository;
        }
        public  async void DeleteRental(int inventoryId)
        {
            Rental rental = await _rentalRepository.GetRentalInventoryAsync(inventoryId);

            _rentalRepository.DeleteRental(rental);
        }
    }
}
