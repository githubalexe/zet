﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class InventoriesController : Controller
    {
        private IInventoryRepository _inventoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IRentalRepository _rentalRepository;
        private IRentalService _rentalService;
        public InventoriesController(IInventoryRepository inventoryRepository, IFilmCategoryRepository filmCategoryRepository, IRentalRepository rentalRepository, IRentalService rentalService)
        {
            _inventoryRepository = inventoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _rentalRepository = rentalRepository;
            _rentalService = rentalService;
        }

        [HttpGet("Stores/{storeId}/Inventories")]
        public async Task<IActionResult> GetInventoriesAsync(int storeId)
        {
            IEnumerable<Inventory> inventoryList = await _inventoryRepository.GetFilmsAsync(storeId);
            List<InventoryResponseLite> inventoryResponseLite = new List<InventoryResponseLite>();

            foreach (Inventory inventory in inventoryList)
            {
                int filmId = inventory.Film.FilmId;
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(filmId);
                if (filmCategory != null)
                {
                    FilmResponseLite filmResponseLite = inventory.Film.ToFilmResponseLite(filmCategory.Category);
                    inventoryResponseLite.Add(inventory.ToInventoryResponseLite(filmResponseLite));
                }
                else
                {
                    FilmResponseLite filmResponseLite = inventory.Film.ToFilmResponseLite();
                    inventoryResponseLite.Add(inventory.ToInventoryResponseLite(filmResponseLite));
                }
            }

            return Ok(inventoryResponseLite);
        }

        [HttpGet("Stores/{storeId}/Films/{filmId}", Name = "GetInventoryAsync")]
        public async Task<IActionResult> GetInventoryAsync(int storeId, int filmId)
        {
            IEnumerable<Inventory> inventoryList = await _inventoryRepository.GetInventoriesAsync(storeId, filmId);

            List<InventoryResponseLite> inventoryResponseLite = new List<InventoryResponseLite>();

            foreach (Inventory inventory in inventoryList)
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(inventory.Film.FilmId);

                if (filmCategory != null)
                {
                    FilmResponseLite filmResponseLite = inventory.Film.ToFilmResponseLite(filmCategory.Category);
                    inventoryResponseLite.Add(inventory.ToInventoryResponseLite(filmResponseLite));
                }
                else
                {
                    FilmResponseLite filmResponseLite = inventory.Film.ToFilmResponseLite();
                    inventoryResponseLite.Add(inventory.ToInventoryResponseLite(filmResponseLite));
                }
            }

            return Ok(inventoryResponseLite);
        }

        [HttpPost("Stores/{storeId}/Inventories")]
        public IActionResult AddInventoryAsync([FromBody] InventoryCreateRequest request, int storeId)
        {
            Inventory inventory = request.ToInventoryModel(storeId);
            _inventoryRepository.AddInventory(inventory);
            _inventoryRepository.SaveChanges();
            InventoryResponse inventoryResponse = inventory.ToInventoryResponse();

            return CreatedAtRoute("GetInventoryAsync", new { storeId = inventory.StoreId, filmId = inventory.FilmId }, inventoryResponse);
        }

        [HttpDelete("Stores/{storeId}/Inventories/{inventoryId}")]
        public async Task<IActionResult> DeleteInventoryAsync(int storeId, int inventoryId)
        {
            Inventory inventory = await _inventoryRepository.GetInventoryAsync(storeId,inventoryId);
            if (inventory != null)
            {
                int id = inventory.InventoryId;
                _inventoryRepository.DeleteInventory(inventory);
                _rentalService.DeleteRental(id);
                _inventoryRepository.SaveChanges();

                return Ok("The inventory has been deleted!");
            }

            return NotFound("The inventory doesn't exist!");
        }
    }
}