﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class FilmsController : Controller
    {
        private IFilmRepository _filmRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private ICategoryRepository _categoryRepository;
        private IActorRepository _actorRepository;
        private IFilmActorRepository _filmActorRepository;
        private IFilmCategoryDeleteServices _filmCategoryService;
        private IInventoryRepository _inventoryRepository;

        public FilmsController(IFilmRepository filmRepository, IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository, IActorRepository actorRepository, ICategoryRepository categoryRepository, IFilmCategoryDeleteServices filmCategoryService, IInventoryRepository inventoryRepository)
        {
            _filmRepository = filmRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _actorRepository = actorRepository;
            _filmActorRepository = filmActorRepository;
            _categoryRepository = categoryRepository;
            _filmCategoryService = filmCategoryService;
            _inventoryRepository = inventoryRepository;
        }
        [HttpGet("Films")]
        public async Task<IActionResult> GetFilmsAsync()
        {
            IEnumerable<Film> filmList = await _filmRepository.GetFilmsAsync();
            List<FilmResponseLite> filmResponseList = new List<FilmResponseLite>();

            foreach (Film film in filmList)
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(film.FilmId);
                if (filmCategory != null)
                {
                    filmResponseList.Add(film.ToFilmResponseLite(filmCategory.Category));
                }
                else
                {
                    filmResponseList.Add(film.ToFilmResponseLite());
                }
            }

            return Ok(filmResponseList);
        }

        [HttpGet("Films/{filmId}", Name = "GetFilmAsync")]
        public async Task<IActionResult> GetFilmAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            if (film != null)
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(film.FilmId);

                if (filmCategory != null)
                {
                    FilmResponseLite filmResponse = film.ToFilmResponseLite(filmCategory.Category);

                    return Ok(filmResponse);
                }
                else
                {
                    FilmResponseLite filmResponse = film.ToFilmResponseLite();

                    return Ok(filmResponse);
                }
            }

            return NotFound("The film doesn't exist!");
        }

        [HttpPost("Films")]
        public IActionResult AddFilmAsync([FromBody]FilmCreateRequest request)
        {
            Film film = request.ToFilmModel();
            _filmRepository.AddFilm(film);
            _filmRepository.SaveChanges();
            FilmResponse filmResponse = film.ToFilmResponse();

            return CreatedAtRoute("GetFilmAsync", new { filmId = film.FilmId }, filmResponse);
        }

        [HttpGet("Films/{filmId}/Actors")]
        public async Task<IActionResult> GetFilmActorsAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            if (film != null)
            {
                IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetActorsAsync(filmId);
                List<ActorResponse> actorList = filmActorList.ToActorResponseList();
                FilmActorsResponse filmResponse = film.ToActorsResponse(actorList);

                return Ok(filmResponse);
            }

            return NotFound("The film doesn't exist!");
        }

        [HttpGet("Films/{filmId}/Actors/{actorId}", Name = "GetFilmActorAsync")]
        public async Task<IActionResult> GetFilmActorAsync(int filmId, int actorId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            FilmActor filmActor = await _filmActorRepository.GetFilmActorAsync(filmId, actorId);

            if (filmActor != null)
            {
                List<ActorResponse> actorList = new List<ActorResponse>();
                actorList.Add(filmActor.Actor.ToActorResponse());
                FilmActorsResponse filmResponse = film.ToActorsResponse(actorList);

                return Ok(filmResponse);
            }

            return NotFound("The actor doesn't exist!");
        }

        [HttpGet("Films/{filmId}/Category/{categoryId}", Name = "GetFilmCategoryAsync")]
        public async Task<IActionResult> GetFilmCategoryAsync(int filmId, int categoryId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (film != null)
            {
                return NotFound("The film doesn't exist!");
            }

            if (category != null)
            {
                return NotFound("The category doesn't exist!");
            }

            FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(filmId, categoryId);
            FilmCategoryResponse filmCategoryResponse = filmCategory.ToFilmCategoryResponse();

            return Ok(filmCategoryResponse);
        }

        [HttpPost("FilmCategories")]
        public async Task<IActionResult> AddFilmCategoryAsync([FromBody] FilmCategoryCreateRequest request)
        {
            Film film = await _filmRepository.GetFilmAsync(request.FilmId);

            if (film == null)
            {
                return NotFound("The film doesn't exist!");
            }
            Category category = await _categoryRepository.GetCategoryAsync(request.CategoryId);

            if (category == null)
            {
                return NotFound("The category doesn't exist!");
            }

            FilmCategory filmCategoryValidation = await _filmCategoryRepository.GetFilmCategoryAsync(request.FilmId, request.CategoryId);
            if (filmCategoryValidation != null)
            {
                return NotFound("The film already has a category!");
            }

            FilmCategory filmCategory = request.ToFilmCategoryModel();
            _filmCategoryRepository.AddFilmCategory(filmCategory);
            _filmCategoryRepository.SaveChanges();
            FilmCategoryResponse filmCategoryResponse = filmCategory.ToFilmCategoryResponse();

            return CreatedAtRoute("GetFilmCategoryAsync", new { filmId = film.FilmId, categoryId = category.CategoryId }, filmCategoryResponse);
        }

        [HttpPost("FilmActors")]
        public async Task<IActionResult> AddFilmActorAsync([FromBody] FilmActorCreateRequest request)
        {
            Film film = await _filmRepository.GetFilmAsync(request.FilmId);
            Actor actor = await _actorRepository.GetActorAsync(request.ActorId);

            if (film == null)
            {
                return NotFound("The film doesn't exist!");
            }

            if (actor == null)
            {
                return NotFound("The actor doesn't exist!");
            }
            FilmActor filmActorValidation = await _filmActorRepository.GetFilmActorAsync(request.FilmId, request.ActorId);

            if (filmActorValidation != null)
            {
                return NotFound("The film already has this actor!");
            }

            FilmActor filmActor = request.ToFilmActorModel();
            _filmActorRepository.AddFilmActor(filmActor);
            _filmActorRepository.SaveChanges();
            FilmActorResponse filmActorResponse = filmActor.ToFilmActorResponse();

            return CreatedAtRoute("GetFilmActorAsync", new { filmId = film.FilmId, actorId = actor.ActorId }, filmActorResponse);
        }

        [HttpDelete("Films/{filmId}/FilmActors/{actorId}")]
        public async Task<IActionResult> DeleteFilmActorAsync(int filmId, int actorId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (film == null)
            {
                return NotFound("The film doesn't exist!");
            }

            if (actor == null)
            {
                return NotFound("The actor doesn't exist!");
            }

            FilmActor filmActor = await _filmActorRepository.GetFilmActorAsync(filmId, actorId);
            if (filmActor != null)
            {
                _filmActorRepository.DeleteFilmActor(filmActor);
                _filmActorRepository.SaveChanges();

                return Ok("The actor has been deleted from film.");
            }

            return NotFound("The actor doesn't exist in this film!");
        }

        [HttpPut("films/{filmId}")]
        public async Task<IActionResult> UpdateFilmAsync([FromBody]FilmUpdateRequest request, [FromRoute]int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film != null)
            {
                film = request.ToFilmModel(film);
                _filmRepository.UpdateFilm(film);
                _filmRepository.SaveChanges();
                FilmResponse filmResponse = film.ToFilmResponse();

                return Ok(filmResponse);
            }

            return NotFound("The film doesn't exist!");
        }

        [HttpDelete("Films/{filmId}")]
        public async Task<IActionResult> DeleteFilmAsync(int filmId)
        {
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film != null)
            {
                _filmCategoryService.DeleteFilmCategoryAsync(filmId);
                _filmCategoryService.DeleteFilmActorAsync(filmId);
                _filmCategoryService.DeleteFilmInventoryAsync(filmId);
   
                _filmRepository.DeleteFilm(film);
                _filmRepository.SaveChanges();

                return Ok("The film has been deleted.");
            }

            return NotFound("The film doesn't exist!");
        }
    }
}