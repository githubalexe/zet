﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICityRepository
    {
        Task<City> GetCityAsync(int id);
    }
}
