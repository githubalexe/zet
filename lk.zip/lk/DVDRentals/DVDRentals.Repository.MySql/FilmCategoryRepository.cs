﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class FilmCategoryRepository : IFilmCategoryRepository
    {
        private UnitOfWork _context;
        public FilmCategoryRepository(UnitOfWork context) 
        {
            _context = context;
        }
        public async Task<FilmCategory> GetFilmCategoryAsync(int filmId)
        {
            return await _context.FilmCategory.Where(f => f.FilmId == filmId)
                                              .Include(c => c.Category)
                                              .FirstOrDefaultAsync(c => c.CategoryId == c.Category.CategoryId);
        }

        public async Task<IEnumerable<FilmCategory>> GetFilmCategoriesAsync(int filmId)
        {
            return await _context.FilmCategory.Where(f => f.FilmId == filmId)
                                              .ToListAsync();
        }
        public async Task<FilmCategory> GetFilmCategoryAsync(int filmId, int categoryId)
        {
            return await _context.FilmCategory.Where(f => f.FilmId == filmId)
                                              .Include(c => c.Category)
                                              .FirstOrDefaultAsync(c => c.CategoryId == categoryId);
        }
        public async Task<IEnumerable<FilmCategory>> GetFilmsCategoryAsync(int categoryId)
        {
            return await _context.FilmCategory.Where(c => c.CategoryId == categoryId)
                                              .Include(c => c.Category)
                                              .Include(f => f.Film)
                                              .ThenInclude(l=>l.Language)
                                              .ToListAsync();
        }

        public void AddFilmCategory(FilmCategory filmCategory)
        {
            _context.FilmCategory.Add(filmCategory);
        }

        public void DeleteFilmCategory(FilmCategory filmCategory)
        {
            _context.FilmCategory.Remove(filmCategory);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
