﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;


namespace DVDRentals.Repository.MySql
{
    public class FilmActorRepository : IFilmActorRepository
    {
        private UnitOfWork _context;

        public FilmActorRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<IEnumerable<FilmActor>> GetActorsAsync(int filmId)
        {
            return await _context.FilmActor.Where(f => f.FilmId == filmId)
                                           .Include(a => a.Actor)
                                           .ToListAsync();
        }

        public async Task<FilmActor> GetFilmActorAsync(int filmId, int actorId)
        {
            return await _context.FilmActor.Include(a => a.Actor)
                                           .FirstOrDefaultAsync(f => f.FilmId == filmId && f.ActorId == actorId);
        }

        public void AddFilmActor(FilmActor filmActor)
        {
            _context.FilmActor.Add(filmActor);
        }

        public void UpdateFilmActor(FilmActor filmActor)
        {
            _context.FilmActor.Update(filmActor);
        }

        public void DeleteFilmActor(FilmActor filmActor)
        {
            _context.FilmActor.Remove(filmActor);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
