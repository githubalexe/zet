﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class FilmRepository : IFilmRepository
    {
        private UnitOfWork _context;

        public FilmRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Film>> GetFilmsAsync()
        {
            return await _context.Film.Include(l => l.Language)
                                      .Include(c => c.FilmCategory)
                                      .ThenInclude(c => c.Category)
                                      .ToListAsync();
        }

        public async Task<Film> GetFilmAsync(int filmId)
        {
            return await _context.Film.Include(l => l.Language)
                                      .Include(c => c.FilmCategory)
                                      .ThenInclude(c => c.Category)
                                      .FirstOrDefaultAsync(f => f.FilmId == filmId);
        }
        
        public void AddFilm(Film film)
        {
            _context.Film.Add(film);
        }

        public void UpdateFilm(Film film)
        {
            _context.Film.Update(film);
        }

        public void DeleteFilm(Film film)
        {
            _context.Film.Remove(film);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
