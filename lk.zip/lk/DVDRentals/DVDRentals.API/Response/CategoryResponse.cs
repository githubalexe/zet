﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    public class CategoryResponse
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
