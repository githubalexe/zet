﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class FilmCreateRequest
    {
        [Required(ErrorMessage = "Title is required.")]
        public string Title { get; set; }
        [Required(ErrorMessage = "Description is required.")]
        public string Description { get; set; }
        [Required(ErrorMessage = "ReleaseYear is required.")]
        public int ReleaseYear { get; set; }
        [Required(ErrorMessage = "LanguageId is required.")]
        public int LanguageId { get; set; }
        public int? OriginalLanguageId { get; set; }
        [Required(ErrorMessage = "RentalDuration is required.")]
        public int RentalDuration { get; set; }
        [Required(ErrorMessage = "RentalRate is required.")]
        public decimal RentalRate { get; set; }
        [Required(ErrorMessage = "Length is required.")]
        public int? Length { get; set; }
        [Required(ErrorMessage = "ReplacementCost is required.")]
        public decimal ReplacementCost { get; set; }
        [Required(ErrorMessage = "Rating is required.")]
        public string Rating { get; set; }
        [Required(ErrorMessage = "SpecialFeatures is required.")]
        public string SpecialFeatures { get; set; }
    }
}
