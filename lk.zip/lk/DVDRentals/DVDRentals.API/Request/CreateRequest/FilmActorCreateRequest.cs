﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class FilmActorCreateRequest
    {
        public int ActorId { get; set; }
        public int FilmId { get; set; }
    }
}
