﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IActorRepository
    {
        Task<Actor> GetAsync(int actorId);
        Task<IEnumerable<Actor>> GetAllAsync();
    }
}
