﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmRepository
    {
        Task<IEnumerable<Film>> GetFilmsAsync();
        Task<Film> GetFilmAsync(int filmId);
    }
}
