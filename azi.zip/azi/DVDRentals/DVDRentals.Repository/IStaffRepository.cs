﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IStaffRepository
    {
        Task<IEnumerable<Staff>> GetStaffsAsync(int storeId);
        Task<Staff> GetStaffAync(int storeId, int staffId);
        void AddStaff(Staff staff);
        void SaveChanges();
    }
}
