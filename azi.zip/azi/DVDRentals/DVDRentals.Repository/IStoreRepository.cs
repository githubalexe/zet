﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IStoreRepository
    {
        Task<Store> GetStoreAsync(int storeId);
    }
}
