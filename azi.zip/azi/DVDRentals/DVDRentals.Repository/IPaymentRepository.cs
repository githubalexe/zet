﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IPaymentRepository
    {
        Task<Payment> GetCustomerPaymentAsync(int customerId, int paymentId);
        Task<Payment> GetStaffPaymentAsync(int staffId, int paymentId);
        Task<IEnumerable<Payment>> GetCustomerPaymentsAsync(int customerId);
        Task<IEnumerable<Payment>> GetStaffPaymentsAsync(int staffId);
    }
}
