﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class ActorRepository : IActorRepository
    {
        private UnitOfWork _context;

        public ActorRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Actor>> GetAllAsync()
        {
            return await _context.Actor.OrderBy(a => a.ActorId)
                                 .ToListAsync();
        }

        public async Task<Actor> GetAsync(int actorId)
        {
            return await _context.Actor.FirstAsync(a => a.ActorId == actorId);
        }   
    }
}
