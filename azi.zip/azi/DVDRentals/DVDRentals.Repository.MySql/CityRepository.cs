﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CityRepository : ICityRepository
    {
        private UnitOfWork _context;
        public CityRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<City> GetCityAsync(int id)
        {
            return await _context.City.Include("Country").FirstOrDefaultAsync(c => c.CityId == id);
        }
    }
}
