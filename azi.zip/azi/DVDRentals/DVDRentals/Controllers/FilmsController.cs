﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class FilmsController : Controller
    {
        private IInventoryRepository _inventoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmActorRepository _filmActorRepository;

        public FilmsController(IInventoryRepository inventoryRepository, IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository)
        {
            _inventoryRepository = inventoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _filmActorRepository = filmActorRepository;
        }

        [HttpGet("Stores/{storeId}/Films")]
        public async Task<IActionResult> GetFilmsAsync(int storeId)
        {
            IEnumerable<Inventory> inventoryList = await _inventoryRepository.GetFilmsAsync(storeId);
            List<FilmResponse> filmResponseList = new List<FilmResponse>();

            int id = 0;
            foreach (Inventory inventory in inventoryList)
            {
                int inventoryId = inventory.Film.FilmId;
                if (inventoryId != id)
                {
                    FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(inventoryId);
                    filmResponseList.Add(inventory.Film.ToFilmResponse(filmCategory.Category));
                }
                id = inventoryId;
            }

            return Ok(filmResponseList);
        }

        [HttpGet("Stores/{storeId}/Films/{filmId}")]
        public async Task<IActionResult> GetOneFilmAsync(int storeId, int filmId)
        {
            Inventory inventory = await _inventoryRepository.GetFilmAsync(storeId, filmId);
            if (inventory != null)
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(inventory.Film.FilmId);
                FilmResponse filmResponse = inventory.Film.ToFilmResponse(filmCategory.Category);

                return Ok(filmResponse);
            }

            return NotFound("The film doesn't exist!");
        }

        [HttpGet("Stores/{storeId}/Films/{filmId}/Actors")]
        public async Task<IActionResult> GetFilmActorsAsync(int storeId, int filmId)
        {
            Inventory inventory = await _inventoryRepository.GetFilmAsync(storeId, filmId);
            if (inventory != null)
            {
                IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetActorsAsync(filmId);
                List<ActorResponse> actorList = filmActorList.ToActorResponseList();
                FilmActorsResponse filmResponse = inventory.Film.ToActorsResponse(actorList);

                return Ok(filmResponse);
            }
            return NotFound("The film doesn't exist!");
        }

        [HttpGet("Stores/{storeId}/Films/{filmId}/Actors/{actorId}")]
        public async Task<IActionResult> GetFilmActorAsync(int storeId, int filmId, int actorId)
        {
            Inventory inventory = await _inventoryRepository.GetFilmAsync(storeId, filmId);
            FilmActor filmActor = await _filmActorRepository.GetActorAsync(filmId, actorId);

            if (inventory == null)
            {
                return NotFound("The film doesn't exist!");
            }
            if (filmActor != null)
            {
                List<ActorResponse> actorList = new List<ActorResponse>();
                actorList.Add(filmActor.Actor.ToActorResponse());
                FilmActorsResponse filmResponse = inventory.Film.ToActorsResponse(actorList);

                return Ok(filmResponse);
            }

            return NotFound("The actor doesn't exist!");
        }
    }
}