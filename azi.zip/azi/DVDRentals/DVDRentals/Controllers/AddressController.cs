﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Repository.MySql;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class AddressController : Controller
    {

        private IAddressRepository _addressRepository;

        public AddressController(IAddressRepository addressRepository)
        {
            _addressRepository = addressRepository;
        }
        [HttpPost("Address")]
        public IActionResult CreateAddress([FromBody]AddressCreateRequest request)
        {
            Address address = request.ToAddressModel();
            _addressRepository.AddAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }

        [HttpPut("Address/{addressId}")]
        public async Task<IActionResult> UpdateAddress([FromBody]AddressUpdateRequest request)
        {
            // Address address = await _addressRepository.GetAddressAsync(request.AddressId);
            Address address = request.ToAddressModel();
            _addressRepository.UpdateAddress(address);
            _addressRepository.SaveChanges();
            AddressResponse addressResponse = address.ToAddressResponse();

            return Ok(addressResponse);
        }
        [HttpDelete("Address/{addressId}")]
        public async Task<IActionResult> DeleteAddress(int addressId)
        {
            Address address = await _addressRepository.GetAddressAsync(addressId);

            if (address != null)
            {
                _addressRepository.DeleteAddress(address);
                _addressRepository.SaveChanges();

                return Ok("The address has been deleted!");
            }

            return NotFound("The address doesn't exist!");
        }
    }
}