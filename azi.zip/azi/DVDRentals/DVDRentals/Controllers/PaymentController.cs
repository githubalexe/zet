﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class PaymentController : Controller
    {
        private IPaymentRepository _paymentRepository;
        private IStaffRepository _staffRepository;

        public PaymentController(IPaymentRepository paymentRepository, IStaffRepository staffRepository)
        {
            _paymentRepository = paymentRepository;
            _staffRepository = staffRepository;
        }

        [HttpGet("Stores/{storeId}/Payments")]
        public async Task<IActionResult> GetStorePaymentsAsync(int storeId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StorePaymentsResponse> paymentResponseList = new List<StorePaymentsResponse>();

            foreach (Staff staff in staffList)
            {
                IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staff.StaffId);
                foreach (Payment payment in paymentList)
                {
                    if (payment.Rental != null)
                    {
                        paymentResponseList.Add(payment.ToStorePaymentResponse());
                    }
                }
            }

            return Ok(paymentResponseList);
        }

        [HttpGet("Stores/{storeId}/Payments/{paymentId}")]
        public async Task<IActionResult> GetStorePaymentAsync(int storeId, int paymentId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StorePaymentsResponse> paymentResponseList = new List<StorePaymentsResponse>();

            foreach (Staff staff in staffList)
            {
                Payment payment = await _paymentRepository.GetStaffPaymentAsync(staff.StaffId, paymentId);
                if (payment == null)
                {
                    return NotFound("The payment doesn't exist!");
                }
                paymentResponseList.Add(payment.ToStorePaymentResponse());
            }

            return Ok(paymentResponseList);
        }
    }
}