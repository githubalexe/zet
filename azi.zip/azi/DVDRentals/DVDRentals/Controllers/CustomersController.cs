﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Models;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class CustomersController : Controller
    {
        private ICustomerRepository _customerRepository;
        private IPaymentRepository _paymentRepository;

        public CustomersController(ICustomerRepository customerRepository, IPaymentRepository paymentRepository)
        {
            _customerRepository = customerRepository;
            _paymentRepository = paymentRepository;
        }

        [HttpGet("Stores/{storeId}/Customers")]
        public async Task<IActionResult> GetAllCustomersAsync(int storeId)
        {
            IEnumerable<Customer> customerList = await _customerRepository.GetCustomersAsync(storeId);
            List<CustomerResponse> customerResponseList = customerList.ToCustomerResponseList();

            return Ok(customerResponseList);
        }

        [HttpGet("Stores/{storeId}/Customers/{customerId}")]
        public async Task<IActionResult> GetOnCustomerAsync(int storeId, int customerId)
        {
            //put the address if u want
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            if (customer != null)
            {
                CustomerResponse customerResponse = customer.ToCustomerResponse();
                return Ok(customerResponse);
            }

            return NotFound("The customer doesn't exist!");
        }

        [HttpGet("Stores/{storeId}/Customers/{customerId}/Payments")]
        public async Task<IActionResult> GetCustomerPaymentsAsync(int storeId, int customerId)
        {
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);

            if (customer != null)
            {
                IEnumerable<Payment> paymentList = await _paymentRepository.GetCustomerPaymentsAsync(customerId);
                List<PaymentForCustomerResponse> paymentResponseList = paymentList.ToCustomerPaymentsResponse();
                CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

                return Ok(customerResponse);
            }

            return NotFound("The customer doesn't exist!");
        }

        [HttpGet("Stores/{storeId}/Customers/{customerId}/Payments/{paymentId}")]
        public async Task<IActionResult> GetCustomerPaymentAsync(int storeId, int customerId, int paymentId)
        {
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Payment payment = await _paymentRepository.GetCustomerPaymentAsync(customerId, paymentId);

            if (customer == null)
            {
                CustomerErrorValidation error = new CustomerErrorValidation();
                error.isValid = false;
                error.errorMessage = "The customer doesn't exist!";

                return NotFound(error.errorMessage);
            }

            if (payment != null)
            {
                PaymentForCustomerResponse paymentResponse = payment.ToCustomerPaymentResponse();
                List<PaymentForCustomerResponse> paymentResponseList = new List<PaymentForCustomerResponse>();
                paymentResponseList.Add(paymentResponse);
                CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

                return Ok(customerResponse);
            }

            return NotFound("The payment doesn't exist!");
        }
    }
}