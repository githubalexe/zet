﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static RentalResponse ToRentalResponse(this Rental rental)
        {
            RentalResponse rentalResponse = new RentalResponse()
            {
                RentalId = rental.RentalId,
                RentalDate = rental.RentalDate,
                InventoryId = rental.InventoryId,
                CustomerId = rental.CustomerId,
                ReturnDate = rental.ReturnDate,
                StaffId = rental.StaffId,
                LastUpdate = rental.LastUpdate,
                Film = rental.Inventory.Film.ToFilmTextResponse()
            };

            return rentalResponse;
        }
    }
}
