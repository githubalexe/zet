﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreResponse ToStoreResponse(this Store store)
        {
            StoreResponse storeResponse = new StoreResponse()
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                LastUpdate = store.LastUpdate,
            };

            storeResponse.Address = store.Address.ToAddressResponseLite();
            storeResponse.Address.City = store.Address.City.ToCityResponse();
            storeResponse.Address.City.Country = store.Address.City.Country.ToCountryResponse();

            return storeResponse;
        }
    }
}
