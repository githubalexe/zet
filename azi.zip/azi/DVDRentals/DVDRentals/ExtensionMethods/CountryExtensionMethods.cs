﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CountryExtensionMethods
    {
        public static CountryResponse ToCountryResponse(this Country country)
        {
            CountryResponse countryResponse = new CountryResponse()
            {
                CountryId = country.CountryId,
                Country1 = country.Country1,
                LastUpdate = country.LastUpdate
            };

            return countryResponse;
        }
    }
}
