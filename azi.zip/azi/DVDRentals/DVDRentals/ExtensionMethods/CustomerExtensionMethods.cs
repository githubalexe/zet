﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerResponse ToCustomerResponseLite(this Customer customer)
        {
            CustomerResponse customerResponse = new CustomerResponse()
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                LastUpdate = customer.LastUpdate
            };

            return customerResponse;
        }

        public static CustomerResponse ToCustomerResponse(this Customer customer)
        {
            CustomerResponse customerResponse = new CustomerResponse();
            customerResponse = customer.ToCustomerResponseLite();
            customerResponse.Address = customer.Address.ToAddressResponseLite();
            customerResponse.Address.City = customer.Address.City.ToCityResponse();
            customerResponse.Address.City.Country = customer.Address.City.Country.ToCountryResponse();

            return customerResponse;
        }
        public static List<CustomerResponse> ToCustomerResponseList(this IEnumerable<Customer> customerList)
        {
            List<CustomerResponse> customerResponseList = new List<CustomerResponse>();

            foreach (Customer customer in customerList)
            {
                CustomerResponse customerResponse = new CustomerResponse();
                customerResponse = customer.ToCustomerResponse();

                customerResponseList.Add(customerResponse);
            }

            return customerResponseList;
        }
        //public static CustomerResponse ToCustomerResponse(this Customer customer, Address address)
        //{
        //    CustomerResponse customerResponse = new CustomerResponse
        //    {
        //        Active = customer.Active,
        //        Address = new AddressResponse
        //        {
        //            City = new CityResponse
        //            {
        //                Country = new CountryResponse
        //                {
        //                    Country1 = address.City.Country.Country1
        //                }
        //            }
        //        }
        //    };

        //    return customerResponse;
        //}
    }
}
