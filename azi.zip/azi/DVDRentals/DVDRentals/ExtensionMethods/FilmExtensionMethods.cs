﻿using DVDRentals.API.Response;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static FilmResponse ToFilmResponse(this Film film, Category category)
        {
            FilmResponse filmResponse = new FilmResponse()
            {
                FilmId = film.FilmId,
                Title = film.Title,
                Description = film.Description,
                ReleaseYear = film.ReleaseYear,
                LanguageId = film.LanguageId,
                OriginalLanguageId = film.OriginalLanguageId,
                RentalDuration = film.RentalDuration,
                RentalRate = film.RentalRate,
                Length = film.Length,
                ReplacementCost = film.ReplacementCost,
                LastUpdate = film.LastUpdate,
                Rating = film.Rating,
                SpecialFeatures = film.SpecialFeatures,
                Language = film.Language.ToLanguageResponse(),
                Category = category.ToCategoryResponse()
            };

            return filmResponse;
        }

        public static FilmActorsResponse ToActorsResponse(this Film film, List<ActorResponse> actorList)
        {
            FilmActorsResponse filmResponse = new FilmActorsResponse()
            { 
                FilmId = film.FilmId,
                Title = film.Title,
                FilmActors = actorList
            };

            return filmResponse;
        }
    }
}
