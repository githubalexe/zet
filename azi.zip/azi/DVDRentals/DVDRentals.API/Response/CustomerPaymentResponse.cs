﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    public class CustomerPaymentResponse
    {
        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
