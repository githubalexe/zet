﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class RentalCreateRequest
    {
        [Required(ErrorMessage = "RentalDate is required.")]
        public DateTime RentalDate { get; set; }
        [Required(ErrorMessage = "InventoryId is required.")]
        public int InventoryId { get; set; }
        [Required(ErrorMessage = "CustomerId is required.")]
        public int CustomerId { get; set; }
        public DateTime? ReturnDate { get; set; }
        [Required(ErrorMessage = "StaffId is required.")]
        public int StaffId { get; set; }
    }
}
