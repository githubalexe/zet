﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Country;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class CountriesController : Controller
    {
        private ICountryRepository _countryRepository;

        public CountriesController(ICountryRepository countryRepository)
        {
            _countryRepository = countryRepository;
        }

        [HttpGet("countries")]
        public async Task<IActionResult> GetCountriesAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Country> countriesQuery = _countryRepository.CountriesQuery();

            countriesQuery = countriesQuery.OrderBy(country => country.CountryId);

            IEnumerable<Country> countries = await _countryRepository.CountriesListAsync(countriesQuery, true);

            if (countries.Count() == 0)
            {
                errorMessage.Message = CountryMessages.InvalidCountriesList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<CountryResponseLite> response = countries.Select(country => country.ToCountryResponseLite());

                return Ok(response);
            }
        }

        [HttpGet("countries/{countryId}", Name = "GetCountryAsync")]
        public async Task<IActionResult> GetCountryAsync(int countryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Country country = await _countryRepository.GetCountryAsync(countryId);

            if (country == null)
            {
                errorMessage.Message = CountryMessages.NoCountryResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                CountryResponseLite response = country.ToCountryResponseLite();

                return Ok(response);
            }
        }

        [HttpPost("countries")]
        public async Task<IActionResult> CreateCityAsync([FromBody] CountryCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = CountryMessages.InvalidCountryRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Country country = request.ToCountryModel();

                await _countryRepository.CreateCountryAsync(country);
                await _countryRepository.SaveChangesAsync();

                CountryResponseLite response = country.ToCountryResponseLite();

                return CreatedAtRoute("GetCountryAsync", new { countryId = country.CountryId }, response);
            }
        }

        [HttpPut("countries/{countryId}")]
        public async Task<IActionResult> UpdateCountryAsync([FromBody]CountryUpdateRequest request, int countryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Country country = await _countryRepository.GetCountryAsync(countryId);

            if (country == null)
            {
                errorMessage.Message = CountryMessages.NoCountryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = CountryMessages.InvalidCountryRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                country = request.ToCountryModel(country);

                await _countryRepository.SaveChangesAsync();

                CountryResponseLite response = country.ToCountryResponseLite();

                return Ok(response);
            }
        }

        [HttpDelete("countries/{countryId}")]
        public async Task<IActionResult> DeleteCountryAsync(int countryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Country country = await _countryRepository.GetCountryAsync(countryId);

            if (country == null)
            {
                errorMessage.Message = CountryMessages.NoCountryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCity = await _countryRepository.CityExistsAsync(countryId);

            if (isCity == true)
            {
                errorMessage.Message = CountryMessages.DeleteCountryFalid.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _countryRepository.DeleteCountry(country);

                await _countryRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}