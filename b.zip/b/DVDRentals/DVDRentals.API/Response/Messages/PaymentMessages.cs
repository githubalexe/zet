﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum PaymentMessages
    {
        [Description("The payment doesn't exist!")]
        NoPaymentResponse,
        [Description("The request payment in NULL!")]
        InvalidPaymentRequest,
        [Description("The payment list is empty!")]
        InvalidPaymentList,
    }
}
