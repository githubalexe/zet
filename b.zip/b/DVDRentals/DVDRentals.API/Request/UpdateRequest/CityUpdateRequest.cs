﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.UpdateRequest
{
    public class CityUpdateRequest
    {
        public string Name { get; set; }
        public int CountryId { get; set; }
    }
}
