﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class LanguageRepository : ILanguageRepository
    {
        private UnitOfWork _unitOfWork;
        public LanguageRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<Language> LanguagesQuery()
        {
            IQueryable<Language> languagesQuery = _unitOfWork.Language;
            return languagesQuery;
        }

        public async Task<IEnumerable<Language>> ListLanguagesAsync(IQueryable<Language> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.AsNoTracking().ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public async Task<bool> FilmExistsAsync(int languageId)
        {
            return await _unitOfWork.Film.AnyAsync(l => l.LanguageId == languageId);
        }

        public async Task<Language> GetLanguageAsync(int languageId)
        {
            return await _unitOfWork.Language.FirstOrDefaultAsync(l => l.LanguageId == languageId);
        }

        public async Task CreateLanguageAsync(Language language)
        {
            await _unitOfWork.Language.AddAsync(language);
        }

        public void DeleteLanguage(Language language)
        {
            _unitOfWork.Language.Remove(language);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
