﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.Domain
{
    public class Language
    {
        public Language()
        {
            FilmLanguage = new HashSet<Film>();
            FilmOriginalLanguage = new HashSet<Film>();
        }

        public int LanguageId { get; set; }
        public string Name { get; set; }
        public DateTime LastUpdate { get; set; }

        public virtual IEnumerable<Film> FilmLanguage { get; set; }
        public virtual IEnumerable<Film> FilmOriginalLanguage { get; set; }
    }
}
