(function () {
    var firstNameElement = document.getElementById("firstName");
    var lastNameElement = document.getElementById("lastName");
    var roleElement = document.getElementById("role");
    var fileInputElement = document.getElementById("fileInput");
    var maleRadio = document.getElementById("male");
    var femaleRadio = document.getElementById("female");
    var birthDateElement = document.getElementById("birthDate");
    var fileDisplayAreaElement = document.getElementById("fileDisplayArea");
    var pictureContainer = document.getElementById("pictureContainer");
    var firstNameErrorMessage = document.getElementById("firstNameMessage");
    var lastNameErrorMessage = document.getElementById("lastNameMessage");
    var genderErrorMessage = document.getElementById("genderMessage");
    var birthDateErrorMessage = document.getElementById("birthDateMessage");
    var roleErrorMessage = document.getElementById("roleMessage");
    var pictureErrorMessage = document.getElementById("pictureMessage");
    var saveButton = document.getElementById("save");
    var cancelButton = document.getElementById("cancel");
    var genderElement = "";

    firstNameElement.addEventListener("focusout", function () {
        setFirstNameError();
    });

    lastNameElement.addEventListener("focusout", function () {
        setLastNameMessage();
    });
    roleElement.addEventListener("focusout", function () {
        setRoleMessage();
    });

    birthDateElement.addEventListener("focusout", function () {
        setBirthDateMessage();
    });

    maleRadio.addEventListener("focusout", function () {
        setGenderMessage();
    });

    femaleRadio.addEventListener("focusout", function () {
        setGenderMessage();
    });

    fileInputElement.addEventListener("focusout", function () {
        setFileInputMessage();
    });

    function setFirstNameError() {
        var errorMessage = User.validateFirstName(firstNameElement.value, 30);
        firstNameErrorMessage.innerHTML = errorMessage;
    }
    function setLastNameMessage() {
        var errorMessage = User.validateLastName(lastNameElement.value, 50);
        lastNameErrorMessage.innerHTML = errorMessage;
    }
    function setRoleMessage() {
        var errorMessage = User.validateRole(roleElement.value);
        roleErrorMessage.innerHTML = errorMessage;
    }
    function setBirthDateMessage() {
        var errorMessage = User.validateBirthDate(birthDateElement.value);
        birthDateErrorMessage.innerHTML = errorMessage;
        if (errorMessage != "") {
            birthDateElement.value = "";
        }
    }
    function setGenderMessage() {
        var genderElement = getGender();
        errorMessage = User.validateGender(genderElement);
        genderErrorMessage.innerHTML = errorMessage;
    }
    function setFileInputMessage() {
        var errorMessage = User.validatefilleInput(fileInputElement.value);
        pictureErrorMessage.innerHTML = errorMessage;
    }

    function getGender() {
        if (maleRadio.checked == true) {
            genderElement = "Male";
        }
        else
            if (femaleRadio.checked == true) {
                genderElement = "Female";
            }
        return genderElement;
    }

    saveButton.addEventListener("click", function () {
        setFirstNameError();
        setLastNameMessage();
        setGenderMessage();
        setBirthDateMessage();
        setRoleMessage();
        setFileInputMessage();

        var options = {
            firstName: firstNameElement.value,
            lastName: lastNameElement.value,
            gender: genderElement,
            birthDate: birthDateElement.value,
            role: roleElement.value,
            fileInput: fileInputElement.value
        };
        var user = new User(options);
        var errorMessages = user.getAllValidationErrors();
        if (errorMessages.length > 0) {
            alert("Complete all the fields!");
        } else {
            user.displayUser();
            alert("User saved in console log");
        }
    });
    cancelButton.addEventListener("click", function () {
        if (confirm('Are you sure you want to cancel?')) {
            genderElement = "";
            firstNameElement.value = "";
            lastNameElement.value = "";
            birthDateElement.value = "";
            roleElement.value = "";
            fileInputElement.value = "";
            maleRadio.checked = false;
            femaleRadio.checked = false;
            firstNameErrorMessage.innerHTML = "";
            lastNameErrorMessage.innerHTML = "";
            genderErrorMessage.innerHTML = "";
            birthDateErrorMessage.innerHTML = "";
            roleErrorMessage.innerHTML = "";
            pictureErrorMessage.innerHTML = "";
            pictureContainer.style.display = "table";
            if (fileDisplayAreaElement.children[0] != null) {
                fileDisplayAreaElement.children[0].remove();
            }
        }
    });

    fileInputElement.addEventListener('change', function (e) {
        var file = fileInputElement.files[0];
        var fileElement=fileInputElement;
        var imageType = /image.*/;
        validateExtensions(fileElement);
        validateSize(file);
        if (validateExtensions(fileElement) === true) {
            alert("ALERT");
            if (validateSize(file) === true && file.type.match(imageType)) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    fileDisplayAreaElement.innerHTML = "";

                    var img = new Image();
                    img.src = reader.result;

                    fileDisplayAreaElement.appendChild(img);
                    pictureContainer.style.display = "none";
                }
                reader.readAsDataURL(file);
            }
            else {
                fileDisplayAreaElement.innerHTML = "File not supported!"

            }
        }
        else
        {
            fileDisplayAreaElement.value="";
        }

    });

    function validateSize(file) {
        var ok = true;
        if (file.size > 50 * 1024) {
            fileDisplayAreaElement.innerHTML = "";
            pictureErrorMessage.innerHTML = "Maximum required is 50 Kb!";
            fileInputElement.value = "";
            pictureContainer.style.display = "table";
            ok = false;
        }
        return ok;
    }

    function validateExtensions(file) {
        var fileValid = false;
        var _validFileExtensions = [".png", ".jpg", ".jpeg", ".bmp"];
        if (file.type == "file") {
            var sFileName = file.value;
            if (sFileName.length > 0) {
                for (var j = 0; j < _validFileExtensions.length; j++) {
                    var sCurExtension = _validFileExtensions[j];
                    if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                        fileValid = true;
                        break;
                    }
                }
                if (!fileValid) {
                    pictureErrorMessage.innerHTML = "Supported extensions are .png, .jpg, .jpeg, .bmp!";
                    fileInputElement.value = "File not supported!";
                    fileDisplayAreaElement.value="";
                }
            }
        }
        return fileValid;
    }

})();
