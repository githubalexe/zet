class User {
    constructor(options) {
        this.firstName = options.firstName;
        this.lastName = options.lastName;
        this.gender = options.gender;
        this.birthDate = options.birthDate;
        this.role = options.role;
        this.fileInput = options.fileInput;
    }

    displayUser() {
        console.log(this.firstName, this.lastName, this.gender, this.birthDate, this.role, this.fileInput);
    }

    getAllValidationErrors() {
        var errorMessages = [];
        var errorMessage = "";

        errorMessage = User.validateFirstName(this.firstName, 30);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";

        }
        errorMessage = User.validateLastName(this.lastName, 30);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }

        errorMessage = User.validateBirthDate(this.birthDate);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }

        errorMessage = User.validateRole(this.role);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }
        errorMessage = User.validateGender(this.gender);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }
        errorMessage = User.validatefilleInput(this.fileInput);

        if (errorMessage !== "") {
            errorMessages.push(errorMessage);
            errorMessage = "";
        }
     
        return errorMessages;
    }

    static validateFirstName(nameArg, lengthAllowed) {
        return User._commonRulesValidationForName(nameArg, lengthAllowed);
    }
    static validateLastName(nameArg, lengthAllowed) {
        return User._commonRulesValidationForName(nameArg, lengthAllowed);
    }
    static _commonRulesValidationForName(name, lengthAllowed) {
        var errorMessage = "";
        var lengthWord;
        if (name === "") {
            lengthWord = 0;
        }
        else {
            lengthWord = name.length;
        }
        var characters = String(name);

        if ((/[0-9]/.test(characters))) {
            errorMessage = "Only alpha characters are allowed!";
        }
        else
            if (lengthWord <= 2) {
                errorMessage = "Minimum required characters is 3!";
            }
            else
                if (lengthWord >= lengthAllowed) {
                    errorMessage = "Maximum allowed characters is " + lengthAllowed + "!";
                }
                else
                    if (lengthWord >= 2 && lengthWord < lengthAllowed && !(/[0-9]/.test(characters))) {
                        errorMessage = "";
                    }

        return errorMessage;
    }
    static validateBirthDate(birthDateArg) {

        var errorMessage = "";
        if (birthDateArg == "") {
            var errorMessage = "Birth Date is required!";
        }
        else if (birthDateArg != "") {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1;
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = '0' + dd
            }
            if (mm < 10) {
                mm = '0' + mm
            }
            today = mm + '/' + dd + '/' + yyyy;
            var birthYear = new Date(birthDateArg);
            var year = birthYear.getFullYear();
            var difference = yyyy - year;
            if(difference<0)
            {
                errorMessage="Future data is not allowed!";
            }
            else
            if (difference <=18) {
                errorMessage = "The minimum age is 18 years!";
            }
            else
                if (difference >= 45) {
                    errorMessage = "The maximum age is 45 years!";
                }
                else
                    if (difference >= 18 && difference <= 45) {
                        errorMessage = "";
                    }
        }
        return errorMessage;
    }

    static validateGender(genderArg) {
    
        var errorMessage = "";
        if (genderArg === "" ) {
            errorMessage = "Select a gender!";
        }
        else {
            errorMessage = "";
        }
        return errorMessage;
    }
    static validateRole(roleArg) {
        var errorMessage = "";
        if (roleArg == "") {
            errorMessage = "Role is required!";
        }
        else {
            errorMessage = "";
        }

        return errorMessage;
    }
    static validatefilleInput(fileInputArg) {
        var errorMessage = "";
        if (fileInputArg == "") {
            errorMessage = "Image is required!";
        }
        else {
            errorMessage = "";
        }

        return errorMessage;
    }
}