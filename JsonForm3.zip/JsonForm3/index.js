define(["jquery", "InputGenerator", "CodeMirror", "InputsList", "InputHelper", "bootstrap"], function($, InputGenerator, CodeMirror, InputsList, InputHelper) {

    var $textInput = $("#textInput");
    var $clearButton = $("#clearButton");
    var $generateButton = $("#generateButton");
    var $inputsContainer = $("#inputsContainer");
    var $itemTemplate = $("#itemTemplate");
    var $selectList = $("#selectList");
    var $warningContainer = $("#warningContainer");

    var index = {};

    function initializeInputGenerator() {

        var options = {
            $generateButton: $generateButton,
            $textInput: $textInput,
            $inputsContainer: $inputsContainer,
            $clearButton: $clearButton,
            $itemTemplate: $itemTemplate,
            $warningContainer: $warningContainer,

            onControlCreate: function(control) {

                addSettings(control)
            },

            onControlDestroy: function() {

            }
        }

        return options;
    }

    appendOptionTolist();

    index.generateForm = function(controls) {

        var options = initializeInputGenerator();
        var inputGenerator = new InputGenerator(options);

        inputGenerator.createByJsonValue(controls);

        $generateButton.on("click", function() {

            var value = $textInput.val();
            inputGenerator.createByJsonValue(value);

        });

        $selectList.on("change", function() {

            var value = this.value;

            console.log(InputsList.inputs);

            if (value === InputsList.Inputs.option.value) {

                var items = InputsList.inputs.items;
            }

            inputGenerator.createByJsonValue(items);

        });

        $clearButton.on("click", function() {

            $textInput.val("");

        });

        $textInput.on("change", function() {

            var value = this.value;

            if (InputHelper.IsJson(value) || value === "") {

                $warningContainer.addClass("d-none");

            } else {

                $warningContainer.removeClass("d-none");
            }
        });
    };

    function addSettings(control) {

        var $settingsContainer = $("<div/>", {
            class: "settings-container"
        });

        var $setButton = $("<button/>", {
            class: "btn btn-primary button",
            html: "Set Value",
            id: "setValue-" + control.inputId,
            click: function() {
                setValue(control);
            }
        });

        var $getButton = $("<button/>", {
            class: "btn btn-success button",
            html: "Get Value",
            id: "getValue-" + control.inputId,
            click: function() {
                getValue(control);
            }
        });

        var $input = $("<input/>", {
            class: "second-input",
            id: "second-" + control.inputId,

        });

        var $removeButton = $("<button/>", {
            class: "btn btn-danger remove-button",
            html: "Remove",
            click: function() {
                destoryContainer(control);
            }
        });

        $settingsContainer.append($setButton, $getButton, $input, $removeButton);
        control.GetContainerDomElement().append($settingsContainer);
    };

    function setValue(control) {

        var $secondInput = $("#second-" + control.inputId);
        control.SetInputValue($secondInput.val());
    };

    function getValue(control) {

        var $secondInput = $("#second-" + control.inputId);
        $secondInput.val(control.GetInputValue());

    };

    function destoryContainer(control) {

        control.DestroyContainer();
    };

    function appendOptionTolist() {

        $selectList.append(
            getOptionForList("Textbox List", 1),
            getOptionForList("Textbox and Dropdownlist List", 2)
        )
    };

    function getOptionForList(textOption, valueOption) {

        var $option = $("<option>", {
            text: textOption,
            value: valueOption,
        })

        return $option;
    };

    return index;

});