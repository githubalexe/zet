define(["jquery", "InputGenerator", "CodeMirror", "InputsList", "InputHelper", "Dropdown", "bootstrap"], function($, InputGenerator, CodeMirror, InputsList, InputHelper) {

    var index = {};

    var $textInput = $("#textInput");
    var $clearButton = $("#clearButton");
    var $generateButton = $("#generateButton");
    var $inputsContainer = $("#inputsContainer");
    var $selectList = $("#selectList");
    var $warningContainer = $("#warningContainer");
    var $clearInputs = $("#clearInputs");
    var $submitButton = $("#submitButton");

    index.generateForm = function(controls) {

        var options = {
            $inputsContainer: $inputsContainer,
            onControlCreate: function(control) {

                addSettings(control)

            },

            onControlDestroy: function() {

            }
        }

        var inputGenerator = new InputGenerator(options);

        inputGenerator.createByJsonValue(controls);

        bindEvents(inputGenerator);
    };


    function bindEvents(inputGenerator) {

        $generateButton.on("click", function() {

            var value = $textInput.val();
            inputGenerator.createByJsonValue(value);

        });

        $clearButton.on("click", function() {

            $textInput.val("");

        });

        $textInput.on("change", function() {

            var value = this.value;

            if (InputHelper.IsJson(value) || value === "") {

                $warningContainer.addClass("d-none");

            } else {

                $warningContainer.removeClass("d-none");
            }
        });


        $clearInputs.on("click", function() {

            var controlsLength = inputGenerator.controls.length;

            for (var i = 0; i < controlsLength; i++) {

                inputGenerator.controls[i].DestroyContainer();
            }

            inputGenerator.controls = [];

        });

        $submitButton.on("click", function() {

            var controlsLength = inputGenerator.controls.length;

            for (var i = 0; i < controlsLength; i++) {

                console.log(inputGenerator.controls[i].GetInputDomElement().val());
            }
        });
    }

    function addSettings(control) {

        var $settingsContainer = $("<div/>", {
            class: "settings-container"
        });

        var $setButton = $("<button/>", {
            class: "btn btn-primary button",
            html: "Set Value",
            id: "setValue-" + control.inputId,
            click: function() {
                setTypeOfControl(control);
            }
        });

        var $getButton = $("<button/>", {
            class: "btn btn-success button",
            html: "Get Value",
            id: "getValue-" + control.inputId,
            click: function() {
                getValue(control);
            }
        });

        var $input = $("<input/>", {
            class: "second-input",
            id: "second-" + control.inputId,

        });

        var $removeButton = $("<button/>", {
            class: "btn btn-danger remove-button",
            html: "Remove",
            click: function() {
                destoryContainer(control);
            }
        });

        $settingsContainer.append($setButton, $getButton, $input, $removeButton);
        control.GetContainerDomElement().append($settingsContainer);

        $("select").selectpicker();
    };

    function setTypeOfControl(control) {

        var inputType = control.jsonOptions.type;

        switch (inputType) {
            case "textbox":
                {
                    setTextboxValue(control);
                }
                break;

            case "dropDownList":
                {
                    setDropdownValue(control);
                }
                break;

            default:
                // code block
        }
    }

    function setTextboxValue(control) {

        var $secondInput = $("#second-" + control.inputId);

        control.SetInputValue($secondInput.val());
    };

    function setDropdownValue(control) {

        var $secondInput = $("#second-" + control.inputId);

        var items = [];

        $.each($secondInput.val().split(","), function(i, e) {
            items.push(e);
        });

        control.SetInputValue(items);

        control.GetInputDomElement().selectpicker("refresh");
    };

    function getValue(control) {

        var $secondInput = $("#second-" + control.inputId);
        $secondInput.val(control.GetInputValue());

    };

    function destoryContainer(control) {

        control.DestroyContainer();
    };

    // function appendOptionTolist() {

    //     $selectList.append(
    //         getOptionForList("Textbox List", 1),
    //         getOptionForList("Textbox and Dropdownlist List", 2)
    //     )
    // };

    // function getOptionForList(textOption, valueOption) {

    //     var $option = $("<option>", {
    //         text: textOption,
    //         value: valueOption,
    //     })

    //     return $option;
    // };


    //bind for selectlist
    // $selectList.on("change", function() {

    //     var value = this.value;

    //     console.log(InputsList.inputs);

    //     if (value === InputsList.Inputs.option.value) {

    //         var items = InputsList.inputs.items;
    //     }

    //     inputGenerator.createByJsonValue(items);

    // });

    return index;

});