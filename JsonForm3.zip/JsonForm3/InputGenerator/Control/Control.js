define(["jquery", "knockout", "InputHelper"], function($, ko, InputHelper) {

    var _index = null;

    function generateInputId() {

        return "input-" + _index;
    }

    function generateContainerInputId() {

        return "input-" + _index + "-container";
    }

    function generateNewId() {
        _index = InputHelper.GenerateNewGuid();
    }

    function Control() {

        generateNewId();

        this.inputId = generateInputId();
        this.containerId = generateContainerInputId();

        this.BuildHtml = function(container, template, options) {
            ko.applyBindingsToNode(container[0], {
                template: {
                    name: template,
                    data: options
                }
            });
            container.find("[data-bind]").removeAttr("data-bind");
        };

        this.GetInputDomElement = function() {

            var $inputId = $("#" + this.inputId);

            return $inputId;
        };

        this.GetContainerDomElement = function() {

            var $containerId = $("#" + this.containerId);

            return $containerId;
        };

        this.SetInputValue = function(value) {

            var $inputId = this.GetInputDomElement();

            $inputId.val(value);
        };

        this.GetInputValue = function() {

            var $inputId = this.GetInputDomElement();

            return $inputId.val();
        };

        this.DestroyContainer = function() {

            this.GetContainerDomElement().remove();
        };
    };

    return Control;

});