define(["InputHelper", "InputFactory", "bootstrap"], function(InputHelper, InputFactory) {

    function InputGenerator(options) {

        this.options = $.extend({}, true, InputGenerator.defaultOptions, options);

        this.$inputsContainer = this.options.$inputsContainer;
        this.onControlCreate = this.options.onControlCreate;
        this.onControlDestroy = this.options.onControlDestroy;

        this.jsonOptions = {};
        this.controls = [];
    };

    InputGenerator.prototype.createByJsonValue = function(value) {

        if (InputHelper.IsJson(value)) {

            this.jsonOptions = JSON.parse(value);

            this.createInput();
        } else {

            this.jsonOptions = value;

            this.createInput();
        }
    };

    InputGenerator.prototype.createInput = function() {

        var self = this;

        if (InputHelper.IsArray(self.jsonOptions)) {

            var inputs = [...self.jsonOptions];

            for (i = 0; i < inputs.length; i++) {

                var $templateContainer = self.createTemplateContainer();

                var jsonObject = {
                    $templateContainer: $templateContainer,
                    jsonOptions: inputs[i]
                };

                InputFactory.LoadFileInput(jsonObject, function(control) {
                    self.controls.push(control);
                    self.onControlCreate(control);
                });
            }
        }
    };

    //wraper
    InputGenerator.prototype.createTemplateContainer = function() {

        var $templateContainer = $("<div/>", {
            class: "template-container"
        });

        this.$inputsContainer.append($templateContainer);

        return $templateContainer;
    };

    InputGenerator.defaultOptions = {

        $inputsContainer: $({}),
        onControlDestroy: null,
        onControlCreate: null,
    };

    return InputGenerator;
});