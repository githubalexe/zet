define(["InputHelper", "InputFactory", "bootstrap"], function(InputHelper, InputFactory) {

    function InputGenerator(options) {

        this.options = $.extend({}, true, InputGenerator.defaultOptions, options);

        this.$inputsContainer = this.options.$inputsContainer;
        this.onControlCreate = this.options.onControlCreate;
        this.onControlDestroy = this.options.onControlDestroy;

        this.jsonOptions = {};
        this.controls = [];
    };

    InputGenerator.prototype.createByJsonValue = function(value) {

        if (InputHelper.IsJson(value)) {

            this.jsonOptions = JSON.parse(value);

            this.createInput();
        } else {

            this.jsonOptions = value;

            this.createInput();
        }
    };

    InputGenerator.prototype.createInput = function() {

        var self = this;

        if (InputHelper.IsArray(self.jsonOptions)) {

            var inputs = [...self.jsonOptions];

            for (i = 0; i < inputs.length; i++) {

                var $wrapperInput = self.createWrapper();

                var jsonObject = {
                    $wrapperInput: $wrapperInput,
                    jsonOptions: inputs[i]
                };

                InputFactory.CreateControl(jsonObject, function(control) {
                    ////aici apelez functie unde pun id pe wrapper
                    self.controls.push(control);
                    self.onControlCreate(control);

                });
            }
        }
    };

    InputGenerator.prototype.setIdWrapper = function(control) {

        //aici setez id-ul
    };

    InputGenerator.prototype.deleteControl = function(control) {

        var self = this;

        self.controls.splice(self.controls.indexOf(control));
    };

    InputGenerator.prototype.createWrapper = function() {

        var $wrapperInput = $("<div/>", {
            class: "wrapper-input"
        });

        this.$inputsContainer.append($wrapperInput);

        return $wrapperInput;
    };

    InputGenerator.defaultOptions = {

        $inputsContainer: $({}),
        onControlDestroy: null,
        onControlCreate: null,
    };

    return InputGenerator;
});