define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function DropDownListInput(options) {

        var self = this;

        this.options = $.extend({}, true, DropDownListInput.defaultOptions, options);

        this.$templateContainer = this.options.$templateContainer;
        this.jsonOptions = this.options.jsonOptions;

        Control.call(this);

        this.BuildHtml(
            self.$templateContainer,
            Templates.DropDownListTemplate,
            dropDownListOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label,
                dropdownList: new DropDownList(self.jsonOptions.inputOptions.items)
            }
        );
    }

    function DropDownList(items) {

        var dropDownListItems = [];

        for (i = 0; i < items.length; i++) {

            dropDownListItems.push(new Item(items[i]));
        }

        return dropDownListItems;
    };

    function Item(option) {
        return {
            text: option.text,
            value: option.value
        };
    };

    DropDownListInput.defaultOptions = {

        $templateContainer: $({}),
        jsonOptions: {}

    };

    return DropDownListInput;
});