define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function TextBoxInput(options) {

        var self = this;

        this.options = $.extend({}, true, options);

        this.$templateContainer = this.options.$templateContainer;
        this.jsonOptions = this.options.jsonOptions;

        Control.call(this);

        this.BuildHtml(
            self.$templateContainer,
            Templates.TextBoxTemplate,
            textboxOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label,
                placeholder: self.jsonOptions.inputOptions.placeholder
            }
        );
    };

    TextBoxInput.options = {

        $templateContainer: $({}),
        jsonOptions: {}

    }

    return TextBoxInput;
});