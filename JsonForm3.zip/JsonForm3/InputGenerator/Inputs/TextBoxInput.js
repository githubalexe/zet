define(["jquery", "Control", "Templates"], function($, Control, Templates) {

    function TextBoxInput(options, callback) {

        var self = this;

        this.options = $.extend({}, true, options);

        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        Control.call(this);

        callback(this);

        this.BuildHtml(
            self.$wrapperInput,
            Templates.TextBoxTemplate,
            textboxOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label,
                placeholder: self.jsonOptions.inputOptions.placeholder
            }
        );
    };

    TextBoxInput.options = {

        $wrapperInput: $({}),
        jsonOptions: {}

    }

    return TextBoxInput;
});