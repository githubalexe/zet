define(["InputsType"], function(InputsType) {

    var InputFactory = {};

    InputFactory.CreateControl = function(options, callback) {

        var inputType = options.jsonOptions.type;

        switch (inputType) {
            case InputsType.TextBox:
                {
                    require(["TextBoxInput"], function(TextBoxInput) {

                        var control = new TextBoxInput(options, callback);
                        callback(control);
                    })
                }
                break;
            case InputsType.DropDownList:
                {
                    require(["DropDownListInput"], function(DropDownListInput) {

                        var control = new DropDownListInput(options, callback);
                        callback(control);
                    })
                }
                break;
            default:
                {
                    console.log("something wrong");
                }
        }
    };

    return InputFactory;
});