requirejs.config({
    paths: {
        jquery: "node_modules/jquery/dist/jquery.min",
        bootstrap: "node_modules/bootstrap/dist/js/bootstrap.bundle.min",
        knockout: "node_modules/knockout/build/output/knockout-latest",
        CodeMirror: "node_modules/codeMirror/lib/codemirror",
        Control: "InputGenerator/Control/Control",
        InputGenerator: "InputGenerator/Main/InputGenerator",
        Templates: "InputGenerator/Dictionary/Templates",
        InputsType: "InputGenerator/Dictionary/InputsType",
        InputHelper: "InputGenerator/Helpers/InputHelper",
        TextBoxInput: "InputGenerator/Inputs/TextBoxInput",
        DropDownListInput: "InputGenerator/Inputs/DropDownListInput",
        InputFactory: "InputGenerator/Factory/InputFactory",
        InputsList: "InputsList",
    }

});