define([], function() {

    var InputsList = {};

    InputsList.Inputs = [

        option = {
            value: 1,
            items: [{
                    type: "textbox",
                    inputOptions: {
                        label: "Age",
                        placeholder: "Write your age",
                        type: "integer"
                    }
                },
                {
                    type: "textbox",
                    inputOptions: {
                        label: "First Name",
                        placeholder: "Write your firstName",
                        type: "integer"
                    }
                },
                {
                    type: "textbox",
                    inputOptions: {
                        label: "Last Name",
                        placeholder: "Write your Last Name",
                        type: "integer"
                    }
                },
                {
                    type: "textbox",
                    inputOptions: {
                        label: "A Name",
                        placeholder: "Any Name",
                        type: "integer"
                    }
                }
            ]
        },
        option = {
            value: 2,
            items: [{
                    type: "textbox",
                    inputOptions: {
                        label: "Last Name",
                        placeholder: "Write your Last Name",
                        type: "integer"
                    }
                },
                {
                    type: "textbox",
                    inputOptions: {
                        label: "A Name",
                        placeholder: "Any Name",
                        type: "integer"
                    }
                }
            ]
        },
    ];


    // InputsList.Textbox = {
    //     value: 1,
    //     items: [{
    //             type: "textbox",
    //             inputOptions: {
    //                 label: "Age",
    //                 placeholder: "Write your age",
    //                 type: "integer"
    //             }
    //         },
    //         {
    //             type: "textbox",
    //             inputOptions: {
    //                 label: "First Name",
    //                 placeholder: "Write your firstName",
    //                 type: "integer"
    //             }
    //         },
    //         {
    //             type: "textbox",
    //             inputOptions: {
    //                 label: "Last Name",
    //                 placeholder: "Write your Last Name",
    //                 type: "integer"
    //             }
    //         },
    //         {
    //             type: "textbox",
    //             inputOptions: {
    //                 label: "A Name",
    //                 placeholder: "Any Name",
    //                 type: "integer"
    //             }
    //         }
    //     ]
    // };

    // InputsList.TextboxAndDropdownList = `[{
    //         "type": "textbox",
    //         "inputOptions": {
    //             "label": "Age",
    //             "placeholder": "Write your age",
    //             "type": "integer"
    //         }
    //     },
    //     {
    //         "type": "dropDownList",
    //         "inputOptions": {
    //             "label": "Cars",
    //             "items": [{
    //                     "text": "Volvo",
    //                     "value": "1"
    //                 },
    //                 {
    //                     "text": "Dacia",
    //                     "value": "2"
    //                 },
    //                 {
    //                     "text": "Toyota",
    //                     "value": "3"
    //                 }
    //             ]
    //         }
    //     },
    //     {
    //         "type": "textbox",
    //         "inputOptions": {
    //             "label": "First Name",
    //             "placeholder": "Write your firstName",
    //             "type": "integer"
    //         }
    //     },
    //     {
    //         "type": "dropDownList",
    //         "inputOptions": {
    //             "label": "Colors",
    //             "items": [{
    //                     "text": "Black",
    //                     "value": "1"
    //                 },
    //                 {
    //                     "text": "Red",
    //                     "value": "2"
    //                 },
    //                 {
    //                     "text": "Green",
    //                     "value": "3"
    //                 }
    //             ]
    //         }
    //     }
    // ]`

    return InputsList;

});