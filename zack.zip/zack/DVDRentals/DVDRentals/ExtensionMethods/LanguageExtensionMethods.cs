﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Language;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class LanguageExtensionMethods
    {
        public static LanguageResponse ToLanguageResponse(this Language language)
        {
            LanguageResponse languageResponse = new LanguageResponse()
            {
                LanguageId = language.LanguageId,
                Name = language.Name,
                LastUpdate = language.LastUpdate
            };

            return languageResponse;
        }
        public static List<LanguageResponse> ToLanguageResponseList(this IEnumerable<Language> languageList)
        {
            List<LanguageResponse> languageResponseList = new List<LanguageResponse>();

            foreach (Language language in languageList)
            {
                languageResponseList.Add(language.ToLanguageResponse());
            }

            return languageResponseList;
        }

        public static Language ToLanguageModel(this LanguageCreateRequest request)
        {
            Language language = new Language()
            {
                Name = request.Name
            };

            return language;
        }
    }
}
