﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public interface IFilmCategoryService
    {
        Task DeleteFilmCategoryAsync(int categoryId);
    }
}
