﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.Domain;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;
using DVDRentals.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;
using DVDRentals.Services;
using DVDRentals.API.Request.DeleteRequest;
using System;
using System.Linq;
using DVDRentals.API.Response.Messages;

namespace DVDRentals.Controllers
{
    public class CategoriesController : Controller
    {
        private ICategoryRepository _categoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmCategoryService _filmCategoryService;
        public CategoriesController(ICategoryRepository categoryRepository, IFilmCategoryRepository filmCategoryRepository, IFilmCategoryService filmCategoryService)
        {
            _categoryRepository = categoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _filmCategoryService = filmCategoryService;
        }
        [HttpGet("categories")]
        public async Task<IActionResult> GetCategoriesAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IEnumerable<Category> categoryList = await _categoryRepository.GetCategoriesAsync();

            if (categoryList == null)
            {
                errorMessage.Message = CategoryMessages.InvalidCategoryList.GetDescription();

                return BadRequest(errorMessage);
            }

            List<CategoryResponse> categoryResponseList = categoryList.ToCategoryResponseList();

            return Ok(categoryResponseList);
        }

        [HttpGet("categories/{categoryId}/films")]
        public async Task<IActionResult> GetFilmsCategoryAsync(int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmsCategoryAsync(categoryId);
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (filmCategoryList.Count() == 0)
            {
                errorMessage.Message = CategoryMessages.InvalidFilmCategoryList.GetDescription();

                return BadRequest(errorMessage);
            }

            List<FilmResponse> filmResponseList = new List<FilmResponse>();

            foreach (FilmCategory filmCategory in filmCategoryList)
            {
                filmResponseList.Add(filmCategory.Film.ToFilmResponse());
            }

            return Ok(filmResponseList);
        }

        [HttpGet("categories/{categoryId}", Name = "GetCategoryAsync")]
        public async Task<IActionResult> GetCategoryAsync(int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            CategoryResponse categoryResponse = category.ToCategoryResponse();

            return Ok(categoryResponse);
        }

        [HttpPost("categories")]
        public IActionResult CreateCategoryAsync([FromBody] CategoryCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = CategoryMessages.InvalidCategoryRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            Category category = request.ToCategoryModel();
            _categoryRepository.AddCategory(category);
            _categoryRepository.SaveChanges();
            CategoryResponse categoryResponse = category.ToCategoryResponse();

            return CreatedAtRoute("GetCategoryAsync", new { categoryId = category.CategoryId }, categoryResponse);
        }

        [HttpDelete("categories/{categoryId}")]
        public async Task<IActionResult> DeleteCategoryAsync(int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            await _filmCategoryService.DeleteFilmCategoryAsync(categoryId);
            _categoryRepository.DeleteCategory(category);
            _categoryRepository.SaveChanges();

            return Ok();
        }

        [HttpDelete("categories")]
        public async Task<IActionResult> DeleteCategoriesAsync([FromBody] CategoryDeleteRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = CategoryMessages.InvalidCategoryRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (string categoryId in request.CategoryIds)
            {
                int id = Int32.Parse(categoryId);
                Category category = await _categoryRepository.GetCategoryAsync(id);

                if (category == null)
                {
                    errorList.Add("The actor with id " + categoryId + " doesn't exist!");
                }
                else
                {
                    await _filmCategoryService.DeleteFilmCategoryAsync(id);
                    _categoryRepository.DeleteCategory(category);
                }
            }

            if (errorList.Count != 0)
            {
                return BadRequest(errorList);
            }

            _categoryRepository.SaveChanges();

            return Ok();
        }
    }
}