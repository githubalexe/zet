﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Response.City;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class CitiesController : Controller
    {
        private ICityRepository _cityRepository;
        public CitiesController(ICityRepository cityRepository)
        {
            _cityRepository = cityRepository;
        }

        [HttpGet("cities")]
        public async Task<IActionResult> GetCities()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IEnumerable<City> cityList = await _cityRepository.GetCitiesAsync();
            List<CityResponseLite> cityResponseList = new List<CityResponseLite>();

            if (cityList.Count() == 0)
            {
                errorMessage.Message = CityMessages.InvalidCityList.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (City city in cityList)
            {
                CityResponseLite cityResponse = new CityResponseLite();
                cityResponse = city.ToCityResponseLite();
                cityResponse.Country = city.Country.ToCountryResponse();

                cityResponseList.Add(cityResponse);
            }

            return Ok(cityResponseList);
        }
    }
}