﻿using System.Threading.Tasks;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StoresController : Controller
    {
        private IStoreRepository _storeRepository;
        private IStaffRepository _staffRepository;
        private IAddressRepository _addressRepository;

        public StoresController(IStoreRepository storeRepository, IStaffRepository staffRepository, IAddressRepository addressRepository)
        {
            _storeRepository = storeRepository;
            _staffRepository = staffRepository;
            _addressRepository = addressRepository;
        }

        [HttpGet("stores/{storeId}")]
        public async Task<IActionResult> GetStoreAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            StoreResponseLite storeResponse = store.ToStoreResponseLite();

            return Ok(storeResponse);
        }

        [HttpPut("stores/{storeId}")]
        public async Task<IActionResult> UpdateStoreAsync([FromBody] StoreUpdateRequest request, int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = StoreMessages.InvalidStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            Staff staff = await _staffRepository.GetStaffAync(storeId, request.ManagerStaffId);

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            Address address = await _addressRepository.GetAddressAsync(request.AddressId);

            if (address == null)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            store = request.ToStoreModel(store);
            _storeRepository.UpdateStore(store);
            _storeRepository.SaveChanges();
            StoreResponse storeResponse = store.ToStoreResponse();

            return Ok(storeResponse);
        }
    }
}