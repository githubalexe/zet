﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class FilmsController : Controller
    {
        private IFilmRepository _filmRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private ICategoryRepository _categoryRepository;
        private IActorRepository _actorRepository;
        private IFilmActorRepository _filmActorRepository;
        private IFilmCategoryDeleteServices _filmCategoryService;
        private IInventoryRepository _inventoryRepository;

        public FilmsController(IFilmRepository filmRepository, IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository, IActorRepository actorRepository, ICategoryRepository categoryRepository, IFilmCategoryDeleteServices filmCategoryService, IInventoryRepository inventoryRepository)
        {
            _filmRepository = filmRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _actorRepository = actorRepository;
            _filmActorRepository = filmActorRepository;
            _categoryRepository = categoryRepository;
            _filmCategoryService = filmCategoryService;
            _inventoryRepository = inventoryRepository;
        }
        [HttpGet("films")]
        public async Task<IActionResult> GetFilmsAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IEnumerable<Film> filmList = await _filmRepository.GetFilmsAsync();
            List<FilmResponseLite> filmResponseList = new List<FilmResponseLite>();

            if (filmList.Count() == 0)
            {
                errorMessage.Message = FilmMessages.InvalidFilmList.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (Film film in filmList)
            {
                IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmCategoriesAsync(film.FilmId);

                if (filmCategoryList == null)
                {
                    filmResponseList.Add(film.ToFilmResponseLite());
                }
                else
                {
                    List<CategoryResponse> categoryList = new List<CategoryResponse>();
                    foreach (FilmCategory filmCategory in filmCategoryList)
                    {
                        categoryList.Add(filmCategory.Category.ToCategoryResponse());
                    }

                    filmResponseList.Add(film.ToFilmResponseLite(categoryList));
                }
            }

            return Ok(filmResponseList);
        }

        [HttpGet("films/{filmId}", Name = "GetFilmAsync")]
        public async Task<IActionResult> GetFilmAsync(int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmCategoriesAsync(filmId);

            if (filmCategoryList == null)
            {
                FilmResponseLite filmResponse = film.ToFilmResponseLite();

                return Ok(filmResponse);
            }
            else
            {
                List<CategoryResponse> categoryList = new List<CategoryResponse>();
                foreach (FilmCategory filmCategory in filmCategoryList)
                {
                    categoryList.Add(filmCategory.Category.ToCategoryResponse());
                }
                FilmResponseLite filmResponse = film.ToFilmResponseLite(categoryList);

                return Ok(filmResponse);
            }
        }

        [HttpPost("films")]
        public IActionResult CreateFilmAsync([FromBody]FilmCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidFilmRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            Film film = request.ToFilmModel();
            _filmRepository.AddFilm(film);
            _filmRepository.SaveChanges();
            FilmResponse filmResponse = film.ToFilmResponse();

            return CreatedAtRoute("GetFilmAsync", new { filmId = film.FilmId }, filmResponse);
        }

        [HttpGet("films/{filmId}/actors")]
        public async Task<IActionResult> GetFilmActorsAsync(int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetFilmsAsync(filmId);

            if (filmActorList.Count() == 0)
            {
                errorMessage.Message = ActorMessages.InvalidActorList.GetDescription();

                return BadRequest(errorMessage);
            }

            List<ActorResponse> actorList = filmActorList.ToActorResponseList();
            FilmActorsResponseLite filmResponse = film.ToActorsResponse(actorList);

            return Ok(filmResponse);

        }

        [HttpGet("films/{filmId}/actors/{actorId}", Name = "GetFilmActorAsync")]
        public async Task<IActionResult> GetFilmActorAsync(int filmId, int actorId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);
            FilmActor filmActor = await _filmActorRepository.GetFilmActorAsync(filmId, actorId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (filmActor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            ActorResponse actorResponse = filmActor.Actor.ToActorResponse();
            FilmActorResponseLite filmResponse = film.ToActorResponseLite(actorResponse);

            return Ok(filmResponse);

        }

        [HttpGet("films/{filmId}/category/{categoryId}", Name = "GetFilmCategoryAsync")]
        public async Task<IActionResult> GetFilmCategoryAsync(int filmId, int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(filmId, categoryId);
            FilmCategoryResponse filmCategoryResponse = filmCategory.ToFilmCategoryResponse();

            return Ok(filmCategoryResponse);
        }

        [HttpPost("filmCategories")]
        public async Task<IActionResult> AddFilmCategoryAsync([FromBody] FilmCategoryCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            Film film = await _filmRepository.GetFilmAsync(request.FilmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            Category category = await _categoryRepository.GetCategoryAsync(request.CategoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            FilmCategory filmCategoryValidation = await _filmCategoryRepository.GetFilmCategoryAsync(request.FilmId, request.CategoryId);

            if (filmCategoryValidation != null)
            {
                errorMessage.Message = CategoryMessages.AddCategoryFailed.GetDescription();

                return BadRequest(errorMessage);
            }

            FilmCategory filmCategory = request.ToFilmCategoryModel();
            _filmCategoryRepository.AddFilmCategory(filmCategory);
            _filmCategoryRepository.SaveChanges();
            FilmCategoryResponse filmCategoryResponse = filmCategory.ToFilmCategoryResponse();

            return CreatedAtRoute("GetFilmCategoryAsync", new { filmId = film.FilmId, categoryId = category.CategoryId }, filmCategoryResponse);
        }

        [HttpPost("filmActors")]
        public async Task<IActionResult> AddFilmActorAsync([FromBody] FilmActorCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            Film film = await _filmRepository.GetFilmAsync(request.FilmId);
            Actor actor = await _actorRepository.GetActorAsync(request.ActorId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            FilmActor filmActorValidation = await _filmActorRepository.GetFilmActorAsync(request.FilmId, request.ActorId);

            if (filmActorValidation != null)
            {
                errorMessage.Message = ActorMessages.AddActorFailed.GetDescription();

                return BadRequest(errorMessage);
            }

            FilmActor filmActor = request.ToFilmActorModel();
            _filmActorRepository.AddFilmActor(filmActor);
            _filmActorRepository.SaveChanges();
            FilmActorResponse filmActorResponse = filmActor.ToFilmActorResponse();

            return CreatedAtRoute("GetFilmActorAsync", new { filmId = film.FilmId, actorId = actor.ActorId }, filmActorResponse);
        }

        [HttpDelete("films/{filmId}/filmActors/{actorId}")]
        public async Task<IActionResult> DeleteFilmActorAsync(int filmId, int actorId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            FilmActor filmActor = await _filmActorRepository.GetFilmActorAsync(filmId, actorId);

            if (filmActor == null)
            {
                errorMessage.Message = ActorMessages.DeleteActorFailed.GetDescription();

                return BadRequest(errorMessage);
            }

            _filmActorRepository.DeleteFilmActor(filmActor);
            _filmActorRepository.SaveChanges();

            return Ok();
        }

        [HttpPut("films/{filmId}")]
        public async Task<IActionResult> UpdateFilmAsync([FromBody]FilmUpdateRequest request, [FromRoute]int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidFilmRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            film = request.ToFilmModel(film);
            _filmRepository.UpdateFilm(film);
            _filmRepository.SaveChanges();
            FilmResponse filmResponse = film.ToFilmResponse();

            return Ok(filmResponse);
        }

        [HttpDelete("films/{filmId}")]
        public async Task<IActionResult> DeleteFilmAsync(int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            int id = film.FilmId;
            await _filmCategoryService.DeleteFilmActorAsync(id);
            await _filmCategoryService.DeleteFilmCategoryAsync(id);
            await _filmCategoryService.DeleteFilmInventoryAsync(id);

            _filmRepository.DeleteFilm(film);
            _filmRepository.SaveChanges();


            return Ok();
        }
    }
}