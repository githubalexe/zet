﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CityRepository : ICityRepository
    {
        private UnitOfWork _context;
        public CityRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<IEnumerable<City>> GetCitiesAsync()
        {
            return await _context.City.Include(c => c.Country)
                                      .ToListAsync();
        }

        public async Task<City> GetCityAsync(int cityId)
        {
            return await _context.City.Include(c => c.Address)
                                      .FirstOrDefaultAsync(c => c.CityId == cityId);
        }

        public async Task<bool> GetCityValidAsync(int cityId)
        {
            return await _context.City.AnyAsync(c => c.CityId == cityId);
        }
    }
}
