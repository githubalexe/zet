﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class StoreRepository : IStoreRepository
    {
        private UnitOfWork _context;
        public StoreRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<Store> GetStoreAsync(int storeId)
        {
            return await _context.Store.Include(a => a.Address)
                                       .ThenInclude(c => c.City)
                                       .ThenInclude(c => c.Country)
                                       .FirstOrDefaultAsync(s => s.StoreId == storeId);
        }

        public async Task<bool> HasStoreAddressAsync(int addressId)
        {
            return await _context.Store.AnyAsync(s => s.AddressId == addressId);
        }
        public async Task<Store> GetManagerAsync(int customerId)
        {
            return await _context.Store.FirstOrDefaultAsync(m => m.ManagerStaffId == customerId);
        }

        public void UpdateStore(Store store)
        {
            _context.Update(store);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
