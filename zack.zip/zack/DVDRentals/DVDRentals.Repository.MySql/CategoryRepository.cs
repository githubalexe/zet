﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CategoryRepository : ICategoryRepository
    {
        private UnitOfWork _context;
        public CategoryRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<Category> GetCategoryAsync(int categoryId)
        {
            return await _context.Category.FirstOrDefaultAsync(c => c.CategoryId == categoryId);
        }
        public async Task<IEnumerable<Category>> GetCategoriesAsync()
        {
            return await _context.Category.ToListAsync();
        }
        public void AddCategory(Category category)
        {
            _context.Category.Add(category);
        }

        public void DeleteCategory(Category category)
        {
            _context.Category.Remove(category);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
