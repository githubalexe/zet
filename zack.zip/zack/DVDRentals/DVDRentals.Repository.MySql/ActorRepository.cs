﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class ActorRepository : IActorRepository
    {
        private UnitOfWork _unitOfWork;

        public ActorRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Actor> GetActorAsync(int actorId)
        {
            return await _unitOfWork.Actor.FirstOrDefaultAsync(a => a.ActorId == actorId);
        }

        public async Task<IEnumerable<Actor>> ListActorsAsync(IQueryable<Actor> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.AsNoTracking().ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public IQueryable<Actor> ActorsQuery()
        {
            IQueryable<Actor> actorQuery = _unitOfWork.Actor;

            return actorQuery;
        }

        public async Task CreateActorAsync(Actor actor)
        {
             await _unitOfWork.AddAsync(actor);
        }

        public void DeleteActor(Actor actor)
        {
            _unitOfWork.Remove(actor);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
