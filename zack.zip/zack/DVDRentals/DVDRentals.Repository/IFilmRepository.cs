﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmRepository
    {
        IQueryable<Film> FilmsQuery();
        Task<IEnumerable<Film>> ListFilmsAsync(IQueryable<Film> query, bool asNoTracking = false);
        Task<Film> GetFilmAsync(int filmId);
        Task<bool> FilmExistsAsync(int languageId);
        Task CreateFilm(Film film);
        void DeleteFilm(Film film);
        IQueryable<FilmActor> FilmsActorQuery();
        Task<IEnumerable<FilmActor>> ListActorAsync(IQueryable<FilmActor> query, int filmId, bool asNoTracking = false);
        Task CreateFilmActor(FilmActor filmActor);
        void DeleteFilmActor(FilmActor filmActor);
        Task<FilmCategory> GetCategoryAsync(int filmId);
        Task<IEnumerable<FilmCategory>> ListCategoriesAsync(IQueryable<FilmCategory> query, int filmId, bool asNoTracking = false);
        Task CreateCategoryActor(FilmActor filmActor);
        void DeleteCategoryActor(FilmActor filmActor);
        Task SaveChangesAsync();
    }
}
