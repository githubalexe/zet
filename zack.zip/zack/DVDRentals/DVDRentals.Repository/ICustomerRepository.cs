﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICustomerRepository
    {
        Task<IEnumerable<Customer>> GetCustomersAsync(int storeId);
        Task<Customer> GetCustomerAsync(int storeId, int customerId);
        Task<bool> ExistCustomerAsync(int customerId);
        Task<bool> HasCustomerAddressAsync(int addressId);
        void AddCustomer(Customer customer);
        void UpdateCustomer(Customer customer);
        void DeleteCustomer(Customer customer);
        void SaveChanges();
    }
}
