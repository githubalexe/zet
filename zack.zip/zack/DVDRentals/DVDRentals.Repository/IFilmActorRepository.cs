﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmActorRepository
    {
        Task<FilmActor> GetFilmActorAsync(int filmId, int actorId);
        Task<IEnumerable<FilmActor>> GetActorsAsync(int actorId);
       // Task<IEnumerable<FilmActor>> GetFilmsAsync(int filmId);
       // void AddFilmActor(FilmActor filmActor);
      //  void UpdateFilmActor(FilmActor filmActor);
       // void DeleteFilmActor(FilmActor filmActor);
      //  void SaveChanges();
    }
}
