﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Staff
{
    public class StaffNameResponse
    {
        public int StaffId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
