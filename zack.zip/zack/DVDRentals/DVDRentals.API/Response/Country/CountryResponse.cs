﻿using System;

namespace DVDRentals.API.Response.Country
{
    public class CountryResponse
    {
        public int CountryId { get; set; }
        public string Country1 { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
