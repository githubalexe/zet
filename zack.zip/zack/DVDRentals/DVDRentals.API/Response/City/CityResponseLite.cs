﻿using DVDRentals.API.Response.Country;
using System;

namespace DVDRentals.API.Response.City
{
    public class CityResponseLite
    {
        public int CityId { get; set; }
        public string City1 { get; set; }
        public int CountryId { get; set; }
        public DateTime LastUpdate { get; set; }
        public virtual CountryResponse Country { get; set; }
    }
}
