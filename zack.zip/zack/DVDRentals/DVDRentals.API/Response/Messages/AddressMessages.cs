﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum AddressMessages
    {
        [Description("The address doesn't exist!")]
        NoAddressResponse,
        [Description("The address request is NULL!")]
        InvalidAddressRequest,
        [Description("Cannot delete this address because someone has it!")]
        DeleteAddressFalid,
    }
}
