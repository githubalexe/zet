﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum FilmMessages
    {
        [Description("The film doesn't exist!")]
        NoFilmResponse,
        [Description("The film list is empty!")]
        InvalidFilmList,
        [Description("The film request is NULL!")]
        InvalidFilmRequest,
        [Description("The request is NULL!")]
        InvalidRequest,
    }
}
