import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSliderModule } from '@angular/material/slider';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';

import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';


import { NgModule } from '@angular/core';

@NgModule({
    imports: [MatButtonModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatIconModule,
        MatToolbarModule,
        MatSliderModule,
        MatMenuModule,
        MatInputModule,
        MatSelectModule],
    exports: [MatButtonModule,
        MatCheckboxModule,
        MatFormFieldModule,
        MatIconModule,
        MatToolbarModule,
        MatSliderModule,
        MatMenuModule,
        MatInputModule,
        MatSelectModule],
})
export class MaterialModule { }