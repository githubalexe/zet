﻿using DVDRentals.API.Response.Actor;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Film
{
    public class FilmActorResponseLite
    {
        public int FilmId { get; set; }
        public string Title { get; set; }
        public virtual ActorResponse Actor { get; set; }
    }
}
