﻿using DVDRentals.API.Response.Film;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Rental
{
    public class RentalResponse
    {
        public RentalResponse()
        {

        }
        public int RentalId { get; set; }
        public DateTime RentalDate { get; set; }
        public int InventoryId { get; set; }
        public int CustomerId { get; set; }
        public DateTime? ReturnDate { get; set; }
        public int StaffId { get; set; }
        public DateTime LastUpdate { get; set; }
        public virtual FilmTitleResponse Film { get; set; }
    }
}
