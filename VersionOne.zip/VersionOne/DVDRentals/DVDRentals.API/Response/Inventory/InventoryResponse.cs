﻿using DVDRentals.API.Response.Film;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Inventory
{
    public class InventoryResponse
    {
        public int InventoryId { get; set; }
        public int FilmId { get; set; }
        public int StoreId { get; set; }
        public virtual FilmTitleResponse Film { get; set; }
    }
}
