﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace DVDRentals.API.ApiMethods
{
    public class CustomerApiMethods
    {
        //public static GetCustomers()
        //{
        //    //string data;
        //    //string url = "https://localhost:44361/countries";
        //    //using (HttpClient client = new HttpClient())
        //    //{
        //    //    client.DefaultRequestHeaders.Add(schemename, header);
        //    //    data = client.GetAsync(url).Result.Content.ReadAsStringAsync().Result;
                
        //    //}

        //    //return data;
        //}
    }
}
