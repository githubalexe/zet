﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace DVDRentals.API
//{
//    public static class WebApiUrl
//    {
//        public static string Url { get; set; }
//    }
//}
