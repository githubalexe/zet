﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.Domain;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;
using DVDRentals.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;
using DVDRentals.Services;
using DVDRentals.API.Request.DeleteRequest;
using System;
using DVDRentals.Models;
using System.Linq;

namespace DVDRentals.Controllers
{
    public class CategoriesController : Controller
    {
        private ICategoryRepository _categoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmCategoryService _filmCategoryService;
        public CategoriesController(ICategoryRepository categoryRepository, IFilmCategoryRepository filmCategoryRepository, IFilmCategoryService filmCategoryService)
        {
            _categoryRepository = categoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _filmCategoryService = filmCategoryService;
        }
        [HttpGet("categories")]
        public async Task<IActionResult> GetCategoriesAsync()
        {
            ErrorValidation errorValidation = new ErrorValidation();
            IEnumerable<Category> categoryList = await _categoryRepository.GetCategoriesAsync();

            if (categoryList == null)
            {
                errorValidation.Message = Messages.InvalidCategoryList.GetDescription();

                return BadRequest(errorValidation);
            }

            List<CategoryResponse> categoryResponseList = categoryList.ToCategoryResponseList();

            return Ok(categoryResponseList);
        }

        [HttpGet("categories/{categoryId}/films")]
        public async Task<IActionResult> GetFilmsCategoryAsync(int categoryId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmsCategoryAsync(categoryId);

            if (filmCategoryList.Count() == 0)
            {
                errorValidation.Message = Messages.InvalidFilmCategoryList.GetDescription();

                return BadRequest(errorValidation);
            }

            List<FilmResponse> filmResponseList = new List<FilmResponse>();

            foreach (FilmCategory filmCategory in filmCategoryList)
            {
                filmResponseList.Add(filmCategory.Film.ToFilmResponse());
            }

            return Ok(filmResponseList);
        }

        [HttpGet("categories/{categoryId}", Name = "GetCategoryAsync")]
        public async Task<IActionResult> GetCategoryAsync(int categoryId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorValidation.Message = Messages.InvalidCategory.GetDescription();

                return BadRequest(errorValidation);
            }

            CategoryResponse categoryResponse = category.ToCategoryResponse();

            return Ok(categoryResponse);
        }

        [HttpPost("categories")]
        public IActionResult CreateCategoryAsync([FromBody] CategoryCreateRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            Category category = request.ToCategoryModel();
            _categoryRepository.AddCategory(category);
            _categoryRepository.SaveChanges();
            CategoryResponse categoryResponse = category.ToCategoryResponse();

            return CreatedAtRoute("GetCategoryAsync", new { categoryId = category.CategoryId }, categoryResponse);
        }

        [HttpDelete("categories/{categoryId}")]
        public async Task<IActionResult> DeleteCategoryAsync(int categoryId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category == null)
            {
                errorValidation.Message = Messages.InvalidCategory.GetDescription();

                return BadRequest(errorValidation);
            }

            await _filmCategoryService.DeleteFilmCategoryAsync(categoryId);
            _categoryRepository.DeleteCategory(category);
            _categoryRepository.SaveChanges();

            errorValidation.Message = Messages.DeleteCategory.GetDescription();

            return Ok(errorValidation);
        }

        [HttpDelete("categories")]
        public async Task<IActionResult> DeleteCategoriesAsync([FromBody] CategoryDeleteRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            List<string> errorList = new List<string>();

            foreach (string categoryId in request.CategoryIds)
            {
                int id = Int32.Parse(categoryId);
                Category category = await _categoryRepository.GetCategoryAsync(id);

                if (category == null)
                {
                    errorList.Add("The actor with id " + categoryId + " doesn't exist!");
                }
                else
                {
                    await _filmCategoryService.DeleteFilmCategoryAsync(id);
                    _categoryRepository.DeleteCategory(category);
                }
            }

            if (errorList.Count != 0)
            {
                return BadRequest(errorList);
            }

            _categoryRepository.SaveChanges();
            errorValidation.Message = Messages.DeleteCategories.GetDescription();

            return Ok(errorValidation);
        }
    }
}