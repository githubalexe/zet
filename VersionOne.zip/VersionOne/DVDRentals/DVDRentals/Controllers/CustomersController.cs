﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.DeleteRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Models;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class CustomersController : Controller
    {
        private ICustomerRepository _customerRepository;
        private IPaymentRepository _paymentRepository;
        private IPaymentService _paymentService;
        private IRentalService _rentalService;
        private IStoreRepository _storeRepository;

        public CustomersController(ICustomerRepository customerRepository, IPaymentRepository paymentRepository, IPaymentService paymentService, IRentalService rentalService, IStoreRepository storeRepository)
        {
            _customerRepository = customerRepository;
            _paymentRepository = paymentRepository;
            _paymentService = paymentService;
            _rentalService = rentalService;
            _storeRepository = storeRepository;
        }

        [HttpGet("stores/{storeId}/customers")]
        public async Task<IActionResult> GetCustomersAsync(int storeId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            IEnumerable<Customer> customerList = await _customerRepository.GetCustomersAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customerList.Count() == 0)
            {
                errorValidation.Message = Messages.InvalidCustomerList.GetDescription();

                return BadRequest(errorValidation);
            }

            List<CustomerResponseLite> customerResponseList = customerList.ToCustomerResponseList();

            return Ok(customerResponseList);
        }

        [HttpGet("stores/{storeId}/customers/{customerId}", Name = "GetCustomerAsync")]
        public async Task<IActionResult> GetCustomerAsync(int storeId, int customerId)
        {
            //put the address if u want
            ErrorValidation errorValidation = new ErrorValidation();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customer == null)
            {
                errorValidation.Message = Messages.InvalidCustomer.GetDescription();

                return NotFound(errorValidation);
            }

            CustomerResponseLite customerResponse = customer.ToCustomerResponseLite();

            return Ok(customerResponse);

        }

        [HttpGet("stores/{storeId}/customers/{customerId}/payments")]
        public async Task<IActionResult> GetCustomerPaymentsAsync(int storeId, int customerId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            IEnumerable<Payment> paymentList = await _paymentRepository.GetCustomerPaymentsAsync(customerId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customer == null)
            {
                errorValidation.Message = Messages.InvalidCustomer.GetDescription();

                return BadRequest(errorValidation);
            }

            if (paymentList == null)
            {
                errorValidation.Message = Messages.InvalidCustomerPayments.GetDescription();

                return BadRequest(errorValidation);
            }

            List<PaymentForCustomerResponse> paymentResponseList = paymentList.ToCustomerPaymentsResponse();
            CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

            return Ok(customerResponse);

        }

        [HttpGet("stores/{storeId}/customers/{customerId}/payments/{paymentId}")]
        public async Task<IActionResult> GetCustomerPaymentAsync(int storeId, int customerId, int paymentId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Payment payment = await _paymentRepository.GetCustomerPaymentAsync(customerId, paymentId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customer == null)
            {
                errorValidation.Message = Messages.InvalidCustomer.GetDescription();

                return BadRequest(errorValidation);
            }

            if (payment == null)
            {
                errorValidation.Message = Messages.InvalidCustomerPayment.GetDescription();

                return BadRequest(errorValidation);
            }

            PaymentForCustomerResponse paymentResponse = payment.ToCustomerPaymentResponse();
            List<PaymentForCustomerResponse> paymentResponseList = new List<PaymentForCustomerResponse>();
            paymentResponseList.Add(paymentResponse);
            CostomerPaymentsResponse customerResponse = customer.ToCustomerPaymentListResponse(paymentResponseList);

            return Ok(customerResponse);

        }

        [HttpPost("stores/{storeId}/customers")]
        public async Task<IActionResult> CreateCustomerAsync([FromBody] CustomerCreateRequest request, int storeId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            Customer customer = request.ToCustomerModel(storeId);
            _customerRepository.AddCustomer(customer);
            _customerRepository.SaveChanges();
            CustomerResponse customerResponse = customer.ToCustomerResponse();

            return CreatedAtRoute("GetCustomerAsync", new { customerId = customer.CustomerId }, customerResponse);
        }

        [HttpPut("stores/{storeId}/customers/{customerId}")]
        public async Task<IActionResult> UpdateCustomerAsync([FromBody] CustomerUpdateRequest request, int storeId, int customerId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customer == null)
            {
                errorValidation.Message = Messages.InvalidCustomer.GetDescription();

                return BadRequest(errorValidation);
            }

            customer = request.ToCustomerModel(customer, storeId);
            _customerRepository.UpdateCustomer(customer);
            _customerRepository.SaveChanges();
            CustomerResponse customerResponse = customer.ToCustomerResponse();

            return Ok(customerResponse);
        }

        [HttpDelete("stores/{storeId}/customers/{customerId}")]
        public async Task<IActionResult> DeleteCustomerAsync(int storeId, int customerId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Customer customer = await _customerRepository.GetCustomerAsync(storeId, customerId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customer == null)
            {
                errorValidation.Message = Messages.InvalidCustomer.GetDescription();

                return BadRequest(errorValidation);
            }

            await _paymentService.DeleteCustomerPaymentsAsync(customer.CustomerId);
            await _rentalService.DeleteCustomerRentalsAsync(customer.CustomerId);

            _customerRepository.DeleteCustomer(customer);
            _customerRepository.SaveChanges();

            errorValidation.Message = Messages.DeleteCustomer.GetDescription();

            return Ok(errorValidation);
        }

        [HttpDelete("stores/{storeId}/customers")]
        public async Task<IActionResult> DeleteCustomersAsync([FromBody] CustomerDeleteRequest request, int storeId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            List<string> errorList = new List<string>();

            if (store == null)
            {
                errorValidation.Message = Messages.InvalidStore.GetDescription();

                return BadRequest(errorValidation);
            }

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            foreach (string customerId in request.CustomerIds)
            {
                int id = Int32.Parse(customerId);
                Customer customer = await _customerRepository.GetCustomerAsync(storeId, id);

                if (customer == null)
                {
                    errorList.Add("The customer with id " + customerId + " doesn't exist!");
                }
                else
                {
                    await _paymentService.DeleteCustomerPaymentsAsync(customer.CustomerId);
                    await _rentalService.DeleteCustomerRentalsAsync(customer.CustomerId);
                    _customerRepository.DeleteCustomer(customer);
                }
            }

            if (errorList.Count == 0)
            {
                _customerRepository.SaveChanges();
                errorValidation.Message = Messages.DeleteCustomers.GetDescription();

                return Ok(errorValidation);
            }
            else
            {
                return BadRequest(errorList);
            }
        }
    }
}