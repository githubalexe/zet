﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Rental;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Models;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class RentalsController : Controller
    {
        private IRentalRepository _rentalRepository;
        private IInventoryRepository _inventoryRepository;
        private ICustomerRepository _customerRepository;
        private IStaffRepository _staffRepository;
        public RentalsController(IRentalRepository rentalRepository, IInventoryRepository inventoryRepository, ICustomerRepository customerRepository, IStaffRepository staffRepository)
        {
            _rentalRepository = rentalRepository;
            _inventoryRepository = inventoryRepository;
            _customerRepository = customerRepository;
            _staffRepository = staffRepository;
        }

        [HttpGet("rentals/{rentalId}", Name = "GetRentalAsync")]
        public async Task<IActionResult> GetRentalAsync(int rentalId)
        {
            ErrorValidation errorValidation = new ErrorValidation();

            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental == null)
            {
                errorValidation.Message = Messages.InvalidRental.GetDescription();

                return BadRequest(errorValidation);
            }

            RentalResponse rentalResponse = rental.ToRentalResponse();

            return Ok(rentalResponse);
        }

        [HttpPost("rentals")]
        public async Task<IActionResult> CreateRentalAsync([FromBody] RentalCreateRequest request)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            bool customer = await _customerRepository.GetCustomerAsync(request.CustomerId);
            bool staff = await _staffRepository.GetStaffAync(request.StaffId);
            bool inventory = await _inventoryRepository.GetInventoryValidationAsync(request.InventoryId);

            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorValidation.Message = Messages.InvalidRequest.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customer == false)
            {
                errorList.Add("The " + request.CustomerId + " property is null!");
            }
            if (inventory == false)
            {
                errorList.Add("The " + request.InventoryId + " property is null!");
            }

            if (staff == false)
            {
                errorList.Add("The " + request.StaffId + " property is null!");
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            Rental rental = request.ToRentalModel();
            _rentalRepository.AddRental(rental);
            _rentalRepository.SaveChanges();
            RentalResponse rentalResponse = rental.ToRentalResponse();

            return CreatedAtRoute("GetRentalAsync", new { rentalId = rental.RentalId }, rentalResponse);
        }

        [HttpPut("rentals/{rentalId}")]
        public async Task<IActionResult> UpdateRentalAsync([FromBody]RentalUpdateRequest request, int rentalId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);
            bool customer = await _customerRepository.GetCustomerAsync(request.CustomerId);
            bool inventory = await _inventoryRepository.GetInventoryValidationAsync(request.InventoryId);
            bool staff = await _staffRepository.GetStaffAync(request.StaffId);

            List<string> errorList = new List<string>();

            if (rental == null)
            {
                errorValidation.Message = Messages.InvalidRental.GetDescription();

                return BadRequest(errorValidation);
            }

            if (customer == false)
            {
                errorList.Add("The " + request.CustomerId + " property is null!");
            }
            if (inventory == false)
            {
                errorList.Add("The " + request.InventoryId + " property is null!");
            }

            if (staff == false)
            {
                errorList.Add("The " + request.StaffId + " property is null!");
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            rental = request.ModifyRental(rental);
            _rentalRepository.UpdateRental(rental);
            _rentalRepository.SaveChanges();
            RentalResponse rentalResponse = rental.ToRentalResponse();

            return Ok(rentalResponse);
        }

        [HttpDelete("rentals/{rentalId}")]
        public async Task<IActionResult> DeleteRentalAsync(int rentalId)
        {
            ErrorValidation errorValidation = new ErrorValidation();
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental == null)
            {
                errorValidation.Message = Messages.InvalidRental.GetDescription();

                return BadRequest(errorValidation);
            }

            _rentalRepository.DeleteRental(rental);
            _rentalRepository.SaveChanges();

            errorValidation.Message = Messages.DeleteRental.GetDescription();

            return Ok(errorValidation);
        }
    }
}