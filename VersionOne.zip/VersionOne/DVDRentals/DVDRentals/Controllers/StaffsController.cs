﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffRepository _staffRepository;
        private IStoreRepository _storeRepository;
        private IPaymentRepository _paymentRepository;
        private IPaymentService _paymentService;
        private IRentalService _rentalService;
        private IAddressRepository _addressRepository;

        public StaffsController(IStaffRepository staffRepository, 
                                IPaymentRepository paymentRepository, 
                                IPaymentService paymentService, 
                                IRentalService rentalService, 
                                IStoreRepository storeRepository, 
                                IAddressRepository addressRepository)
        {
            _staffRepository = staffRepository;
            _paymentRepository = paymentRepository;
            _paymentService = paymentService;
            _storeRepository = storeRepository;
            _rentalService = rentalService;
            _addressRepository = addressRepository;
        }

        [HttpGet("stores/{storeId}/Staffs")]
        public async Task<IActionResult> GetStaffsAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<Staff> staffsQuery = _staffRepository.StaffsQuery();

            staffsQuery = staffsQuery.OrderBy(staff => staff.StaffId);

            IEnumerable<Staff> staffs = await _staffRepository.ListStaffsAsync(staffsQuery, storeId, true);

            if (staffs.Count() == 0)
            {
                errorMessage.Message = StaffMessages.InvalidStaffList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<StaffResponse> response = staffs.Select(staff => staff.ToStaffResponse());

                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}", Name = "GetStaffAsync")]
        public async Task<IActionResult> GetStaffAsync(int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                StaffResponse response = staff.ToStaffResponse();

                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}/payments")]
        public async Task<IActionResult> GetStaffPayments(int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<Payment> paymentsQuery = _paymentRepository.PaymentsQuery();

            paymentsQuery = paymentsQuery.OrderBy(payment => payment.PaymentId);

            IEnumerable<Payment> payments = await _paymentRepository.StaffsPaymentsListAsync(paymentsQuery, staffId, true);

            if (payments.Count() == 0)
            {
                errorMessage.Message = StaffMessages.InvalidStaffPayments.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<StaffPaymentsResponse> response = payments.Select(payment => payment.ToStaffPaymentResponse());

                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}/payments/{paymentId}")]
        public async Task<IActionResult> GetStaffPaymentAsync(int storeId, int staffId, int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Payment payment = await _paymentRepository.GetStaffPaymentAsync(staffId, paymentId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (payment == null)
            {
                errorMessage.Message = StaffMessages.NoStaffPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                List<StaffPaymentsResponse> response = new List<StaffPaymentsResponse>();
                StaffPaymentsResponse paymentResponse = payment.ToStaffPaymentResponse();
                response.Add(paymentResponse);

                return Ok(response);
            }
        }

        [HttpPost("stores/{storeId}/staffs")]
        public async Task<IActionResult> CreateStaffAsync([FromBody] StaffCreateRequest request, int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = StaffMessages.InvalidStaffRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool address = await _addressRepository.AddressExistsAsync(request.AddressId);

            if (address == false)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Staff staff = request.ToStaffModel(storeId);

                await _staffRepository.CreateStaffAsync(staff);
                await _staffRepository.SaveChangesAsync();

                StaffResponseLite response = staff.ToStaffResponseLite();

                return CreatedAtRoute("GetStaffAsync", new { staffId = staff.StaffId }, response);
            }
        }

        [HttpPut("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> UpdateStaffAsync([FromBody] StaffUpdateRequest request, int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);

            if (request == null)
            {
                errorMessage.Message = StaffMessages.InvalidStaffRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isAddress = await _addressRepository.AddressExistsAsync(request.AddressId);

            if (isAddress == false)
            {
                errorMessage.Message = AddressMessages.NoAddressResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                staff = request.ToStaffModel(staff, storeId);

                await _staffRepository.SaveChangesAsync();

                StaffResponseLite response = staff.ToStaffResponseLite();

                return Ok(response);
            }
        }

        [HttpDelete("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> DeleteCustomerAsync(int storeId, int staffId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Staff staff = await _staffRepository.GetStaffAync(storeId, staffId);
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isManager = await _storeRepository.ManagerExistsAsync(storeId, staffId);

            if (isManager == true)
            {
                errorMessage.Message = StaffMessages.DeleteStaffFailed.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                await _paymentService.DeleteStaffPaymentsAsync(staff.StaffId);
                await _rentalService.DeleteStaffRentalsAsync(staffId);

                _staffRepository.DeleteStaff(staff);
                await _staffRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}