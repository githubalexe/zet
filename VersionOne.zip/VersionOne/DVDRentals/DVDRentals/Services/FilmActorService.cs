﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class FilmActorService: IFilmActorService
    {
        private IFilmActorRepository _filmActorRepository;

        public FilmActorService(IFilmActorRepository filmActorRepository)
        {
            _filmActorRepository = filmActorRepository;
        }

        public async Task DeleteFilmActorAsync(int actorId)
        {
            IEnumerable<FilmActor> filmActorList = await _filmActorRepository.GetActorsAsync(actorId);

            if(filmActorList!=null)
            {
                foreach (FilmActor filmActor in filmActorList)
                {
                    _filmActorRepository.DeleteFilmActor(filmActor);
                }
            }
        }
    }
}
