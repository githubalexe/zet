﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public interface IFilmCategoryDeleteServices
    {
        Task DeleteFilmCategoryAsync(int filmId);
        Task DeleteFilmActorAsync(int filmId);
        Task DeleteFilmInventoryAsync(int filmId);
    }
}
