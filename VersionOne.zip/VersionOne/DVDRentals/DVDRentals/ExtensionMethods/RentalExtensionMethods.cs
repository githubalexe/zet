﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Rental;
using DVDRentals.Domain;

namespace DVDRentals.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static RentalResponse ToRentalResponse(this Rental rental)
        {
            if (rental == null)
            {
                return null;
            }
            else
            {
                return new RentalResponse()
                {
                    RentalId = rental.RentalId,
                    RentalDate = rental.RentalDate,
                    InventoryId = rental.InventoryId,
                    CustomerId = rental.CustomerId,
                    ReturnDate = rental.ReturnDate,
                    StaffId = rental.StaffId,
                    LastUpdate = rental.LastUpdate,
                    Film = rental.Inventory.Film.ToFilmTitleResponse()
                };
            }
        }

        public static RentalResponseLite ToRentalResponseLite(this Rental rental)
        {
            return new RentalResponseLite()
            {
                RentalId = rental.RentalId,
                RentalDate = rental.RentalDate,
                InventoryId = rental.InventoryId,
                CustomerId = rental.CustomerId,
                ReturnDate = rental.ReturnDate,
                StaffId = rental.StaffId,
                LastUpdate = rental.LastUpdate,
            };
        }

        public static Rental ToRentalModel(this RentalCreateRequest request)
        {
            return new Rental()
            {
                RentalDate = request.RentalDate,
                InventoryId = request.InventoryId,
                CustomerId = request.CustomerId,
                ReturnDate = request.ReturnDate,
                StaffId = request.StaffId
            };
        }

        public static Rental ModifyRental(this RentalUpdateRequest request, Rental rental)
        {
            rental.RentalDate = request.RentalDate;
            rental.InventoryId = request.InventoryId;
            rental.CustomerId = request.CustomerId;
            rental.ReturnDate = request.ReturnDate;
            rental.StaffId = request.StaffId;

            return rental;
        }
    }
}
