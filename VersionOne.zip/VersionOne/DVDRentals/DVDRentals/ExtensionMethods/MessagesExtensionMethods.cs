﻿using System;
using System.ComponentModel;
using System.Reflection;

namespace DVDRentals.ExtensionMethods
{
    public static class MessagesExtensionMethods
    {
        public static string GetDescription(this Enum message)
        {
            FieldInfo fieldInfo = message.GetType().GetField(message.ToString());
            DescriptionAttribute[] attributes = (DescriptionAttribute[])fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (attributes.Length > 0)
            {
                return attributes[0].Description;
            }
            else
            {
                return message.ToString();
            }
        }
    }
}
