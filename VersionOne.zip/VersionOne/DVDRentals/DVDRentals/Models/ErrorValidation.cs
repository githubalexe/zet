﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Models
{
    public class ErrorValidation
    {
        public string Message { get; set; }
    }
}
