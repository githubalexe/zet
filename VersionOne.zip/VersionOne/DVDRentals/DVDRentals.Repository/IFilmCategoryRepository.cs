﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmCategoryRepository
    {
        Task<FilmCategory> GetFilmCategoryAsync(int filmId);
        Task<IEnumerable<FilmCategory>> GetFilmCategoriesAsync(int filmId);
        Task<IEnumerable<FilmCategory>> GetFilmsCategoryAsync(int categoryId);
        Task<FilmCategory> GetFilmCategoryAsync(int filmId, int categoryId);
        void AddFilmCategory(FilmCategory filmCategory);
        void DeleteFilmCategory(FilmCategory filmCategory);
        void SaveChanges();
    }
}
