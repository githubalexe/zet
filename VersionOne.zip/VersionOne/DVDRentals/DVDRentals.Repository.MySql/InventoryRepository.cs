﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class InventoryRepository : IInventoryRepository
    {
        private UnitOfWork _context;

        public InventoryRepository(UnitOfWork context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Inventory>> GetFilmsAsync(int storeId)
        {
            return await _context.Inventory.Where(i => i.StoreId == storeId)
                                           .Include(f => f.Film)
                                           .ThenInclude(l => l.Language)
                                           .Include(f => f.Film)
                                           .ThenInclude(c => c.FilmCategory)
                                           .ThenInclude(c => c.Category)
                                           .ToListAsync();

        }
        public async Task<Inventory> GetInventoryAsync(int storeId, int inventoryId)
        {
            return await _context.Inventory.FirstOrDefaultAsync(i => i.StoreId == storeId && i.InventoryId == inventoryId);
        }

        public async Task<Inventory> GetInventoryAsync(int inventoryId)
        {
            return await _context.Inventory.FirstOrDefaultAsync(i => i.InventoryId == inventoryId);
        }

        public async Task<bool> GetInventoryValidationAsync(int inventoryId)
        {
            return await _context.Inventory.AnyAsync(i => i.InventoryId == inventoryId);
        }

        public async Task<IEnumerable<Inventory>> GetInventoriesAsync(int storeId, int filmId)
        {
            return await _context.Inventory.Where(i => i.StoreId == storeId && i.FilmId == filmId)
                                           .Include(f => f.Film)
                                           .ThenInclude(l => l.Language)
                                           .Include(f => f.Film)
                                           .ThenInclude(c => c.FilmCategory)
                                           .ThenInclude(c => c.Category)
                                           .ToListAsync();
        }

        public async Task<IEnumerable<Inventory>> GetInventoriesAsync(int filmId)
        {
            return await _context.Inventory.Where(i => i.FilmId == filmId)
                                           .ToListAsync();
        }

        public void AddInventory(Inventory inventory)
        {
            _context.Inventory.Add(inventory);
        }

        public void UpdateInventory(Inventory inventory)
        {
            _context.Inventory.Update(inventory);
        }
        public void DeleteInventory(Inventory inventory)
        {
            _context.Inventory.Remove(inventory);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
