﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreTest
{
    public interface IGreater
    {
        string MessageOfTheDay();
    }
    class Greater : IGreater
    {
        public string MessageOfTheDay()
        {
            return "Hi everybody!!";
        }
    }
}
