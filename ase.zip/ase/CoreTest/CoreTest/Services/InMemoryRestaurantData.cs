﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreTest.Models;

namespace CoreTest.Services
{
    public class InMemoryRestaurantData : IRestaurantData
    {
        public InMemoryRestaurantData()
        {
            restaurants = new List<Restaurant>
                 {
                     new Restaurant{Id=1,Name="zlex"},
                     new Restaurant { Id = 2, Name = "Alex" },
                     new Restaurant { Id = 3, Name = "mlex" }
                };
        }

        public IEnumerable<Restaurant> GetAll()
        {
            return restaurants.OrderBy(p => p.Name);
        }
        List<Restaurant> restaurants;
    }
}
