﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreTest.Models;
using CoreTest.Services;
using CoreTest.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace CoreTest.Controllers
{
    public class HomeController : Controller
    {
        IRestaurantData _restaurants;
        IGreater _message;
        public HomeController(IRestaurantData restaurants,IGreater message)
        {
            _restaurants = restaurants;
            _message = message;
        }

        public IActionResult Index()
        {
            var model = new HomeIndexViewModel();
            model.Restaurants = _restaurants.GetAll();
            model.CurentMessage = _message.MessageOfTheDay();

            return View(model);
        }


    }
}