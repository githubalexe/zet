﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Store;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class RentalController : Controller
    {
        [HttpGet("Rental/RentalDetails/{rentalId}")]
        public async Task<IActionResult> RentalDetails(int rentalId)
        {
            int storeId = 1;
            RentalView model = new RentalView();
            StoreRentalResponse rental = new StoreRentalResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            rental = await RentalApiMethods.GetRental(storeId, rentalId);

            if (rental == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = rental.ToRentalResponseView();

            return View(model);
        }

        public IActionResult CreateRental()
        {
            return View();
        }
        public IActionResult RentalList()
        {
            return View();
        }

        [HttpGet("UpdateRental/{rentalId}")]
        public async Task<IActionResult> UpdateRental(int rentalId)
        {
            int storeId = 1;
            RentalView model = new RentalView();
            StoreRentalResponse rental = new StoreRentalResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            rental = await RentalApiMethods.GetRental(storeId, rentalId);

            if (rental == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = rental.ToRentalResponseView();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> RentalList([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            List<RentalView> list = new List<RentalView>();

            IEnumerable<StoreRentalResponse> apiResult = await RentalApiMethods.GetRentals(storeId);

            foreach (StoreRentalResponse rental in apiResult)
            {
                list.Add(rental.ToRentalResponseView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost("Rental/RentalDetails/{rentalId}")]
        public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request, int rentalId)
        {
            int storeId = 1;

            List<RentalPaymentsView> list = new List<RentalPaymentsView>();
            RentalView model = new RentalView();

            IEnumerable<PaymentResponseLite> apiResult = await RentalApiMethods.GetPayments(storeId, rentalId);

            foreach (PaymentResponseLite payment in apiResult)
            {
                list.Add(payment.ToRentalPaymentsResponse());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRental(RentalView request)
        {
            int storeId = 1;
            StoreRentalResponse rental = new StoreRentalResponse();
            rental = await RentalApiMethods.CreateRental(request.ToModelCreateRental(), storeId);

            return RedirectToAction(nameof(RentalDetails), new { id = rental.RentalId });
        }

        [HttpPost("UpdateRental/{rentailId}")]
        public async Task<IActionResult> UpdateRental(RentalView request, int rentailId)
        {
            int storeId = 1;
            StoreRentalResponse rental = new StoreRentalResponse();
            rental = await RentalApiMethods.UpdateRental(request.ToModelUpdateRental(), storeId, rentailId);

            return RedirectToAction(nameof(RentalDetails), new { id = rentailId });
        }

        public async Task<IActionResult> DeleteRental(int storeId, int rentalId)
        {
            storeId = 1;
            rentalId = 11;
            await CustomerApiMethods.DeleteCustomer(storeId, rentalId);

            return RedirectToAction(nameof(RentalList), new { storeId = 2 });
        }
    }
}