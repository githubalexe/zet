﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.User;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class CustomerController : Controller
    {
        [HttpGet("Customer/CustomerDetails/{customerId}")]
        public async Task<IActionResult> CustomerDetails(int customerId)
        {
            int storeId = 1;
            CustomerView model = new CustomerView();
            CustomerResponse customer = new CustomerResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            customer = await CustomerApiMethods.GetCustomer(storeId, customerId);

            if (customer == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = customer.ToCustomerResponseViewModel();

            return View(model);
        }

        public IActionResult CreateCustomer()
        {
            return View();
        }
        public IActionResult Index()
        {
            //ViewBag.FirstName = StaffUser.FirstName;
            //ViewBag.Picture = Convert.ToBase64String(StaffUser.Picture);

            return View();
        }

        [HttpGet("UpdateCustomer/{customerId}")]
        public async Task<IActionResult> UpdateCustomer(int customerId)
        {
            int storeId = 1;

            CustomerView model = new CustomerView();
            CustomerResponse customer = await CustomerApiMethods.GetCustomer(storeId, customerId);
            model = customer.ToCustomerResponseViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CustomersList([DataSourceRequest] DataSourceRequest request)
        {
            //int storeId = StaffUser.StoreId;

            int storeId = 1;

            List<CustomerIndexViewModel> list = new List<CustomerIndexViewModel>();

            IEnumerable<CustomerResponse> apiResult = await CustomerApiMethods.GetCustomers(storeId);

            foreach (CustomerResponse customer in apiResult)
            {
                list.Add(customer.ToCustomerIndexViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetCustomers()
        {
            int storeId = 1;
            IEnumerable<CustomerNameResponse> apiResult = await CustomerApiMethods.GetCustomersName(storeId);

            return Json(apiResult);
        }

        [HttpPost("Customer/CustomerDetails/{customerId}")]
        public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request, int customerId)
        {
            int storeId = 1;

            List<CustomerPaymentsViewModel> list = new List<CustomerPaymentsViewModel>();
            CustomerView model = new CustomerView();

            IEnumerable<CustomerPaymentsResponse> apiResult = await CustomerApiMethods.GetPayments(storeId, customerId);

            foreach (CustomerPaymentsResponse payment in apiResult)
            {
                list.Add(payment.ToCustomerPaymentsResponse());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateCustomer(CustomerView request)
        {
            int storeId = 1;

            CustomerResponse customer = await CustomerApiMethods.CreateCustomer(request.ToCustomerForm(), storeId);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.CustomerId });
        }

        [HttpPost("UpdateCustomer/{customerId}")]
        public async Task<IActionResult> UpdateCustomer(CustomerView request, int customerId)
        {
            int storeId = 1;
            CustomerResponse customer = await CustomerApiMethods.UpdateCustomer(request.ToCustomerForm(), storeId, customerId);

            return RedirectToAction(nameof(CustomerDetails));
        }

        [HttpPost]
        public async Task<IActionResult> UpdateCustomerStatus(bool isActive, int customerId)
        {
            int storeId = 1;

            CustomerResponse customer = await CustomerApiMethods.UpdateCustomerStatus(isActive, storeId, customerId);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.CustomerId });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<int> customersIds)
        {
            int storeId = 1;

            foreach (int customerId in customersIds)
            {
                await CustomerApiMethods.DeleteCustomer(storeId, customerId);
            }

            return RedirectToAction(nameof(Index), new { storeId = 1 });
        }
    }
}
