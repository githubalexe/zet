﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Customer;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class CustomerController : Controller
    {

        [HttpGet]
        public async Task<IActionResult> CustomerDetails(int customerId)
        {
            int storeId = 2;
            customerId = 11;
            CustomerViewModel model = new CustomerViewModel();
            CustomerResponseLite customer = new CustomerResponseLite();
            customer = await CustomerApiMethods.GetCustomer(storeId, customerId);

            model = customer.ToCustomerGridViewModel();

            if (model == null)
            {
                return NotFound();
            }

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Customers(int storeId)
        {
            storeId = 2;
            IEnumerable<CustomerResponseLite> customers = new List<CustomerResponseLite>();
            customers = await CustomerApiMethods.GetCustomers(storeId);

            if (customers == null)
            {
                return NotFound();
            }

            ViewBag.List = customers;

            return View();
        }

        public IActionResult Create()
        {
            return View();
        }
        public IActionResult CustomersList()
        {
            return View();
        }

        public async Task<IActionResult> Update(int customerId, int storeId)
        {
            storeId = 2;
            customerId =11;
            CustomerViewModel model = new CustomerViewModel();
            CustomerResponseLite customer = new CustomerResponseLite();
            customer = await CustomerApiMethods.GetCustomer(storeId, customerId);
            model = customer.ToCustomerGridViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CustomersList([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            List<CustomerViewModel> list = new List<CustomerViewModel>();

            IEnumerable<CustomerResponseLite> apiResult = await CustomerApiMethods.GetCustomers(storeId);

            foreach (CustomerResponseLite customer in apiResult)
            {
                list.Add(customer.ToCustomerGridViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> Create(CustomerViewModel request)
        {
            int storeId = 1;
            await CustomerApiMethods.CreateCustomer(request.ToModelCreateCustomer(), storeId);

            return RedirectToAction(nameof(CustomerDetails), new { id = 8 });
        }

        [HttpPost]
        public async Task<IActionResult> Update(CustomerViewModel request, int customerId)
        {
            int storeId = 2;
            customerId =11;
            await CustomerApiMethods.UpdateCustomer(request.ToModelUpdateCustomer(), storeId, customerId);

            return RedirectToAction(nameof(CustomerDetails), new { id = customerId });
        }


        public async Task<IActionResult> Delete(int storeId, int customerId)
        {
            storeId = 2;
            customerId = 11;
            await CustomerApiMethods.DeleteCustomer(storeId, customerId);

            return RedirectToAction(nameof(CustomersList), new { storeId = 2 });
        }
    }
}