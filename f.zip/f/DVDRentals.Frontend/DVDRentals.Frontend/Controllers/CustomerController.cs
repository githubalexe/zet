﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class CustomerController : Controller
    {

        [HttpGet("customer/CustomerDetails/{customerId}")]
        public async Task<IActionResult> CustomerDetails(int customerId)
        {
            int storeId = 1;
            CustomerViewModel model = new CustomerViewModel();
            CustomerResponse customer = new CustomerResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            customer = await CustomerApiMethods.GetCustomer(storeId, customerId);

            if (customer == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = customer.ToCustomerResponseViewModel();

            return View(model);
        }

        public IActionResult Payments()
        {

            return View();
        }

        public IActionResult Create()
        {
            return View();
        }
        public IActionResult CustomersList()
        {
            return View();
        }

        [HttpGet("Update/{customerId}")]
        public async Task<IActionResult> Update(int customerId)
        {
            int storeId = 1;

            CustomerViewModel model = new CustomerViewModel();
            CustomerResponse customer = new CustomerResponse();
            customer = await CustomerApiMethods.GetCustomer(storeId, customerId);
            model = customer.ToCustomerResponseViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CustomersList([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            List<CustomerViewModel> list = new List<CustomerViewModel>();

            IEnumerable<CustomerResponse> apiResult = await CustomerApiMethods.GetCustomers(storeId);

            foreach (CustomerResponse customer in apiResult)
            {
                list.Add(customer.ToCustomerResponseViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            int customerId = 63;
            List<CustomerPaymentsViewModel> list = new List<CustomerPaymentsViewModel>();

            IEnumerable<CustomerPaymentsResponse> apiResult = await CustomerApiMethods.GetPayments(storeId, customerId);

            foreach (CustomerPaymentsResponse customer in apiResult)
            {
                list.Add(customer.ToCustomerPaymentsResponse());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }
        [HttpPost]
        public async Task<IActionResult> Create(CustomerViewModel request)
        {
            int storeId = 1;
            CustomerResponse customer = new CustomerResponse();
            customer = await CustomerApiMethods.CreateCustomer(request.ToModelCreateCustomer(), storeId);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.CustomerId });
        }

        [HttpPost("Update/{customerId}")]
        public async Task<IActionResult> Update(CustomerViewModel request, int customerId)
        {
            int storeId = 1;
            CustomerResponse customer = new CustomerResponse();
            customer = await CustomerApiMethods.UpdateCustomer(request.ToModelUpdateCustomer(), storeId, customerId);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.CustomerId });
        }

        public async Task<IActionResult> Delete(int storeId, int customerId)
        {
            storeId = 1;
            customerId = 11;
            await CustomerApiMethods.DeleteCustomer(storeId, customerId);

            return RedirectToAction(nameof(CustomersList), new { storeId = 2 });
        }
    }
}

//public static async Task<IEnumerable<CustomerPaymentsResponse>> GetPayments(int storeId, int customerId)
//{
//    IEnumerable<CustomerPaymentsResponse> payments = new List<CustomerPaymentsResponse>();

//    using (HttpClient client = new HttpClient())
//    {
//        string uri = "https://localhost:44361/";
//        string url = String.Format("{0}stores/{1}/customers/{2}/payments", uri, storeId, customerId);
//        HttpResponseMessage response = await client.GetAsync(url);

//        if (!response.IsSuccessStatusCode)
//        {
//            return null;
//        }
//        else
//        {
//            string dataJson = await response.Content.ReadAsStringAsync();
//            payments = JsonConvert.DeserializeObject<List<CustomerPaymentsResponse>>(dataJson);
//        }
//    }

//    return payments;
//}