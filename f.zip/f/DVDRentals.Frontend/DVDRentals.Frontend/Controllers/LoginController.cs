﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.User;
using DVDRentals.Frontend.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetStaff(LoginViewModel model)
        {
            StaffResponse staff = await StoreApiMethods.GetStaff(model.ToStaffVerifyRequest());

            StaffUser.StaffId = staff.StaffId;
            StaffUser.StoreId = staff.StoreId;
            StaffUser.Picture = staff.Picture;
            StaffUser.FirstName = staff.FirstName;

            //return Ok();
            if (staff != null)
            {

                return RedirectToAction("Index", "Customer");
            }
            else
            {
                return BadRequest("Mai incearca!!");
            }
        }
    }
}