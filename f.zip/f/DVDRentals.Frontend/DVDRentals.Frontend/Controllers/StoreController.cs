﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Store;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class StoreController : Controller
    {
        [HttpGet]
        public async Task<IActionResult> StoreDetails()
        {
            int storeId = 1;
            StoreView model = new StoreView();
            StoreResponse store = new StoreResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            store = await StoreApiMethods.GetStore(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = store.ToStoreResponseViewModel();

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> UpdateStore()
        {
            int storeId = 1;
            StoreView model = new StoreView();
            StoreResponse store = new StoreResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            store = await StoreApiMethods.GetStore(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = store.ToStoreResponseViewModel();

            return View(model);
        }

        [HttpPost("UpdateStore/{storeId}")]
        public async Task<IActionResult> UpdateStore(StoreView request, int storeId)
        {
            StoreResponse store = new StoreResponse();

            store = await StoreApiMethods.UpdateStore(request.ToModelUpdateStore(), storeId);

            return RedirectToAction(nameof(StoreDetails), new { id = store.StoreId });
        }
    }
}