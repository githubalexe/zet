﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class StaffController : Controller
    {
        [HttpGet("Staff/StaffDetails/{staffId}")]
        public async Task<IActionResult> StaffDetails(int staffId)
        {
            int storeId = 1;
            StaffView model = new StaffView();
            StaffResponse staff = new StaffResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            staff = await StaffApiMethods.GetStaff(storeId, staffId);

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = staff.ToStaffResponseView();

            return View(model);
        }

        public IActionResult CreateStaff()
        {
            return View();
        }
        public IActionResult StaffsList()
        {
            return View();
        }

        [HttpGet("UpdateStaff/{staffId}")]
        public async Task<IActionResult> UpdateStaff(int staffId)
        {
            int storeId = 1;
            //make this a global setting

            //a real scenario -> fetch store ID from login cookie not now

            StaffView model = new StaffView();
            StaffResponse staff = new StaffResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            staff = await StaffApiMethods.GetStaff(storeId, staffId);

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = staff.ToStaffResponseView();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> StaffsList([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            List<StaffView> list = new List<StaffView>();

            IEnumerable<StaffResponse> apiResult = await StaffApiMethods.GetStaffs(storeId);

            foreach (StaffResponse staff in apiResult)
            {
                list.Add(staff.ToStaffResponseView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost("Staff/StaffDetails/{staffId}")]
        public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request, int staffId)
        {
            int storeId = 1;

            List<StaffPaymentsView> list = new List<StaffPaymentsView>();
            StaffView model = new StaffView();

            IEnumerable<StaffPaymentsResponse> apiResult = await StaffApiMethods.GetPayments(storeId, staffId);

            foreach (StaffPaymentsResponse payment in apiResult)
            {
                list.Add(payment.ToStaffPaymentsResponseView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateCreate(StaffView request)
        {
            int storeId = 1;
            StaffResponse staff = new StaffResponse();
            staff = await StaffApiMethods.CreateStaff(request.ToModelCreateStaff(), storeId);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.StoreId });
        }

        [HttpPost("UpdateStaff/{staffId}")]
        public async Task<IActionResult> UpdateStaff(StaffView request, int staffId)
        {
            int storeId = 1;
            StaffResponse staff = new StaffResponse();
            staff = await StaffApiMethods.UpdateStaff(request.ToModelUpdateStaff(), storeId, staffId);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.StoreId });
        }

        public async Task<IActionResult> DeleteStaff(int storeId, int customerId)
        {
            storeId = 1;
            customerId = 11;
            await StaffApiMethods.DeleteStaff(storeId, customerId);

            return RedirectToAction(nameof(StaffsList), new { storeId = 2 });
        }
    }
}