﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.City;
using DVDRentals.API.Response.Country;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class CountryController : Controller
    {
        public async Task<IActionResult> GetCountries()
        {
            IEnumerable<CountryResponseLite> apiResult = await CountryApiMethods.GetCountriesAsync();

            return Json(apiResult);
        }

        public async Task<IActionResult> GetCountriesByCountry(int countryId)
        {
         
            IEnumerable<CityResponse> apiResult = await CityApiMethods.GetCitiesByCountryAsync(countryId);

            return Json(apiResult);
        }
    }
}