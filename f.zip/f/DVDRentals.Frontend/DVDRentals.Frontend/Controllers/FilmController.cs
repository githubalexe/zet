﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Messages;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class FilmController : Controller
    {
        [HttpGet("Film/FilmDetails/{filmId}")]
        public async Task<IActionResult> FilmDetails(int filmId)
        {
            FilmView model = new FilmView();
            FilmResponse film = new FilmResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            film = await FilmApiMethods.GetFilm(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = film.ToFilmResponseFilmView();

            return View(model);
        }

        public IActionResult CreateFilm()
        {
            return View();
        }
        public IActionResult FilmsList()
        {
            return View();
        }

        [HttpGet("UpdateFilm/{filmId}")]
        public async Task<IActionResult> UpdateFilm(int filmId)
        {
            FilmView model = new FilmView();
            FilmResponse film = new FilmResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            film = await FilmApiMethods.GetFilm(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = film.ToFilmResponseFilmView();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> FilmsList([DataSourceRequest] DataSourceRequest request)
        {
            List<FilmView> list = new List<FilmView>();

            IEnumerable<FilmResponse> apiResult = await FilmApiMethods.GetFilms();

            foreach (FilmResponse film in apiResult)
            {
                list.Add(film.ToFilmResponseFilmView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateFilm(FilmView request)
        {
            FilmResponse film = new FilmResponse();
            film = await FilmApiMethods.CreateFilm(request.ToModelCreateFilm());

            return RedirectToAction(nameof(FilmDetails), new { id = film.FilmId });
        }

        [HttpPost("UpdateFilm/{filmId}")]
        public async Task<IActionResult> UpdateCustomer(FilmView request, int filmId)
        {
            FilmResponse film = new FilmResponse();
            film = await FilmApiMethods.UpdateFilm(request.ToModelUpdateFilm(), filmId);

            return RedirectToAction(nameof(FilmDetails), new { id = film.FilmId });
        }

        [HttpPost("Actors/{filmId}")]
        public async Task<IActionResult> Actors([DataSourceRequest] DataSourceRequest request, int filmId)
        {
            List<ActorView> list = new List<ActorView>();
            FilmResponse film = await FilmApiMethods.GetFilm(filmId);

            IEnumerable<ActorResponseLite> apiResult = await ActorApiMethods.GetActors(filmId);

            foreach (ActorResponseLite actor in apiResult)
            {
                list.Add(actor.ToActorResponseVieW(film));
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        public async Task<IActionResult> DeleteFilm(int filmId)
        {
            filmId = 11;
            await FilmApiMethods.DeleteFilm(filmId);

            return RedirectToAction(nameof(FilmsList), new { storeId = 2 });
        }
    }
}