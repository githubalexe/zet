﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Messages;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class FilmController : Controller
    {
        [HttpGet("Film/FilmDetails/{filmId}")]
        public async Task<IActionResult> FilmDetails(int filmId)
        {
            FilmView model = new FilmView();
            FilmResponse film = new FilmResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            film = await FilmApiMethods.GetFilm(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = film.ToFilmResponseFilmView();

            return View(model);
        }

        public IActionResult CreateFilm()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("AddActor/{filmId}")]
        public IActionResult AddActor(int filmId)
        {
            return View();
        }

        [HttpGet("UpdateFilm/{filmId}")]
        public async Task<IActionResult> UpdateFilm(int filmId)
        {
            FilmView model = new FilmView();
            FilmResponse film = new FilmResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            film = await FilmApiMethods.GetFilm(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = film.ToFilmResponseFilmView();

            return View(model);
        }

        [HttpGet("Film/UpdateActor/{actorId}")]
        public async Task<IActionResult> UpdateActor(int actorId, int filmId)
        {
            ActorView model = new ActorView();
            ActorResponseLite actor = new ActorResponseLite();
            ErrorMessage errorMessage = new ErrorMessage();

            actor = await ActorApiMethods.GetActor(actorId);

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = actor.ToActorResponseView();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> FilmsList([DataSourceRequest] DataSourceRequest request)
        {
            List<FilmView> list = new List<FilmView>();

            IEnumerable<FilmResponse> apiResult = await FilmApiMethods.GetFilms();

            foreach (FilmResponse film in apiResult)
            {
                list.Add(film.ToFilmResponseFilmView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateFilm(FilmView request)
        {
            FilmResponse film = new FilmResponse();
            film = await FilmApiMethods.CreateFilm(request.ToModelCreateFilm());

            return RedirectToAction(nameof(FilmDetails), new { id = film.FilmId });
        }

        [HttpPost("UpdateFilm/{filmId}")]
        public async Task<IActionResult> UpdateCustomer(FilmView request, int filmId)
        {
            FilmResponse film = new FilmResponse();
            film = await FilmApiMethods.UpdateFilm(request.ToModelUpdateFilm(), filmId);

            return RedirectToAction(nameof(FilmDetails), new { id = film.FilmId });
        }

        [HttpPost("Film/UpdateActor/{actorId}")]
        public async Task<IActionResult> UpdateActor(ActorView request, int actorId, int filmId)
        {
            ActorResponseLite actor = new ActorResponseLite();
            actor = await ActorApiMethods.UpdateActor(request.ToModelUpdateActor(), actorId);

            return RedirectToAction(nameof(Index));
        }

        [HttpPost("Actors/{filmId}")]
        public async Task<IActionResult> Actors([DataSourceRequest] DataSourceRequest request, int filmId)
        {
            List<ActorView> list = new List<ActorView>();
            FilmResponse film = await FilmApiMethods.GetFilm(filmId);

            IEnumerable<ActorResponseLite> apiResult = await ActorApiMethods.GetActors(filmId);

            foreach (ActorResponseLite actor in apiResult)
            {
                list.Add(actor.ToActorResponseView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }


        [HttpPost("AddActor/{filmId}")]
        public async Task<IActionResult> AddActor(AddActorView request, int filmId)
        {
            FilmActorResponse actor = new FilmActorResponse();
            actor = await FilmApiMethods.AddActor(request.ToModelAddActor(filmId));

            return RedirectToAction(nameof(FilmDetails), new { id = filmId });
        }

        [HttpGet]
        public async Task<IActionResult> GetActors()
        {
            IEnumerable<ActorResponseLite> apiResult = await ActorApiMethods.GetActors();

            return Json(apiResult);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<int> filmsIds)
        {
            foreach (int filmId in filmsIds)
            {
                await FilmApiMethods.DeleteFilm(filmId);

            }

            return RedirectToAction(nameof(Index), new { storeId = 1 });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteActor(int filmId, IEnumerable<int> actorIds)
        {
            foreach (int actorId in actorIds)
            {
                await ActorApiMethods.DeleteActor(filmId, actorId);
            }

            return RedirectToAction(nameof(Index), new { storeId = 1 });
        }
    }
}