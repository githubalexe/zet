﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Category;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class CategoryController : Controller
    {
        public async Task<IActionResult> GetCategories()
        {
            IEnumerable <CategoryResponseLite> apiResult = await CategoryApiMethods.GetCategoriesAsync();

            return Json(apiResult);
        }
    }
}