﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class StaffProfileViewModel
    {
        public static int StoreId { get; set; }
        public static int StaffId { get; set; }
        public byte[] Picture { get; set; }
    }
}
