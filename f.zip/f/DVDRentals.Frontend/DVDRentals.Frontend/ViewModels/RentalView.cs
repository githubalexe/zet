﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class RentalView
    {
        [Display(Name = "Rental Id")]
        public int RentalId { get; set; }
        [Display(Name = "Film Title")]
        public string FilmTitle { get; set; }
        [Display(Name = "Name")]
        public string Customer { get; set; }
        [Display(Name = "Rental Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public DateTime RentalDate { get; set; }
        [Display(Name = "Return Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy")]
        public DateTime? ReturnDate { get; set; }
        [Display(Name = "Staff")]
        public string Staff { get; set; }
        [Display(Name = "Amount")]
        public string Amount { get; set; }
        [Display(Name = "Payment Date")]
        public string PaymentDate { get; set; }
        //
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "Email")]
        public string Email { get; set; }
        public int AddressId { get; set; }
        [Display(Name = "Address")]
        public string Address { get; set; }
        [Display(Name = "Address 2")]
        public string Address2 { get; set; }
        [Display(Name = "Distrinct")]
        public string Distrinct { get; set; }
        [Display(Name = "Country")]
        public string Country { get; set; }
        [Display(Name = "City")]
        public string City { get; set; }
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }
        [Display(Name = "Phone")]
        public string Phone { get; set; }
        ///
        [Display(Name = "Inventory Id")]
        public int InventoryId { get; set; }
        [Display(Name = "Customer Id")]
        public int CustomerId { get; set; }
        [Display(Name = "Staff Id")]
        public int StaffId { get; set; }
    }
}
