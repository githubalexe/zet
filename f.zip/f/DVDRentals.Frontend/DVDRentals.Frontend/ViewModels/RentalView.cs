﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class RentalView
    {
        [Display(Name ="Rental Id")]
        public int RentalId { get; set; }
        [Display(Name = "Film Title")]
        public string FilmTitle { get; set; }
        [Display(Name = "Name")]
        public string Customer { get; set; }
        [Display(Name = "Rental Date")]
        public DateTime RentalDate { get; set; }
        [Display(Name = "Return Date")]
        public DateTime? ReturnDate { get; set; }
        [Display(Name = "Staff")]
        public string Staff { get; set; }
        [Display(Name = "Amount")]
        public string Amount { get; set; }
        [Display(Name = "Payment Date")]
        public string PaymentDate { get; set; }
        ///
        [Display(Name = "Inventory Id")]
        public int InventoryId { get; set; }
        [Display(Name = "Customer Id")]
        public int CustomerId { get; set; }
        [Display(Name = "Staff Id")]
        public int StaffId { get; set; }
    }
}
