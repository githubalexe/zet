﻿using System.ComponentModel.DataAnnotations;

namespace DVDRentals.Frontend.ViewModels
{
    public class InventoryView
    {
        [Display(Name = "Inventory Id")]
        public int InventoryId { get; set; }
        [Display(Name = "Film Title")]
        public string FilmTitle { get; set; }
        [Display(Name = "Release Year")]
        public int ReleaseYear { get; set; }
        [Display(Name = "Reting")]
        public string Rating { get; set; }
        [Display(Name = "Film Id")]
        public int FilmId { get; set; }
    }
}
