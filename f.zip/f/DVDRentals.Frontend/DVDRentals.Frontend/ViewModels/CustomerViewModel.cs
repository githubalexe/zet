﻿using DVDRentals.API.Response.Customer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class CustomerViewModel
    {
        public int CustomerId { get; set; }
        public int StoreId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int AddressId { get; set; }
        public int Address { get; set; }
        public int Address2 { get; set; }
        public int Distrinct { get; set; }
        public int Country { get; set; }
        public int City { get; set; }
        public bool Active { get; set; }
        public bool PostalCode { get; set; }
        public bool Phone { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
