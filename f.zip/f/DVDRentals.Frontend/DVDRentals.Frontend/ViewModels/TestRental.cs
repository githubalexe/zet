﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class TestRental
    {
        [Display(Name = "Existing Customer")]
        public string ExistingCustomer { get; set; }

        [Display(Name = "Rental Id")]
        public int RentalId { get; set; }

        [Display(Name = "Film Title")]
        public int FilmId { get; set; }

        [Display(Name = "Customer Name")]
        public int CustomerId { get; set; }

        [Display(Name = "Inventories")]
        public int InventoryId { get; set; }

        [Display(Name = "Rental Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public string RentalDate { get; set; }

        [Display(Name = "Return Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy")]
        public string ReturnDate { get; set; }

        [Display(Name = "Amount")]
        public decimal? Amount { get; set; }

        [Display(Name = "Payment Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public DateTime PaymentDate { get; set; }

        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "Email")]
        public string Email { get; set; }

        [Display(Name = "Address")]
        public string Address { get; set; }

        [Display(Name = "Address 2")]
        public string Address2 { get; set; }

        [Display(Name = "Distrinct")]
        public string Distrinct { get; set; }

        [Display(Name = "Country")]
        public int CountryId { get; set; }

        [Display(Name = "City")]
        public int CityId { get; set; }

        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        [Display(Name = "Phone")]
        public string Phone { get; set; }


        [Display(Name = "Staff Id")]
        public int StaffId { get; set; }

        public string Customer { get; set; }

        public string Staff { get; set; }

        public string FilmTitle { get; set; }
    }
}
