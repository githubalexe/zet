﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class StaffPaymentsViewModel
    {
        public int PaymentId { get; set; }
        public int CustomerId { get; set; }
        public int? RentalId { get; set; }
        public string FilmTitle { get; set; }
        public string RentalDate { get; set; }
        public string ReturnDate { get; set; }
        public string PaymentDate { get; set; }
        public string Amount { get; set; }
        public string Customer { get; set; }
    }
}
