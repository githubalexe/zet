﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class PaymentView
    {
        [Display(Name = "Customer Name")]
        public string Customer { get; set; }

        [Display(Name = "Amount")]
        public decimal Amount { get; set; }

        [Display(Name = "Rental Date")]
        public DateTime PaymentDate { get; set; }
    }
}
