﻿using DVDRentals.API.Response.Address;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class StoreView
    {
        [Display(Name = "Store Id")]
        public int StoreId { get; set; }

        [Display(Name = "Manager Name")]
        public int ManagerStaffId { get; set; }

        [Display(Name = "Manager Name")]
        public string ManagerName { get; set; }

        public int AddressId { get; set; }

        [Display(Name = "Address")]
        public string Address { get; set; }

        [Display(Name = "Address 2")]
        public string Address2 { get; set; }

        [Display(Name = "District")]
        public string District { get; set; }

        [Display(Name = "City")]
        public string  City { get; set; }

        [Display(Name = "Country")]
        public string Country { get; set; }

        [Display(Name = "City")]
        public int CityId { get; set; }

        [Display(Name = "Country")]
        public int CountryId { get; set; }

        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }

        [Display(Name = "Phone")]
        public string Phone { get; set; }
    }
}
