﻿using DVDRentals.API.Response.Address;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class StoreView
    {
        [Display(Name = "Store Id")]
        public int StoreId { get; set; }

        [Display(Name = "Manager Name")]
        [Required(ErrorMessage = "Manager Name is required!")]
        public int ManagerStaffId { get; set; }

        [Display(Name = "Manager Name")]
        public string ManagerName { get; set; }

        public int AddressId { get; set; }

        [Display(Name = "Address")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Address is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z z0-9/ -.,']*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string Address { get; set; }

        [Display(Name = "Address 2")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z z0-9/ -.,']*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string Address2 { get; set; }

        [Display(Name = "District")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Distrinct is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z z0-9/ -.,']*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string District { get; set; }

        [Display(Name = "City")]

        public string  City { get; set; }

        [Display(Name = "Country")]
        public string Country { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "City is required!")]
        public int CityId { get; set; }

        [Display(Name = "Country")]
        public int CountryId { get; set; }

        [Display(Name = "Postal Code")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Postal Code is required!")]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "Length required is between 3 and 10 digits!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only digits are allowed!")]
        public string PostalCode { get; set; }

        [Display(Name = "Phone")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Phone is required!")]
        [StringLength(12, MinimumLength = 10, ErrorMessage = "Length required is between 5 and 15 digits!")]
        [RegularExpression("^[0-9/ -:]+$", ErrorMessage = "Only digits are allowed!")]
        public string Phone { get; set; }

    }
}
