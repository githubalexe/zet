﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class StaffView
    {
        [Display(Name = "Staff Id")]
        public int StaffId { get; set; }

        [Display(Name = "Store Id")]
        public int StoreId { get; set; }

        [Display(Name = "First Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "First Name is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Last Name is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string LastName { get; set; }

        [Display(Name = "Picture")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Picture is required! string")]
        public string Picture { get; set; }

        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Email")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Email is required!")]
        [RegularExpression(@"^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$", ErrorMessage = "Incorect email!")]
        public string Email { get; set; }

        [Display(Name = "Address")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Address is required!")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Length required is between three and thirty characters!")]
        [RegularExpression("^[a-zA-Z z0-9/ -]*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string Address { get; set; }

        [Display(Name = "Address 2")]
        [RegularExpression("^[a-zA-Z z0-9/ -]*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string Address2 { get; set; }
        public int AddressId { get; set; }

        [Display(Name = "District")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Distrinct is required!")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Length required is between three and thirty characters!")]
        [RegularExpression("^[a-zA-Z z0-9/ -]*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string District { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Country is required!")]
        public string Country { get; set; }

        [Display(Name = "City")]

        public string City { get; set; }

        [Display(Name = "Status")]
        public bool Active { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; }

        [Display(Name = "Postal Code")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Postal Code is required!")]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "Length required is between three and ten digits!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only digits are allowed!")]
        public string PostalCode { get; set; }

        [Display(Name = "Phone")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Phone is required!")]
        [StringLength(12, MinimumLength = 10, ErrorMessage = "Length required is between ten and twelve digits!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only digits are allowed!")]
        public string Phone { get; set; }

        [Display(Name = "Username")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Username is required!")]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "Length required is between three and ten characters!")]
        public string Username { get; set; }

        [Display(Name = "Password")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Password is required!")]
        [StringLength(50, MinimumLength = 5, ErrorMessage = "Length required is five ten and fifty characters!")]
        public string Password { get; set; }

        [Display(Name = "Picture")]
        [Required(ErrorMessage = "Picture is required!")]
        public byte[] BinaryImage { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Country is required!")]
        public int CountryId { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "City is required!")]
        public int CityId { get; set; }
    }
}
