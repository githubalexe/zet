﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DVDRentals.Frontend.ViewModels
{
    public class CustomerView
    {
        [Display(Name = "Customer Id")]
        public int CustomerId { get; set; }

        [Display(Name = "Store Id")]
        public int StoreId { get; set; }

        [Display(Name = "First Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "First Name is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Last Name is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string LastName { get; set; }

        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Email")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Email is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and thirty characters!")]
        public string Email { get; set; }

        public int AddressId { get; set; }

        [Display(Name = "Address")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Address is required!")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Length required is between three and thirty characters!")]
        public string Address { get; set; }

        [Display(Name = "Address 2")]
        [StringLength(30, MinimumLength = 1, ErrorMessage = "Length required is between three and thirty characters!")]
        public string Address2 { get; set; }

        [Display(Name = "Distrinct")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Distrinct is required!")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Length required is between three and thirty characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string Distrinct { get; set; }

        [Display(Name = "Country")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Country is required!")]
        public string Country { get; set; }

        [Display(Name = "Country")]
        [Required]
        [Range(1, 1000, ErrorMessage = "Select a country!")]
        public int CountryId { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "City is required!")]
        [Range(1, 1000)]
        public int CityId { get; set; }

        [Display(Name = "City")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "City is required!")]
        public string City { get; set; }

        [Display(Name = "Active")]
        public bool Active { get; set; }

        [Display(Name = "Postal Code")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Postal Code is required!")]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "Length required is between three and ten characters!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only digits are allowed!")]
        public string PostalCode { get; set; }

        [Display(Name = "Phone")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Phone is required!")]
        [StringLength(11, MinimumLength = 3, ErrorMessage = "Length required is between three and eleven characters!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only digits are allowed!")]
        public string Phone { get; set; }

        [Display(Name = "Create Date")]
        public DateTime CreateDate { get; set; }
    }
}
