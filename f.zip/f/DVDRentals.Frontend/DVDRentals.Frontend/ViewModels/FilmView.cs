﻿using DVDRentals.API.Response.Category;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class FilmView
    {
        [Display(Name ="Film Id")]
        public int FilmId { get; set; }
        [Display(Name = "Title")]
        public string Title { get; set; }
        [Display(Name = "Description")]
        public string Description { get; set; }
        [Display(Name = "Release Year")]
        public int ReleaseYear { get; set; }
        [Display(Name = "Language Id")]
        public int LanguageId { get; set; }
        [Display(Name = "Original LanguageId")]
        public int? OriginalLanguageId { get; set; }
        [Display(Name = "Rental Duration")]
        public int RentalDuration { get; set; }
        [Display(Name = "Rental Rate")]
        public decimal RentalRate { get; set; }
        [Display(Name = "Duration")]
        public int? Length { get; set; }
        [Display(Name = "Replacement Cost")]
        public decimal ReplacementCost { get; set; }
        [Display(Name = "Rating")]
        public string Rating { get; set; }
        [Display(Name = "Special Features")]
        public string SpecialFeatures { get; set; }
        [Display(Name = "Language")]
        public string Language { get; set; }
        [Display(Name = "Categories")]
        public string Category { get; set; }
    }
}
