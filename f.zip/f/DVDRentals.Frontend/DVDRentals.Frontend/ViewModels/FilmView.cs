﻿using DVDRentals.API.Response.Category;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class FilmView
    {
        [Display(Name = "Film Id")]
        public int FilmId { get; set; }

        [Display(Name = "Title")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Title is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between three and fifty characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string Title { get; set; }

        [Display(Name = "Description")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Description is required!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string Description { get; set; }

        [Display(Name = "Release Year")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Release Year is required!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only alpha characters are allowed!")]
        public int ReleaseYear { get; set; }

        [Display(Name = "Language")]
        [Required(ErrorMessage = "Language is required!")]
        public int LanguageId { get; set; }

        [Display(Name = "Original LanguageId")]
        public int? OriginalLanguageId { get; set; }

        [Display(Name = "Rental Duration")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Rental Duration is required!")]

        [RegularExpression("^[0-9]+$", ErrorMessage = "Only alpha characters are allowed!")]
        public int RentalDuration { get; set; }

        [Display(Name = "Rental Rate")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Rental Rate is required!")]
        [Range(0, 9999.00, ErrorMessage = "Rental Rate must be a number")]
        public decimal RentalRate { get; set; }

        [Display(Name = "Duration")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Duration is required!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only alpha characters are allowed!")]
        public int? Length { get; set; }

        [Display(Name = "Replacement Cost")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Replacement Cost is required!")]
        [Range(0,9999.00, ErrorMessage = "Replacement Cost must be a number")]
        public decimal ReplacementCost { get; set; }

        [Display(Name = "Rating")]
        public string Rating { get; set; }

        [Display(Name = "Special Features")]
        public string SpecialFeatures { get; set; }

        [Display(Name = "Language")]
        public string Language { get; set; }

        [Display(Name = "Category")]
        public string Category { get; set; }

        [Display(Name = "Category")]
        [Required(ErrorMessage = "Category is required!")]
        public int CategoryId { get; set; }
    }
}
