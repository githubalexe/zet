﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class ActorView
    {
        [Display(Name ="Actor Id")]
      
        public int ActorId { get; set; }

        [Display(Name = "Existing Actor")]
        public string ExistingActor { get; set; }

        [Display(Name = "Actors Name")]
        [Required]
        [Range(1,1000, ErrorMessage = "Select an actor!")]
        public string Name { get; set; }

        [Display(Name = "First Name")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string LastName { get; set; }

    }
}
