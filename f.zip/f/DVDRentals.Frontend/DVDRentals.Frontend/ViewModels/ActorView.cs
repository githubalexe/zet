﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class ActorView
    {
        [Display(Name ="Actor Id")]
        public int ActorId { get; set; }
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

    }
}
