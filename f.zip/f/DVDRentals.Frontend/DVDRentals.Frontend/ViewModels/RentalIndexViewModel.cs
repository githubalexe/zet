﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class RentalIndexViewModel
    {

        public int RentalId { get; set; }

        public string RentalDate { get; set; }

        public string ReturnDate { get; set; }

        public string Customer { get; set; }

        public string Staff { get; set; }

        public string FilmTitle { get; set; }
    }
}
