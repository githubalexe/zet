﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class RentalPaymentsView
    {
        [Display(Name = "Payment Id")]
        public int PaymentId { get; set; }
        [Display(Name = "Title")]
        public string FilmTitle { get; set; }
        [Display(Name = "Payment Date")]
        public DateTime PaymentDate { get; set; }
        [Display(Name = "Amount")]
        public decimal Amount { get; set; }
    }
}
