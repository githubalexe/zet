﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class StaffPaymentsView
    {
        public int PaymentId { get; set; }
        public int CustomerId { get; set; }
        public int? RentalId { get; set; }
        public string FilmTitle { get; set; }
        public DateTime? RentalDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public DateTime PaymentDate { get; set; }
        public decimal Amount { get; set; }
        public string Customer { get; set; }
    }
}
