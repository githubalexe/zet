﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Film;
using DVDRentals.Frontend.ViewModels;
using System;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static ActorView ToActorResponseView(this ActorResponseLite actor)
        {
            return new ActorView
            {
                ActorId = actor.ActorId,
                FirstName = actor.FirstName,
                LastName = actor.LastName,
                Name = actor.GetActorName(),
            };
        }

        public static ActorCreateRequest ToModelCreateActor(this ActorView actor)
        {
            return new ActorCreateRequest
            {
                FirstName = actor.FirstName,
                LastName = actor.LastName,
            };
        }

        public static ActorUpdateRequest ToModelUpdateActor(this ActorView actor)
        {
            return new ActorUpdateRequest
            {
                FirstName = actor.FirstName,
                LastName = actor.LastName,
            };
        }

        public static string GetActorName(this ActorResponseLite actor)
        {
            string name = String.Format("{0} {1}", actor.FirstName, actor.LastName);

            return name;
        }
    }
}
