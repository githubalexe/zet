﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Inventory;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class InventoryExtensionMethods
    {
        public static InventoryView ToInventoryResponseView(this InventoryResponse inventory)
        {
            return new InventoryView
            {
                InventoryId = inventory.InventoryId,
                FilmTitle = inventory.Film.Title,
                ReleaseYear = inventory.Film.ReleaseYear,
                Rating = inventory.Film.Rating,
                FilmId = inventory.InventoryId
            };
        }

        public static InventoryCreateRequest ToModelCreateInventory(this InventoryView model)
        {
            return new InventoryCreateRequest
            {
                FilmId = model.InventoryId
            };
        }
    }
}
