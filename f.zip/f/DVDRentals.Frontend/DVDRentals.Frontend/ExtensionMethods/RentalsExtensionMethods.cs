﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Store;
using DVDRentals.Frontend.ViewModels;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class RentalsExtensionMethods
    {
        public static RentalView ToRentalResponseView(this StoreRentalResponse rental)
        {
            return new RentalView
            {
                RentalId = rental.RentalId,
                FilmTitle = rental.Film.Title,
                Customer = rental.Customer.Name,
                RentalDate = rental.RentalDate,
                ReturnDate = rental.ReturnDate,
                Staff = rental.Staff.Name
            };
        }

        public static RentalIndexViewModel ToRentalTest(this StoreRentalResponse rental)
        {
            return new RentalIndexViewModel
            {
                RentalId = rental.RentalId,
                FilmTitle = rental.Film.Title,
                Customer = rental.Customer.Name,
                RentalDate = rental.RentalDate.ToString("dd/MM/yyyy"),
                ReturnDate = rental.ReturnDate?.ToString("dd/MM/yyyy") ?? rental.ReturnDate.ToString(),
                Staff = rental.Staff.Name
            };
        }

        public static RentalPaymentsView ToRentalPaymentsResponse(this PaymentResponseLite payment)
        {
            return new RentalPaymentsView
            {
                PaymentId = payment.PaymentId,
                PaymentDate = payment.PaymentDate,
                Amount = payment.Amount
            };
        }

        public static PaymentCreateRequest ToModelCreatePayment(this RentalPaymentsView model, StoreRentalResponse rental)
        {
            return new PaymentCreateRequest()
            {
                CustomerId = rental.CustomerId,
                StaffId = rental.StaffId,
                RentalId = rental.RentalId,
                Amount = model.Amount,
                PaymentDate = model.PaymentDate
            };
        }

        public static RentalUpdateRequest ToModelUpdateRental(this RentalView model)
        {
            return new RentalUpdateRequest
            {
                RentalDate = model.RentalDate,
                InventoryId = model.InventoryId,
                CustomerId = model.CustomerId,
                ReturnDate = model.ReturnDate,
                StaffId = model.StaffId
            };
        }

        public static RentalFormRequest ToRentalViewForm(this RentalView model)
        {
            return new RentalFormRequest
            {
                ExistingCustomer = model.ExistingCustomer,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Address = model.Address,
                Address2 = model.Address2,
                Distrinct = model.Distrinct,
                CountryId = model.CountryId,
                CityId = model.CityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone,
                InventoryId = model.InventoryId,
                CustomerId = model.CustomerId,
                FilmId = model.FilmId,
                RentalDate = model.RentalDate,
                Amount = model.Amount,
                PaymentDate = model.PaymentDate
            };
        }

    }
}
