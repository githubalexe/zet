﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Store;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class RentalsExtensionMethods
    {
        public static RentalView ToRentalResponseView(this StoreRentalResponse rental)
        {
            return new RentalView
            {
                RentalId = rental.RentalId,
                FilmTitle = rental.Film.Title,
                Customer = rental.Customer.GetCustomerName(),
                RentalDate = rental.RentalDate,
                ReturnDate = rental.ReturnDate,
                Staff = rental.Staff.GetStaffName()
            };
        }

        public static RentalPaymentsView ToRentalPaymentsResponse(this PaymentResponseLite payment)
        {
            return new RentalPaymentsView
            {
                PaymentId = payment.PaymentId,
                PaymentDate = payment.PaymentDate,
                Amount = payment.Amount
            };
        }

        public static RentalCreateRequest ToModelCreateRental(this RentalView model)
        {
            return new RentalCreateRequest
            {
                RentalDate = model.RentalDate,
                InventoryId = model.InventoryId,
                CustomerId = model.CustomerId,
                ReturnDate = model.ReturnDate,
                StaffId = model.StaffId
            };
        }

        public static RentalUpdateRequest ToModelUpdateRental(this RentalView model)
        {
            return new RentalUpdateRequest
            {
                RentalDate = model.RentalDate,
                InventoryId = model.InventoryId,
                CustomerId = model.CustomerId,
                ReturnDate = model.ReturnDate,
                StaffId = model.StaffId
            };
        }

    }
}
