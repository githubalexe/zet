﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Film;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static FilmView ToFilmResponseFilmView(this FilmResponse film)
        {
            return new FilmView
            {
                FilmId = film.FilmId,
                Title = film.Title,
                Description = film.Description,
                ReleaseYear = film.ReleaseYear,
                LanguageId = film.LanguageId,
                OriginalLanguageId = film.OriginalLanguageId,
                RentalRate = film.RentalRate,
                RentalDuration = film.RentalDuration,
                Length = film.Length,
                ReplacementCost = film.ReplacementCost,
                Rating = film.Rating,
                SpecialFeatures = film.SpecialFeatures,
                Language = film.Language.Name,
                Category = film.Category.Name,
                CategoryId = film.Category.CategoryId

            };
        }

        public static FilmCreateRequest ToModelCreateFilm(this FilmView model)
        {
            return new FilmCreateRequest()
            {
                Title = model.Title,
                Description = model.Description,
                ReleaseYear = model.ReleaseYear,
                LanguageId = Int32.Parse(model.Language),
                OriginalLanguageId = model.OriginalLanguageId,
                RentalDuration = model.RentalDuration,
                RentalRate = model.RentalRate,
                Length = model.Length,
                ReplacementCost = model.ReplacementCost,
                Rating = model.Rating,
                SpecialFeatures = model.SpecialFeatures
            };
        }


        public static ActorFilmCreateRequest ToModelAddActor(this ActorView model, int filmId)
        {
            return new ActorFilmCreateRequest()
            {
                FilmId = filmId,
                ActorId = Int32.Parse(model.Name)
            };
        }

        public static FilmFormRequest ToFilmViewFilmForm(this FilmView model)
        {
            return new FilmFormRequest
            {
                FilmId = model.FilmId,
                Title = model.Title,
                Description = model.Description,
                ReleaseYear = model.ReleaseYear,
                LanguageId = model.LanguageId,
                OriginalLanguageId = model.OriginalLanguageId,
                RentalRate = model.RentalRate,
                RentalDuration = model.RentalDuration,
                Length = model.Length,
                ReplacementCost = model.ReplacementCost,
                Rating = model.Rating,
                SpecialFeatures = model.SpecialFeatures,
                Language = model.Language,
                CategoryId = model.CategoryId
            };
        }
    }
}
