﻿using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Store;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreView ToStoreResponseViewModel(this StoreResponse store)
        {
            return new StoreView
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                Address = store.Address.Address1,
                Address2 = store.Address.Address2,
                Distrinct = store.Address.District,
                City = store.Address.City.Name,
                Country = store.Address.City.Country.Name,
                PostalCode = store.Address.PostalCode,
                Phone = store.Address.Phone
            };
        }
        public static StoreUpdateRequest ToModelUpdateStore(this StoreView store)
        {
            return new StoreUpdateRequest
            {
                ManagerStaffId=store.ManagerStaffId,
                AddressId=store.AddressId
            };
        }
    }
}
