﻿using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Store;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreView ToStoreViewModel(this StoreResponse store)
        {
            return new StoreView
            {
                StoreId = store.StoreId,
                ManagerStaffId = store.ManagerStaffId,
                ManagerName= store.ManagerName.Name,
                AddressId = store.AddressId,
                Address = store.Address.Address1,
                Address2 = store.Address.Address2,
                District = store.Address.District,
                City = store.Address.City.Name,
                Country = store.Address.City.Country.Name,
                CityId = store.Address.City.CityId,
                CountryId = store.Address.City.Country.CountryId,
                PostalCode = store.Address.PostalCode,
                Phone = store.Address.Phone
            };
        }

        public static StoreFormRequest ToStoreFormRequest(this StoreView model)
        {
            return new StoreFormRequest
            {
                StoreId = model.StoreId,
                ManagerStaffId = model.ManagerStaffId,
                ManagerName = model.ManagerName,
                AddressId = model.AddressId,
                Address = model.Address,
                Address2 = model.Address2,
                District = model.District,
                City = model.City,
                Country = model.Country,
                CityId = model.CityId,
                CountryId = model.CountryId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }
    }
}
