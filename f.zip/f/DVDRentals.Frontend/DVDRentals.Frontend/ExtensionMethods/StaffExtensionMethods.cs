﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Staff;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Text;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static StaffView ToStaffResponseView(this StaffResponse staff)
        {
            return new StaffView
            {
                StaffId = staff.StaffId,
                StoreId = staff.StoreId,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                Picture = Convert.ToBase64String(staff.Picture),
                BinaryImage = staff.Picture,
                Name = staff.GetStaffName(),
                Email = staff.Email,
                AddressId = staff.AddressId,
                Address = staff.Address.Address1,
                Address2 = staff.Address.Address2,
                District = staff.Address.District,
                Country = staff.Address.City.Country.Name,
                City = staff.Address.City.Name,
                CityId = staff.Address.City.CityId,
                CountryId = staff.Address.City.Country.CountryId,
                PostalCode = staff.Address.PostalCode,
                Phone = staff.Address.Phone,
                Active = staff.Active,
                Username = staff.Username,
                Password = staff.Password
            };
        }

        public static StaffFormRequest ToStaffForm(this StaffView model)
        {
            return new StaffFormRequest
            {
                StaffId = model.StaffId,
                StoreId = model.StoreId,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Picture = model.Picture,
                Name = model.Name,
                Email = model.Email,
                AddressId = model.AddressId,
                Address = model.Address,
                Address2 = model.Address2,
                District = model.District,
                Country = model.Country,
                City = model.City,
                PostalCode = model.PostalCode,
                Phone = model.Phone,
                Active = model.Active,
                Username = model.Username,
                Password = model.Password,
                CountryId = model.CountryId,
                CityId = model.CityId,
                BinaryImage = model.BinaryImage
            };
        }

        public static StaffPaymentsView ToStaffPaymentsResponseView(this StaffPaymentsResponse payment)
        {
            return new StaffPaymentsView
            {
                PaymentId = payment.PaymentId,
                RentalId = payment.RentalId,
                FilmTitle = payment.Rental.Film.Title,
                RentalDate = payment.Rental.RentalDate,
                ReturnDate = payment.PaymentDate,
                Amount = payment.Amount,
                Customer = payment.Customer.Name
            };
        }

        public static StaffUpdateRequest ToModelUpdateStaff(this StaffView staff)
        {
            return new StaffUpdateRequest
            {
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                Email = staff.Email,
                AddressId = staff.AddressId,
                Active = staff.Active
            };
        }

        public static string GetStaffName(this StaffResponse staff)
        {
            string name = String.Format("{0} {1}", staff.FirstName, staff.LastName);

            return name;
        }
    }
}
