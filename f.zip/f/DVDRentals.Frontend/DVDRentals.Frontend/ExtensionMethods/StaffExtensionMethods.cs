﻿using DVDRentals.API.Response.Staff;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static string GetStaffName(this StaffNameResponse staff)
        {
            string name = String.Format("{0} {1}", staff.FirstName, staff.LastName);

            return name;
        }
    }
}
