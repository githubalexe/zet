﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerViewModel ToCustomerGridViewModel(this CustomerResponseLite customer)
        {
            return new CustomerViewModel
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static CustomerCreateRequest ToModelCreateCustomer(this CustomerViewModel customer)
        {
            return new CustomerCreateRequest
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static CustomerUpdateRequest ToModelUpdateCustomer(this CustomerViewModel customer)
        {
            return new CustomerUpdateRequest
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }
    }
}
