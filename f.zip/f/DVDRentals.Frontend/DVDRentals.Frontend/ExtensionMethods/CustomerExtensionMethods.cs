﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Payment;
using DVDRentals.Frontend.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerViewModel ToCustomerResponseViewModel(this CustomerResponse customer)
        {
            return new CustomerViewModel
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Name = customer.GetCustomerName(),
                Email = customer.Email,
                AddressId = customer.AddressId,
                Address = customer.Address.Address1,
                Address2 = customer.Address.Address2,
                Distrinct = customer.Address.District,
                Country = customer.Address.City.Country.Name,
                City = customer.Address.City.Name,
                PostalCode = customer.Address.PostalCode,
                Phone = customer.Address.Phone,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static CustomerPaymentsViewModel ToCustomerPaymentsResponse(this CustomerPaymentsResponse payment)
        {
            return new CustomerPaymentsViewModel
            {
                PaymentId = payment.PaymentId,
                RentalId = payment.RentalId,
                FilmTitle = payment.Rental.Film.Title,
                RentalDate = payment.Rental.RentalDate,
                ReturnDate = payment.PaymentDate,
                Amount = payment.Amount,
                Staff = payment.Staff.GetStaffName()
            };
        }

        public static CustomerCreateRequest ToModelCreateCustomer(this CustomerViewModel customer)
        {
            return new CustomerCreateRequest
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static CustomerUpdateRequest ToModelUpdateCustomer(this CustomerViewModel customer)
        {
            return new CustomerUpdateRequest
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        private static string GetCustomerName(this CustomerResponse customer)
        {
            string name = String.Format("{0} {1}", customer.FirstName, customer.LastName);

            return name;
        }
    }
}
