﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Payment;
using DVDRentals.Frontend.ViewModels;
using System;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerView ToCustomerResponseViewModel(this CustomerResponse customer)
        {
            return new CustomerView
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Name = customer.GetCustomerName(),
                Email = customer.Email,
                AddressId = customer.AddressId,
                Address = customer.Address.Address1,
                Address2 = customer.Address.Address2,
                Distrinct = customer.Address.District,
                CountryId = customer.Address.City.Country.CountryId,
                Country = customer.Address.City.Country.Name,
                CityId = customer.Address.City.CityId,
                City = customer.Address.City.Name,
                PostalCode = customer.Address.PostalCode,
                Phone = customer.Address.Phone,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static CustomerIndexViewModel ToCustomerIndexViewModel(this CustomerResponse customer)
        {
            CustomerIndexViewModel model = new CustomerIndexViewModel();

            model.CustomerId = customer.CustomerId;
            model.Name = customer.GetCustomerName();
            model.Email = customer.Email;
            if (customer.Active == false)
            {
                model.Active = "Inactive";

            }
            else
            {
                model.Active = "Active";
            }

            model.CreateDate = customer.CreateDate.ToString("dd/MM/yyyy");

            return model;
        }

        public static CustomerPaymentsViewModel ToCustomerPaymentsResponse(this CustomerPaymentsResponse payment)
        {
            return new CustomerPaymentsViewModel
            {
                PaymentId = payment.PaymentId,
                RentalId = payment.RentalId,
                FilmTitle = payment.Rental.Film.Title,
                RentalDate = payment.Rental.RentalDate.ToString("dd/MM/yyyy"),
                PaymentDate= payment.PaymentDate.ToString("dd/MM/yyyy"),
                ReturnDate = payment.Rental.ReturnDate?.ToString("dd/MM/yyyy") ?? payment.Rental.ReturnDate.ToString(),
                Amount = payment.Amount.ToString(),
                Staff = payment.Staff.Name
            };
        }

        public static CustomerCreateRequest ToModelCreateCustomer(this CustomerView customer, int addressId)
        {
            return new CustomerCreateRequest
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = addressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static CustomerUpdateRequest ToModelUpdateCustomer(this CustomerView customer)
        {
            return new CustomerUpdateRequest
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static string GetCustomerName(this CustomerResponse customer)
        {
            string name = String.Format("{0} {1}", customer.FirstName, customer.LastName);

            return name;
        }

        public static CustomerFormRequest ToCustomerForm(this CustomerView model)
        {
            return new CustomerFormRequest
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                AddressId = model.AddressId,
                Address = model.Address,
                Address2 = model.Address2,
                Distrinct = model.Distrinct,
                CountryId = model.CountryId,
                CityId = model.CityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }
    }
}
