﻿$(function () {

    Cities = function (options) {
        this.options = $.extend({}, true, Cities.options, options);

        this.setKendo();

        this.options.$city.kendoComboBox({
            dataTextField: "Text",
            dataValueField: "Value",
            filter: "contains",
            autoBind: false,
        });

    };

    Cities.prototype.setKendo = function () {

        var self = this;

        self.options.$country.on("change", function () {

            var countryId = $(this).val();

            if ($.isNumeric(countryId)) {

                self.options.$city.data("kendoComboBox").setDataSource();
                self.GetCities(countryId);


            }
            else {
                self.options.$city.data("kendoComboBox").setDataSource();
            }
            
        });

    };

    Cities.prototype.GetCities = function (countyIdValue) {

        var self = this;

        return $.ajax({
            type: "GET",
            url: "/Country/GetCitiesByCountry",
            data: {
                countryId: countyIdValue
            },
        })
            .done(function (data) {

                for (var i = 0; i < data.length; i++) {

                    var cityId = {};

                    cityId.CityId = data[i].CityId;
                    cityId.Name = data[i].Name

                    self.options.$city.data("kendoComboBox").dataSource.add({
                        Text: cityId.Name,
                        Value: cityId.CityId,
                    });

                }

            })

            .fail(function () {
                console.log("eroare");
            })
    };

    Cities.options = {

        $country: $({}),
        $city: $({})

    };

}());