﻿$(document).ready(function () {

    var $pictureContainer = $(".picture-container");
    var $image = $(".image");
    var $close = $(".close");
    var $fileInput = $("#fileInput");
    var $defaultIcon = $("#defaultIcon");
    var validImageTypes = ["image/gif", "image/jpeg", "image/png"]

    $fileInput.on("change", function (event) {
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {

            var file = files[i];
            var fileType = file["type"];
            if ($.inArray(fileType, validImageTypes) > 0) {
                var reader = new FileReader();
                $(reader).on("load", function (e) {
                    $image.attr("src", e.target.result);
                    $close.removeClass("d-none");
                    $pictureContainer.css("background-color", "transparent");
                });
                reader.readAsDataURL(file);

                $defaultIcon.addClass("d-none");
            }
            else {
                setDefaultImage()
            }

        }
    });

    $close.on("click", function () {
        $(this).addClass("d-none");
        setDefaultImage();
    });

    function setDefaultImage() {
        var $pictureSrc = $("#pictureSrc");
        var $pictureValidation = $(".picture-validation");

        $pictureValidation.addClass("text-danger");

        $pictureValidation.html("Picture is required!");

        $close.addClass("d-none");
        $image.attr("src", "");
        $fileInput.val("");
        $pictureSrc.val("");
        $pictureContainer.css("background-color", "#E5F3F1");
        $defaultIcon.removeClass("d-none");
    }

});