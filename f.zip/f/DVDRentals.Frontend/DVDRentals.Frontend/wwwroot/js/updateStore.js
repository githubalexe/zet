﻿$(document).ready(function () {

    var $form = $("#updateStoreForm");
    $form.data("validator").settings.ignore = "";


});