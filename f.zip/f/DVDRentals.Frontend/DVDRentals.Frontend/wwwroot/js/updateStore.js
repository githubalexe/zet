﻿
$(document).ready(function () {

    var $form = $("#updateStoreForm");


    var $countryId = $("#countryId");
    var $cityId = $("#cityId");

    getCountries($countryId.val());
    getCity($cityId.val());

    $countryId.on("change", function () {

        var countryId = $(this).val();

        if ($.isNumeric(countryId)) {

            $cityId.data("kendoComboBox").setDataSource();
            getCountries(countryId);


        }
        else {
            $cityId.data("kendoComboBox").setDataSource();
        }


    });


    function getCountries(countryIdValue) {

        $cityId.kendoComboBox({
            dataTextField: "Name",
            dataValueField: "CityId",
            dataSource: {
                transport: {
                    read: {
                        url: "/Country/GetCitiesByCountry",
                        data: {
                            countryId: countryIdValue
                        }
                    }
                }
            },
            filter: "contains",
            placeholder: "Select City",
            autoBind: false,
        });
    }

    function getCity(cityIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Country/GetCity",
            data: {
                cityId: cityIdValue
            },
        })
            .done(function (data) {
                var city = {};
                city.Name = data.Name;
                cityFilter: $("#cityId").data("kendoComboBox").input.val(city.Name);
            })
            .fail(function () {
                console.log("wrong");
            })
    }

    var kendoFields = [

        {
            id: "staffId",
            kendoType: "kendoComboBox"
        },
        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };
});