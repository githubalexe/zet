﻿$(document).ready(function () {

    var $form = $("#updateStoreForm");
    $form.data("validator").settings.ignore = "";

    var kendoFields = [

        {
            id: "staffId",
            kendoType: "kendoComboBox"
        },
        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };
});