﻿
$(document).ready(function () {

    var $form = $("#updateStoreForm");
    var $countryId = $("#countryId");
    var $cityId = $("#cityId");

    console.log($countryId.val());

    setKendoComboBox($countryId.val());


    $countryId.on("change", function () {

        var countryId = $(this).val();

        if ($.isNumeric(countryId)) {

            $cityId.data("kendoComboBox").setDataSource();
            setKendoComboBox(countryId);


        }
        else {
            $cityId.data("kendoComboBox").setDataSource();
        }


    });


    function setKendoComboBox(countryIdValue) {

        $cityId.kendoComboBox({
            dataTextField: "Name",
            dataValueField: "CityId",
            dataSource: {
                transport: {
                    read: {
                        url: "/Country/GetCitiesByCountry",
                        data: {
                            countryId: countryIdValue
                        }
                    }
                }
            },
            filter: "contains",
            autoBind: false,
        });

        //var options = {
        //    $country: $countryId,
        //    $city: $cityId
        //}

        //var x = new Cities(options);

        //x.GetCities($countryId.val());
    }

    var kendoFields = [

        {
            id: "staffId",
            kendoType: "kendoComboBox"
        },
        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };
});