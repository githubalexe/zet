﻿$(document).ready(function () {

    var $form = $('#createFilmForm');
    var $kListFilter = $(".k-list-filter");

    $kListFilter.addClass("d-none");
    $form.data("validator").settings.ignore = "";
});