﻿$(document).ready(function () {

    var $deleteInventory = $("#deleteInventory");
    var $inventoryDeleteContainer = $("#inventoryDeleteContainer");
    var $inventorySearchContainer = $("#inventorySearchContainer");
    var $inventoriesGrid = $("#inventoriesGrid");

    setSearchItems();

    $deleteInventory.on("click", function () {

        var optionsGrid = {
            grid: "inventoriesGrid",
            id: "InventoryId",
            name: "InventoryId"
        }

        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $inventoryDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Inventory",
            idsLength: numberOfIds.length,
            url: "/Inventory/Delete",
            dataJson: {
                inventoriesIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {

            $container: $inventorySearchContainer,
            $kendoGrid: $inventoriesGrid,

            buttonFilters: [
                {
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "ReleaseYear"
                },
                {
                    field: "ReleaseYear",
                    operator: "eq",
                    value: 2010,
                    display: "2010"
                },
                {
                    field: "titleField",
                    display: "Rating"
                },
                {
                    field: "Rating",
                    operator: "eq",
                    value: "PG-13",
                    display: "PG-13"
                },
            ],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "Rating",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "FilmTitle",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Rating",
                            operator: "contains",
                            value: 0,
                        },
                        {
                            field: "InventoryId",
                            operator: "eq",
                            value: 0,
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }

});
