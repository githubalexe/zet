﻿$(document).ready(function () {

    var $deleteInventory = $("#deleteInventory");
    var $inventoryDeleteContainer = $("#inventoryDeleteContainer");

    $deleteInventory.on("click", function () {

        var optionsGrid = {
            grid: "inventoriesGrid",
            id: "InventoryId",
            name: "InventoryId"
        }

        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $inventoryDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Inventory",
            idsLength: numberOfIds.length,
            url: "/Inventory/Delete",
            dataJson: {
                inventoriesIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            var modal = new DeleteModal(options);

            modal.appendText();
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });
});
