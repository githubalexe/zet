﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteFilm");
    var $searchFilmContainer = $("#filmsSearchContainer");
    var $filmDeleteContainer = $("#filmDeleteContainer");
    var $filmsGrid = $("#filmsGrid");
    var $toggleButton = $(".toggle-button");

    setSearchItems();


    $deleteFilm.prop("disabled", true);

    $toggleButton.on("click", function () {

        if ($filmsGrid.data("kendoGrid").selectedKeyNames().length === 0) {

            $deleteFilm.prop("disabled", true);
            $deleteFilm.removeClass("item-color");

        }
        else {

            $deleteFilm.addClass("item-color");
            $deleteFilm.prop("disabled", false);
        }

    });

    $deleteFilm.on("click", function () {

        var optionsGrid = {
            grid: "filmsGrid",
            id: "FilmId",
            name: "Title"
        }

        var entityGrid = new EntityGrid(optionsGrid);

        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $filmDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Film",
            idsLength: numberOfIds.length,
            url: "/Film/Delete",
            dataJson: {
                filmsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {

                entityGrid.refreshGrid();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {

            $container: $searchFilmContainer,
            $kendoGrid: $("#filmsGrid"),

            buttonFilters: [
                {
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "ReleaseYear"
                },
                {
                    field: "ReleaseYear",
                    operator: "eq",
                    value: 2010,
                    display: "2010"
                },
                {
                    field: "titleField",
                    display: "Language"
                },
                {
                    field: "Language",
                    operator: "eq",
                    value: "English",
                    display: "English"
                },
                {
                    field: "Language",
                    operator: "eq",
                    value: "French",
                    display: "French"
                },
                {
                    field: "Language",
                    operator: "eq",
                    value: "Italian",
                    display: "Italian",
                },
                {
                    field: "titleField",
                    display: "Rating"
                },
                {
                    field: "Rating",
                    operator: "eq",
                    value: "NC-17",
                    display: "NC-17"
                }
            ],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "Rating",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Language",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Title",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "ReleaseYear",
                            operator: "eq",
                            value: 0,
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }

});


