﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteFilm");
    var $searchFilmContainer = $("#filmsSearchContainer");
    var $filmDeleteContainer = $("#filmDeleteContainer");


    setSearchItems();

    $deleteFilm.on("click", function () {

        var optionsGrid = {
            grid: "filmsGrid",
            id: "FilmId",
            name: "Title"
        }

        var entityGrid = new EntityGrid(optionsGrid);

        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $filmDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Film",
            idsLength: numberOfIds.length,
            url: "/Film/Delete",
            dataJson: {
                filmsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            var modal = new DeleteModal(options);

            modal.appendText();
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });



    function setSearchItems() {
        var options = {
            $container: $searchFilmContainer,
            $kendoGrid: $("#filmsGrid"),
            searchField: "Title",
            buttonFilters: [
                { field: "Title", operator: "contains", value: "", display: "All" },
                { field: "Language", operator: "contains", value: "English", display: "English" },
                { field: "Language", operator: "contains", value: "French", display: "French" },
                { field: "Language", operator: "contains", value: "Italian", display: "Italian" },
            ],
            andfilters: {
                logic: "or", filters: [
                    { field: "Rating", operator: "contains", value: "" },
                    { field: "Language", operator: "contains", value: "" },
                    { field: "Title", operator: "contains", value: "" }
                ],
            },
         
        }

        new SearchLabel(options);
    }
});

//buttonFilters: [
//    { field: "Title", operator: "contains", value: "", display: "All" },
//    { field: "ReleaseYear", operator: "gte", value: 2010, display: "Release Year: 2010" },
//    { field: "Rating", operator: "contains", value: "R", display: "Rating: R" }
//],