﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteFilm");
    var $searchFilmContainer = $("#filmsSearchContainer")

    setSearchItems();

    $deleteFilm.on("click", function () {
        var $options = {
            $container: $("#filmDeleteContainer"),
            kendoGrid: "filmsGrid",
            entity: "Film",
            name: "Title",
            id: "FilmId",
            url: "/Film/Delete/",
        }

        var $grid = $("#" + $options.kendoGrid + " tr.k-state-selected");

        if ($grid.length > 0) {

            var modal = new DeleteModal($options);

            modal.getClickedItems()
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {
            $container: $searchFilmContainer,
            $kendoGrid: $("#filmsGrid"),
            searchField: "Title",
            buttonFilters: [
                { field: "Title", operator: "contains", value: "", display: "All" },
                { field: "ReleaseYear", operator: "gte", value: 2010, display: "Release Year: 2010"},
                { field: "Rating", operator: "contains", value: "R", display: "Rating: R"}
            ]
        }

        new SearchLabel(options);
    }
});