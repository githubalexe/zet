﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteFilm");
    var $searchFilmContainer = $("#filmsSearchContainer")

    //setSearchContainer();

    $deleteFilm.on("click", function () {
        var $options = {
            $container: $("#filmDeleteContainer"),
            kendoGrid: "filmsGrid",
            entity: "Film",
            name: "Title",
            id: "FilmId",
            url: "/Film/Delete/",
        }

        var $grid = $("#" + $options.kendoGrid + " tr.k-state-selected");

        if ($grid.length > 0) {

            var modal = new DeleteModal($options);

            modal.getClickedItems()
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });

    //$(".search").on("keyup", function () {
    //    var val = $('.search').val();
    //    $("#filmsGrid").data("kendoGrid").dataSource.filter({
    //        logic: "and",
    //        filters: [
    //            { field: "Title", operator: "contains", value: val },
    //            { field: "ReleaseYear", operator: "eq", value: 2010 }
    //        ]
    //    });
    //});

    //function setSearchContainer() {
    //    var empty=-"";
    //    var $options = {
    //        $container: $searchFilmContainer,
    //        $kendoGrid: $("#filmsGrid"),
    //        value:"",
    //        filters: [
    //            { field: "Title", operator: "contains", value: value },
    //           /* { field: "ReleaseYear", operator: "eq", value: 2010 }*/]
    //    }

    //    var searchLabel = new SearchLabel($options);

    //    searchLabel.setLabel();
    //}


    //$(".search").on("keyup", function () {
    //    var selecteditem = $(".search").val();
    //    var kgrid = $("#filmsGrid").data("kendoGrid");
    //    selecteditem = selecteditem.toUpperCase();
    //    var selectedArray = selecteditem.split(" ");
    //    if (selecteditem) {

    //        var orfilter = { logic: "or", filters: [] };
    //        var andfilter = { logic: "and", filters: [] };
    //        $.each(selectedArray, function (i, v) {
    //            if (v.trim() == "") {
    //            }
    //            else {
    //                $.each(selectedArray, function (i, v1) {
    //                    if (v1.trim() == "") {
    //                    }
    //                    else {
    //                        orfilter.filters.push({ field: "Title", operator: "startswith", value: v1 },
    //                            { field: "Title", operator: "contains", value: v1 });
    //                        andfilter.filters.push(orfilter);
    //                        orfilter = { logic: "or", filters: [] };
    //                    }

    //                });
    //            }
    //        });
    //        kgrid.dataSource.filter(andfilter);
    //    }
    //    else {
    //        kgrid.dataSource.filter({});
    //    }
    //});

});