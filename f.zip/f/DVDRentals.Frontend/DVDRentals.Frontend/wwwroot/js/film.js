﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteFilm");
    var $searchFilmContainer = $("#filmsSearchContainer");
    var $filmDeleteContainer = $("#filmDeleteContainer");
    var $filmsGrid = $("#filmsGrid");

    setSearchItems();

    $deleteFilm.on("click", function () {

        var optionsGrid = {
            grid: "filmsGrid",
            id: "FilmId",
            name: "Title"
        }

        var entityGrid = new EntityGrid(optionsGrid);

        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $filmDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Film",
            idsLength: numberOfIds.length,
            url: "/Film/Delete",
            dataJson: {
                filmsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

             new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {
            $container: $searchFilmContainer,
            $kendoGrid: $("#filmsGrid"),
            buttonFilters: [
                //{ field: "Title", operator: "contains", value: "", display: "All" },
                { field: "Language", operator: "eq", value: "English", display: "English" },
                { field: "Language", operator: "eq", value: "French", display: "French" },
                { field: "Language", operator: "eq", value: "Italian", display: "Italian" },
            ],
            orFilters: [{
                logic: "or", filters: [
                    { field: "Rating", operator: "contains", value: "" },
                    { field: "Language", operator: "contains", value: "" },
                    { field: "Title", operator: "contains", value: "" }
                ],
            }]
        }

        new SearchLabel(options);
    }
});
