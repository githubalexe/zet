﻿$(document).ready(function () {

    var $options = {
        $container: $("#filmDeleteContainer"),
        $kendoGrid:$("#filmsGrid"),
        header:"Mike Hiller",
        entity:"staff"
    }

    new DeleteModal($options);

    $("#deleteFilm").on("click", function () {

        var $gridItem = $("#filmsGrid tr.k-state-selected"),
            $kendoGridData = $("#filmsGrid").data("kendoGrid");

        var selectedItems = [];
        for (var i = 0; i < $gridItem.length; i++) {
            var item = $kendoGridData.dataItem($gridItem[i]);
            selectedItems.push(item);
        }


        var id = selectedItems[0].FilmId;

        deleteFilm(id);

    });


    function deleteFilm(filmId) {
        $.ajax({
            type: "DELETE",
            url: "/Film/Delete/" + filmId,
        })
            .done(function () {
                $("#filmsGrid").data("kendoGrid").refresh();
                $("#filmsGrid").data("kendoGrid").dataSource.read();
            })
            .fail(function () {
                console.log("Esti bou!");
            })
    }

});