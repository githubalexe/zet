﻿$(function () {

    SearchLabel = function (options) {
        var self = this;

        this.$container = options.$container
        self.$kendoGrid = options.$kendoGrid;
        self.filters = options.filters

        self.buildBody();
    }

    SearchLabel.prototype.buildBody = function () {

        var searchBody = `<div class="search-container float-sm-left">
                        <input class="form-control search " type="text" placeholder="Search" id="searchFilm" aria-label="Search">
                            <button type="button" class="close" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="btn-group float-sm-left search-button">
                            <button type="button" class="btn button" id="filterButton">All</button>
                            <button type="button" class="btn dropdown-toggle dropdown-toggle-split button toggle-button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-button"></div>
                        </div>`


        this.$container.append(searchBody);
    }

    SearchLabel.prototype.setButton = function () {

        //    <button class="dropdown-item item" id="deleteFilm" value="Delete">All</button>
        //<button class="dropdown-item item" id="deleteFilm" value="Delete">2010</button>
    }

    SearchLabel.prototype.setLabel = function () {

        var self = this;

        $(".search").on("keyup", function () {
            var val = $('.search').val();
            self.value = val;
            self.$kendoGrid.data("kendoGrid").dataSource.filter({
                logic: "and",
                filters: filters
            });
        });
    }
}());