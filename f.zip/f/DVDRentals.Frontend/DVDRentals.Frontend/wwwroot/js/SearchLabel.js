﻿$(function () {

    SearchLabel = function (options) {

        this.options = $.extend({}, true, options);

        this.$container = options.$container
        this.$kendoGrid = options.$kendoGrid;
        this.searchField = options.searchField;
        this.buttonFilters = options.buttonFilters;
        this.filter = {};
        this.index = 0;

        this.buildBody();
        this.searchItem();
        this.setFilterButtons();
        this.setButton();
    }

    SearchLabel.prototype.buildBody = function () {

        var searchBody = `<div class="search-container float-sm-left">
                        <input class="form-control search " type="text" placeholder="Search" id="searchFilm" aria-label="Search">
                            <button type="button" class="close" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="btn-group float-sm-left search-button">
                            <button type="button" class="btn button" id="filterButton">All</button>
                            <button type="button" class="btn dropdown-toggle dropdown-toggle-split button toggle-button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-button"></div>
                        </div>`

        this.$container.append(searchBody);
    };

    SearchLabel.prototype.setFilterButtons = function () {
        var self = this;
        var $filterButton = $(".dropdown-menu", this.$container);
        var button = "";

        for (var i = 0; i < self.buttonFilters.length; i++) {
            button = " <button class='dropdown-item item filter' >" + self.buttonFilters[i].display + "</button>";
            $filterButton.append(button);
        }
    };

    SearchLabel.prototype.searchItem = function () {
        var self = this;

        $(".search").on("keyup", function () {
            var val = $('.search').val();
            self.$kendoGrid.data("kendoGrid").dataSource.filter({
                logic: "and",
                filters: [
                    { field: self.searchField, operator: "contains", value: val },
                    { field: self.filter.field, operator: self.filter.operator, value: self.filter.value }
                ]
            });
        });

        $(".close").on("click", function () {
            $('.search').val("");
            self.setFilter();
        });
    };

    SearchLabel.prototype.setButton = function () {
        var self = this;
        var $filter = $(".filter");

        $filter.on("click", function () {
            $("#filterButton").text($(this).text());
            $("#filterButton").val($(this).text());
            $('.search').val("");

            self.index = $(this).index();
            self.setFilter();
        });
    };

    SearchLabel.prototype.setFilter = function () {

        this.filter.field = this.buttonFilters[this.index].field;
        this.filter.operator = this.buttonFilters[this.index].operator;
        this.filter.value = this.buttonFilters[this.index].value;

        this.$kendoGrid.data("kendoGrid").dataSource.filter(this.filter);
    };

    //SearchLabel.options = {
    //    $container: $({}),
    //    $container: $({}),
    //    $kendoGrid: $({}),
    //    searchField: $({}),
    //    buttonFilters: $({}),
    //}

}());