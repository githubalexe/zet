﻿$(function () {

    SearchLabel = function (options) {

        this.$container = options.$container
        this.$kendoGrid = options.$kendoGrid;
        this.searchField = options.searchField;
        this.buttonFilters = options.buttonFilters;

        this.buildBody();
    }

    SearchLabel.prototype.buildBody = function () {

        var searchBody = `<div class="search-container float-sm-left">
                        <input class="form-control search " type="text" placeholder="Search" id="searchFilm" aria-label="Search">
                            <button type="button" class="close" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="btn-group float-sm-left search-button">
                            <button type="button" class="btn button" id="filterButton">All</button>
                            <button type="button" class="btn dropdown-toggle dropdown-toggle-split button toggle-button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-button"></div>
                        </div>`


        this.$container.append(searchBody);
    }

    SearchLabel.prototype.setFilterButton = function () {
        var self = this;
        var $filterButton = $(".dropdown-menu", this.$container);
        var button = "";

        for (var i = 0; i < self.buttonFilters.length; i++) {
            button += " <button class='dropdown-item item' id='deleteFilm' >" + self.buttonFilters[i].value + "</button>";
            $filterButton.append(button);
        }

    }

    SearchLabel.prototype.setLabel = function () {
        var self = this;

        for (var i = 0; i < self.buttonFilters.length; i++) {

            self.$kendoGrid.data("kendoGrid").dataSource.filter(self.buttonFilters[i]);
        }

        console.log("functie " + self.searchField)
        $(".search").on("keyup", function () {
            var val = $('.search').val();
            self.$kendoGrid.data("kendoGrid").dataSource.filter({
                logic: "and",
                filters: [
                    { field: self.searchField, operator: "contains", value: val }
                ]
            });
        });
    }
}());