﻿$(document).ready(function () {

    var $deleteStaff = $("#deleteStaff");
    var $staffDeleteContainer = $("#staffDeleteContainer");
    var $staffsGrid = $("#staffsGrid");
    var $searchStaffsContainer = $("#staffsSearchContainer");

    $deleteStaff.on("click", function () {

        var optionsGrid = {
            grid: "staffsGrid",
            id: "StaffId",
            name: "Name"
        }

        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $staffDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Staff",
            idsLength: numberOfIds.length,
            url: "/Staff/Delete",
            dataJson: {
                staffsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {
            $container: $searchStaffsContainer,
            $kendoGrid: $staffsGrid,
            searchField: "Name",
            buttonFilters: [
                { field: "Name", operator: "contains", value: "", display: "All" },
                { field: "Active", operator: "eq", value: true, display: "Active" },
                { field: "Active", operator: "eq", value: false, display: "Inactive" }
            ]
        }

        new SearchLabel(options);
    }
}); 