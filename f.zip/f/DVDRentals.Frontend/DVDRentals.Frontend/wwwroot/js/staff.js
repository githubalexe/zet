﻿$(document).ready(function () {

    var $deleteStaff = $("#deleteStaff");
    var $staffDeleteContainer = $("#staffModalContainer");
    var $staffsGrid = $("#staffsGrid");
    var $searchStaffsContainer = $("#staffsSearchContainer");
    var $toggleButton = $(".toggle-button");
    var $staffsGrid = $("#staffsGrid");

    setSearchItems();


    $deleteStaff.prop("disabled", true);

    $toggleButton.on("click", function () {

        if ($staffsGrid.data("kendoGrid").selectedKeyNames().length === 0) {

            $deleteStaff.prop("disabled", true);
            $deleteStaff.removeClass("item-color");

        }
        else {

            $deleteStaff.addClass("item-color");
            $deleteStaff.prop("disabled", false);
        }

    });

    $deleteStaff.on("click", function () {

        var optionsGrid = {
            grid: "staffsGrid",
            id: "StaffId",
            name: "Name"
        }

        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $staffDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Staff",
            idsLength: numberOfIds.length,
            url: "/Staff/Delete",
            dataJson: {
                staffsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {

            $container: $searchStaffsContainer,
            $kendoGrid: $staffsGrid,

            buttonFilters: [
                {
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "Status"
                },
                {
                    field: "Status",
                    operator: "eq",
                    value: "Active",
                    display: "Active"
                },
                {
                    field: "Status",
                    operator: "eq",
                    value: "Inactive",
                    display: "Inactive"
                },

            ],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "Name",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Email",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Status",
                            operator: "contains",
                            value: "",
                        },
                        {
                            field: "City",
                            operator: "contains",
                            value: "",
                        },
                        {
                            field: "Country",
                            operator: "contains",
                            value: "",
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }

}); 