﻿$(document).ready(function () {

    var $options = {
        $container: $("#staffDeleteContainer"),
        header: $("#lol"),
        entity: "staff"
    }


    $("#deleteStaff").on("click", function () {
        new DeleteModal($options);
        $('#deleteModal').modal('show');
    });
}); 