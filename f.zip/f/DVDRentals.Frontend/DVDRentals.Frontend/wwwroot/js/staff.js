﻿$(document).ready(function () {

    var $options = {
        $container: $("#staffDeleteContainer"),
        header: "Mike Hillyer",
        entity: "staff"
    }

    new DeleteModal($options);

    $("#deleteStaff").on("click", function () {

        $('#dummyModal').modal('show');
    });
}); 