﻿
$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $actorNameContainer = $("#actorNameContainer");
    var $actorActiveCombobox = $("#actorActiveDropDownList");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#addActorForm");
    var $actorFirstName = $("#actorFirstName");
    var $actorLastName = $("#actorLastName");
    var $actorsName = $("#actorsName");

    $kListFilter.addClass("d-none");
    
    $form.data("validator").settings.ignore = "";
   
    $actorActiveCombobox.on("change", function () {
        $containerForm.slideToggle("slow");
        $actorNameContainer.toggleClass("display-none");
        console.log($actorActiveCombobox.val());


        if ($(this).val() === "No") {
       
            //$actorsName.removeAttr("required");
            $actorFirstName.prop("required", true);
            $actorLastName.prop("required", true);
            $form.data("validator").settings.ignore = ":hidden:not(:visible.k-widget .kendo-force-validation)";
        }
        else {

            //$form.validator.setDefaults({
            //    ignore: ":hidden:not(:visible.k-widget .kendo-force-validation)"
            //});

            $form.data("validator").settings.ignore = "";

            $actorsName.prop("required", true);
            $actorFirstName.prop("required", false);
            $actorLastName.prop("required", false);

        }
    });


    //$form.data("validator").settings.ignore = "";
    function setRequeredField(isYes) {

        if (isYes === "No") {

            $form.validate({
                ignore: ""
            })

            $actorsName.prop("required", false);
            $actorFirstName.prop("required", true);
            $actorLastName.prop("required", true);

        }
        else {
            //$form.data("validator").settings.ignore = "";
       
            $actorsName.prop("required", true);
            $actorFirstName.prop("required", false);
            $actorLastName.prop("required", false);

        }

    }

});