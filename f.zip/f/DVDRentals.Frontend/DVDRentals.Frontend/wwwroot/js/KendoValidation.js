﻿$(function () {

    KendoValidation = function (options) {

        this.$form = options.$form;
        this.kendoFileds = options.kendoFileds;

        this.IsData();

        this.setRequired();

    };

    KendoValidation.prototype.IsData = function () {

        var self = this;

        for (var i = 0; i < self.kendoFileds.lenght; i++) {

            var $kendoField = $("#" + this.kendoField);
            setFields($kendoField);
        }

    };

    KendoValidation.prototype.setFields = function (field) {


        self.$kendoField.on("change", function () {

            var kendoValue = field.data('kendoComboBox').dataItem();

            if (typeof kendoValue !== "undefined") {

                $("#" + self.kendoField + "-error").remove();
            }
            else {
                self.$form.data("validator").settings.ignore = ":hidden:not(#" + self.kendoField + ")";
            }

        });


        self.$kendoField.on("focusout", function () {

            if (typeof self.kendoValue === "undefined") {

                self.$kendoField.data("kendoComboBox").value("");
            }

        });
    };

    KendoValidation.prototype.setRequired = function () {

        var self = this;

        //$("#createRentalForm :input").each(function () {
        //    var input = $(this);
        //    var id = input.attr('id');
        //    console.log(id);

        //    if (id === self.kendoField) {


        //    }

        //});
    
        //for (var i = 0; i < self.kendoFileds.length; i++) {

        //    console.log(self.kendoFileds[i]); 
        //    var =

        //}

        self.$form.data("validator").settings.ignore = ":hidden:not(#" + self.kendoFileds[0] + ", #" + self.kendoFileds[1] + ")";

    };

}());
