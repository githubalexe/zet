﻿

var $countryId = $("#countryId");
var $cityId = $("#cityId");



$countryId.on("change", function () {

    var countryId = $(this).val();

    if ($.isNumeric(countryId)) {

        $cityId.data("kendoComboBox").setDataSource();
       


    }
    else {
        $cityId.data("kendoComboBox").setDataSource();
    }


});

$(document).ready(function () {

    var $form = $('#updateCustomerForm');

    var kendoFields = [

        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

});

