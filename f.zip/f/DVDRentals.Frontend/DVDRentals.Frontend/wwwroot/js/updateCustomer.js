﻿$(document).ready(function () {

    var $form = $('#updateFormCustomer');
    $form.data("validator").settings.ignore = "";

});