﻿$(function () {
    $('.nav-button').on('click', function(){
        $('.nav-button').removeClass('active');
        $(this).addClass('active');
        console.log(5);
    });

    $(".dropdown-menu a").click(function () {

        $(".btn:first-child").text($(this).text());
        $(".btn:first-child").val($(this).text());

    });
});