﻿$(document).ready ( function(){
    var deleteData = {};
    var grid = $("#customers-grid").data("kendoGrid");

    $('.nav-button').on('click', function () {
        $('.nav-button').removeClass('active-nav-button');
        $(this).addClass('active-nav-button');
        console.log("buton");
    });

    $('.nav-link').on('click', function () {
        $('.nav-link').removeClass('active-nav-link');
        $(this).addClass('active-nav-link');
    });

    $('.dropdown-menu .item').on('click', function () {
        $(".cud-button:first-child").text($(this).text());
        $(".cud-button:first-child").val($(this).text());
        $(".cud-button").css("background-color", "#008a73");
        $(".cud-button").css("color", "#FFFFFF");
        $(".dropdown - toggle").css("background-color", "#008a73");

    });


    $("#customers-grid").on('change', function () {
        var row = grid.select();
        var data = grid.dataItem(row);
        deleteData.FirstName = data.FirstName;
        deleteData.puila = "muie";
        console.log("custom data", deleteData);
        console.log(5);
        console.log(data);
    });

    $(".item[value*='Create']").on('click', function () {
        alert("Create");
    });

    $('.item[value*="Delete"]').on('click', function () {
        alert("Delete");
    });
 

});