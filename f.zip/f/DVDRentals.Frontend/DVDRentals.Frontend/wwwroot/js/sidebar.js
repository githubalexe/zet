﻿$(function () {
    var deleteData = {};
    var grid = $("#customers-grid").data("kendoGrid");

    $('.nav-button').on('click', function () {
        $('.nav-button').removeClass('active-nav-button');
        $(this).addClass('active-nav-button');
        console.log("buton");
    });

    $('.nav-link').on('click', function () {
        $('.nav-link').removeClass('active-nav-link');
        $(this).addClass('active-nav-link');
    });

    $('.dropdown-menu .item').on('click', function () {
        $(".cud-button:first-child").text($(this).text());
        $(".cud-button:first-child").val($(this).text());
        console.log(5);
    });


    $("#customers-grid").on('change', function () {
        var row = grid.select();
        var data = grid.dataItem(row);
        deleteData.FirstName = data.FirstName;
        deleteData.puila = "muie";
        console.log("custom data", deleteData);
        console.log(5);
        console.log(data);
    });


    $(".model-value").on("click", function () {
        $.ajax({
            type: "GET",
            url:"/Customer/Update"
        })

        console.log(5);
    });
});