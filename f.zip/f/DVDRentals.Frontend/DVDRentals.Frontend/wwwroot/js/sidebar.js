﻿$(document).ready(function () {
    $('.nav-button').on('click', function(){
        $('.nav-button').removeClass('active');
        $(this).addClass('active');
        console.log(5);
    });
});