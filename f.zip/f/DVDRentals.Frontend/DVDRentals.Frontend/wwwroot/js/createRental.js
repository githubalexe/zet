﻿$(document).ready(function () {
    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");
    });


    //$.ajax({
    //    type: "GET",
    //    url: "/Customer/Customers",
    //    contentType: "application/json; charset=utf-8",
    //    dataType: "json"
    //})
    //    .done(function (data) {
    //        var s = "";
    //        for (var i = 0; i < data.length; i++) {
    //            s += "<option >" + data[i].FirstName + " " + data[i].LastName + "</option>";
    //        }

    //        $("#searchCustomer").html(s);
    //    })
    //    .fail(function () {
    //        console.log("fail");
    //    })

    //$("#searchCustomer").on("change", function () {
    //    console.log("now");
    //});

    });