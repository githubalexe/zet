﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#createRentalForm");
    var $email = $("#email");


    console.log($email.val())

    $kListFilter.addClass("d-none");

    var kendoFields = [
        {
            id: "filmComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "customerComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "rentalDate",
            kendoType: "kendoDatePicker"
        },
    ];

    setKendoCustomer(kendoFields);

    $email.on("change", function () {

        console.log(isValidEmailAddress($email.val()));

    });


    function isValidEmailAddress(emailAddress) {
        var pattern = new RegExp(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/);
        return pattern.test(emailAddress);
    };

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");

        var isCustomer = $activeform.data("kendoDropDownList").value();

        if (isCustomer === "Yes") {

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "customerComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            $(".customer-field").prop("required", true);

            setKendoCustomer(kendoFields);

        }
        else {
            $(".customer-field").prop("required", false);

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "countryRental",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "cityRental",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            setKendoCustomer(kendoFields);
        }

    });


    function setKendoCustomer(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

});