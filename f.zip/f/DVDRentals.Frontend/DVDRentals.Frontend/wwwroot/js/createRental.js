﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");
    });

    var $kListFilter = $(".k-list-filter");

    $kListFilter.addClass("d-none");

   //var a= $("#inventoryComboBox").kendoComboBox();
   // var combobox = a.data("kendoComboBox");
   // combobox.readonly(true);
});