﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#createRentalForm");
    var $email = $("#email");
    var $filmId = $("#filmComboBox");

    $filmId.on("change", function () {

        var filmId = $(this).val();
        var invetoryIds = [];
        var invetoryIds = getInventories(filmId);


        //console.log(invetoryIds[1] + " merge");

        console.log(getInventoryRentals(26));



        //console.log(obj);
        //console.log(inventories);

    });

    $kListFilter.addClass("d-none");

    var kendoFields = [
        {
            id: "filmComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "customerComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "rentalDate",
            kendoType: "kendoDatePicker"
        },
    ];

    setKendoCustomer(kendoFields);

    $email.on("change", function () {

        console.log(isValidEmailAddress($email.val()));


    });


    function isValidEmailAddress(emailAddress) {
        var pattern = new RegExp(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/);
        return pattern.test(emailAddress);
    };

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");

        var isCustomer = $activeform.data("kendoDropDownList").value();

        if (isCustomer === "Yes") {

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "customerComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            $(".customer-field").prop("required", true);

            setKendoCustomer(kendoFields);

        }
        else {
            $(".customer-field").prop("required", false);

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "countryRental",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "cityRental",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            setKendoCustomer(kendoFields);
        }

    });

    function setKendoCustomer(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

    function getInventories(filmIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Inventory/GetFilmInventories",
            data: {
                filmId: filmIdValue
            },
        })
            .done(function (data) {
                var dataLength = data.length;

                for (var i = 0; i < dataLength; i++) {

                    var inventoryId = {};

                    inventoryId.InventoryId = data[i].InventoryId;
                    console.log(inventoryId.InventoryId);

                }
            })
            .fail(function () {
                self.options.onFail();
            })
    }

    function getInventoryRentals(inventoryIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Rental/GetInventoryRentals",
            data: {
                inventoryId: inventoryIdValue
            },
        })
            .done(function (data) {
       

                    console.log(data);

             
            })
            .fail(function () {
                console.log("eroare");
            })
    }

});