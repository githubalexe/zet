﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#createRentalForm");

    $kListFilter.addClass("d-none");



    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");

        $(".customer-field").prop("required", true);
    });


    setKendoCustomer();


    function setKendoCustomer() {

        var optionCustomer = {
            $form: $form,
            kendoFileds: ["customerComboBox", "filmComboBox"]
        };

        new KendoValidation(optionCustomer);
    };


    //var object = {};
    //var title;

    //title = $filmComboBox.data('kendoComboBox').dataItem();

    //console.log(title);

    //$filmComboBox.on("change", function () {

    //    title = $filmComboBox.data('kendoComboBox').dataItem();

    //    if (typeof title === "undefined") {

    //        console.log("invalid");
    //        $kendoValidation.html("Ba esti prost trebuie sa completezi acest fild ");

    //    }
    //    else {

    //        object.Title = title.Title;
    //        console.log(object.Title);
    //        $kendoValidation.html("");

    //    }
    //});

    //$createRental.on("click", function () {
    //    console.log(object.title);


    //    if (title === "undefined") {
    //        $form.unbind('submit').submit();
    //    } else {
    //        console.log("intra aici")
    //    }

    //});

});