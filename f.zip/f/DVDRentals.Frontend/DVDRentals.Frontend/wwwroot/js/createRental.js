﻿$(document).ready(function () {

    var $containerForm = $(".container-form");


    $("#activeForm").on("click", function () {
        if ($(this).val() === "No") {
            $containerForm.addClass("active-form-customer");
            $(".active-form-customer").animate({ width: "10%" }, 10 );
        }
        else {
            $containerForm.removeClass("active-form-customer", 10);
        }
    });


    console.log(50);
});