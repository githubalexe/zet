﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $rentalActiveForm = $("#rentalActiveForm");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");
    });

    setValuesBoolCombobox();

    function setValuesBoolCombobox() {

        $rentalActiveForm.kendoComboBox({
            dataSource: [
                { Id: 1, Name: "Yes" },
                { Id: 2, Name: "No" }
            ],
            dataTextField: "Name",
            dataValueField: "Id",
        });
    }

});