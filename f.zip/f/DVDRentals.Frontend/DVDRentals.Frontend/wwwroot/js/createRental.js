﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#activeForm");
    var $customerNameContainer = $("#customerNameContainer");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");
    });


    $("#rentalDate").kendoDatePicker({
        value: new Date(),
        format: 'MM/dd/yyyy',
        icons: {
            today: '<fas fa-calendar-alt',
        }
    });

    $("#paymentDate").kendoDatePicker({
        value: new Date(),
        format: 'MM/dd/yyyy'
    });
});