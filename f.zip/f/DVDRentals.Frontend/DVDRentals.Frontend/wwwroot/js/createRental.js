﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#createRentalForm");
    var $email = $("#email");
    var $filmId = $("#filmComboBox");

    var $inventoryId = $("#inventoryId");

    var inventories = [];


    $filmId.on("change", function () {

        var filmId = $(this).val();


        if ($.isNumeric(filmId)) {

            getInventories(filmId);

        console.log(inventories.length);

        }
        else {
            $inventoryId.val("");
        }


    });

    $kListFilter.addClass("d-none");

    var kendoFields = [
        {
            id: "filmComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "customerComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "rentalDate",
            kendoType: "kendoDatePicker"
        },
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },

    ];

    setKendoCustomer(kendoFields);


    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");

        var isCustomer = $activeform.data("kendoDropDownList").value();

        if (isCustomer === "Yes") {

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "customerComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
                {
                    id: "paymentDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            $(".customer-field").prop("required", true);

            setKendoCustomer(kendoFields);

        }
        else {
            $(".customer-field").prop("required", false);

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "countryRental",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "cityRental",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
                {
                    id: "paymentDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            setKendoCustomer(kendoFields);
        }

    });

    function setKendoCustomer(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

    function getInventories(filmIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Inventory/GetFilmInventories",
            data: {
                filmId: filmIdValue
            },
        })
            .done(function (data) {
                var dataLength = data.length;

                for (var i = 0; i < dataLength; i++) {

                    var inventoryId = {};

                    inventoryId.InventoryId = data[i].InventoryId;

                    getInventoryRentals(inventoryId.InventoryId);

                }

            })
            .fail(function () {
                self.options.onFail();
            })
    }

    function getInventoryRentals(inventoryIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Rental/GetInventoryRentals",
            data: {
                inventoryId: inventoryIdValue
            },
        })
            .done(function (data) {
                //console.log(inventoryIdValue);
                //console.log(data);

                if (data === null) {

                    inventories.push(inventoryIdValue);

                }
                else {

                    var isRented = true;

                    for (var i = 0; i < data.length; i++) {

                        var returnDate = {};

                        returnDate.ReturnDate = data[i].ReturnDate;

                        if (returnDate.ReturnDate === null) {

                            isRented = false;

                            break;
                        }
                    }

                    if (isRented === true) {
                        inventories.push(inventoryIdValue);
                    }
                }

            })

            .fail(function () {
                console.log("eroare");
            })
    }

});