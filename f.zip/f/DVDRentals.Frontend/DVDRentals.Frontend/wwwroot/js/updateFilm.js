﻿$(document).ready(function () {

    var $form = $("#updateFilmForm");
    var $kListFilter = $(".k-list-filter");

    $form.data("validator").settings.ignore = "";
    $kListFilter.addClass("d-none");

});