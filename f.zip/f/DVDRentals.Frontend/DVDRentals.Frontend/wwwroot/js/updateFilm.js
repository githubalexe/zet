﻿$(document).ready(function () {

    var $form = $("#updateFilmForm");
    var $kListFilter = $(".k-list-filter");

    $form.data("validator").settings.ignore = "";
    $kListFilter.addClass("d-none");

    var kendoFields = [

        {
            id: "languageId",
            kendoType: "kendoComboBox"
        },
        {
            id: "categoryId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

});