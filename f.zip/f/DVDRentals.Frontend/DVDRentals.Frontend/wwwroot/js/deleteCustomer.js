﻿$(document).ready(function () {
    var $customerId = $("#customerId");
    var $customerName = $("#customerName");
    var $deleteButton = $("#deleteCustomerButton");
    var $customerDeleteContainer = $("#customerDeleteContainer");

    $deleteButton.on("click", function () {

        var options = {
            $container: $customerDeleteContainer,
            modelName: "<label class='active-entity'>" + $customerName.text() + "</label>",
            entity: "Customer",
            idsLength: 1,
            url: "/Customer/Delete",
            dataJson: {
                customersIds: parseInt($customerId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Customer/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        };

        new DeleteModal(options);

        $("#deleteModal").modal("show");
    });
});