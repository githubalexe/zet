﻿$(document).ready(function () {
    //var customers = [];

    $("#customersGrid").on('change', function () {
    var grid = $("#customersGrid").data("kendoGrid");
        var row = grid.select();
        var grid = row.closest(".k-grid").data("kendoGrid");
        var dataItem = grid.dataItem(row);

        console.log(dataItem.CustomerId);

        
    });

    //function selectRow() {
    //    var checked = this.checked,
    //        row = $(this).closest("tr"),
    //        grid = $("#grid").data("kendoGrid"),
    //        dataItem = grid.dataItem(row);

    //    checkedrows[dataItem.uid] = checked;
    //}


    var allSelected = $("#customersGrid tr.k-state-selected");
    var allSelectedModels = [];
    $.each(allSelected, function (e) {
        var row = $(this);
        var grid = row.closest(".k-grid").data("kendoGrid");
        var dataItem = grid.dataItem(row);

        allSelectedModels.push(dataItem);
        console.log(dataItem.CustomerId);

    });


});