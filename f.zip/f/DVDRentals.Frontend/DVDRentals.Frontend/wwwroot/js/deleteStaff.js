﻿$(document).ready(function () {
    
    var $staffId = $("#staffId");
    var $staffName = $("#staffName");
    var $deleteButton = $("#deleteStaffButton");
    var $customerDeleteContainer = $("#staffDeleteContainer");

    $deleteButton.on("click", function () {

        var options = {
            $container: $customerDeleteContainer,
            modelName: "<label class='active-entity'>" + $staffName.text() + "</label>",
            entity: "Staff",
            idsLength: 1,
            url: "/Staff/Delete",
            dataJson: {
                staffsIds: parseInt($staffId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Staff/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        };

        new DeleteModal(options);

        $("#deleteModal").modal("show");
    });
});