﻿$(document).ready(function () {

    var $pictureContainer = $(".picture-container");
    var $image = $(".image");
    var $close = $(".close");
    var $fileInput = $("#fileInput");
    var $defaultIcon = $("#defaultIcon");
    var $form = $("#updateStaffForm");
    var $photoValid = $(".photo-valid");
    var $messageValid = $(".message-valid");
    var $pictureValidation = $(".picture-validation");


    var $staffPicture = $("#staffPicture");

    var $pictureSrc = $("#pictureSrc");

    console.log();

    $staffPicture.on("load", function () {

        var $src = $staffPicture.attr("src");

        $pictureSrc.val($src);
        $pictureValidation.html("");
        console.log($fileInput.val());
    });


    setPictureRequired();

    function setPictureRequired() {

        $(".image").prop("required", false);

    }

    $close.removeClass("d-none");
    $pictureContainer.css("background-color", "transparent");
    $defaultIcon.addClass("d-none");

    $photoValid.addClass("valid");

    $messageValid.addClass("field-validation-valid");

    var kendoFields = [

        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };



});