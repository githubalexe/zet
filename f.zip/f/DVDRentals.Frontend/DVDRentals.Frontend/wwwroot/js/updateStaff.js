﻿$(document).ready(function () {
    var $pictureContainer = $(".picture-container");
    var $image = $(".image");
    var $close = $(".close");
    var $fileInput = $("#fileInput");
    var $defaultIcon = $("#defaultIcon");
    var $form = $("#updateStaffForm");
    var $photoValid = $(".photo-valid");
    var $messageValid = $(".message-valid");
    var $staffPicture = $("#staffPicture");

    console.log($staffPicture.attr("src"));

    $fileInput.on("change", function () {
        console.log($staffPicture.attr("src"));

        if ($staffPicture.attr("src") === "") {

            $staffPicture.prop("required", true);
        }
    });

    $close.removeClass("d-none");
    $pictureContainer.css("background-color", "transparent");
    $defaultIcon.addClass("d-none");

    $photoValid.addClass("valid");

    $messageValid.addClass("field-validation-valid");

    var kendoFields = [

        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

});