﻿$(document).ready(function () {

    //var $fileInput = $("#fileInput");

    //$fileInput.on("click", function () {
    //    $(this).prop("type", "file");
    //    console.log("alex");
    //});

    var $pictureContainer = $(".picture-container");
    var $image = $(".image");
    var $close = $(".close");
    var $fileInput = $("#fileInput");
    var $defaultIcon = $("#defaultIcon");
    var $form = $("#updateStaffForm");
    var $photoValid = $(".photo-valid");
    var $messageValid = $(".message-valid");

    $close.removeClass("d-none");
    $pictureContainer.css("background-color", "transparent");
    $defaultIcon.addClass("d-none");

    $photoValid.addClass("valid");

    $messageValid.addClass("field-validation-valid");
    $form.data("validator").settings.ignore = "";

});