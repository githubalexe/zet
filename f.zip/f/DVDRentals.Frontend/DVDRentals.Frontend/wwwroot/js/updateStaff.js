﻿$(document).ready(function () {

    var $fileInput = $("#fileInput");

    $fileInput.on("click", function () {
        $(this).prop("type", "file");
        console.log("alex");
    });
});