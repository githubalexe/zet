﻿$(document).ready(function () {

    var $fileInput = $("#fileInput");

    console.log("alex" + $fileInput.val());

    console.log($("#staff").val());
   
});