﻿$(document).ready(function () {
    
    var $staffId = $("#staffId");
    var $staffName = $("#staffName");
    var $deleteButton = $("#deleteStaffButton");
    var $customerDeleteContainer = $("#staffModalContainer");
    var $searchStaffRentalsContainer = $("#searchStaffRentalsContainer");

    setSearchItems();

    $deleteButton.on("click", function () {

        var options = {
            $container: $customerDeleteContainer,
            modelName: "<label class='active-entity'>" + $staffName.text() + "</label>",
            entity: "Staff",
            idsLength: 1,
            url: "/Staff/Delete",
            dataJson: {
                staffsIds: parseInt($staffId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Staff/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        };

        new DeleteModal(options);

        $("#deleteModal").modal("show");
    });

    function setSearchItems() {
        var options = {

            $container: $searchStaffRentalsContainer,
            $kendoGrid: $("#staffsPaymentsGrid"),
            filterButton: false,
            buttonFilters: [],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "RentalId",
                            operator: "eq",
                            value: 0
                        },
                        {
                            field: "FilmTitle",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "RentalDate",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "ReturnDate",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "PaymentDate",
                            operator: "contains",
                            value: "",
                        },
                        {
                            field: "Amount",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Customer",
                            operator: "contains",
                            value: "",
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }
});