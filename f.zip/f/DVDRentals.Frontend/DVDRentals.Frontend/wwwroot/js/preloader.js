﻿$(window).on("load", function () {
    $(this.document).addClass("slow");
});