﻿$(document).ready(function () {
    var $containerForm = $(".container-form");
    var $activeform = $("#actorActiveForm");
    var $actorNameContainer = $("#actorNameContainer");
    var $deleteActor = $("#deleteActor");
    var $actorDeleteContainer = $("#actorDeleteContainer");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $actorNameContainer.toggleClass("display-none");
    });

    $deleteActor.on("click", function () {
        var options = {
            $container: $actorDeleteContainer,
            kendoGrid: "actorsGrid",
            entity: "Actor",
            name: "Name",
            id: "ActorId",
            url: "Film/DeleteActor",
        }

        var $grid = $("#" + options.kendoGrid + " tr.k-state-selected");

        if ($grid.length > 0) {

            var modal = new DeleteModal(options);

            modal.getClickedItems();
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });


    $.ajax({
        type: "GET",
        url: "/Film/GetActors",
        contentType: "application/json; charset=utf-8",
        dataType: "json"
    })
        .done(function (data) {
            var s = "";
            for (var i = 0; i < data.length; i++) {
                s += "<option >" + data[i].FirstName + " " + data[i].LastName + "</option>";
            }

            $("#searchActor").html(s);
        })
        .fail(function () {
            console.log("fail");
        })

    $("#searchCustomer").on("change", function () {
        console.log("now");
    });
});