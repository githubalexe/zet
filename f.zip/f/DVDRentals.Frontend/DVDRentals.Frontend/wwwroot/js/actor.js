﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#actorActiveForm");
    var $actorNameContainer = $("#actorNameContainer");
    var $deleteActor = $("#deleteActor");
    var $actorDeleteContainer = $("#actorDeleteContainer");
    var $filmId = $("#filmId");
    var $filmTitle = $("#filmTitle");
    var $deleteButton = $("#deleteFilmButton");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $actorNameContainer.toggleClass("display-none");
    });

    $deleteActor.on("click", function () {

        var optionsGrid = {
            grid: "actorsGrid",
            id: "ActorId",
            name: "Name"
        }

        var entityGrid = new EntityGrid(optionsGrid);

        var numberOfIds = entityGrid.getSelectedIds();

        console.log(numberOfIds.length);

        var options = {
            $container: $actorDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Actor",
            idsLength: numberOfIds.length,
            url: "/Film/DeleteActor",
            dataJson: {
                filmId: parseInt($filmId.text()),
                actorIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            var modal = new DeleteModal(options);

            modal.appendText();
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });


    $deleteButton.on("click", function () {

        var options = {
            $container: $actorDeleteContainer,
            modelName: "<label class='active-entity'>" + $filmTitle.text() + "</label>",
            entity: "Film",
            idsLength: 1,
            url: "/Film/Delete",
            dataJson: {
                filmsIds: parseInt($filmId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Film/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        };

        new DeleteModal(options);

        $("#deleteModal").modal("show");
    });


    //$.ajax({
    //    type: "GET",
    //    url: "/Film/GetActors",
    //    contentType: "application/json; charset=utf-8",
    //    dataType: "json"
    //})
    //    .done(function (data) {
    //        var s = "";
    //        for (var i = 0; i < data.length; i++) {
    //            s += "<option >" + data[i].FirstName + " " + data[i].LastName + "</option>";
    //        }

    //        $("#searchActor").html(s);
    //    })
    //    .fail(function () {
    //        console.log("fail");
    //    })

    //$("#searchCustomer").on("change", function () {
    //    console.log("now");
    //});
});