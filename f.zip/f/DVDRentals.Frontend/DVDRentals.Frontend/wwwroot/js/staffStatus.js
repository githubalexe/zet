﻿$(document).ready(function () {

    var $activeStaffStatus = $("#activeStaffStatus");
    var $inactiveStaffStatus = $("#inactiveStaffStatus");
    var $staffModalContainer = $("#staffModalContainer");
    var $staffId = $("#staffId");
    var $staffName = $("#staffName");
    var $staffStatus = $("#staffStatus");

    setStatusButton();

    $activeStaffStatus.on("click", function () {

        var options = {
            $container: $staffModalContainer,
            entity: "staff",
            status: "active",
            name: $staffName.text(),
            url: "/Staff/UpdateStaffStatus",
            dataJson: {
                isActive: true,
                staffId: parseInt($staffId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Staff/StaffDetails/" + parseInt($staffId.html());
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");

    });

    $inactiveStaffStatus.on("click", function () {

        var options = {
            $container: $staffModalContainer,
            entity: "staff",
            status: "inactive",
            name: $staffName.text(),
            url: "/Staff/UpdateStaffStatus",
            dataJson: {
                isActive: false,
                staffId: parseInt($staffId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Staff/StaffDetails/" + parseInt($staffId.html());
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");

    });

    function setStatusButton() {

        if ($staffStatus.html() === "True") {
            alert.log("true");
            $activeStaffStatus.prop("disabled", true);
            $activeStaffStatus.removeClass("item-color");

        } else {
            alert.log("true");
            $inactiveStaffStatus.prop("disabled", true);
            $inactiveStaffStatus.removeClass("item-color");
        }

    }

});