﻿$(document).ready(function () {

    var $activeStaffStatus = $("#activeStaffStatus");
    var $inactiveStaffStatus = $("#inactiveSaffStatus");
    var $staffModalContainer = $("#staffModalContainer");
    var $staffId = $("#staffId");
    var $staffName = $("#staffName");
  

    $activeStaffStatus.on("click", function () {

        var options = {
            $container: $staffModalContainer,
            entity: "staff",
            status: "active",
            name: $staffName.text(),
            url: "/Staff/UpdateStaffStatus",
            dataJson: {
                isActive: true,
                staffId: parseInt($staffId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                //window.location.href = "/Customer/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");

    });

    $inactiveStaffStatus.on("click", function () {

        var options = {
            $container: $staffModalContainer,
            entity: "staff",
            status: "inactive",
            name: $staffName.text(),
            url: "/Staff/UpdateStaffStatus",
            dataJson: {
                isActive: false,
                staffId: parseInt($staffId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                //window.location.href = "/Customer/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");

    });
});