﻿$(document).ready(function () {
    $("#datetimepicker").kendoDatePicker({
        value: new Date(),
        format: 'MM/dd/yyyy'
    });
});