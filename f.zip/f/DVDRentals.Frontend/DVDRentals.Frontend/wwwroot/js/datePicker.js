﻿$(document).ready(function () {
    $(".k-icon").ready(function () {
        $(".k-icon").removeClass("k-i-calendar");
        $(".k-icon").addClass("fas fa-calendar-alt");
    });
});