﻿$(function () {

    DeleteModal = function (options) {

        this.$container = options.$container
        this.kendoGrid = options.kendoGrid;
        this.entity = options.entity;
        this.name = options.name;
        this.id = options.id;
        this.url = options.url;

        //rename this in case you only hold the IDs
        this.selectedItems = [];

        this.buildBody();
    }

    DeleteModal.prototype.buildBody = function () {
        var $grid = $("#" + this.kendoGrid + " tr.k-state-selected");
        var entityOption = "";

        if ($grid.length > 1) {
            entityOption = this.entity + "s";
        }
        else {
            entityOption = this.entity;
        }

        var modalBody =
            `<div class="container">
                <div id="deleteModal" role="dialog" class="modal fade" data-backdrop="static">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title selected-items">Delete ${entityOption} </h5>
                            </div>
                            <div class="modal-body">
                                <label class="selected-items">WARNING: ${entityOption} </label >
                                <label> will be deleted.&nbspThere is no way to recover the ${entityOption.charAt(0).toLowerCase() + entityOption.slice(1)} after delition.</label>
                            </div>
                            <div class="modal-footer">
                                <div class="container text-right px-3 pb-4">
                                    <hr />
                                    <button type="button" data-dismiss="modal" id="cancelButton" class="btn modal-button cancel">Cancel</button>
                                    <button type="submit" data-dismiss="modal" id="deleteButton" form="customerCreateForm" class="btn modal-button submit delete">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`

        this.$container.append(modalBody);
    }

    DeleteModal.prototype.getClickedItems = function () {
        var self = this;
        var title = "";
        var $grid = $("#" + self.kendoGrid + " tr.k-state-selected");
        var $kendoGridData = $("#" + self.kendoGrid).data("kendoGrid");

        self.selectedItems = [];

        for (var i = 0; i < $grid.length; i++) {
            var item = $kendoGridData.dataItem($grid[i]);

            self.selectedItems.push(item[self.id]);

            if (i === $grid.length - 1) {

                title += "<label class='active-entity'>" + item[self.name] + "&nbsp" + "</label>";
            }
            else {
                title += "<label class='active-entity'>" + item[self.name] + ",&nbsp" + "</label>";
            }
        }
        $(".selected-items").append(title);
        console.log(JSON.stringify($kendoGridData.selectedKeyNames()));
    }

    DeleteModal.prototype.clean = function () {
        $kendoGridData = $("#" + this.kendoGrid).data("kendoGrid");
        $(".active-entity").remove();
        $kendoGridData.clearSelection();
    }

    DeleteModal.prototype.deleteItems = function () {
        var self = this;

        $("#deleteButton").on("click", function () {

            for (var i = 0; i < self.selectedItems.length; i++) {

                self.deleteItem(self.selectedItems[i]);
            }
        });
    }

    DeleteModal.prototype.cancelEvent = function () {
        var self = this;
        $kendoGridData = $("#" + self.kendoGrid).data("kendoGrid");

        $("#cancelButton").on("click", function () {
            $kendoGridData.clearSelection();
            $(".modal-backdrop").remove(".show");
            $(".container").remove();
        });
    }

    DeleteModal.prototype.deleteItem = function (id) {
        var self = this;
        $.ajax({
            type: "DELETE",
            url: self.url + id
        })
            .done(function () {
                $("#" + self.kendoGrid).data("kendoGrid").refresh();
                $("#" + self.kendoGrid).data("kendoGrid").dataSource.read();
            })
            .fail(function () {
                console.log("Something is wrong");
            })
    }

    myModeal.deleteItemV2({
        myProp: value,
        myProp2: something
    });

    DeleteModal.prototype.deleteItemV2 = function (jsonData) {
        var self = this;
        $.ajax({
            type: "DELETE",
            url: self.url,
            data: jsonData
        })
            .done(function () {
                $("#" + self.kendoGrid).data("kendoGrid").refresh();
                $("#" + self.kendoGrid).data("kendoGrid").dataSource.read();
            })
            .fail(function () {
                console.log("Something is wrong");
            })
    }
}());