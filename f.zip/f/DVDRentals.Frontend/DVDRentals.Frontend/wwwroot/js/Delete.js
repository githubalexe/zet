﻿$(function () {

    DeleteModal = function (options) {
        this.options = $.extend({}, true, DeleteModal.options, options);

        this.buildBody();
        this.appendText();
        this.deleteItems();
        this.cancelEvent();
    };

    DeleteModal.prototype.buildBody = function () {

        var entityOption = "";

        if (this.options.idsLength > 1) {
            entityOption = this.options.entity + "s";
        }
        else {
            entityOption = this.options.entity;
        }

        var modalBody =
            `<div class="container">
                <div id="deleteModal" role="dialog" class="modal fade" data-backdrop="static">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title ">Delete ${entityOption} </h5>
                            </div>
                            <div class="modal-body">
                                <label class="selected-items">WARNING: ${entityOption} </label >
                                <label> will be deleted.&nbspThere is no way to recover the ${entityOption.charAt(0).toLowerCase() + entityOption.slice(1)} after delition.</label>
                            </div>
                            <div class="modal-footer">
                                <div class="container text-right px-3 pb-4">
                                    <hr />
                                    <button type="button" data-dismiss="modal" id="cancelButton" class="btn modal-button cancel">Cancel</button>
                                    <button type="submit" data-dismiss="modal" id="deleteButton" form="customerCreateForm" class="btn modal-button submit delete">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`

        this.options.$container.append(modalBody);
    };

    DeleteModal.prototype.appendText = function () {
        $(".selected-items").append(this.options.modelName);
    };

    DeleteModal.prototype.deleteItems = function () {
        var self = this;

        $("#deleteButton").on("click", function () {
            self.deleteItemV2();
        });
    };

    DeleteModal.prototype.cancelEvent = function () {
        var self = this;

        $("#cancelButton").on("click", function () {
            self.options.onCancel();
        });
    };

    DeleteModal.prototype.deleteItemV2 = function () {
        var self = this;
        return $.ajax({
            type: "POST",
            url: this.options.url,
            data: this.options.dataJson,
        })
            .done(function () {
                self.options.onSucces();
            })
            .fail(function () {
                self.options.onFail();
            })
    };

    DeleteModal.options = {
        $container: $({}),
        entity: $({}),
        idsLength: $({}),
        modelName: $({}),
        url: $({}),
        dataJson: $({}),
        onCancel: $({}),
        onSucces: $({}),
        onFail: $({})
    };

}());