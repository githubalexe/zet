﻿$(function () {

    DeleteModal = function (options) {
        var self = this;

        self.$container = options.$container;
        self.header=options.header,
        self.entity=options.entity

        self.buildBody();
    }

    DeleteModal.prototype.buildBody = function () { 
        //${ }-- se pune la label
   
        var modalBody =
            `<div class="container">
                <div id="dummyModal" role="dialog" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Delete ${this.header}</h5>
                            </div>
                            <div class="modal-body">
                                <p>WARNING: ${this.entity} will be deleted.There is no way to recover the ${this.entity} after delition.</p>
                            </div>
                            <div class="modal-footer">
                                <div class="container text-right px-3 pb-4">
                                    <hr />
                                    <button type="button" data-dismiss="modal" class="btn modal-button cancel">Cancel</button>
                                    <button type="submit" form="customerCreateForm" class="btn modal-button submit create">Delete</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`

        this.$container.append(modalBody);
    }

    DeleteModal.prototype.deleteItem = function () {

    }

}());