﻿$(document).ready(function () {

    var $form = $("#inventoryAddForm");
    $form.data("validator").settings.ignore = "";

});