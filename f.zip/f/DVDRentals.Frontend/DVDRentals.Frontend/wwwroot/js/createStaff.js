﻿$(document).ready(function () {

    var $form = $("#createStaffForm");
    $form.data("validator").settings.ignore = "";
});