﻿$(document).ready(function () {

    var $imageInput = $("#fileInput");
    var $imageContainer = $("#fileDisplayArea");
    var $pictureIcon = $("#pictureIcon");
    var $picture = $("#picture");
    var $createStaff = $("#createStaff");
    var $image = $(".image");
    var image = "";
    console.log($image.attr("src"));

    $imageInput.on("change", function (event) {
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            $(reader).on("load", function (e) {
                //var $close = $("<button/>", {
                //    class: "close",
                //});
                //var $image = $("<img/>", {
                //    class: "image",
                //    src: e.target.result
                //});
                //$picture.append($image);
                //$picture.append($close);
                //$imageContainer.append($picture);
                $image.attr("src", e.target.result);
                console.log(e.target.result);
            });
            reader.readAsDataURL(file);
        }
        $pictureIcon.addClass("d-none");
    });

    console.log(image);

    //$createStaff.on("click", function () {
    //    var $image = $(".image");
    //    console.log($image.text());
    //});

    var $close = $(".close");

    $close.on("click", function () {
        $(this).parent().remove();
        $imageInput.val() = "";
    });
});