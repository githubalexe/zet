﻿$(document).ready(function () {

    $(".picture-container").on("click", function () {
        $("#fileInput").click();
        console.log("merge");
    })
});