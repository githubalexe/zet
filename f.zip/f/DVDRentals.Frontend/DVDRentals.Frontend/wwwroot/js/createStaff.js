﻿$(document).ready(function () {

    var $imageInput = $("#fileInput");
    var $imageContainer = $("#fileDisplayArea");
    var $pictureIcon = $("#pictureIcon");
    var $picture = $("#picture");
    var $createStaff = $("#createStaff");


    $imageInput.on("change", function (event) {
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            var reader = new FileReader();
            $(reader).on("load", function (e) {
                var $close = $("<button/>", {
                    class: "close",
                });
                var $image = $("<img/>", {
                    class: "image",
                    src: e.target.result
                });
                $picture.append($image);
                $picture.append($close);
                $imageContainer.append($picture);
            });
            reader.readAsDataURL(file);
        }
        $pictureIcon.addClass("d-none");
    });

    $createStaff.on("click", function () {
        console.log("alex");
    });

    var $close = $(".close");

    $close.on("click", function () {
        console.log("alex");
        $(this).parent().remove();
        $imageInput.val() = "";
    });
});