﻿$(document).ready(function () {

    $(".image").on("click", function () {
        $("#fileInput").click();
        console.log("merge");
    })
});