﻿$(document).ready(function () {

    var $searchContainer = $("#searchCustomerRentalsContainer");
    var $searchButton = $("#searchFilterButton");

    setSearchItems();

    function setSearchItems() {
        var options = {

            $container: $searchContainer,
            $kendoGrid: $("#customerPaymentsGrid"),
            filterButton: false,
            buttonFilters: [],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "RentalId",
                            operator: "eq",
                            value: 0
                        },
                        {
                            field: "FilmTitle",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "RentalDate",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "ReturnDate",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "PaymentDate",
                            operator: "contains",
                            value: "",
                        },
                        {
                            field: "Amount",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Staff",
                            operator: "contains",
                            value: "",
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }
    $searchButton.css("display","none");
});