﻿$(document).ready(function () {

    var activeNavLink = "active-nav-link";
    var $navLink = $(".nav-link");
    var $toggleButton = $(".toggle-button");

    $toggleButton.on({
        click: function () {
            $(this).addClass("button-color");
        },
        focusout: function () {
            $(this).removeClass("button-color");
        }
    });

    $navLink.on("click", function () {
        $navLink.removeClass(activeNavLink);
        $(this).addClass(activeNavLink);
    });

    setSidebar();

    function setSidebar() {
        var path = window.location.pathname;
        path = decodeURIComponent(path);

        $(".sidebar a").each(function () {
            var href = $(this).attr('href');

            if (path.substring(0, href.length) === href) {
                $(this).parent().addClass("active-button");
            }
        });
    }
});
