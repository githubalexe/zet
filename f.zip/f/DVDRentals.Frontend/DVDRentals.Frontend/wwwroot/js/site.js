﻿$(document).ready(function () {
    $('.nav-button').on('click', function () {
        $('.nav-button').removeClass('active-nav-button');
        $(this).addClass('active-nav-button');
        console.log("buton");
    });

    $('.nav-link').on('click', function () {
        $('.nav-link').removeClass('active-nav-link');
        $(this).addClass('active-nav-link');
    });


});
