﻿$(document).ready(function () {

    $(".nav-link").on("click", function () {
        $(".nav-link").removeClass("active-nav-link");
        $(this).addClass("active-nav-link");
    });

    $(".cud-button").on("click"){
        $.ajax({
            
        });
    }

    setSidebar();

    function setSidebar() {
        var path = window.location.pathname;
        path = decodeURIComponent(path);

        $(".sidebar a").each(function () {
            var href = $(this).attr('href');
            if (path.substring(0, href.length) === href) {
                $(this).closest("li").addClass("active-button");
            }
        });
    }
});
