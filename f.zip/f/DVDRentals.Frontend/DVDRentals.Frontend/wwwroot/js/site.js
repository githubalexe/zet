﻿$(document).ready(function () {
    var $rentalButton = $("#rentalButton");
    var $customerButton = $("#customerButton");
    var $staffButton = $("#staffButton");
    var $inventoryButton = $("#inventoryButton");
    var $filmButton = $("#filmButton");
    var $storeButton = $("#storeButton");

    var rentalPath = "/Rental";
    var customerPath = "/Customer";
    var staffPath = "/Staff";
    var inventoryPath = "/Inventory";
    var filmPath = "/Film/Index";
    var StaffPath = "/Staff/Index";

    $(".nav-link").on("click", function () {
        $(".nav-link").removeClass("active-nav-link");
        $(this).addClass("active-nav-link");
    });


    setPath(customerPath, $customerButton);
    setPath(rentalPath, $rentalButton);
    setPath(staffPath, $staffButton);
    setPath(inventoryPath, $inventoryButton);

    function setPath(path, button) {
        if (window.location.pathname == path) {
            button.addClass("active-button")
                .css("color", "#FFFFFF");
        }
    }



    //if (window.location.pathname == "/Customer/CustomersList") {
    //    $("#customerButton").addClass("active-button")
    //        .css("color", "#FFFFFF");
    //}
    setNavigation();

    function setNavigation() {
        var path = window.location.pathname;
        path = decodeURIComponent(path);

        $(".nav-button").each(function () {
            var href = $(this).attr('href');
        });
    }
});
