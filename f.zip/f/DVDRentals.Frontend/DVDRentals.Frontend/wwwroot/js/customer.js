﻿$(document).ready(function () {

    var $deleteCustomer = $("#deleteCustomer");
    var $customersSearchContainer = $("#customersSearchContainer");
    var $customerDeleteContainer = $("#customerDeleteContainer");

    setSearchItems();

    $deleteCustomer.on("click", function () {

        var optionsGrid = {
            grid: "customersGrid",
            id: "CustomerId",
            name: "Name"
        }

        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $customerDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Customer",
            idsLength: numberOfIds.length,
            url: "/Customer/Delete",
            dataJson: {
                customersIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            var modal = new DeleteModal(options);

            modal.appendText();
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });


    function setSearchItems() {
        var options = {
            $container: $customersSearchContainer,
            $kendoGrid: $("#customersGrid"),
            searchField: "Name",
            buttonFilters: [
                { field: "Name", operator: "contains", value: "", display: "All" },
                { field: "Active", operator: "eq", value: true, display: "Active" },
                { field: "Active", operator: "eq", value: false, display: "Inactive" }
            ]
        }

        new SearchLabel(options);
    }

});