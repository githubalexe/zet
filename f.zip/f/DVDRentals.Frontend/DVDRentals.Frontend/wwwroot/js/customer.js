﻿$(document).ready(function () {
    var $customerCreateForm = $("#customerCreateForm");
    var $createButton = $(".create");

    $createButton.on("click", function () {
        console.log($customerCreateForm);
    });

});