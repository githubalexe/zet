﻿$(document).ready(function () {
    var $customerCreateForm = $("#customerCreateForm");
    var $createButton = $(".create");

    $createButton.on("click", function () {
        console.log($customerCreateForm);
    });

    var $deleteFilm = $("#deleteCustomer");



    $deleteFilm.on("click", function () {
        var $options = {
            $container: $("#customerDeleteContainer"),
            kendoGrid: "customersGrid",
            entity: "Customer",
            name: "Name",
            id: "CustomerId",
            url: "/Customer/Delete/",
        }

        var $grid = $("#" + $options.kendoGrid + " tr.k-state-selected");

        if ($grid.length > 0) {

            var modal = new DeleteModal($options);

            modal.getClickedItems()
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });


    $(".search").on("keyup",function () {
        var val = $('.search').val();
        $("#customersGrid").data("kendoGrid").dataSource.filter({
            logic: "and",
            filters: [
                { field: "Name", operator: "contains", value: val },
                { field: "Active", operator: "eq", value: false }
            ]
        });
    });


});