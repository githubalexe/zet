﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteCustomer");
    var $customersSearchContainer = $("#customersSearchContainer")

    setSearchItems();

    $deleteFilm.on("click", function () {
        var $options = {
            $container: $("#customerDeleteContainer"),
            kendoGrid: "customersGrid",
            entity: "Customer",
            name: "Name",
            id: "CustomerId",
            url: "/Customer/Delete/",
        }

        var $grid = $("#" + $options.kendoGrid + " tr.k-state-selected");

        if ($grid.length > 0) {

            var modal = new DeleteModal($options);

            modal.getClickedItems()
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {
            $container: $customersSearchContainer,
            $kendoGrid: $("#customersGrid"),
            searchField: "Name",
            buttonFilters: [
                { field: "Name", operator: "contains", value: "", display: "All" },
                { field: "Active", operator: "eq", value: true, display: "Active" },
                { field: "Active", operator: "eq", value: false, display: "Inactive" }
            ]
        }

        new SearchLabel(options);
    }

});