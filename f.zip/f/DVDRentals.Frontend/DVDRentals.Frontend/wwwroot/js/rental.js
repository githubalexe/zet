﻿$(document).ready(function () {
    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $deleteRental = $("#deleteRental");
    var $rentalDeleteContainer = $("#rentalDeleteContainer");
    var $searchRentalContainer = $("#rentalSearchContainer");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");
    });

    $deleteRental.on("click", function () {
        var $options = {
            $container: $rentalDeleteContainer,
            kendoGrid: "rentalsGrid",
            entity: "Rental",
            name: "RentalId",
            id: "RentalId",
            url: "/Rental/Delete/",
        }

        var $grid = $("#" + $options.kendoGrid + " tr.k-state-selected");

        if ($grid.length > 0) {

            var modal = new DeleteModal($options);

            modal.getClickedItems()
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });

});