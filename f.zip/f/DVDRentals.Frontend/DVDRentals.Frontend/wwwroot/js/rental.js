﻿$(document).ready(function () {
    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $deleteRental = $("#deleteRental");
    var $rentalDeleteContainer = $("#rentalDeleteContainer");
    var $searchRentalContainer = $("#rentalSearchContainer");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");
    });

    $deleteRental.on("click", function () {

        var optionsGrid = {
            grid: "rentalsGrid",
            id: "RentalId",
            name: "RentalId"
        }

        var entityGrid = new EntityGrid(optionsGrid);

        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $rentalDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Rental",
            idsLength: numberOfIds.length,
            url: "/Rental/Delete",
            dataJson: {
                rentalsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            var modal = new DeleteModal(options);

            modal.appendText();
            modal.deleteItems();
            modal.cancelEvent();

            $("#deleteModal").modal("show");
        }
    });

});