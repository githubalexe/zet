﻿$(function () {

    SearchLabel = function (options) {
        var self = this;

        self.$container = options.$container
        self.$kendoGrid = options.$kendoGrid;

        self.buildBody();
        self.setButton();
    }

    SearchLabel.prototype.buildBody = function () {

        var searchBody = `<div class="btn-group float-sm-left search-button">
                            <button type="button" class="btn button" id="filterButton">All</button>
                            <button type="button" class="btn dropdown-toggle dropdown-toggle-split button toggle-button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-button"></div>
                        </div>`



        this.$container.append(searchBody);
    }

    SearchLabel.prototype.setButton = function () {

    }

}());