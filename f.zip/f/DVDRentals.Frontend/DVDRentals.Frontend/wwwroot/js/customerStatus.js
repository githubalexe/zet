﻿$(document).ready(function () {

    var $activeCustomerStatus = $("#activeCustomerStatus");
    var $inactiveCustomerStatus = $("#inactiveCustomerStatus");
    var $customerModalContainer = $("#customerModalContainer");
    var $customerId = $("#customerId");
    var $customerName = $("#customerName");
    var $customerStatus = $("#customerStatus");

    setStatusButton();

    $activeCustomerStatus.on("click", function () {

        var options = {
            $container: $customerModalContainer,
            entity: "Customer",
            status: "active",
            name: $customerName.text(),
            url: "/Customer/UpdateCustomerStatus",
            dataJson: {
                isActive: true,
                customerId: parseInt($customerId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Customer/CustomerDetails/" + parseInt($customerId.html());
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");

    });

    $inactiveCustomerStatus.on("click", function () {

        var options = {
            $container: $customerModalContainer,
            entity: "Customer",
            status: "inctive",
            name: $customerName.text(),
            url: "/Customer/UpdateCustomerStatus",
            dataJson: {
                isActive: false,
                customerId: parseInt($customerId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Customer/CustomerDetails/" + parseInt($customerId.html());
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");

    });

    function setStatusButton() {

        if ($customerStatus.html() === "True") {

            $activeCustomerStatus.prop("disabled", true);
            $activeCustomerStatus.removeClass("item-color");

        } else {

            $inactiveCustomerStatus.prop("disabled", true);
            $inactiveCustomerStatus.removeClass("item-color");
        }

    }
});