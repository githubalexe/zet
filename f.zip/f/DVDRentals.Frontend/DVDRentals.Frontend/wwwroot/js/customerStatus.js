﻿$(document).ready(function () {

    var $activeCustomerStatus = $("#activeCustomerStatus");
    var $inactiveCustomerStatus = $("#inactiveCustomerStatus");
    var $customerModalContainer = $("#customerModalContainer");
    var $customerId = $("#customerId");
    var $customerName = $("#customerName");


    $activeCustomerStatus.on("click", function () {

        var options = {
            $container: $customerModalContainer,
            entity: "customer",
            status: "active",
            name: $customerName.text(),
            url: "/Customer/UpdateCustomerStatus",
            dataJson: {
                isActive: true,
                customerId: parseInt($customerId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                //window.location.href = "/Customer/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");

    });

    $inactiveCustomerStatus.on("click", function () {

        var options = {
            $container: $customerModalContainer,
            entity: "customer",
            status: "inactive",
            name: $customerName.text(),
            url: "/Customer/UpdateCustomerStatus",
            dataJson: {
                isActive: false,
                customerId: parseInt($customerId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                //window.location.href = "/Customer/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        new StatusModal(options);

        $("#statusModal").modal("show");


    });
});