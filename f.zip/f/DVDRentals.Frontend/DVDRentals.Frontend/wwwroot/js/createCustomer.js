﻿$(document).ready(function () {

    var $form = $('#customerCreateForm');

    ///kendo country
    var $countryId = $("#countryId");
    var $cityId = $("#cityId");

    $cityId.kendoComboBox({
        placeholder: "Select City",
    });


    $countryId.on("change", function () {

        var countryId = $(this).val();

        if ($.isNumeric(countryId)) {

            $cityId.data("kendoComboBox").setDataSource();
            getCountries(countryId);


        }
        else {
            $cityId.data("kendoComboBox").setDataSource();
        }


    });


    function getCountries(countryIdValue) {

        $cityId.kendoComboBox({
            dataTextField: "Name",
            dataValueField: "CityId",
            dataSource: {
                transport: {
                    read: {
                        url: "/Country/GetCitiesByCountry",
                        data: {
                            countryId: countryIdValue
                        }
                    }
                }
            },
            filter: "contains",
            placeholder: "Select City",
            autoBind: false,
        });
    }

    ///////////////////////////////

    var kendoFields = [

        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

})