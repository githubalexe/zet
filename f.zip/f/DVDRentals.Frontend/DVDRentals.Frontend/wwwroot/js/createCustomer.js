﻿$(document).ready(function () {

    var $form = $('#customerCreateForm');

    var kendoFields = [

        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

})