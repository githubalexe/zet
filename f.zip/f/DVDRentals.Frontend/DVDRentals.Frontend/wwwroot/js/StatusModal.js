﻿$(function () {

    StatusModal = function (options) {
        this.options = $.extend({}, true, StatusModal.options, options);

        this.buildBody();
        this.onEditStatus();
        this.cancelEvent();
    };

    StatusModal.prototype.buildBody = function () {

        var modalBody =
            `<div class="container">
                <div id="statusModal" role="dialog" class="modal fade" data-backdrop="static">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title selected-items">Change Status </h5>
                            </div>
                            <div class="modal-body">
                                <label class="selected-items">Are you sure you want to ${this.options.status}  ${this.options.entity}  ${this.options.name} ?</label >
                            </div>
                            <div class="modal-footer">
                                <div class="container text-right px-3 pb-4">
                                    <hr />
                                    <button type="button" data-dismiss="modal" id="cancelStatusButton" class="btn modal-button cancel">No</button>
                                    <button type="submit" data-dismiss="modal" id="okStatusButton"  class="btn modal-button submit delete">Yes</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`

        this.options.$container.append(modalBody);
    };

    StatusModal.prototype.cancelEvent = function () {
        var self = this;

        $("#cancelStatusButton").on("click", function () {
            self.options.onCancel();
        });
    };

    StatusModal.prototype.onEditStatus = function () {
        var self = this;

        $("#okStatusButton").on("click", function () {
            self.editStatus();
        });
    };

    StatusModal.prototype.editStatus = function () {
        var self = this;
        return $.ajax({
            type: "POST",
            url: this.options.url,
            data: this.options.dataJson,
        })
            .done(function () {
                self.options.onSucces();
            })
            .fail(function () {
                self.options.onFail();
            })
    };

    StatusModal.options = {
        $container: $({}),
        entity: $({}),
        status: $({}),
        name: $({}),
        url: $({}),
        dataJson: $({}),
        onCancel: $({}),
        onSucces: $({}),
        onFail: $({})
    };

}());