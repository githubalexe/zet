﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.User
{
    public class StaffUser
    {
        public static int StoreId { get; set; }
        public static int StaffId { get; set; }
        public static string FirstName { get; set; }
        public static byte[]  Picture { get; set; }
    }
}
