﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Film;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmActorExtensionMethods
    {
        public static FilmActor ToFilmActorModel(this AddActorFilmCreateRequest request)
        {
            return new FilmActor()
            {
                FilmId = request.FilmId,
                ActorId = request.ActorId
            };;
        }

        public static FilmActorResponse  ToFilmActorResponse (this FilmActor filmActor)
        {
            return new FilmActorResponse()
            {
                FilmId = filmActor.FilmId,
                ActorId = filmActor.ActorId,
                LastUpdate = filmActor.LastUpdate
            };
        }
    }
}
