﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;

namespace DVDRentals.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static StaffResponse ToStaffResponse(this Staff staff)
        {
            StaffResponse staffResponse = new StaffResponse()
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                AddressId = staff.AddressId,
                Picture = staff.Picture,
                Email = staff.Email,
                StoreId = staff.StoreId,
                Active = staff.Active,
                Username = staff.Username,
                Password = staff.Password,
                LastUpdate = staff.LastUpdate
            };

            staffResponse.Address = staff.Address.ToAddressResponse();
            staffResponse.Address.City = staff.Address.City.ToCityResponse();
            staffResponse.Address.City.Country = staff.Address.City.Country.ToCountryResponseLite();

            return staffResponse;
        }

        public static Staff ToStaffModel(this StaffCreateRequest request, int storeId)
        {
            return new Staff()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                AddressId = request.AddressId,
                Picture = request.Picture,
                Email = request.Email,
                StoreId = storeId,
                Active = request.Active,
                Username = request.Username,
                Password = request.Password
            };
        }
        public static Staff ToStaffModel(this StaffUpdateRequest request, Staff staff, int storeId)
        {
            staff.FirstName = request.FirstName;
            staff.LastName = request.LastName;
            staff.AddressId = request.AddressId;
            staff.Picture = request.Picture;
            staff.Email = request.Email;
            staff.StoreId = storeId;
            staff.Active = request.Active;
            staff.Username = request.Username;
            staff.Password = request.Password;

            return staff;
        }

        public static StaffResponseLite ToStaffResponseLite(this Staff staff)
        {
            return new StaffResponseLite()
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                AddressId = staff.AddressId,
                Picture = staff.Picture,
                Email = staff.Email,
                StoreId = staff.StoreId,
                Active = staff.Active,
                Username = staff.Username,
                Password = staff.Password,
                LastUpdate = staff.LastUpdate
            };
        }

        public static StaffPaymentsResponseLite ToStaffPaymentsResponse(this Staff staff)
        {
            return new StaffPaymentsResponseLite()
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName
            };
        }

        public static StaffPaymentsResponseLite ToStaffPaymentListResponse(this Staff staff, List<StaffPaymentsResponse> paymentResponseList)
        {
            StaffPaymentsResponseLite staffResponse = staff.ToStaffPaymentsResponse();
            staffResponse.Payments = paymentResponseList;

            return staffResponse;
        }

        public static string GetStaffName(this Staff staff)
        {
            string name = string.Empty;

            name = String.Format("{0} {1}", staff.FirstName, staff.LastName);

            return name;
        }
    }
}
