﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Inventory;
using DVDRentals.Domain;

namespace DVDRentals.ExtensionMethods
{
    public static class InventoryExtentionMethods
    {
        public static Inventory ToInventoryModel(this InventoryCreateRequest request, int storeId)
        {
            return new Inventory()
            {
                StoreId = storeId,
                FilmId = request.FilmId
            };
        }

        public static InventoryResponseLite ToInventoryResponseLite(this Inventory inventory)
        {
            return new InventoryResponseLite()
            {
                InventoryId = inventory.InventoryId,
                StoreId = inventory.StoreId,
                FilmId = inventory.FilmId,
                LastUpdate = inventory.LastUpdate
            };
        }

        public static InventoryResponse ToInventoryResponse(this Inventory inventory, FilmResponseLite film)
        {
            return new InventoryResponse()
            {
                InventoryId = inventory.InventoryId,
                FilmId = inventory.FilmId,
                StoreId = inventory.StoreId,
                Film = film
            };
        }
    }
}
