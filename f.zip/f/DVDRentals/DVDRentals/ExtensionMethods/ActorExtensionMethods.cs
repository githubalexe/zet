﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;

namespace DVDRentals.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static ActorResponseLite ToActorResponseLite(this Actor actor)
        {
            return new ActorResponseLite()
            {
                ActorId = actor.ActorId,
                FirstName = actor.FirstName,
                LastName = actor.LastName,
                Name = actor.GetName(),
                LastUpdate = actor.LastUpdate
            };
        }

        public static List<ActorResponseLite> ToActorResponseList(this IEnumerable<FilmActor> actorList)
        {
            List<ActorResponseLite> actorResponseList = new List<ActorResponseLite>();

            foreach (FilmActor filmActor in actorList)
            {
                actorResponseList.Add(filmActor.Actor.ToActorResponseLite());
            }

            return actorResponseList;
        }
        public static Actor ToActorModel(this ActorCreateRequest request)
        {
            return new Actor()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
            };
        }

        public static Actor ToActorModel(this ActorUpdateRequest request, Actor actor)
        {
            actor.FirstName = request.FirstName;
            actor.LastName = request.LastName;

            return actor;
        }

        public static string GetName(this Actor actor)
        {
            string name = String.Format("{0} {1}", actor.FirstName, actor.LastName);

            return name;
        }
    }
}
