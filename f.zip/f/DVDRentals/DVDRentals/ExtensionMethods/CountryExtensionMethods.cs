﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Country;
using DVDRentals.Domain;

namespace DVDRentals.ExtensionMethods
{
    public static class CountryExtensionMethods
    {
        public static CountryResponseLite ToCountryResponseLite(this Country country)
        {
            return new CountryResponseLite()
            {
                CountryId = country.CountryId,
                Name = country.Country1,
                LastUpdate = country.LastUpdate
            };
        }

        public static Country ToCountryModel(this CountryCreateRequest request)
        {
            return new Country
            {
                Country1 = request.Country
            };
        }

        public static Country ToCountryModel(this CountryUpdateRequest request, Country country)
        {
            country.Country1 = request.Country;

            return country;
        }
    }
}
