﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Category;
using DVDRentals.Domain;

namespace DVDRentals.ExtensionMethods
{
    public static class CategoryExtensionMethods
    {
        public static CategoryResponseLite ToCategoryResponseLite(this Category category)
        {
            if (category == null)
            {
                return null;
            }
            else
            {
                return new CategoryResponseLite()
                {
                    CategoryId = category.CategoryId,
                    Name = category.Name,
                    LastUpdate = category.LastUpdate
                };
            }
        }

        public static Category ToCategoryModel(this CategoryCreateRequest request)
        {
            return new Category()
            {
                Name = request.Name
            };
        }
    }
}
