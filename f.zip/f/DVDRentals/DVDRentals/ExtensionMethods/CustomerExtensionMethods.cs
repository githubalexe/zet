﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Payment;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;

namespace DVDRentals.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerResponse ToCustomerResponse(this Customer customer)
        {
            CustomerResponse customerResponse = new CustomerResponse()
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                LastUpdate = customer.LastUpdate
            };

            customerResponse.Address = customer.Address.ToAddressResponse();
            customerResponse.Address.City = customer.Address.City.ToCityResponse();
            customerResponse.Address.City.Country = customer.Address.City.Country.ToCountryResponseLite();

            return customerResponse;
        }
        public static Customer ToCustomerModel(this CustomerCreateRequest request, int storeId)
        {
            return new Customer()
            {
                StoreId = storeId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                AddressId = request.AddressId,
                Active = request.Active,
                CreateDate = request.CreateDate
            };

        }
        public static Customer ToCustomerModel(this CustomerUpdateRequest request, Customer customer, int storeId)
        {
            customer.StoreId = storeId;
            customer.FirstName = request.FirstName;
            customer.LastName = request.LastName;
            customer.Email = request.Email;
            customer.AddressId = request.AddressId;
            customer.Active = request.Active;
            //customer.CreateDate = request.CreateDate;

            return customer;
        }
        public static CustomerResponseLite ToCustomerResponseLite(this Customer customer)
        {
            return new CustomerResponseLite()
            {
                CustomerId = customer.CustomerId,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                LastUpdate = customer.LastUpdate
            };

        }
        public static CustomerNameResponse ToCustomerPaymentResponse(this Customer customer)
        {
            return new CustomerNameResponse()
            {
                CustomerId = customer.CustomerId,
                Name = customer.GetCustomerName()
            };
        }
        public static CostomerPaymentsResponseLite ToCustomerPaymentsResponse(this Customer customer)
        {
            return new CostomerPaymentsResponseLite()
            {
                CustomerId = customer.CustomerId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
            };
        }
        public static CostomerPaymentsResponseLite ToCustomerPaymentListResponse(this Customer customer, List<CustomerPaymentsResponse> paymentResponseList)
        {
            CostomerPaymentsResponseLite customerResponse = customer.ToCustomerPaymentsResponse();
            customerResponse.Payments = paymentResponseList;

            return customerResponse;
        }

        public static string GetCustomerName(this Customer customer)
        {
            string name = string.Empty;

            name = String.Format("{0} {1}", customer.FirstName, customer.LastName);

            return name;
        }

        //public static CustomerResponse ToCustomerResponse(this Customer customer, Address address)
        //{
        //    CustomerResponse customerResponse = new CustomerResponse
        //    {
        //        Active = customer.Active,
        //        Address = new AddressResponse
        //        {
        //            City = new CityResponse
        //            {
        //                Country = new CountryResponse
        //                {
        //                    Country1 = address.City.Country.Country1
        //                }
        //            }
        //        }
        //    };

        //    return customerResponse;
        //}
    }
}
