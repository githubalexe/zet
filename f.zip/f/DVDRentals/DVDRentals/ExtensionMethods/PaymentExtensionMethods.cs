﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Staff;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class PaymentExtensionMethods
    {
        public static CustomerPaymentsResponse ToCustomerPaymentResponse(this Payment payment)
        {
            return new CustomerPaymentsResponse()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                Rental = payment.Rental.ToRentalResponse(),
                Staff = payment.Staff.ToStaffPaymentResponse()
            };
        }

        public static List<CustomerPaymentsResponse> ToCustomerPaymentsResponse(this IEnumerable<Payment> paymentList)
        {
            List<CustomerPaymentsResponse> paymentReponseList = new List<CustomerPaymentsResponse>();

            foreach (Payment payment in paymentList)
            {
                if (payment.Staff != null && payment.Rental != null)
                {
                    paymentReponseList.Add(payment.ToCustomerPaymentResponse());
                }
            }

            return paymentReponseList;
        }

        public static StaffPaymentsResponse ToStaffPaymentResponse(this Payment payment)
        {
            return new StaffPaymentsResponse()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                Rental = payment.Rental.ToRentalResponse(),
                Customer = payment.Customer.ToCustomerPaymentResponse()
            };
        }

        public static StorePaymentsResponse ToStorePaymentResponse(this Payment payment)
        {
            return new StorePaymentsResponse()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                Rental = payment.Rental.ToRentalResponse(),
                Staff = payment.Staff.ToStaffPaymentResponse(),
                Customer = payment.Customer.ToCustomerPaymentResponse()
            };
        }

        public static Payment ToPaymentModel(this PaymentCreateRequest request)
        {
            return new Payment()
            {
                CustomerId = request.CustomerId,
                StaffId = request.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount,
                PaymentDate = request.PaymentDate
            };
        }

        public static Payment ToPaymentModel(this PaymentUpdateRequest request, Payment payment)
        {
            payment.CustomerId = request.CustomerId;
            payment.StaffId = request.StaffId;
            payment.RentalId = request.RentalId;
            payment.Amount = request.Amount;
            payment.PaymentDate = request.PaymentDate;

            return payment;
        }

        public static PaymentResponseLite ToPaymentResponse(this Payment payment)
        {
            return new PaymentResponseLite()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,
                LastUpdate = payment.LastUpdate
            };

        }

        public static StaffNameResponse ToStaffPaymentResponse(this Staff staff)//change method name
        {
            return new StaffNameResponse()
            {
                StaffId = staff.StaffId,
                Name= staff.GetStaffName()
            };
        }
    }
}
