﻿using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public interface IPaymentService
    {
        Task DeleteCustomerPaymentsAsync(int customerId);
        Task DeleteStaffPaymentsAsync(int staffId);
    }
}
