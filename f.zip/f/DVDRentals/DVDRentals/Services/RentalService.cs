﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class RentalService : IRentalService
    {
        private IRentalRepository _rentalRepository;

        public RentalService(IRentalRepository rentalRepository)
        {
            _rentalRepository = rentalRepository;
        }
        public async Task DeleteRentalsAsync(int inventoryId)
        {
            IQueryable<Rental> rentalsQuery = _rentalRepository.RentalsQuery();

            rentalsQuery = rentalsQuery.OrderBy(rental => rental.RentalId);

            IEnumerable<Rental> rentals = await _rentalRepository.InventoriesListAsync(rentalsQuery, inventoryId, true);

            if (rentals != null)
            {
                foreach (Rental rental in rentals)
                {
                    _rentalRepository.DeleteRental(rental);
                }
            }
        }

        public async Task DeleteCustomerRentalsAsync(int customerId)
        {
            IQueryable<Rental> rentalsQuery = _rentalRepository.RentalsQuery();

            rentalsQuery = rentalsQuery.OrderBy(rental => rental.RentalId);

            IEnumerable<Rental> rentals = await _rentalRepository.CustomersRentalsListAsync(rentalsQuery, customerId, false);

            if (rentals != null)
            {
                foreach (Rental rental in rentals)
                {
                    _rentalRepository.DeleteRental(rental);
                }
            }
        }

        public async Task DeleteStaffRentalsAsync(int staffId)
        {
            IQueryable<Rental> rentalsQuery = _rentalRepository.RentalsQuery();

            rentalsQuery = rentalsQuery.OrderBy(rental => rental.RentalId);

            IEnumerable<Rental> rentals = await _rentalRepository.StaffsRentalsListAsync(rentalsQuery, staffId, true);

            if (rentals != null)
            {
                foreach (Rental rental in rentals)
                {
                    _rentalRepository.DeleteRental(rental);
                }
            }
        }
    }
}
