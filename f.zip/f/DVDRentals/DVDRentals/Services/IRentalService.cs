﻿using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public interface IRentalService
    {
        Task DeleteRentalsAsync(int inventoryId);
        Task DeleteCustomerRentalsAsync(int customerId);
        Task DeleteStaffRentalsAsync(int staffId);
    }
}