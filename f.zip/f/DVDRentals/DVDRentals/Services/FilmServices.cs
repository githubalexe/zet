﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class FilmServices : IFilmServices
    {
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmActorRepository _filmActorRepository;
        private IInventoryRepository _inventoryRepository;
        private IRentalService _rentalService;

        public FilmServices(IFilmCategoryRepository filmCategoryRepository, IFilmActorRepository filmActorRepository, IInventoryRepository inventoryRepository, IRentalService rentalService)
        {
            _filmCategoryRepository = filmCategoryRepository;
            _filmActorRepository = filmActorRepository;
            _inventoryRepository = inventoryRepository;
            _rentalService = rentalService;
        }
        public async Task DeleteCategoryAsync(int categoryId)
        {
            IQueryable<FilmCategory> categoriesQuery = _filmCategoryRepository.CategoriesQuery();

            categoriesQuery = categoriesQuery.OrderBy(category => category.CategoryId);

            IEnumerable<FilmCategory> categories = await _filmCategoryRepository.FilmsListAsync(categoriesQuery, categoryId, true);

            if (categories != null)
            {
                foreach (FilmCategory filmCategory in categories)
                {
                    _filmCategoryRepository.DeleteCategoryAsync(filmCategory);
                }
            }
        }
        public async Task DeleteFilmCategoryAsync(int filmId)
        {
            IQueryable<FilmCategory> categoriesQuery = _filmCategoryRepository.CategoriesQuery();

            categoriesQuery = categoriesQuery.OrderBy(category => category.CategoryId);

            IEnumerable<FilmCategory> categories = await _filmCategoryRepository.FilmCategoriesListAsync(categoriesQuery, filmId, true);

            if (categories != null)
            {
                foreach (FilmCategory filmCategory in categories)
                {
                    _filmCategoryRepository.DeleteCategoryAsync(filmCategory);
                }
            }
        }

        public async Task DeleteFilmActorAsync(int filmId)
        {
            IQueryable<FilmActor> actorsQuery = _filmActorRepository.ActorsQuery();

            actorsQuery = actorsQuery.OrderBy(actor => actor.ActorId);

            IEnumerable<FilmActor> actors = await _filmActorRepository.ActorsListAsync(actorsQuery, filmId, true);

            if (actors != null)
            {
                foreach (FilmActor filmActor in actors)
                {
                    _filmActorRepository.DeleteActor(filmActor);
                }
            }
        }
        public async Task DeleteFilmAsync(int actorId)
        {
            IQueryable<FilmActor> actorsQuery = _filmActorRepository.ActorsQuery();

            actorsQuery = actorsQuery.OrderBy(actor => actor.ActorId);

            IEnumerable<FilmActor> films = await _filmActorRepository.FilmsListAsync(actorsQuery, actorId, true);

            if (films != null)
            {
                foreach (FilmActor filmActor in films)
                {
                    _filmActorRepository.DeleteActor(filmActor);
                }
            }
        }

        public async Task DeleteFilmInventoryAsync(int filmId)
        {
            IQueryable<Inventory> inventoriesQuery = _inventoryRepository.InventoriesQuery();

            inventoriesQuery = inventoriesQuery.OrderBy(inventory => inventory.FilmId);

            IEnumerable<Inventory> inventories = await _inventoryRepository.ListCopiesAsync(inventoriesQuery, filmId, true);

            if (inventories.Count() != 0)
            {
                foreach (Inventory inventory in inventories)
                {
                    int id = inventory.InventoryId;

                    _inventoryRepository.DeleteInventory(inventory);

                   await _rentalService.DeleteRentalsAsync(id);
                }
            }
        }
    }
}
