﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class PaymentService : IPaymentService
    {
        private IPaymentRepository _paymentRepository;

        public PaymentService(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        public async Task DeleteCustomerPaymentsAsync(int customerId)
        {
            IQueryable<Payment> paymentsQuery = _paymentRepository.PaymentsQuery();

            paymentsQuery = paymentsQuery.OrderBy(payment => payment.PaymentId);

            IEnumerable<Payment> payments = await _paymentRepository.CustomersPaymentsListAsync(paymentsQuery, customerId, true);

            if (payments != null)
            {
                foreach (Payment payment in payments)
                {
                    _paymentRepository.DeletePayment(payment);
                }
            }
        }

        public async Task DeleteStaffPaymentsAsync(int staffId)
        {
            IQueryable<Payment> paymentsQuery = _paymentRepository.PaymentsQuery();

            paymentsQuery = paymentsQuery.OrderBy(payment => payment.PaymentId);

            IEnumerable<Payment> payments = await _paymentRepository.StaffsPaymentsListAsync(paymentsQuery, staffId, false);

            if (payments != null)
            {
                foreach (Payment payment in payments)
                {
                    _paymentRepository.DeletePayment(payment);
                }
            }
        }
    }
}
