﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class FilmsController : Controller
    {
        private IFilmRepository _filmRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private ICategoryRepository _categoryRepository;
        private IActorRepository _actorRepository;
        private IFilmActorRepository _filmActorRepository;
        private IFilmServices _filmCategoryService;
        private IInventoryRepository _inventoryRepository;

        public FilmsController(IFilmRepository filmRepository, 
                               IFilmCategoryRepository filmCategoryRepository, 
                               IFilmActorRepository filmActorRepository, 
                               IActorRepository actorRepository, 
                               ICategoryRepository categoryRepository, 
                               IFilmServices filmCategoryService, 
                               IInventoryRepository inventoryRepository)
        {
            _filmRepository = filmRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _actorRepository = actorRepository;
            _filmActorRepository = filmActorRepository;
            _categoryRepository = categoryRepository;
            _filmCategoryService = filmCategoryService;
            _inventoryRepository = inventoryRepository;
        }
        [HttpGet("films")]
        public async Task<IActionResult> GetFilmsAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Film> filmsQuery = _filmRepository.FilmsQuery();

            filmsQuery = filmsQuery.OrderBy(film => film.FilmId);

            IEnumerable<Film> films = await _filmRepository.FilmsListAsync(filmsQuery, true);
            List<FilmResponse> response = new List<FilmResponse>();

            if (films.Count() == 0)
            {
                errorMessage.Message = FilmMessages.InvalidFilmList.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (Film film in films)
            {
                IQueryable<FilmCategory> categoriesQuery = _filmCategoryRepository.CategoriesQuery();

                categoriesQuery = categoriesQuery.OrderBy(category => category.CategoryId);

                IEnumerable<FilmCategory> categories = await _filmCategoryRepository.FilmCategoriesListAsync(categoriesQuery, film.FilmId, true);

                if (categories.Count() == 0)
                {
                    response.Add(film.ToFilmResponseLite());
                }
                else
                {
                    List<CategoryResponseLite> categoryList = new List<CategoryResponseLite>();

                    foreach (FilmCategory filmCategory in categories)
                    {
                        categoryList.Add(filmCategory.Category.ToCategoryResponseLite());
                    }

                    response.Add(film.ToFilmResponseLite(categoryList));

                }
            }

            return Ok(response);
        }

        [HttpGet("films/{filmId}", Name = "GetFilmAsync")]
        public async Task<IActionResult> GetFilmAsync(int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<FilmCategory> categoriesQuery = _filmCategoryRepository.CategoriesQuery();

            categoriesQuery = categoriesQuery.OrderBy(category => category.CategoryId);

            IEnumerable<FilmCategory> categories = await _filmCategoryRepository.FilmCategoriesListAsync(categoriesQuery, film.FilmId, true);

            if (categories.Count() == 0)
            {
                FilmResponse response = film.ToFilmResponseLite();

                return Ok(response);
            }
            else
            {
                List<CategoryResponseLite> categoryList = new List<CategoryResponseLite>();

                foreach (FilmCategory filmCategory in categories)
                {
                    categoryList.Add(filmCategory.Category.ToCategoryResponseLite());
                }
                FilmResponse response = film.ToFilmResponseLite(categoryList);

                return Ok(response);
            }
        }

        [HttpPost("films")]
        public async Task<IActionResult> CreateFilmAsync([FromBody]FilmCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidFilmRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Film film = request.ToFilmModel();

                await _filmRepository.CreateFilmAsync(film);
                await _filmRepository.SaveChangesAsync();

                FilmResponseLite response = film.ToFilmResponse();

                return CreatedAtRoute("GetFilmAsync", new { filmId = film.FilmId }, response);
            }
        }

        [HttpGet("films/{filmId}/actors")]
        public async Task<IActionResult> GetFilmActorsAsync(int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<FilmActor> actorsQuery = _filmActorRepository.ActorsQuery();

            actorsQuery = actorsQuery.OrderBy(actor => actor.ActorId);

            IEnumerable<FilmActor> actors = await _filmActorRepository.ActorsListAsync(actorsQuery, film.FilmId, true);

            if (actors.Count() == 0)
            {
                errorMessage.Message = ActorMessages.InvalidActorList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                List<ActorResponseLite> actorList = actors.ToActorResponseList();
                FilmActorsResponseLite response = film.ToActorsResponse(actorList);

                return Ok(actorList);
            }
        }

        [HttpGet("films/{filmId}/actors/{actorId}", Name = "GetFilmActorAsync")]
        public async Task<IActionResult> GetFilmActorAsync(int filmId, int actorId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);
            FilmActor filmActor = await _filmActorRepository.GetActorAsync(filmId, actorId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (filmActor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                ActorResponseLite actorResponse = filmActor.Actor.ToActorResponseLite();
                FilmActorResponseLite filmResponse = film.ToActorResponseLite(actorResponse);

                return Ok(filmResponse);
            }
        }

        [HttpGet("films/{filmId}/category/{categoryId}", Name = "GetFilmCategoryAsync")]
        public async Task<IActionResult> GetFilmCategoryAsync(int filmId, int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(filmId, categoryId);
                FilmCategoryResponse filmCategoryResponse = filmCategory.ToFilmCategoryResponse();

                return Ok(filmCategoryResponse);
            }

        }

        [HttpPost("filmCategories")]
        public async Task<IActionResult> AddFilmCategoryAsync([FromBody] FilmCategoryCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            Film film = await _filmRepository.GetFilmAsync(request.FilmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            Category category = await _categoryRepository.GetCategoryAsync(request.CategoryId);

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            FilmCategory filmCategoryValidation = await _filmCategoryRepository.GetFilmCategoryAsync(request.FilmId, request.CategoryId);

            if (filmCategoryValidation != null)
            {
                errorMessage.Message = CategoryMessages.AddCategoryFailed.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                FilmCategory filmCategory = request.ToFilmCategoryModel();

                await _filmCategoryRepository.AddCategoryAsync(filmCategory);
                await _filmCategoryRepository.SaveChangesAsync();

                FilmCategoryResponse response = filmCategory.ToFilmCategoryResponse();

                return CreatedAtRoute("GetFilmCategoryAsync", new { filmId = film.FilmId, categoryId = category.CategoryId }, response);
            }
        }

        [HttpPost("filmActors")]
        public async Task<IActionResult> AddFilmActorAsync([FromBody] AddActorFilmCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            List<string> errorList = new List<string>();

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            Film film = await _filmRepository.GetFilmAsync(request.FilmId);
            Actor actor = await _actorRepository.GetActorAsync(request.ActorId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                errorList.Add(errorMessage.Message);
            }

            if (errorList.Count() != 0)
            {
                return BadRequest(errorList);
            }

            bool isActor = await _filmActorRepository.ActorExistsAsync(request.FilmId, request.ActorId);

            if (isActor == true)
            {
                errorMessage.Message = ActorMessages.AddActorFailed.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                FilmActor filmActor = request.ToFilmActorModel();

                await _filmActorRepository.AddActorAsync(filmActor);
                await _filmActorRepository.SaveChangesAsync();

                FilmActorResponse response = filmActor.ToFilmActorResponse();

                return CreatedAtRoute("GetFilmActorAsync", new { filmId = film.FilmId, actorId = actor.ActorId }, response);
            }
        }

        [HttpPut("films/{filmId}")]
        public async Task<IActionResult> UpdateFilmAsync([FromBody]FilmUpdateRequest request, [FromRoute]int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = FilmMessages.InvalidFilmRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                film = request.ToFilmModel(film);
                await _filmRepository.SaveChangesAsync();
                FilmResponseLite response = film.ToFilmResponse();

                return Ok(response);
            }
        }

        [HttpDelete("films/{filmId}/filmActors/{actorId}")]
        public async Task<IActionResult> DeleteFilmActorAsync(int filmId, int actorId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            FilmActor filmActor = await _filmActorRepository.GetActorAsync(filmId, actorId);

            if (filmActor == null)
            {
                errorMessage.Message = ActorMessages.DeleteActorFailed.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _filmActorRepository.DeleteActor(filmActor);

                await _filmActorRepository.SaveChangesAsync();

                return Ok();
            }
        }

        [HttpDelete("films/{filmId}/category/{categoryId}")]
        public async Task<IActionResult> DeleteCategoryAsync(int filmId, int categoryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (category == null)
            {
                errorMessage.Message = CategoryMessages.NoCategoryResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            FilmCategory filmCategory = await _filmCategoryRepository.GetFilmCategoryAsync(filmId, categoryId);

            if (filmCategory == null)
            {
                errorMessage.Message = FilmMessages.InvalidCategory.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _filmCategoryRepository.DeleteCategoryAsync(filmCategory);

                await _filmCategoryRepository.SaveChangesAsync();

                return Ok();
            }
        }

        [HttpDelete("films/{filmId}")]
        public async Task<IActionResult> DeleteFilmAsync(int filmId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Film film = await _filmRepository.GetFilmAsync(filmId);

            if (film == null)
            {
                errorMessage.Message = FilmMessages.NoFilmResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                int id = film.FilmId;
                await _filmCategoryService.DeleteFilmActorAsync(id);
                await _filmCategoryService.DeleteFilmCategoryAsync(id);
                await _filmCategoryService.DeleteFilmInventoryAsync(id);

                _filmRepository.DeleteFilm(film);

                await _filmRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}