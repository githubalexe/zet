﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class PaymentsController : Controller
    {
        private IPaymentRepository _paymentRepository;
        private IStaffRepository _staffRepository;
        private IStoreRepository _storeRepository;
        private ICustomerRepository _customerRepository;
        private IRentalRepository _rentalRepository;

        public PaymentsController(IPaymentRepository paymentRepository, 
                                  IStaffRepository staffRepository, 
                                  IStoreRepository storeRepository, 
                                  ICustomerRepository customerRepository, 
                                  IRentalRepository rentalRepository)
        {
            _paymentRepository = paymentRepository;
            _staffRepository = staffRepository;
            _customerRepository = customerRepository;
            _rentalRepository = rentalRepository;
            _storeRepository = storeRepository;
        }

        [HttpGet("stores/{storeId}/payments")]
        public async Task<IActionResult> GetStorePaymentsAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            IQueryable<Staff> staffsQuery = _staffRepository.StaffsQuery();

            staffsQuery = staffsQuery.OrderBy(staff => staff.StaffId);

            IEnumerable<Staff> staffs = await _staffRepository.ListStaffsAsync(staffsQuery, storeId, true);
            List<StorePaymentsResponse> response = new List<StorePaymentsResponse>();

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staffs.Count() == 0)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                foreach (Staff staff in staffs)
                {
                    IQueryable<Payment> paymentsQuery = _paymentRepository.PaymentsQuery();

                    paymentsQuery = paymentsQuery.OrderBy(payment => payment.PaymentId);

                    IEnumerable<Payment> payments = await _paymentRepository.StaffsPaymentsListAsync(paymentsQuery, staff.StaffId, true);

                    foreach (Payment payment in payments)
                    {
                        response.Add(payment.ToStorePaymentResponse());
                    }
                }

                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}/payments/{paymentId}")]
        public async Task<IActionResult> GetStorePaymentAsync(int storeId, int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            IQueryable<Staff> staffsQuery = _staffRepository.StaffsQuery();

            staffsQuery = staffsQuery.OrderBy(staff => staff.StaffId);

            IEnumerable<Staff> staffs = await _staffRepository.ListStaffsAsync(staffsQuery, storeId, true);
            List<StorePaymentsResponse> response = new List<StorePaymentsResponse>();

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (Staff staff in staffs)
            {
                Payment payment = await _paymentRepository.GetStaffPaymentAsync(staff.StaffId, paymentId);
                if (payment != null)
                {
                    response.Add(payment.ToStorePaymentResponse());
                }
            }

            if (response.Count() == 0)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                return Ok(response);
            }
        }

        [HttpGet("payments/{paymentId}", Name = "GetPaymentAsync")]
        public async Task<IActionResult> GetPaymentAsync(int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);

            if (payment == null)
            {
                errorMessage.Message = PaymentMessages.NoPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                PaymentResponseLite response = payment.ToPaymentResponse();

                return Ok(response);
            }
        }

        [HttpPost("payments")]
        public async Task<IActionResult> CreatePaymentAsync([FromBody] PaymentCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            ErrorList errorList = new ErrorList();

            if (request == null)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCustomer = await _customerRepository.CustomerExistsAsync(request.CustomerId);
            bool isStaff = await _staffRepository.StaffExistsAync(request.StaffId);
            bool isRental = await _rentalRepository.RentalExistsAsync(request.RentalId);

            if (isCustomer == false)
            {
                errorList.Errors.Add(CustomerMessages.NoCustomerResponse.GetDescription());
            }

            if (isStaff == false)
            {
                errorList.Errors.Add(StaffMessages.NoStaffResponse.GetDescription());

            }

            if (isRental == false)
            {
                errorList.Errors.Add(RentalMessages.NoRentalResponse.GetDescription());

            }

            if (errorList.Errors.Count() != 0)
            {
                return BadRequest(errorList);
            }
            else
            {

                Payment payment = request.ToPaymentModel();

                await _paymentRepository.CreatePaymentAsync(payment);
                await _paymentRepository.SaveChangesAsync();

                PaymentResponseLite response = payment.ToPaymentResponse();

                return CreatedAtRoute("GetPaymentAsync", new { paymentId = response.PaymentId }, response);
            }
        }

        [HttpPut("payments/{paymentId}")]
        public async Task<IActionResult> UpdatePaymentAsync([FromBody] PaymentUpdateRequest request, int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);
            ErrorList errorList = new ErrorList();

            if (payment == null)
            {
                errorMessage.Message = PaymentMessages.NoPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCustomer = await _customerRepository.CustomerExistsAsync(request.CustomerId);
            bool isStaff = await _staffRepository.StaffExistsAync(request.StaffId);
            bool isRental = await _rentalRepository.RentalExistsAsync(request.RentalId);

            if (isCustomer == false)
            {
                errorList.Errors.Add(CustomerMessages.NoCustomerResponse.GetDescription());
            }

            if (isStaff == false)
            {
                errorList.Errors.Add(StaffMessages.NoStaffResponse.GetDescription());

            }

            if (isRental == false)
            {
                errorList.Errors.Add(RentalMessages.NoRentalResponse.GetDescription());

            }

            if (errorList.Errors.Count() != 0)
            {
                return BadRequest(errorList);
            }
            else
            {
                payment = request.ToPaymentModel(payment);

                await _paymentRepository.SaveChangesAsync();

                PaymentResponseLite response = payment.ToPaymentResponse();

                return Ok(response);
            }
        }

        [HttpDelete("payments/{paymentId}")]
        public async Task<IActionResult> DeletePaymentAsync(int paymentId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);

            if (payment == null)
            {
                errorMessage.Message = PaymentMessages.NoPaymentResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _paymentRepository.DeletePayment(payment);

                await _paymentRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}