﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.DeleteRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using DVDRentals.Services;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class ActorsController : Controller
    {
        private IActorRepository _actorRepository;
        private IFilmServices _filmActorService;
        public ActorsController(IActorRepository actorRepository, IFilmServices filmActorService)
        {
            _actorRepository = actorRepository;
            _filmActorService = filmActorService;
        }

        [HttpGet("actors")]
        public async Task<IActionResult> GetActorsAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Actor> actorsQuery = _actorRepository.ActorsQuery();

            actorsQuery = actorsQuery.OrderBy(actor => actor.ActorId);

            IEnumerable<Actor> actors = await _actorRepository.ActorsListAsync(actorsQuery, true);

            if (actors == null)
            {
                errorMessage.Message = ActorMessages.InvalidActorList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<ActorResponseLite> response = actors.Select(actor => actor.ToActorResponseLite());

                return Ok(response);
            }
        }

        [HttpGet("actors/{actorId}", Name = "GetActorsAsync")]
        public async Task<IActionResult> GetActorsAsync(int actorId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                ActorResponseLite response = actor.ToActorResponseLite();

                return Ok(response);
            }
        }

        [HttpPost("actors")]
        public async Task<IActionResult> CreateActorAsync([FromBody]ActorCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = ActorMessages.InvalidActorRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                Actor actor = request.ToActorModel();

                await _actorRepository.CreateActorAsync(actor);
                await _actorRepository.SaveChangesAsync();

                ActorResponseLite response = actor.ToActorResponseLite();

                return CreatedAtRoute("GetActorsAsync", new { actorId = actor.ActorId }, response);
            }
        }

        [HttpPut("actors/{actorId}")]
        public async Task<IActionResult> UpdateActorAsync([FromBody]ActorUpdateRequest request, int actorId)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = ActorMessages.InvalidActorRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                actor = request.ToActorModel(actor);

                await _actorRepository.SaveChangesAsync();

                ActorResponseLite actorResponse = actor.ToActorResponseLite();

                return Ok(actorResponse);
            }
        }

        [HttpDelete("actors/{actorId}")]
        public async Task<IActionResult> DeleteActorAsync(int actorId)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            Actor actor = await _actorRepository.GetActorAsync(actorId);

            if (actor == null)
            {
                errorMessage.Message = ActorMessages.NoActorResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                await _filmActorService.DeleteFilmAsync(actorId);

                _actorRepository.DeleteActor(actor);

                await _actorRepository.SaveChangesAsync();

                return Ok();
            }
        }

        [HttpDelete("actors")]
        public async Task<IActionResult> DeleteActorsAsync([FromBody] ActorDeleteRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            ErrorList errorList = new ErrorList();

            if (request == null)
            {
                errorMessage.Message = ActorMessages.InvalidActorRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            foreach (string actorId in request.ActorIds)
            {
                int id = Int32.Parse(actorId);
                Actor actor = await _actorRepository.GetActorAsync(id);

                if (actor == null)
                {
                    string message = errorList.GetMessage("actor", id.ToString());
                    errorList.Errors.Add(message);
                }
                else
                {
                    await _filmActorService.DeleteFilmAsync(id);

                    _actorRepository.DeleteActor(actor);
                }
            }

            if (errorList.Errors.Count() != 0)
            {
                return BadRequest(errorList);
            }
            else
            {
                await _actorRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}