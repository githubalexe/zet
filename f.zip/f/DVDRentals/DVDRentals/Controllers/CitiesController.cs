﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.City;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class CitiesController : Controller
    {
        private ICityRepository _cityRepository;
        public CitiesController(ICityRepository cityRepository)
        {
            _cityRepository = cityRepository;
        }

        [HttpGet("cities")]
        public async Task<IActionResult> GetCities()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<City> citiesQuery = _cityRepository.CitiesQuery();

            citiesQuery = citiesQuery.OrderBy(city => city.CityId);

            IEnumerable<City> cities = await _cityRepository.CitiesListAsync(citiesQuery, true);

            if (cities.Count() == 0)
            {
                errorMessage.Message = CityMessages.InvalidCitiesList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<CityResponse> response = cities.Select(city => city.ToCityResponse());

                return Ok(response);
            }
        }

        [HttpGet("country/{countryId}/cities")]
        public async Task<IActionResult> GetCitiesByCountry(int countryId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<City> citiesQuery = _cityRepository.CitiesQuery();

            citiesQuery = citiesQuery.OrderBy(city => city.CityId);

            IEnumerable<City> cities = await _cityRepository.CitiesListByCountryAsync(citiesQuery, countryId, true);

            if (cities.Count() == 0)
            {
                errorMessage.Message = CityMessages.InvalidCitiesList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<CityResponse> response = cities.Select(city => city.ToCityResponse());

                return Ok(response);
            }
        }

        [HttpGet("cities/{cityId}", Name = "GetCityAsync")]
        public async Task<IActionResult> GetCityAsync(int cityId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            City city = await _cityRepository.GetCityAsync(cityId);

            if (city == null)
            {
                errorMessage.Message = CityMessages.NoCityResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                CityResponse response = city.ToCityResponse();

                return Ok(response);
            }
        }

        [HttpPost("cities")]
        public async Task<IActionResult> CreateCityAsync([FromBody] CityCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = CityMessages.InvalidCityRequest.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                City city = request.ToCityModel();

                await _cityRepository.CreateCityAsync(city);
                await _cityRepository.SaveChangesAsync();

                CityResponseLite response = city.ToCityResponseLite();

                return CreatedAtRoute("GetCityAsync", new { cityId = city.CityId }, response);
            }
        }

        [HttpPut("cities/{cityId}")]
        public async Task<IActionResult> UpdateCityAsync([FromBody]CityUpdateRequest request, int cityId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            City city = await _cityRepository.GetCityAsync(cityId);

            if (city == null)
            {
                errorMessage.Message = CityMessages.NoCityResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (request == null)
            {
                errorMessage.Message = CityMessages.InvalidCityRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCountry = await _cityRepository.CountryExistsAsync(request.CountryId);

            if (isCountry == false)
            {
                errorMessage.Message = CountryMessages.NoCountryResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                city = request.ToCityModel(city);

                await _cityRepository.SaveChangesAsync();

                CityResponse response = city.ToCityResponse();

                return Ok(response);
            }
        }

        [HttpDelete("cities/{cityId}")]
        public async Task<IActionResult> DeleteCityAsync(int cityId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            City city = await _cityRepository.GetCityAsync(cityId);

            if (city == null)
            {
                errorMessage.Message = CityMessages.NoCityResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isAddress = await _cityRepository.AddressExistsAsync(cityId);

            if (isAddress == true)
            {
                errorMessage.Message = CityMessages.DeleteCityFalid.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _cityRepository.DeleteCity(city);

                await _cityRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}