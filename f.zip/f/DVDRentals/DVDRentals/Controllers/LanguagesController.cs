﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Language;
using DVDRentals.API.Response.Messages;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class LanguagesController : Controller
    {
        private ILanguageRepository _languageRepository;
        public LanguagesController(ILanguageRepository languageRepository)
        {
            _languageRepository = languageRepository;
        }

        [HttpGet("languages")]
        public async Task<IActionResult> GetLanguagesAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Language> languagesQuery = _languageRepository.LanguagesQuery();

            languagesQuery = languagesQuery.OrderBy(language => language.LanguageId);

            IEnumerable<Language> languages = await _languageRepository.ListLanguagesAsync(languagesQuery, true);

            if (languages.Count() == 0)
            {
                errorMessage.Message = LanguageMessages.InvalidLanguageList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<LanguageResponseLite> response = languages.Select(language => language.ToLanguageResponseLite());

                return Ok(response);
            }
        }

        [HttpGet("languages/{languageId}", Name = "GetLanguageAsync")]
        public async Task<IActionResult> GetLanguageAsync(int languageId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Language language = await _languageRepository.GetLanguageAsync(languageId);

            if (language == null)
            {
                errorMessage.Message = LanguageMessages.NoLanguageResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                LanguageResponseLite languageResponse = language.ToLanguageResponseLite();

                return Ok(languageResponse);
            }
        }

        [HttpPost("languages")]
        public async Task<IActionResult> CreateLanguageAsync([FromBody] LanguageCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();

            if (request == null)
            {
                errorMessage.Message = LanguageMessages.InvalidLanguageRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            Language language = request.ToLanguageModel();

            await _languageRepository.CreateLanguageAsync(language);
            await _languageRepository.SaveChangesAsync();

            LanguageResponseLite response = language.ToLanguageResponseLite();

            return CreatedAtRoute("GetLanguageAsync", new { languageId = language.LanguageId }, response);
        }

        [HttpDelete("languages/{languageId}")]
        public async Task<IActionResult> DeleteLanguageAsync(int languageId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Language language = await _languageRepository.GetLanguageAsync(languageId);

            if (language == null)
            {
                errorMessage.Message = LanguageMessages.NoLanguageResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isFilm = await _languageRepository.FilmExistsAsync(languageId);

            if (isFilm == true)
            {
                errorMessage.Message = LanguageMessages.DeleteLanguageFailed.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _languageRepository.DeleteLanguage(language);

                await _languageRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}