﻿using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Rental;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class RentalsController : Controller
    {
        private IRentalRepository _rentalRepository;
        private IInventoryRepository _inventoryRepository;
        private IStoreRepository _storeRepository;
        private IPaymentRepository _paymentRepository;
        private ICustomerRepository _customerRepository;
        private IStaffRepository _staffRepository;
        public RentalsController(IRentalRepository rentalRepository,
                                 IInventoryRepository inventoryRepository,
                                 ICustomerRepository customerRepository,
                                 IStoreRepository storeRepository,
                                 IPaymentRepository paymentRepository,
                                 IStaffRepository staffRepository)
        {
            _rentalRepository = rentalRepository;
            _inventoryRepository = inventoryRepository;
            _customerRepository = customerRepository;
            _staffRepository = staffRepository;
            _paymentRepository = paymentRepository;
            _storeRepository = storeRepository;
        }

        [HttpGet("rentals")]
        public async Task<IActionResult> RentalsAsync()
        {
            ErrorMessage errorMessage = new ErrorMessage();
            IQueryable<Rental> rentalsQuery = _rentalRepository.RentalsQuery();

            rentalsQuery = rentalsQuery.OrderBy(rental => rental.RentalDate);

            IEnumerable<Rental> rentals = await _rentalRepository.RentalsListAsync(rentalsQuery, true);

            if (rentals.Count() == 0)
            {
                errorMessage.Message = RentalMessages.InvalidRentalsList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                IEnumerable<RentalResponseLite> response = rentals.Select(rental => rental.ToRentalResponseLite());

                return Ok(response);
            }
        }

        [HttpGet("rentals/{rentalId}", Name = "GetRentalAsync")]
        public async Task<IActionResult> GetRentalAsync(int rentalId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental == null)
            {
                errorMessage.Message = RentalMessages.NoRentalResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                StoreRentalResponse rentalResponse = rental.ToStoreRentalsResponse();

                return Ok(rentalResponse);
            }
        }

        [HttpGet("stores/{storeId}/rentals")]
        public async Task<IActionResult> GetStoreRentalsAsync(int storeId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);
            IQueryable<Staff> staffsQuery = _staffRepository.StaffsQuery();

            staffsQuery = staffsQuery.OrderBy(staff => staff.StaffId);

            IEnumerable<Staff> staffs = await _staffRepository.ListStaffsAsync(staffsQuery, storeId, true);
            List<StoreRentalResponse> response = new List<StoreRentalResponse>();

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            if (staffs.Count() == 0)
            {
                errorMessage.Message = PaymentMessages.InvalidPaymentList.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                foreach (Staff staff in staffs)
                {
                    IQueryable<Rental> rentalsQuery = _rentalRepository.RentalsQuery();

                    rentalsQuery = rentalsQuery.OrderBy(rental => rental.RentalDate);

                    IEnumerable<Rental> rentals = await _rentalRepository.StaffsRentalsListAsync(rentalsQuery, staff.StaffId, true);

                    foreach (Rental rental in rentals)
                    {
                        if (rental != null)
                        {
                            IQueryable<Payment> paymentsQuery = _paymentRepository.PaymentsQuery();

                            paymentsQuery = paymentsQuery.OrderBy(payment => payment.PaymentId);
                            IEnumerable<Payment> payments = await _paymentRepository.RentalPaymentsListAsync(paymentsQuery, rental.RentalId, true);

                            response.Add(rental.ToStoreRentalsResponse());
                        }
                    }
                }

                return Ok(response);
            }
        }

        [HttpGet("stores/{storeId}/rentals/{rentalId}/payments")]
        public async Task<IActionResult> GetStoreRentalsAsync(int storeId, int rentalId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Store store = await _storeRepository.GetStoreAsync(storeId);

            if (store == null)
            {
                errorMessage.Message = StoreMessages.NoStoreResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            IQueryable<Payment> paymentsQuery = _paymentRepository.PaymentsQuery();

            paymentsQuery = paymentsQuery.OrderBy(payment => payment.PaymentId);

            IEnumerable<Payment> payments = await _paymentRepository.RentalPaymentsListAsync(paymentsQuery, rentalId, true);
            IEnumerable<PaymentResponseLite> response = payments.Select(payment => payment.ToPaymentResponse());

            return Ok(response);
        }

        [HttpPost("rentals")]
        public async Task<IActionResult> CreateRentalAsync([FromBody] RentalCreateRequest request)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            ErrorList errorList = new ErrorList();

            if (request == null)
            {
                errorMessage.Message = RentalMessages.InvalidRentaRequest.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCustomer = await _customerRepository.CustomerExistsAsync(request.CustomerId);
            bool isStaff = await _staffRepository.StaffExistsAync(request.StaffId);
            bool isInventory = await _inventoryRepository.ExistInventoryAsync(request.InventoryId);

            if (isCustomer == false)
            {
                errorList.Errors.Add(CustomerMessages.NoCustomerResponse.GetDescription());
            }
            if (isInventory == false)
            {
                errorList.Errors.Add(InventoryMessages.NoInventoryResponse.GetDescription());
            }

            if (isStaff == false)
            {
                errorList.Errors.Add(StaffMessages.NoStaffResponse.GetDescription());
            }

            if (errorList.Errors.Count() != 0)
            {
                return BadRequest(errorList);
            }
            else
            {
                Rental rental = request.ToRentalModel();

                await _rentalRepository.CreateRentalAsync(rental);
                await _rentalRepository.SaveChangesAsync();

                RentalResponseLite response = rental.ToRentalResponseLite();

                return CreatedAtRoute("GetRentalAsync", new { rentalId = rental.RentalId }, response);
            }
        }

        [HttpPut("rentals/{rentalId}")]
        public async Task<IActionResult> UpdateRentalAsync([FromBody]RentalUpdateRequest request, int rentalId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);
            ErrorList errorList = new ErrorList();

            if (rental == null)
            {
                errorMessage.Message = RentalMessages.NoRentalResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            bool isCustomer = await _customerRepository.CustomerExistsAsync(request.CustomerId);
            bool isStaff = await _staffRepository.StaffExistsAync(request.StaffId);
            bool isInventory = await _inventoryRepository.ExistInventoryAsync(request.InventoryId);

            if (isCustomer == false)
            {
                errorList.Errors.Add(CustomerMessages.NoCustomerResponse.GetDescription());
            }
            if (isInventory == false)
            {
                errorList.Errors.Add(InventoryMessages.NoInventoryResponse.GetDescription());
            }

            if (isStaff == false)
            {
                errorList.Errors.Add(StaffMessages.NoStaffResponse.GetDescription());
            }

            if (errorList.Errors.Count() != 0)
            {
                return BadRequest(errorList);
            }
            else
            {
                rental = request.ModifyRental(rental);
                await _rentalRepository.SaveChangesAsync();
                RentalResponseLite response = rental.ToRentalResponseLite();

                return Ok(response);
            }
        }

        [HttpDelete("rentals/{rentalId}")]
        public async Task<IActionResult> DeleteRentalAsync(int rentalId)
        {
            ErrorMessage errorMessage = new ErrorMessage();
            Rental rental = await _rentalRepository.GetRentalAsync(rentalId);

            if (rental == null)
            {
                errorMessage.Message = RentalMessages.NoRentalResponse.GetDescription();

                return BadRequest(errorMessage);
            }
            else
            {
                _rentalRepository.DeleteRental(rental);

                await _rentalRepository.SaveChangesAsync();

                return Ok();
            }
        }
    }
}