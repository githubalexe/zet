﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.Domain
{
    public class Country
    {
        public int CountryId { get; set; }
        public string Country1 { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
