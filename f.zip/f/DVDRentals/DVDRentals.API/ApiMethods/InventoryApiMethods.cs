﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Inventory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class InventoryApiMethods
    {

        public static async Task<InventoryResponse> GetInventory(int storeId, int inventoryId)
        {
            InventoryResponse inventory = new InventoryResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/inventories/{2}", uri, storeId, inventoryId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    inventory = JsonConvert.DeserializeObject<InventoryResponse>(dataJson);
                }
            }

            return inventory;
        }

        public static async Task<IEnumerable<InventoryResponse>> GetFilmInventoriesAsync(int storeId, int filmId)
        {
            IEnumerable<InventoryResponse> inventories = new List<InventoryResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/inventories/{2}", uri, storeId, filmId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    inventories = JsonConvert.DeserializeObject<List<InventoryResponse>>(dataJson);
                }
            }

            return inventories;
        }

        public static async Task<IEnumerable<InventoryResponse>> GetInventories(int storeId)
        {
            IEnumerable<InventoryResponse> inventories = new List<InventoryResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/inventories", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    inventories = JsonConvert.DeserializeObject<List<InventoryResponse>>(dataJson);
                }
            }

            return inventories;
        }


        public static async Task<InventoryResponse> CreateInventoryAsync(InventoryCreateRequest request, int storeId)
        {
            InventoryResponse inventory = new InventoryResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/inventories", uri, storeId);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                inventory = JsonConvert.DeserializeObject<InventoryResponse>(dataJson);
            }

            return inventory;
        }

        public static async Task DeleteInventory(int storeId, int inventoryId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/inventories/{2}", uri, storeId, inventoryId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}
