﻿using DVDRentals.API.ApiMethods.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Address;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Staff;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class StaffApiMethods
    {
        public static async Task<StaffResponse> GetStaff(int storeId, int staffId)
        {
            StaffResponse staff = new StaffResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
                }
            }

            return staff;
        }

        public static async Task<IEnumerable<StaffResponse>> GetStaffs(int storeId)
        {
            IEnumerable<StaffResponse> staffs = new List<StaffResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/staffs", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staffs = JsonConvert.DeserializeObject<List<StaffResponse>>(dataJson);
                }
            }

            return staffs;
        }

        public static async Task<IEnumerable<StaffNameResponse>> GetStaffsName(int storeId)
        {
            IEnumerable<StaffNameResponse> staffs = new List<StaffNameResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/staffsName", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staffs = JsonConvert.DeserializeObject<List<StaffNameResponse>>(dataJson);
                }
            }

            return staffs;
        }

        public static async Task<IEnumerable<StaffPaymentsResponse>> GetPayments(int storeId, int staffId)
        {
            IEnumerable<StaffPaymentsResponse> payments = new List<StaffPaymentsResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/staffs/{2}/payments", uri, storeId, staffId);

                HttpResponseMessage response = await client.GetAsync(url);


                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    payments = JsonConvert.DeserializeObject<List<StaffPaymentsResponse>>(dataJson);
                }
            }

            return payments;
        }

        public static async Task<StaffResponse> CreateStaff(StaffFormRequest request, int storeId)
        {
            AddressResponseLite address = await AddressApiMethods.CreateAddressAsync(request.ToAddressCreate());
            StaffCreateRequest staffRequest = request.ToFormCreateStaff(address.AddressId);

            StaffResponse staff = new StaffResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/staffs", uri, storeId);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, staffRequest);

                string dataJson = await response.Content.ReadAsStringAsync();
                staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
            }

            return staff;
        }

        public static async Task<StaffResponse> UpdateStaff(StaffFormRequest request, int storeId, int staffId)
        {
            StaffResponse staff = await StaffApiMethods.GetStaff(storeId, staffId);
            AddressResponseLite address = await AddressApiMethods.UpdateAddressAsync(request.ToAddressUpdate(request.CityId), staff.AddressId);

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request.ToFormUpdateStaff(address.AddressId));

                string dataJson = await response.Content.ReadAsStringAsync();
                staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
            }

            return staff;
        }

        public static async Task DeleteStaff(int storeId, int staffId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}
