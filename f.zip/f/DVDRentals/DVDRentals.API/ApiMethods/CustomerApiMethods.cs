﻿using DVDRentals.API.ApiMethods.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Address;
using DVDRentals.API.Response.City;
using DVDRentals.API.Response.Country;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;


namespace DVDRentals.API.ApiMethods
{
    public class CustomerApiMethods
    {
        public static async Task<CustomerResponse> GetCustomer(int storeId, int customerId)
        {
            CustomerResponse customer = new CustomerResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
                }
            }

            return customer;
        }

        public static async Task<IEnumerable<CustomerResponse>> GetCustomers(int storeId)
        {
            IEnumerable<CustomerResponse> customers = new List<CustomerResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/customers", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customers = JsonConvert.DeserializeObject<List<CustomerResponse>>(dataJson);
                }
            }

            return customers;
        }
        public static async Task<IEnumerable<CustomerNameResponse>> GetCustomersName(int storeId)
        {
            IEnumerable<CustomerNameResponse> customers = new List<CustomerNameResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/customersName", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customers = JsonConvert.DeserializeObject<List<CustomerNameResponse>>(dataJson);
                }
            }

            return customers;
        }

        public static async Task<IEnumerable<CustomerPaymentsResponse>> GetPayments(int storeId, int customerId)
        {
            IEnumerable<CustomerPaymentsResponse> payments = new List<CustomerPaymentsResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/customers/{2}/payments", uri, storeId, customerId);

                HttpResponseMessage response = await client.GetAsync(url);


                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    payments = JsonConvert.DeserializeObject<List<CustomerPaymentsResponse>>(dataJson);
                }
            }

            return payments;
        }

        public static async Task<CustomerResponse> CreateCustomer(CustomerFormRequest request, int storeId)
        {
            var cityId = Int16.Parse(request.City);
            //CityResponseLite city = await CityApiMethods.CreateCityAsync(request.ToCityCreateObject(countryId));
            AddressResponseLite address = await AddressApiMethods.CreateAddressAsync(request.ToAddressCreateObject(cityId));
            CustomerCreateRequest customerRequest = request.ToModelCreateCustomer(address.AddressId);

            CustomerResponse customer = new CustomerResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/customers", uri, storeId);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, customerRequest);

                string dataJson = await response.Content.ReadAsStringAsync();
                customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
            }

            return customer;
        }

        public static async Task<CustomerResponse> UpdateCustomer(CustomerFormRequest request, int storeId, int customerId)
        {
            var countryId = Int16.Parse(request.Country);
            AddressResponseLite address = await AddressApiMethods.GetAddressAsync(request.AddressId);
            address = await AddressApiMethods.UpdateAddressAsync(request.ToAddressUpdate(address.CityId),request.AddressId);

            CityResponseLite city = await CityApiMethods.UpdateCityAsync(request.ToFormCityUpdate(countryId), address.CityId);
            CustomerUpdateRequest customerRequest = request.ToModelUpdateCustomer();
            CustomerResponse customer = new CustomerResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
            }

            return customer;
        }

        public static async Task DeleteCustomer(int storeId, int customerId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}

