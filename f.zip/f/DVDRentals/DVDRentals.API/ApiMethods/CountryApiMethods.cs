﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Country;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class CountryApiMethods
    {
        public static async Task<IEnumerable<CountryResponseLite>> GetCountriesAsync()
        {
            IEnumerable<CountryResponseLite> country = new List<CountryResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}countries", uri);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    country = JsonConvert.DeserializeObject<List<CountryResponseLite>>(dataJson);
                }
            }

            return country;
        }
        public static async Task<CountryResponseLite> CreateCountryAsync(CountryCreateRequest request)
        {
            CountryResponseLite country = new CountryResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/countries", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                country = JsonConvert.DeserializeObject<CountryResponseLite>(dataJson);
            }

            return country;
        }
    }
}
