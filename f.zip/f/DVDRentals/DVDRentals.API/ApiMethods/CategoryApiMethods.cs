﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class CategoryApiMethods
    {
        public static async Task<IEnumerable<CategoryResponseLite>> GetCategoriesAsync()
        {
            IEnumerable < CategoryResponseLite> category = new List<CategoryResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}categories", uri);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    category = JsonConvert.DeserializeObject<List<CategoryResponseLite>>(dataJson);
                }
            }

            return category;
        }

        public static async Task<FilmCategoryResponse> AddCategoryAsync(FilmCategoryCreateRequest request)
        {
            FilmCategoryResponse filmCategory = new FilmCategoryResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}filmCategories", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                filmCategory = JsonConvert.DeserializeObject<FilmCategoryResponse>(dataJson);
            }

            return filmCategory;
        }
    }
}
