﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Address;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class AddressApiMethods
    {
        public static async Task<AddressResponseLite> GetAddressAsync(int addressId)
        {
            AddressResponseLite address = new AddressResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}addresses/{1}", uri, addressId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    address = JsonConvert.DeserializeObject<AddressResponseLite>(dataJson);
                }
            }

            return address;
        }
        public static async Task<AddressResponseLite> CreateAddressAsync(AddressCreateRequest request)
        {
            AddressResponseLite customer = new AddressResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}addresses", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                customer = JsonConvert.DeserializeObject<AddressResponseLite>(dataJson);
            }

            return customer;
        }

        public static async Task<AddressResponseLite> UpdateAddressAsync(AddressUpdateRequest request, int addressId)
        {
            AddressResponseLite address = new AddressResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}addresses/{1}", uri, addressId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                address = JsonConvert.DeserializeObject<AddressResponseLite>(dataJson);
            }

            return address;
        }

    }
}
