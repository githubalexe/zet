﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static ActorFilmCreateRequest ToformCreateActorRequest(this ActorFormRequest request, int filmId)
        {
            return new ActorFilmCreateRequest()
            {
                FilmId = filmId,
                ActorId = Int32.Parse(request.Name)
            };
        }

        public static ActorCreateRequest ToRequestCreateActor(this ActorFormRequest request)
        {
            return new ActorCreateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
            };
        }
    }
}
