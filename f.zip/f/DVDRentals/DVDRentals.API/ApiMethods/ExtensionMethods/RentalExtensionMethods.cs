﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static CustomerFormRequest ToCustomerForm(this RentalFormRequest request)//modify the string with int
        {
            return new CustomerFormRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Address = request.Address,
                Address2 = request.Address2,
                Distrinct = request.Distrinct,
                Country = request.CountryId.ToString(),
                CityId = request.CityId,
                City = request.CityId.ToString(),
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }

        public static RentalCreateRequest ToFormCreateRental(this RentalFormRequest request, int staffId)
        {
            return new RentalCreateRequest
            {
                RentalDate = request.RentalDate,
                InventoryId = request.InventoryId,
                CustomerId = request.CustomerId,
                ReturnDate = request.ReturnDate,
                StaffId = staffId
            };
        }
    }
}
