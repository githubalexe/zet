﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;


namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class AddressExtensionMethods
    {
        public static AddressCreateRequest ToAddressCreateObject(this CustomerFormRequest model, int cityId)
        {
            return new AddressCreateRequest
            {
                Address1 = model.Address,
                Address2 = model.Address2,
                District = model.Distrinct,
                CityId = cityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }

        public static AddressUpdateRequest ToAddressUpdate(this CustomerFormRequest model, int cityId)
        {
            return new AddressUpdateRequest
            {
                Address1 = model.Address,
                Address2 = model.Address2,
                District = model.Distrinct,
                CityId = cityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }

        public static AddressUpdateRequest ToAddressUpdate(this StoreFormRequest model, int cityId)
        {
            return new AddressUpdateRequest
            {
                Address1 = model.Address,
                Address2 = model.Address2,
                District = model.Distrinct,
                CityId = cityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }

        public static AddressCreateRequest ToAddressCreate(this StaffFormRequest request)
        {
            return new AddressCreateRequest
            {
                Address1 = request.Address,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }
    }
}
