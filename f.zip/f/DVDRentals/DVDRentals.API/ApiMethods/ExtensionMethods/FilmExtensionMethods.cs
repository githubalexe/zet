﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static FilmCategoryCreateRequest ToRequestAddCategory(this FilmFormRequest request)
        {
            return new FilmCategoryCreateRequest
            {
                FilmId = request.FilmId,
                CategoryId = Int32.Parse(request.Category)
            };
        }


        public static FilmUpdateRequest ToFormUpdateFilm(this FilmFormRequest model)
        {
            return new FilmUpdateRequest()
            {
                Title = model.Title,
                Description = model.Description,
                ReleaseYear = model.ReleaseYear,
                LanguageId = Int32.Parse(model.Language),
                OriginalLanguageId = model.OriginalLanguageId,
                RentalDuration = model.RentalDuration,
                RentalRate = model.RentalRate,
                Length = model.Length,
                ReplacementCost = model.ReplacementCost,
                Rating = model.Rating,
                SpecialFeatures = model.SpecialFeatures
            };
        }
    }
}
