﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public class StoreExtensionMethods
    {
        public int StoreId { get; set; }
        public int ManagerStaffId { get; set; }
        public string ManagerName { get; set; }
        public int AddressId { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string Distrinct { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string PostalCode { get; set; }
        public string Phone { get; set; }
    }
}
