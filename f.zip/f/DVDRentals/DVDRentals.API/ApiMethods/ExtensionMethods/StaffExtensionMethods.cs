﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static StaffCreateRequest ToFormCreateStaff(this StaffFormRequest request, int addressId)
        {
            return new StaffCreateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Picture = request.BinaryImage,
                AddressId = addressId,
                Active = true,
                Username = request.Username,
                Password = request.Password
            };
        }

        public static StaffUpdateRequest ToFormUpdateStaff(this StaffFormRequest request)
        {
            return new StaffUpdateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Picture = request.BinaryImage,
                AddressId = request.AddressId,
                Active = request.Active,
                Username = request.Username,
                Password = request.Password
            };
        }
    }
}
