﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerCreateRequest ToModelCreateCustomer(this CustomerFormRequest model, int addressId)
        {
            return new CustomerCreateRequest
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                AddressId = addressId,
                Active = true,
                CreateDate = DateTime.Today
            };
        }

        public static CustomerUpdateRequest ToModelUpdateCustomer(this CustomerFormRequest model, int addressId)
        {
            return new CustomerUpdateRequest
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                AddressId = addressId,
                CreateDate = model.CreateDate
            };
        }

        public static CustomerUpdateRequest ToCustomerUpdateRequest(this CustomerResponse request, bool isActive)
        {
            return new CustomerUpdateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                AddressId = request.AddressId,
                Active = isActive,
                CreateDate = request.CreateDate
            };
        }
    }
}
