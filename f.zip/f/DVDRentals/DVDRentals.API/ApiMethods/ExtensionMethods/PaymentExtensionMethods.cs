﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class PaymentExtensionMethods
    {
        public static PaymentCreateRequest ToFormCreatePayment(this RentalFormRequest request)
        {
            return new PaymentCreateRequest()
            {
                CustomerId = request.CustomerId,
                StaffId = request.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount ?? default(decimal),
                PaymentDate = request.PaymentDate
            };
        }
    }
}
