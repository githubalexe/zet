﻿using DVDRentals.API.ApiMethods.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Rental;
using DVDRentals.API.Response.Store;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class RentalApiMethods
    {
        public static async Task<StoreRentalResponse> GetRental(int storeId, int rentalId)
        {
            StoreRentalResponse rental = new StoreRentalResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}rentals/{1}", uri, rentalId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    rental = JsonConvert.DeserializeObject<StoreRentalResponse>(dataJson);
                }
            }

            return rental;
        }

        public static async Task<IEnumerable<StoreRentalResponse>> GetRentals(int storeId)
        {
            IEnumerable<StoreRentalResponse> rentals = new List<StoreRentalResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/rentals", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    rentals = JsonConvert.DeserializeObject<List<StoreRentalResponse>>(dataJson);
                }
            }

            return rentals;
        }

        public static async Task<IEnumerable<RentalResponseLite>> GetInventoryRentalsAsync(int inventoryId)
        {
            IEnumerable<RentalResponseLite> rentals = new List<RentalResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/inventoryRentals/{1}", uri, inventoryId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    rentals = JsonConvert.DeserializeObject<List<RentalResponseLite>>(dataJson);
                }
            }

            return rentals;
        }

        public static async Task<IEnumerable<PaymentResponseLite>> GetPayments(int storeId, int rentalId)
        {
            IEnumerable<PaymentResponseLite> payments = new List<PaymentResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}/rentals/{2}/payments", uri, storeId, rentalId);

                HttpResponseMessage response = await client.GetAsync(url);


                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    payments = JsonConvert.DeserializeObject<List<PaymentResponseLite>>(dataJson);
                }
            }

            return payments;
        }

        public static async Task<StoreRentalResponse> CreateRental(RentalFormRequest request, int storeId, int staffId)
        {
            if (request.ExistingCustomer == "No")
            {
                CustomerResponse customer = await CustomerApiMethods.CreateCustomer(request.ToCustomerForm(), storeId);
                request.CustomerId = customer.CustomerId;
            }

            StoreRentalResponse rental = new StoreRentalResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}rentals", uri, storeId);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request.ToFormCreateRental(staffId));

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    rental = JsonConvert.DeserializeObject<StoreRentalResponse>(dataJson);

                    request.RentalId = rental.RentalId;
                    request.CustomerId = rental.CustomerId;
                    request.StaffId = rental.StaffId;

                    if (request.Amount != null)
                    {
                        PaymentResponseLite payment = await RentalApiMethods.AddPayment(request.ToFormCreatePayment());
                    }
                }
            }

            return rental;
        }

        public static async Task<PaymentResponseLite> AddPayment(PaymentCreateRequest request)
        {
            PaymentResponseLite payment = new PaymentResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/payments", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                payment = JsonConvert.DeserializeObject<PaymentResponseLite>(dataJson);
            }

            return payment;
        }

        public static async Task<StoreRentalResponse> UpdateRental(RentalUpdateRequest request, int storeId, int rentalId)
        {
            StoreRentalResponse rental = new StoreRentalResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/rentals/{2}", uri, storeId, rentalId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                rental = JsonConvert.DeserializeObject<StoreRentalResponse>(dataJson);
            }

            return rental;
        }

        public static async Task DeleteRental(int rentalId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}rentals/{1}", uri, rentalId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }

        public static async Task DeletePayment(int paymentId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}payments/{1}", uri, paymentId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}
