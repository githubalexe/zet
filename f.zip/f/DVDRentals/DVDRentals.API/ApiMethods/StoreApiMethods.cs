﻿using DVDRentals.API.ApiMethods.ExtensionMethods;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Address;
using DVDRentals.API.Response.Store;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class StoreApiMethods
    {
        public static async Task<StoreResponse> GetStore(int storeId)
        {
            StoreResponse store = new StoreResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}", uri, storeId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    store = JsonConvert.DeserializeObject<StoreResponse>(dataJson);
                }
            }

            return store;
        }

        public static async Task<StoreResponse> UpdateStore(StoreFormRequest request, int storeId)
        {
            StoreResponse store = await StoreApiMethods.GetStore(storeId);
            AddressResponseLite address = await AddressApiMethods.UpdateAddressAsync(request.ToAddressUpdate(), store.AddressId);

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}stores/{1}", uri, storeId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request.ToStoreUpdateRequest(address.AddressId));

                string dataJson = await response.Content.ReadAsStringAsync();
                store = JsonConvert.DeserializeObject<StoreResponse>(dataJson);
            }

            return store;
        }
    }
}
