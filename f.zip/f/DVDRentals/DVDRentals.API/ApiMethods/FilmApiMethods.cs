﻿using DVDRentals.API.ApiMethods.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using DVDRentals.API.Response.Film;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class FilmApiMethods
    {
        public static async Task<FilmResponse> GetFilm(int filmId)
        {
            FilmResponse film = new FilmResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}films/{1}", uri, filmId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    film = JsonConvert.DeserializeObject<FilmResponse>(dataJson);
                }
            }

            return film;
        }

        public static async Task<IEnumerable<FilmResponse>> GetFilms()
        {
            IEnumerable<FilmResponse> films = new List<FilmResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}films", uri);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    films = JsonConvert.DeserializeObject<List<FilmResponse>>(dataJson);
                }
            }

            return films;
        }

        public static async Task<IEnumerable<FilmResponse>> GetStoreFilms(int storeId)
        {
            IEnumerable<FilmResponse> films = new List<FilmResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/stores/{1}/films", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    films = JsonConvert.DeserializeObject<List<FilmResponse>>(dataJson);
                }
            }

            return films;
        }

        public static async Task<FilmResponse> CreateFilm(FilmFormRequest request)
        {
            FilmResponse film = new FilmResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}films", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request.ToFormCreateFilm());

                string dataJson = await response.Content.ReadAsStringAsync();
                film = JsonConvert.DeserializeObject<FilmResponse>(dataJson);
            }

            FilmCategoryResponse filmCategory = await CategoryApiMethods.AddCategoryAsync(FilmExtensionMethods.AddCategory(film.FilmId, request.CategoryId));

            return film;
        }

        public static async Task<FilmResponse> UpdateFilm(FilmFormRequest request, int filmId)
        {
            //var categoryId = Int32.Parse(request.Category);
            FilmResponse film = await FilmApiMethods.GetFilm(filmId);

            await CategoryApiMethods.DeleteCategoryAsync(filmId, film.Category.CategoryId);
            FilmCategoryResponse filmCategory = await CategoryApiMethods.AddCategoryAsync(request.ToRequestAddCategory());

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}films/{1}", uri, filmId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request.ToFormUpdateFilm());

                string dataJson = await response.Content.ReadAsStringAsync();
                film = JsonConvert.DeserializeObject<FilmResponse>(dataJson);
            }

            return film;
        }

        public static async Task DeleteFilm(int filmId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}films/{1}", uri, filmId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }

        public static async Task<FilmActorResponse> AddActor(ActorFormRequest request, int filmId)
        {
            if (request.ExistingActor == "No")
            {
                ActorResponseLite actor = await ActorApiMethods.CreateActorAsync(request.ToRequestCreateActor());
                request.Name = actor.ActorId.ToString();
            }

            FilmActorResponse filmActor = new FilmActorResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}filmActors", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request.ToformCreateActorRequest(filmId));

                string dataJson = await response.Content.ReadAsStringAsync();
                filmActor = JsonConvert.DeserializeObject<FilmActorResponse>(dataJson);
            }
            return filmActor;

        }
    }
}
