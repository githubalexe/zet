﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Actor;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class ActorApiMethods
    {
        public static async Task<ActorResponseLite> GetActor(int actorId)
        {
            ActorResponseLite actor = new ActorResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}actors/{1}", uri, actorId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    actor = JsonConvert.DeserializeObject<ActorResponseLite>(dataJson);
                }
            }

            return actor;
        }

        public static async Task<IEnumerable<ActorResponseLite>> GetActors(int filmId)
        {
            IEnumerable<ActorResponseLite> actors = new List<ActorResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}films/{1}/actors", uri, filmId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    actors = JsonConvert.DeserializeObject<List<ActorResponseLite>>(dataJson);
                }
            }

            return actors;
        }

        public static async Task<IEnumerable<ActorResponseLite>> GetActors()
        {
            IEnumerable<ActorResponseLite> actors = new List<ActorResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/actors", uri);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    actors = JsonConvert.DeserializeObject<List<ActorResponseLite>>(dataJson);
                }
            }

            return actors;
        }

        public static async Task<ActorResponseLite> CreateActor(ActorCreateRequest request)
        {
            ActorResponseLite actor = new ActorResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}/actors", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                actor = JsonConvert.DeserializeObject<ActorResponseLite>(dataJson);
            }

            return actor;
        }

        public static async Task<ActorResponseLite> UpdateActor(ActorUpdateRequest request, int actorId)
        {
            ActorResponseLite actor = new ActorResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}actors/{1}", uri, actorId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                actor = JsonConvert.DeserializeObject<ActorResponseLite>(dataJson);
            }

            return actor;
        }

        public static async Task DeleteActor(int filmId, int actorId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}films/{1}/filmActors/{2}", uri, filmId, actorId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}
