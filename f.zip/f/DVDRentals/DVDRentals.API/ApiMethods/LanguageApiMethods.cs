﻿using DVDRentals.API.Response.Language;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.API.ApiMethods
{
    public class LanguageApiMethods
    {
        public static async Task<IEnumerable<LanguageResponseLite>> GetLanguagesAsync()
        {
            IEnumerable<LanguageResponseLite> language = new List<LanguageResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44361/";
                string url = String.Format("{0}languages", uri);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    language = JsonConvert.DeserializeObject<List<LanguageResponseLite>>(dataJson);
                }
            }

            return language;
        }
    }
}
