﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.UpdateRequest
{
    public class FilmCategoryUpdateRequest
    {
        public int CategoryId { get; set; }
    }
}
