﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.UpdateRequest
{
    public class StoreUpdateRequest
    {
        public int ManagerStaffId { get; set; }
        public int AddressId { get; set; }
    }
}
