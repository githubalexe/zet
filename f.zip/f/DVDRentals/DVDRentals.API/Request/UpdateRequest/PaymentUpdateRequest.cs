﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.UpdateRequest
{
    public class PaymentUpdateRequest
    {
        public int CustomerId { get; set; }
        public int StaffId { get; set; }
        public int? RentalId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
    }
}
