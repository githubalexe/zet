﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.UpdateRequest
{
    public class CountryUpdateRequest
    {
        public string Country { get; set; }
    }
}
