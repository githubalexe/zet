﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.UpdateRequest
{
    public class RentalUpdateRequest
    {
        public DateTime RentalDate { get; set; }
        public int InventoryId { get; set; }
        public int CustomerId { get; set; }
        public DateTime? ReturnDate { get; set; }
        public int StaffId { get; set; }
    }
}
