﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.DeleteRequest
{
    public class ActorDeleteRequest
    {
        public string[] ActorIds { get; set; }
    }
}
