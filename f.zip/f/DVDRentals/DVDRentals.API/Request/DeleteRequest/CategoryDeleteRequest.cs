﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.DeleteRequest
{
    public class CategoryDeleteRequest
    {
        public string[] CategoryIds { get; set; }
    }
}
