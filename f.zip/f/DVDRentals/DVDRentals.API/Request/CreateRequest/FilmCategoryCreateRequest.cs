﻿using System.ComponentModel.DataAnnotations;

namespace DVDRentals.API.Request.CreateRequest
{
    public class FilmCategoryCreateRequest
    {
        [Required(ErrorMessage = "FilmId is required.")]
        public int FilmId { get; set; }
        [Required(ErrorMessage = "CategoryId is required.")]
        public int CategoryId { get; set; }
    }
}
