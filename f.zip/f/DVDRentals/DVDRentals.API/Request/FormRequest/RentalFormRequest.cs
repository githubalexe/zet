﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentals.API.Request.FormRequest
{
    public class RentalFormRequest
    {
        public string ExistingCustomer { get; set; }

        public int RentalId { get; set; }

        public int FilmId { get; set; }

        public int CustomerId { get; set; }

        public int InventoryId { get; set; }

        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public DateTime RentalDate { get; set; }

        [DisplayFormat(DataFormatString = "{dd/MM/yyyy")]
        public DateTime? ReturnDate { get; set; }

        public decimal Amount { get; set; }

        [Display(Name = "Payment Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public DateTime PaymentDate { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string Address { get; set; }

        public string Address2 { get; set; }

        public string Distrinct { get; set; }

        public int CountryId { get; set; }

        public int CityId { get; set; }

        public string PostalCode { get; set; }

        public string Phone { get; set; }

        public int StaffId { get; set; }
    }
}

