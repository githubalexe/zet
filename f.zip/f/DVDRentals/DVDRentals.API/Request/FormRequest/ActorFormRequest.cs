﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.FormRequest
{
    public class ActorFormRequest
    {
        public string ExistingActor { get; set; }
        public int ActorId { get; set; }
        public string Name { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
