﻿using DVDRentals.API.Response.Payment;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response
{
    public class StaffPaymentsResponseLite
    {
        public int StaffId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public virtual List<StaffPaymentsResponse> Payments { get; set; }
        
    }
}
