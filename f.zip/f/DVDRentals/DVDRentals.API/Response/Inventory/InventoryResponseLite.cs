﻿using System;

namespace DVDRentals.API.Response.Inventory
{
    public class InventoryResponseLite
    {
        public int InventoryId { get; set; }
        public int FilmId { get; set; }
        public int StoreId { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
