﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum StoreMessages
    {
        [Description("The stores list is empty!")]
        InvalidStoresList,
        [Description("The store doesn't exist!")]
        NoStoreResponse,
        [Description("The store request is NULL!")]
        InvalidStoreResponse,
    }
}
