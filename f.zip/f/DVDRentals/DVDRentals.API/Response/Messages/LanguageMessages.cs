﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum LanguageMessages
    {
        [Description("The language doesn't exist!")]
        NoLanguageResponse,
        [Description("The language request is NULL!")]
        InvalidLanguageRequest,
        [Description("The language list is empty!")]
        InvalidLanguageList,
        [Description("Cannot delete this language because exist in a film!")]
        DeleteLanguageFailed,
    }
}
