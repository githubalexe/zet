﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum RentalMessages
    {
        [Description("The rental doesn't exist!")]
        InvalidRentalsList,
        [Description("The rental doesn't exist!")]
        NoRentalResponse,
        [Description("The rental request is NULL!")]
        InvalidRentaRequest,
    }
}
