﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
   public class ErrorMessage
    {
        public string Message { get; set; }
    }
}
