﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public class ErrorList
    {
        public ErrorList()
        {
            Errors = new List<string>();
        }      
        public List<string> Errors { get; set; }

        public string GetMessage(string model, string id)
        {
            string message = String.Format("The {0} with id {1} doesn't exist!", model, id);

            return message;
        }
    }
}
