﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum CustomerMessages
    {
        [Description("The customer doesn't exist!")]
        NoCustomerResponse,
        [Description("The customer payments list object is empty!")]
        InvalidCustomerPayments,
        [Description("The customer payment doesn't exist!")]
        NoCustomerPaymentResponse,
        [Description("The customer list is empty!")]
        InvalidCustomerList,
        [Description("The customer request is NULL!")]
        InvalidCustomerRequest,
    }
}
