﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum StaffMessages
    {
        [Description("The staff doesn't exist!")]
        NoStaffResponse,
        [Description("The staff list is empty!")]
        InvalidStaffList,
        [Description("You cannot delete a staff if it is a manager!")]
        DeleteStaffFailed,
        [Description("The staff payment list is empty!")]
        InvalidStaffPayments,
        [Description("The staff payment doesn't exist!")]
        NoStaffPaymentResponse,
        [Description("The staff request is NULL!")]
        InvalidStaffRequest,
    }
}
