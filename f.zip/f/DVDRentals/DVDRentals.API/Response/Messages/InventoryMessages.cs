﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum InventoryMessages
    {
        [Description("The inventory list is empty!")]
        InvalidInventoryList,
        [Description("The inventory doesn't exist!")]
        NoInventoryResponse,
        [Description("The inventory request is NULL!")]
        InvalidInventoryRequest,
    }
}
