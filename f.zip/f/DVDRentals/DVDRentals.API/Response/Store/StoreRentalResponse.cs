﻿using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Film;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Staff;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Store
{
    public class StoreRentalResponse
    {
        public int RentalId { get; set; }
        public DateTime RentalDate { get; set; }
        public int InventoryId { get; set; }
        public int CustomerId { get; set; }
        public DateTime? ReturnDate { get; set; }
        public int StaffId { get; set; }
        public DateTime LastUpdate { get; set; }
        public virtual FilmTitleResponse Film { get; set; }
        public virtual StaffNameResponse Staff { get; set; }
        public virtual CustomerNameResponse Customer { get; set; }
    }
}
