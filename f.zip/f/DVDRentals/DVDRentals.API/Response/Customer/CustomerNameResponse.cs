﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Customer
{
    public class CustomerNameResponse
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
    }
}
