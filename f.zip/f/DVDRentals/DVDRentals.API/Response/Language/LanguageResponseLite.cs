﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Language
{
    public class LanguageResponseLite
    {
        public int LanguageId { get; set; }
        public string Name { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
