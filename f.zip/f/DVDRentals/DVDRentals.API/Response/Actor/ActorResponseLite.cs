﻿using System;

namespace DVDRentals.API.Response.Actor
{
    public class ActorResponseLite
    {
        public int ActorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
