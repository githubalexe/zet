﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Response.Film
{
    public class FilmCategoryResponse
    {
        public int FilmId { get; set; }
        public int CategoryId { get; set; }
    }
}
