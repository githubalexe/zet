﻿using DVDRentals.API.Response.Actor;
using System.Collections.Generic;

namespace DVDRentals.API.Response.Film
{
    public class FilmActorsResponseLite
    {
        public int FilmId { get; set; }
        public string Title { get; set; }
        public virtual List<ActorResponseLite> FilmActors { get; set; }
    }
}

