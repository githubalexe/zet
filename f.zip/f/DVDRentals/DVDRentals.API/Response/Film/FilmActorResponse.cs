﻿using System;

namespace DVDRentals.API.Response.Film
{
    public class FilmActorResponse
    {
        public int FilmId { get; set; }
        public int ActorId { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}
