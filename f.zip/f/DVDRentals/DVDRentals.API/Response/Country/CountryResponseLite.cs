﻿using System;

namespace DVDRentals.API.Response.Country
{
    public class CountryResponseLite
    {
        public int CountryId { get; set; }
        public string Name { get; set; }
        public DateTime LastUpdate { get; set; }
    }
}