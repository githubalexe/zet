﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICategoryRepository
    {
        IQueryable<Category> CategoriesQuery();
        Task<IEnumerable<Category>> CategoriesListAsync(IQueryable<Category> query, bool asNoTracking = false);
        Task<Category> GetCategoryAsync(int categoryId);
        Task CreateCategoryAsync(Category category);
        void DeleteCategory(Category category);
        Task SaveChangesAsync();
    }
}
