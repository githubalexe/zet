﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmActorRepository
    {
        IQueryable<FilmActor> ActorsQuery();
        Task<IEnumerable<FilmActor>> ActorsListAsync(IQueryable<FilmActor> query, int filmId, bool asNoTracking = false);
        Task<IEnumerable<FilmActor>> FilmsListAsync(IQueryable<FilmActor> query, int actorId, bool asNoTracking = false);
        Task<FilmActor> GetActorAsync(int filmId, int actorId);
        Task<bool> ActorExistsAsync(int filmId, int actorId);
        Task AddActorAsync(FilmActor actor);
        void DeleteActor(FilmActor actor);
        Task SaveChangesAsync();
    }
}
