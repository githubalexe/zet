﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IAddressRepository
    {
        IQueryable<Address> AddressesQuery();
        Task<IEnumerable<Address>> AddressesListAsync(IQueryable<Address> query, bool asNoTracking = false);
        Task<Address> GetAddressAsync(int addressId);
        Task CreateAddressAsync(Address address);
        void DeleteAddress(Address address);

        Task<bool> AddressExistsAsync(int addressId);
        Task<bool> CityExistsAsync(int cityId);
        Task<bool> StoreAddressExistsAsync(int addressId);
        Task<bool> StaffAddressExistsAsync(int addressId);
        Task<bool> CustomerAddressExistsAsync(int addressId);

        Task SaveChangesAsync();
    }
}
