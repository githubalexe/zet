﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IStaffRepository
    {
        IQueryable<Staff> StaffsQuery();
        Task<IEnumerable<Staff>> ListStaffsAsync(IQueryable<Staff> query, int storeId, bool asNoTracking = false);
        Task<Staff> GetStaffAync(int storeId, int staffId);
        Task<bool> StaffExistsAync(int staffId);
        Task CreateStaffAsync(Staff staff);
        void DeleteStaff(Staff staff);
        Task SaveChangesAsync();
    }
}