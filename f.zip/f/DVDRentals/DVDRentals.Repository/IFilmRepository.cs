﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmRepository
    {
        IQueryable<Film> FilmsQuery();
        Task<IEnumerable<Film>> FilmsListAsync(IQueryable<Film> query, bool asNoTracking = false);
        Task<Film> GetFilmAsync(int filmId);
        Task CreateFilmAsync(Film film);
        void DeleteFilm(Film film);
        Task<bool> LanguageExistsAsync(int languageId);
        Task SaveChangesAsync();
    }
}
