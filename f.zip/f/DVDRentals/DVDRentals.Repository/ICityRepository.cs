﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICityRepository
    {
        IQueryable<City> CitiesQuery();
        Task<IEnumerable<City>> CitiesListAsync(IQueryable<City> query, bool asNoTracking = false);
        Task<City> GetCityAsync(int cityId);
        Task CreateCityAsync(City city);
        void DeleteCity(City city);

        Task<bool> CountryExistsAsync(int countryId);
        Task<bool> AddressExistsAsync(int countryId);
        Task SaveChangesAsync();
    }
}
