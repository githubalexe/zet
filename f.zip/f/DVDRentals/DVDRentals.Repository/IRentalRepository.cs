﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IRentalRepository
    {
        IQueryable<Rental> RentalsQuery();
        Task<IEnumerable<Rental>> InventoriesListAsync(IQueryable<Rental> query, int inventoryId, bool asNoTracking = false);
        Task<IEnumerable<Rental>> RentalsListAsync(IQueryable<Rental> query, bool asNoTracking = false);
        Task<IEnumerable<Rental>> CustomersRentalsListAsync(IQueryable<Rental> query, int customerId, bool asNoTracking = false);
        Task<IEnumerable<Rental>> StaffsRentalsListAsync(IQueryable<Rental> query, int staffId, bool asNoTracking = false);
        Task<Rental> GetRentalAsync(int? rentalId);
        Task<bool> RentalExistsAsync(int? rentalId);
        Task CreateRentalAsync(Rental rental);
        void DeleteRental(Rental rental);
        Task SaveChangesAsync();
    }
}