﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ICustomerRepository
    {
        IQueryable<Customer> CustomersQuery();
        Task<IEnumerable<Customer>> CustomersListAsync(IQueryable<Customer> query, int storeId, bool asNoTracking = false);
        Task<Customer> GetCustomerAsync(int storeId, int customerId);
        Task<bool> CustomerExistsAsync(int customerId);
        Task CreateCustomerAsync(Customer customer);
        void DeleteCustomer(Customer customer);
        Task SaveChangesAsync();
    }
}