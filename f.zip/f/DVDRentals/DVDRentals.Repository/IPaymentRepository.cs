﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IPaymentRepository
    {
        IQueryable<Payment> PaymentsQuery();
        Task<IEnumerable<Payment>> StaffsPaymentsListAsync(IQueryable<Payment> query, int staffId, bool asNoTracking = false);
        Task<IEnumerable<Payment>> CustomersPaymentsListAsync(IQueryable<Payment> query, int customerId, bool asNoTracking = false);
        Task<IEnumerable<Payment>> RentalPaymentsListAsync(IQueryable<Payment> query, int rentalId, bool asNoTracking = false);
        Task<Payment> GetCustomerPaymentAsync(int customerId, int paymentId);
        Task<Payment> GetStaffPaymentAsync(int staffId, int paymentId);
        Task<Payment> GetPaymentAsync(int paymentId);
        Task CreatePaymentAsync(Payment payment);
        void DeletePayment(Payment payment);
        Task SaveChangesAsync();
    }
}