﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IFilmCategoryRepository
    {
        IQueryable<FilmCategory> CategoriesQuery();
        Task<IEnumerable<FilmCategory>> FilmCategoriesListAsync(IQueryable<FilmCategory> query, int filmId, bool asNoTracking = false);
        Task<IEnumerable<FilmCategory>> FilmsListAsync(IQueryable<FilmCategory> query, int categoryId, bool asNoTracking = false);
        Task<FilmCategory> GetFilmCategoryAsync(int filmId, int categoryId);
        Task<FilmCategory> GetFilmCategoryAsync(int filmId);
        Task AddCategoryAsync(FilmCategory category);
        void UpdateFilm(FilmCategory category);
        void DeleteCategoryAsync(FilmCategory category);
        Task SaveChangesAsync();
    }
}
