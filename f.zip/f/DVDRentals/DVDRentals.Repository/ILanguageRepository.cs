﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface ILanguageRepository
    {
        IQueryable<Language> LanguagesQuery();
        Task<IEnumerable<Language>> ListLanguagesAsync(IQueryable<Language> query, bool asNoTracking = false);
        Task<Language> GetLanguageAsync(int languageId);
        Task<bool> FilmExistsAsync(int filmId);
        Task CreateLanguageAsync(Language language);
        void DeleteLanguage(Language language);
        Task SaveChangesAsync();
    }
}
