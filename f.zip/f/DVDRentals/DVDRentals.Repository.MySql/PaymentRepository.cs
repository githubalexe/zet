﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class PaymentRepository : IPaymentRepository
    {
        private UnitOfWork _unitOfWork;

        public PaymentRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<Payment> PaymentsQuery()
        {
            IQueryable<Payment> paymentsQuery = _unitOfWork.Payment;
            return paymentsQuery;
        }


        public async Task<IEnumerable<Payment>> RentalPaymentsListAsync(IQueryable<Payment> query, int rentalId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(p => p.RentalId == rentalId)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(p => p.RentalId == rentalId)
                                  .ToListAsync();
            }
        }

        public async Task<IEnumerable<Payment>> CustomersPaymentsListAsync(IQueryable<Payment> query, int customerId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(c => c.CustomerId == customerId)
                                  .Include(r => r.Rental)
                                  .ThenInclude(i => i.Inventory)
                                  .ThenInclude(f => f.Film)
                                  .Include(s => s.Staff)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(c => c.CustomerId == customerId)
                                  .ToListAsync();
            }
        }

        public async Task<Payment> GetCustomerPaymentAsync(int customerId, int paymentId)
        {
            return await _unitOfWork.Payment.Where(c => c.CustomerId == customerId)
                                             .Include(r => r.Rental)
                                             .ThenInclude(i => i.Inventory)
                                             .ThenInclude(f => f.Film)
                                             .Include(s => s.Staff)
                                             .FirstOrDefaultAsync(p => p.PaymentId == paymentId);
        }

        public async Task<Payment> GetPaymentAsync(int paymentId)
        {
            return await _unitOfWork.Payment.Include(r => r.Rental)
                                            .ThenInclude(i => i.Inventory)
                                            .ThenInclude(f => f.Film)
                                            .Include(c => c.Customer)
                                            .Include(s => s.Staff)
                                            .FirstOrDefaultAsync(p => p.PaymentId == paymentId);
        }

        public async Task<Payment> GetStaffPaymentAsync(int staffId, int paymentId)
        {
            return await _unitOfWork.Payment.Where(c => c.StaffId == staffId)
                                            .Include(r => r.Rental)
                                            .ThenInclude(i => i.Inventory)
                                            .ThenInclude(f => f.Film)
                                            .Include(c => c.Customer)
                                            .Include(s => s.Staff)
                                            .FirstOrDefaultAsync(p => p.PaymentId == paymentId);
        }

        public async Task<IEnumerable<Payment>> StaffsPaymentsListAsync(IQueryable<Payment> query, int staffId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(c => c.StaffId == staffId)
                                  .Include(r => r.Rental)
                                  .ThenInclude(i => i.Inventory)
                                  .ThenInclude(f => f.Film)
                                  .Include(c => c.Customer)
                                  .Include(s => s.Staff)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(c => c.StaffId == staffId)
                                  .ToListAsync();
            }
        }

        public async Task CreatePaymentAsync(Payment payment)
        {
            await _unitOfWork.Payment.AddAsync(payment);
        }

        public void DeletePayment(Payment payment)
        {
            _unitOfWork.Payment.Remove(payment);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
