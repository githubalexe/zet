﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class StaffRepository : IStaffRepository
    {
        private UnitOfWork _unitOfWork;
        public StaffRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<Staff> StaffsQuery()
        {
            IQueryable<Staff> staffsQuery = _unitOfWork.Staff;
            return staffsQuery;
        }

        public async Task<Staff> GetStaffAync(int storeId, int staffId)
        {
            return await _unitOfWork.Staff.Where(s => s.StoreId == storeId)
                                          .Include(a => a.Address)
                                          .ThenInclude(c => c.City)
                                          .ThenInclude(c => c.Country)
                                          .FirstOrDefaultAsync(s => s.StaffId == staffId);
        }

        public async Task<IEnumerable<Staff>> ListStaffsAsync(IQueryable<Staff> query, int storeId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(s => s.StoreId == storeId)
                                  .Include(a => a.Address)
                                  .ThenInclude(c => c.City)
                                  .ThenInclude(c => c.Country)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(s => s.StoreId == storeId)
                                  .Include(a => a.Address)
                                  .ThenInclude(c => c.City)
                                  .ThenInclude(c => c.Country)
                                  .ToListAsync();
            }
        }

        public async Task<bool> StaffExistsAync(int staffId)
        {
            return await _unitOfWork.Staff.AnyAsync(s => s.StaffId == staffId);
        }

        public async Task CreateStaffAsync(Staff staff)
        {
            await _unitOfWork.Staff.AddAsync(staff);
        }

        public void DeleteStaff(Staff staff)
        {
            _unitOfWork.Staff.Remove(staff);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
