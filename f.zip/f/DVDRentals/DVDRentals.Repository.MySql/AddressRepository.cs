﻿using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository.MySql
{
    public class AddressRepository : IAddressRepository
    {
        private UnitOfWork _unitOfWork;
        public AddressRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<Address> AddressesQuery()
        {
            IQueryable<Address> addressesQuery = _unitOfWork.Address;
            return addressesQuery;
        }

        public async Task<IEnumerable<Address>> AddressesListAsync(IQueryable<Address> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Include(a => a.City)
                                  .ThenInclude(c => c.Country)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Include(a => a.City)
                                  .ThenInclude(c => c.Country)
                                  .ToListAsync();
            }
        }

        public async Task<bool> AddressExistsAsync(int addressId)
        {
            return await _unitOfWork.Address.AnyAsync(c => c.AddressId == addressId);
        }

        public async Task<Address> GetAddressAsync(int addressId)
        {
            return await _unitOfWork.Address.Include(a => a.City)
                                            .ThenInclude(c => c.Country)
                                            .FirstOrDefaultAsync(a => a.AddressId == addressId);
        }

        public async Task<bool> StaffAddressExistsAsync(int addressId)
        {
            return await _unitOfWork.Staff.AnyAsync(s => s.AddressId == addressId);
        }

        public async Task<bool> StoreAddressExistsAsync(int addressId)
        {
            return await _unitOfWork.Store.AnyAsync(s => s.AddressId == addressId);
        }

        public async Task<bool> CustomerAddressExistsAsync(int addressId)
        {
            return await _unitOfWork.Customer.AnyAsync(c => c.AddressId == addressId);
        }

        public async Task<bool> CityExistsAsync(int cityId)
        {
            return await _unitOfWork.City.AnyAsync(c => c.CityId == cityId);
        }

        public async Task CreateAddressAsync(Address address)
        {
            await _unitOfWork.Address.AddAsync(address);
        }

        public void DeleteAddress(Address address)
        {
            _unitOfWork.Address.Remove(address);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
