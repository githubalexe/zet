﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class CountryRepository : ICountryRepository
    {
        private UnitOfWork _unitOfWork;
        public CountryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IQueryable<Country> CountriesQuery()
        {
            IQueryable<Country> countriesQuery = _unitOfWork.Country;
            return countriesQuery;
        }

        public async Task<IEnumerable<Country>> CountriesListAsync(IQueryable<Country> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public async Task<Country> GetCountryAsync(int countryId)
        {
            return await _unitOfWork.Country.FirstOrDefaultAsync(c => c.CountryId == countryId);
        }

        public async Task<bool> CityExistsAsync(int countryId)
        {
            return await _unitOfWork.City.AnyAsync(a => a.CountryId == countryId);
        }

        public async Task CreateCountryAsync(Country country)
        {
            await _unitOfWork.Country.AddAsync(country);
        }

        public void DeleteCountry(Country country)
        {
            _unitOfWork.Country.Remove(country);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}
