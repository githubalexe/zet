﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;


namespace DVDRentals.Repository.MySql
{
    public class FilmActorRepository : IFilmActorRepository
    {
        private UnitOfWork _unitOfWork;

        public FilmActorRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<FilmActor> ActorsQuery()
        {
            IQueryable<FilmActor> actorsQuery = _unitOfWork.FilmActor;
            return actorsQuery;
        }

        public async Task<IEnumerable<FilmActor>> ActorsListAsync(IQueryable<FilmActor> query, int filmId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(f => f.FilmId == filmId)
                                  .Include(a => a.Actor)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(f => f.FilmId == filmId)
                                  .Include(a => a.Actor)
                                  .ToListAsync();
            }
        }

        public async Task<IEnumerable<FilmActor>> FilmsListAsync(IQueryable<FilmActor> query, int actorId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(a => a.ActorId == actorId)
                                  .Include(a => a.Actor)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(a => a.ActorId == actorId)
                                  .Include(a => a.Actor)
                                  .ToListAsync();
            }
        }
        public async Task<bool> ActorExistsAsync(int filmId, int actorId)
        {
            return await _unitOfWork.FilmActor.AnyAsync(f => f.FilmId == filmId && f.ActorId == actorId);
        }

        public async Task<FilmActor> GetActorAsync(int filmId, int actorId)
        {
            return await _unitOfWork.FilmActor.Include(a => a.Actor)
                                              .FirstOrDefaultAsync(f => f.FilmId == filmId && f.ActorId == actorId);
        }

        public async Task AddActorAsync(FilmActor actor)
        {
            await _unitOfWork.FilmActor.AddAsync(actor);
        }

        public void DeleteActor(FilmActor actor)
        {
            _unitOfWork.FilmActor.Remove(actor);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}