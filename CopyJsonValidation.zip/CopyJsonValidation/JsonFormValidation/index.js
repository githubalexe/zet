define(["jquery", "CodeMirror", "JsonSchemaValidation", "InputsType", "bootstrap"], function($, CodeMirror, JsonSchemaValidation, InputsType) {

    var index = {};
    var $inputsJsonSchema = $("#inputsJsonSchema");
    var $dataJsonSchema = $("#dataJsonSchema");
    var $validationsJsonSchema = $("#validationsJsonSchema");
    var $errorsJsonSchema = $("#errorsJsonSchema");
    var $submitButton = $("#submitButton");
    var jsonSchemaValidation = null;
    var controls = [];

    var $inputsJsonSchemaEditor = CodeMirror.fromTextArea($inputsJsonSchema[0], {
        lineNumbers: true,
    });
    var $dataJsonSchemaEditor = CodeMirror.fromTextArea($dataJsonSchema[0], {
        lineNumbers: true,
    });
    var $validationsJsonSchemaEditor = CodeMirror.fromTextArea($validationsJsonSchema[0], {
        lineNumbers: true,
    });
    var $errorsJsonSchemaEditor = CodeMirror.fromTextArea($errorsJsonSchema[0], {
        lineNumbers: true,
    });

    index.setJsonSchema = function(inputs, values, validations) {
        $inputsJsonSchemaEditor.setValue(
            convertObjectToString(inputs)
        );
        $dataJsonSchemaEditor.setValue(
            convertObjectToString(values)
        );
        $validationsJsonSchemaEditor.setValue(
            convertObjectToString(validations)
        );
    }

    bindEvents();

    function initializeJsonSchema() {
        var inputs = $inputsJsonSchemaEditor.getValue();
        var values = $dataJsonSchemaEditor.getValue();
        var validations = $validationsJsonSchemaEditor.getValue();

        var options = {
            onCreateControl: function(control) {
                createControl(control);
            }
        }
        jsonSchemaValidation = new JsonSchemaValidation(options);
        jsonSchemaValidation.createInputByJsonValue(inputs, values, validations);
    };

    function bindEvents() {
        $submitButton.on("click", function() {
            controls = [];
            initializeJsonSchema();
        });

        $("#validation-tab").on("click", function() {
            $errorsJsonSchemaEditor.refresh();

        });
    };

    function createControl(control) {
        var inputType = control.inputType;
        var inputValidations = control.validations;
        switch (inputType) {
            case InputsType.Textbox:
                {
                    setTextboxErrorMessages(inputValidations, control);
                    break;
                }
            case InputsType.Dropdown:
                {
                    setDropsownListErrorMessages(inputValidations, control);
                    break;
                }
            default:
                {
                    console.log("something went wrong");
                }
        }
        getControls();
    };

    function setTextboxErrorMessages(inputValidations, control) {
        var inputValue = control.value;
        if (inputValidations) {
            var controlInput = {
                name: control.inputName,
                errorMessages: getErrorMessages(inputValue, inputValidations, control)
            };
            controls.push(controlInput);
        }
    };

    function setDropsownListErrorMessages(inputValidations, control) {
        var values = control.value;

        if (values === null) {
            if (inputValidations) {
                var controlInput = {
                    name: control.inputName,
                    errorMessages: getErrorMessages(values, inputValidations, control)
                }
                controls.push(controlInput);
            }
        } else {
            var values = control.value.split(",");
            var valuesLength = values.length;

            for (var i = 0; i < valuesLength; i++) {
                var textValue = getDropdownListText(values[i], control.items);
                if (inputValidations) {
                    var controlInput = {
                        name: control.inputName,
                        errorMessages: getErrorMessages(textValue, inputValidations, control)
                    }
                    controls.push(controlInput);
                }
            }
        }
    };

    function getDropdownListText(value, items) {
        var itemLenght = items.length;

        for (var i = 0; i < itemLenght; i++) {
            if (value === items[i].value) {
                var text = items[i].text;
                return text;
            }
        }
    };

    function getErrorMessages(inputValue, inputValidations, control) {
        var isControlRequired = inputValidations.required;
        var minValidation = inputValidations.min;
        var maxValidatiton = inputValidations.max;
        var regex = inputValidations.regex;
        var dataTypeValidation = control.dataType;
        var controlValueDataType = $.type(inputValue);
        var errors = [];

        errors.push(
            control.GetErrorMessageForRequired(inputValue, isControlRequired)
        );

        errors.push(
            control.GetErrorMessageForRegex(inputValue, regex)
        );

        errors.push(
            control.GetErrorMessageForDataType(controlValueDataType, dataTypeValidation)
        );

        errors.push(
            control.GetValueErrorMessage(inputValue, dataTypeValidation, minValidation, maxValidatiton)
        );

        var errorsFiltered = errors.filter(function(element) {
            return element != null;
        });

        return errorsFiltered;
    };

    function getControls() {
        $errorsJsonSchemaEditor.setValue(JSON.stringify(controls, null, '\t'));
    };

    function convertObjectToString(object) {
        return JSON.stringify(object, null, '\t');
    };

    return index;
});