define([], function() {

    var InputErrorMessages = {}

    InputErrorMessages.GetErrorMessageForDataType = function(dataType) {
        var errorMessage = `The field must be a ${dataType}!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForNumberMinValue = function(min) {
        var errorMessage = `The number must be bigger or equal with ${min}!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForNumberMaxValue = function(max) {
        var errorMessage = `The number must be smaller or equal with ${max}!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForStringMinValue = function(min) {
        var errorMessage = `Length required must be bigger or equal with ${min}!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForStringMaxValue = function(max) {
        var errorMessage = `Length required must be smaller or equal with ${max}!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForNumberValue = function(min, max) {
        var errorMessage = `The number must be between ${min} and ${max}!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForStringValue = function(min, max) {
        var errorMessage = `Length required is between ${min} and ${max} characters!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForRequired = function() {
        var errorMessage = `This field is required!`;

        return errorMessage;
    }

    InputErrorMessages.GetErrorMessageForRegex = function() {
        var errorMessage = `The value is incorrect!`;

        return errorMessage;
    }

    return InputErrorMessages;
});