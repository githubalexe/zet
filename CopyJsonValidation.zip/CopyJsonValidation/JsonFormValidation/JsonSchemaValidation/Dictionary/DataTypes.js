define([], function() {

    DataTypes = {
        Number: "number",
        String: "string",
        Null: "null"
    }

    return DataTypes;
});