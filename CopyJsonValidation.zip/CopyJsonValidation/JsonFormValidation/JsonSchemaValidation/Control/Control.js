define(["DataTypes", "InputErrorMessages"], function(DataTypes, InputErrorMessages) {

    function Control() {

        this.GetValueErrorMessage = function(controlValue, dataTypeValidation, minValidation, maxValidatiton) {
            var value = _getValue(controlValue, dataTypeValidation);
            if (!((value <= maxValidatiton) && (value >= minValidation))) {
                return _getValueErrorMessage(value, dataTypeValidation, minValidation, maxValidatiton);
            }
        };

        this.GetErrorMessageForDataType = function(controlValueDataType, dataTypeValidation) {
            if (controlValueDataType !== dataTypeValidation) {
                return InputErrorMessages.GetErrorMessageForDataType(dataTypeValidation);
            }
        };

        this.GetErrorMessageForRegex = function(controlValue, regex) {
            if (regex) {
                if (_getRegexResult(controlValue, regex) === false) {
                    return InputErrorMessages.GetErrorMessageForRegex();
                }
            }
        };

        this.GetErrorMessageForRequired = function(controlValue, isControlRequired) {
            if ((controlValue === null) && (isControlRequired)) {
                return InputErrorMessages.GetErrorMessageForRequired();
            }
        };
    };

    function _getRegexResult(value, regex) {
        var regexp = new RegExp("^" + regex + "*$");
        if (regexp.test(value) === false) {
            return false;
        }

        return true;
    };

    function _getValueErrorMessage(value, dataType, min, max) {
        switch (dataType) {
            case DataTypes.Number:
                {
                    if ((min === undefined) || (max === undefined)) {
                        return _getMinMaxErrorMessages(dataType, value, min, max)
                    } else {
                        return InputErrorMessages.GetErrorMessageForNumberValue(min, max);
                    }
                }
            case DataTypes.String:
                {
                    if ((min === undefined) || (max === undefined)) {
                        return _getMinMaxErrorMessages(dataType, value, min, max)
                    } else {
                        return InputErrorMessages.GetErrorMessageForStringValue(min, max);
                    }
                }
            default:
                {
                    console.log("something went wrong");
                }
        }
    };

    function _getMinMaxErrorMessages(dataType, value, min, max) {
        if ((max === undefined) && (min != undefined)) {
            if (value < min) {
                if (dataType === DataTypes.Number) {
                    return InputErrorMessages.GetErrorMessageForNumberMinValue(min);
                }
                if (dataType === DataTypes.String) {
                    return InputErrorMessages.GetErrorMessageForStringMinValue(min);
                }
            }
        }

        if ((min === undefined) && (max != undefined)) {
            if (value > max) {
                if (dataType === DataTypes.Number) {
                    return InputErrorMessages.GetErrorMessageForNumberMaxValue(max);
                }
                if (dataType === DataTypes.String) {
                    return InputErrorMessages.GetErrorMessageForStringMaxValue(max);
                }
            }
        }
    }

    function _getValue(value, dataType) {
        if (value !== null && value !== undefined) {
            switch (dataType) {
                case DataTypes.Number:
                    {
                        return value;
                    }
                case DataTypes.String:
                    {
                        return value.length;
                    }
                default:
                    {
                        console.log("something went wrong");
                    }
            }
        }
    };


    return Control;
});