﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OdeToFood
{
    public class Greeter : IGreeter
    {
        private IConfiguration config;

        public Greeter(IConfiguration value)
        {
            config = value;
        }
        public string MessageOfTheDay()
        {
            return config["Greeting"];
        }
    }
}
