﻿namespace OdeToFood
{
    public interface IGreeter
    {
        string MessageOfTheDay();
    }
}