﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OdeToFood.Models;
namespace OdeToFood.Services
{
    public class InMemoryRestaurantData : IRestaurantData
    {
        public InMemoryRestaurantData()
        {
            restaurants = new List<Restaurant>
                 {
                     new Restaurant{Id=1,Name="zlex"},
                     new Restaurant { Id = 2, Name = "Alex" },
                     new Restaurant { Id = 3, Name = "mlex" }
                };
        }

        public IEnumerable<Restaurant> GetAll()
        {
            return restaurants.OrderBy(p => p.Name);
        }

        public Restaurant Get(int id)
        {
            return restaurants.FirstOrDefault(p => p.Id==id);
        }

        public Restaurant Add(Restaurant newRestaurant)
        {
            newRestaurant.Id = restaurants.Max(p => p.Id) + 1;
            restaurants.Add(newRestaurant);
            return newRestaurant;
        }

        List<Restaurant> restaurants;
    }
}
