﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OdeToFood.Controllers
{
    [Route("[controller]/[action]")]
    public class AboutController:Controller
    {
        public string Number()
        {
            return "1+555+555";
        }

        public string Address()
        {
            return "Romania";
        }

        public IActionResult About()
        {
            return View();
        } 
    }
}
