﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class PaymentRepository : IPaymentRepository
    {
        private UnitOfWork _context;

        public PaymentRepository(UnitOfWork context)
        {
            _context = context;
        }
        public async Task<Payment> GetCustomerPaymentAsync(int customerId, int paymentId)
        {
            return await _context.Payment.Include(r => r.Rental)
                                         .ThenInclude(i => i.Inventory)
                                         .ThenInclude(f => f.Film)
                                         .Include(s => s.Staff)
                                         .FirstOrDefaultAsync(p => p.CustomerId == customerId && p.PaymentId == paymentId);
        }
        public async Task<Payment> GetStaffPaymentAsync(int staffId, int paymentId)
        {
            return await _context.Payment.Include(r => r.Rental)
                                         .ThenInclude(i => i.Inventory)
                                         .ThenInclude(f => f.Film)
                                         .Include(c => c.Customer)
                                         .FirstOrDefaultAsync(p => p.PaymentId == paymentId && p.StaffId == staffId);
        }
        public async Task<IEnumerable<Payment>> GetCustomerPaymentsAsync(int customerId)
        {
            return await _context.Payment.Where(p => p.CustomerId == customerId)
                                         .Include(r => r.Rental)
                                         .ThenInclude(i => i.Inventory)
                                         .ThenInclude(f => f.Film)
                                         .Include(s => s.Staff)
                                         .ToListAsync();
        }
        public async Task<IEnumerable<Payment>> GetStaffPaymentsAsync(int staffId)
        {
            return await _context.Payment.Where(p => p.StaffId == staffId)
                                         .Include(r => r.Rental)
                                         .ThenInclude(i => i.Inventory)
                                         .ThenInclude(f => f.Film)
                                         .Include(c => c.Customer)
                                         .ToListAsync();
        }
        public async Task<Payment> GetPaymentAsync(int paymentId)
        {
            return await _context.Payment.FirstOrDefaultAsync(p => p.PaymentId == paymentId);
        }
        public async Task<Payment> GetPaymentRentalAsync(int rentalId)
        {
            return await _context.Payment.FirstOrDefaultAsync(p => p.RentalId == rentalId);
        }
        public void AddPayment(Payment payment)
        {
            _context.Payment.Add(payment);
        }

        public void UpdatePayment(Payment payment)
        {
            _context.Payment.Update(payment);
        }

        public void DeletePayment(Payment payment)
        {
            _context.Payment.Remove(payment);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }
    }
}
