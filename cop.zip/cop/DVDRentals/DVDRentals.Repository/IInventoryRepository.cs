﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IInventoryRepository
    {
        Task<Inventory> GetInventoryAsync(int storeId, int inventoryId);
        Task<IEnumerable<Inventory>> GetInventoriesAsync(int filmId);
        Task<IEnumerable<Inventory>> GetFilmsAsync(int storeId);
        Task<IEnumerable<Inventory>> GetInventoriesAsync(int storeId, int filmId);
        void AddInventory(Inventory inventory);
        void UpdateInventory(Inventory inventory);
        void DeleteInventory(Inventory inventory);
        void SaveChanges();
    }
}
