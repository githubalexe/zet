﻿using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public interface IPaymentService
    {
        Task DeleteCustomerPayments(int customerId);
        Task DeleteStaffPayments(int staffId);
    }
}
