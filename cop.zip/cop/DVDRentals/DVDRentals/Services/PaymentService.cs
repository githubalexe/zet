﻿using DVDRentals.Domain;
using DVDRentals.Repository;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Services
{
    public class PaymentService : IPaymentService
    {
        private IPaymentRepository _paymentRepository;
        private IRentalService _rentalService;
        public PaymentService(IPaymentRepository paymentRepository, IRentalService rentalService)
        {
            _paymentRepository = paymentRepository;
            _rentalService = rentalService;
        }

        public async Task DeleteCustomerPayments(int customerId)
        {
            IEnumerable<Payment> paymentList = await _paymentRepository.GetCustomerPaymentsAsync(customerId);

            if (paymentList != null)
            {
                foreach (Payment payment in paymentList)
                {
                    await _rentalService.DeleteRentalAsync(payment.RentalId);

                    _paymentRepository.DeletePayment(payment);
                }
            }
        }

        public async Task DeleteStaffPayments(int staffId)
        {
            IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staffId);

            if (paymentList != null)
            {
                foreach (Payment payment in paymentList)
                {
                    await _rentalService.DeleteRentalAsync(payment.RentalId);

                    _paymentRepository.DeletePayment(payment);
                }
            }
        }
    }
}
