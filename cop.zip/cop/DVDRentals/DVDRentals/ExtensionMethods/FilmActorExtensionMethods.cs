﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Film;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmActorExtensionMethods
    {
        public static FilmActor ToFilmActorModel(this FilmActorCreateRequest request)
        {
            FilmActor filmActor = new FilmActor()
            {
                FilmId = request.FilmId,
                ActorId = request.ActorId
            };

            return filmActor;
        }

        public static FilmActorResponse  ToFilmActorResponse (this FilmActor filmActor)
        {
            FilmActorResponse filmActorResponse = new FilmActorResponse()
            {
                FilmId = filmActor.FilmId,
                ActorId = filmActor.ActorId,
                LastUpdate = filmActor.LastUpdate
            };

            return filmActorResponse;
        }
    }
}
