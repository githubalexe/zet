﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Film;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmCategoryExtensionMethods
    {
        public static FilmCategory ToFilmCategoryModel (this FilmCategoryCreateRequest request)
        {
            FilmCategory filmCategory = new FilmCategory()
            {
                FilmId = request.FilmId,
                CategoryId = request.CategoryId
            };

            return filmCategory;
        }

        public static FilmCategoryResponse ToFilmCategoryResponse(this FilmCategory filmCategory)
        {
            FilmCategoryResponse filmCategoryResponse = new FilmCategoryResponse()
            {
                FilmId = filmCategory.FilmId,
                CategoryId = filmCategory.CategoryId
            };

            return filmCategoryResponse;
        }
    }
}
