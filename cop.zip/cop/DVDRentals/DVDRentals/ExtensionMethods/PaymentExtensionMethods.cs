﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Staff;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class PaymentExtensionMethods
    {
        public static PaymentForCustomerResponse ToCustomerPaymentResponse(this Payment payment)
        {
            PaymentForCustomerResponse paymentReponse = new PaymentForCustomerResponse()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                Rental = payment.Rental.ToRentalResponseLite(),
                Staff = payment.Staff.ToStaffPaymentResponse()
            };

            return paymentReponse;
        }

        public static List<PaymentForCustomerResponse> ToCustomerPaymentsResponse(this IEnumerable<Payment> paymentList)
        {
            List<PaymentForCustomerResponse> paymentReponseList = new List<PaymentForCustomerResponse>();

            foreach (Payment payment in paymentList)
            {
                if (payment.Staff != null)
                {
                    paymentReponseList.Add(payment.ToCustomerPaymentResponse());
                }
            }

            return paymentReponseList;
        }

        public static PaymentForStaffResponse ToStaffPaymentResponse(this Payment payment)
        {
            PaymentForStaffResponse paymentReponse = new PaymentForStaffResponse()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                Rental = payment.Rental.ToRentalResponseLite(),
                Customer = payment.Customer.ToCustomerPaymentResponse()
            };


            return paymentReponse;
        }

        public static List<PaymentForStaffResponse> ToStaffPaymentsResponse(this IEnumerable<Payment> paymentList)
        {
            List<PaymentForStaffResponse> paymentReponseList = new List<PaymentForStaffResponse>();

            foreach (Payment payment in paymentList)
            {
                if (payment.Rental != null)
                {
                    paymentReponseList.Add(payment.ToStaffPaymentResponse());
                }
            }

            return paymentReponseList;
        }
        public static StorePaymentsResponse ToStorePaymentResponse(this Payment payment)
        {
            StorePaymentsResponse storePayment = new StorePaymentsResponse()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                Rental = payment.Rental.ToRentalResponseLite(),
                Staff = payment.Staff.ToStaffPaymentResponse(),
                Customer = payment.Customer.ToCustomerPaymentResponse()
            };

            return storePayment;
        }

        public static Payment ToPaymentModel(this PaymentCreateRequest request)
        {
            Payment payment = new Payment()
            {
                CustomerId = request.CustomerId,
                StaffId = request.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount,
                PaymentDate = request.PaymentDate
            };

            return payment;
        }

        public static Payment ToPaymentModel(this PaymentUpdateRequest request, Payment payment)
        {
            payment.CustomerId = request.CustomerId;
            payment.StaffId = request.StaffId;
            payment.RentalId = request.RentalId;
            payment.Amount = request.Amount;
            payment.PaymentDate = request.PaymentDate;

            return payment;
        }

        public static PaymentResponse ToPaymentResponse(this Payment payment)
        {
            PaymentResponse paymentResponse = new PaymentResponse()
            {
                PaymentId = payment.PaymentId,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,
                LastUpdate = payment.LastUpdate
            };

            return paymentResponse;
        }

        public static StaffPaymentResponse ToStaffPaymentResponse(this Staff staff)
        {
            StaffPaymentResponse staffPaymentResponse = new StaffPaymentResponse()
            {
                StaffId = staff.StaffId,
                FirstName = staff.FirstName,
                LastName = staff.LastName
            };

            return staffPaymentResponse;
        }
    }
}
