﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using DVDRentals.ExtensionMethods;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Controllers
{
    public class PaymentController : Controller
    {
        private IPaymentRepository _paymentRepository;
        private IStaffRepository _staffRepository;

        public PaymentController(IPaymentRepository paymentRepository, IStaffRepository staffRepository)
        {
            _paymentRepository = paymentRepository;
            _staffRepository = staffRepository;
        }

        [HttpGet("stores/{storeId}/payments")]
        public async Task<IActionResult> GetStorePaymentsAsync(int storeId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StorePaymentsResponse> paymentResponseList = new List<StorePaymentsResponse>();

            foreach (Staff staff in staffList)
            {
                IEnumerable<Payment> paymentList = await _paymentRepository.GetStaffPaymentsAsync(staff.StaffId);
                foreach (Payment payment in paymentList)
                {
                    if (payment.Rental != null)
                    {
                        paymentResponseList.Add(payment.ToStorePaymentResponse());
                    }
                }
            }

            return Ok(paymentResponseList);
        }

        [HttpGet("stores/{storeId}/payments/{paymentId}")]
        public async Task<IActionResult> GetStorePaymentAsync(int storeId, int paymentId)
        {
            IEnumerable<Staff> staffList = await _staffRepository.GetStaffsAsync(storeId);
            List<StorePaymentsResponse> paymentResponseList = new List<StorePaymentsResponse>();

            foreach (Staff staff in staffList)
            {
                Payment payment = await _paymentRepository.GetStaffPaymentAsync(staff.StaffId, paymentId);
                if (payment != null)
                {
                    paymentResponseList.Add(payment.ToStorePaymentResponse());
                }
            }

            if (paymentResponseList == null)
            {
                return NotFound("The payment doesn't exist!");
            }

            return Ok(paymentResponseList);
        }

        [HttpGet("payments/{paymentId}", Name = "GetPaymentAsync")]
        public async Task<IActionResult> GetPaymentAsync(int paymentId)
        {
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);
            PaymentResponse paymentResponse = payment.ToPaymentResponse();

            return Ok(paymentResponse);
        }

        [HttpPost("payments")]
        public IActionResult CreatePaymentAsync([FromBody] PaymentCreateRequest request)
        {
            Payment payment = request.ToPaymentModel();
            _paymentRepository.AddPayment(payment);
            _paymentRepository.SaveChanges();
            PaymentResponse paymentResponse = payment.ToPaymentResponse();

            return CreatedAtRoute("GetPaymentAsync", new { paymentId = paymentResponse.PaymentId }, paymentResponse);
        }

        [HttpPut("payments/{paymentId}")]
        public async Task<IActionResult> UpdatePaymentAsync([FromBody] PaymentUpdateRequest request, int paymentId)
        {
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);

            if (payment != null)
            {
                payment = request.ToPaymentModel(payment);
                _paymentRepository.UpdatePayment(payment);
                _paymentRepository.SaveChanges();
                PaymentResponse paymentResponse = payment.ToPaymentResponse();

                return Ok(paymentResponse);
            }

            return NotFound("The payment doesn't exist!");
        }

        [HttpDelete("payments/{paymentId}")]
        public async Task<IActionResult> DeletePaymentAsync(int paymentId)
        {
            Payment payment = await _paymentRepository.GetPaymentAsync(paymentId);

            if (payment != null)
            {
                _paymentRepository.DeletePayment(payment);
                _paymentRepository.SaveChanges();

                return Ok("The payment has been deleted!");
            }

            return NotFound("The payment doesn't exist!");
        }
    }
}