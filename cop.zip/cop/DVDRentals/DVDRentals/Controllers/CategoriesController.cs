﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.Domain;
using DVDRentals.Repository;
using Microsoft.AspNetCore.Mvc;
using DVDRentals.ExtensionMethods;
using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Category;
using DVDRentals.API.Response.Film;

namespace DVDRentals.Controllers
{
    public class CategoriesController : Controller
    {
        private ICategoryRepository _categoryRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        public CategoriesController(ICategoryRepository categoryRepository, IFilmCategoryRepository filmCategoryRepository)
        {
            _categoryRepository = categoryRepository;
            _filmCategoryRepository = filmCategoryRepository;
        }
        [HttpGet("categories")]
        public async Task<IActionResult> GetCategoriesAsync()
        {
            IEnumerable<Category> categoryList = await _categoryRepository.GetCategoriesAsync();
            List<CategoryResponse> categoryResponseList = categoryList.ToCategoryResponseList();

            return Ok(categoryResponseList);
        }

        [HttpGet("categories/{categoryId}/films")]
        public async Task<IActionResult> GetFilmsCategoryAsync(int categoryId)
        {
            IEnumerable<FilmCategory> filmCategoryList = await _filmCategoryRepository.GetFilmsCategoryAsync(categoryId);
            List<FilmResponse> filmResponseList = new List<FilmResponse>();

            foreach (FilmCategory filmCategory in filmCategoryList)
            {
                filmResponseList.Add(filmCategory.Film.ToFilmResponse());
            }

            return Ok(filmResponseList);
        }

        [HttpGet("categories/{categoryId}", Name = "GetCategoryAsync")]
        public async Task<IActionResult> GetCategoryAsync(int categoryId)
        {
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);
            if (category != null)
            {
                CategoryResponse categoryResponse = category.ToCategoryResponse();

                return Ok(categoryResponse);
            }

            return NotFound("The category doesn't exist!");
        }

        [HttpPost("categories")]
        public IActionResult CreateCategoryAsync([FromBody] CategoryCreateRequest request)
        {
            Category category = request.ToCategoryModel();
            _categoryRepository.AddCategory(category);
            _categoryRepository.SaveChanges();
            CategoryResponse categoryResponse = category.ToCategoryResponse();

            return CreatedAtRoute("GetCategoryAsync", new { categoryId = category.CategoryId }, categoryResponse);
        }

        [HttpDelete("categories/{categoryId}")]
        public async Task<IActionResult> DeleteCategoryAsync(int categoryId)
        {
            Category category = await _categoryRepository.GetCategoryAsync(categoryId);

            if (category != null)
            {
                _categoryRepository.DeleteCategory(category);
                _categoryRepository.SaveChanges();
                
                return Ok("The category has been deleted!");
            }

            return NotFound("The category doesn't exist!");
        }
    }
}