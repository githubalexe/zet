﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DVDRentalsMongo.Domain
{
    public class FilmCategory
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string CategoryId { get; set; }
    }
}
