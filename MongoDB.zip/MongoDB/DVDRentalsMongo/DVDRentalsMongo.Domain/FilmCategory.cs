﻿namespace DVDRentalsMongo.Domain
{
    public class FilmCategory
    {
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string CategoryId { get; set; }
    }
}
