﻿namespace DVDRentalsMongo.Domain
{
    public class Film
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int ReleaseYear { get; set; }
        public string LanguageId { get; set; }
        public int RentalDuration { get; set; }
        public decimal RentalRate { get; set; }
        public int? Length { get; set; }
        public decimal ReplacementCost { get; set; }
        public string RatingId { get; set; }
        public string SpecialFeaturesId { get; set; }
        public virtual Language Language { get; set; }
        public virtual Category Category { get; set; }
        public virtual Rating Rating { get; set; }
        public virtual SpecialFeatures SpecialFeatures { get; set; }

    }
}
