﻿namespace DVDRentalsMongo.Domain
{
    public class Country
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
