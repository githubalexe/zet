﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.Domain
{
    public class SpecialFeatures
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
