﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DVDRentalsMongo.Domain
{
    public class FilmActor
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string ActorId { get; set; }
    }
}
