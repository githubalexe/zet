﻿namespace DVDRentalsMongo.Domain
{
    public class FilmActor
    {
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string ActorId { get; set; }
    }
}
