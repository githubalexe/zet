﻿namespace DVDRentalsMongo.Domain
{
    public class Inventory
    {
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string StoreId { get; set; }
    }
}
