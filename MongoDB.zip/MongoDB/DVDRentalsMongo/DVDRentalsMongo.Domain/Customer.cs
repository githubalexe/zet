﻿using System;

namespace DVDRentalsMongo.Domain
{
    public class Customer
    {
        public string Id { get; set; }
        public string StoreId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string AddressId { get; set; }
        public bool Active { get; set; }
        public DateTime CreateDate { get; set; }
        public virtual Address Address { get; set; }
    }
}
