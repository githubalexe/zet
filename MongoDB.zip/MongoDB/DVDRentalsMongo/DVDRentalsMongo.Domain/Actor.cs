﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace DVDRentalsMongo.Domain
{
    public class Actor
    {
        //[BsonId]
        //[BsonRepresentation(BsonType.String)]
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
