﻿namespace DVDRentalsMongo.Domain
{
    public class Store
    {
        public string Id { get; set; }
        public string ManagerStaffId { get; set; }
        public string AddressId { get; set; }
    }
}
