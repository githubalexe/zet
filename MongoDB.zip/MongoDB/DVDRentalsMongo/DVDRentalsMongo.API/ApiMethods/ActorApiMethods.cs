﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Actor;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class ActorApiMethods: IActorApiMethods
    {
        static HttpClient _client = new HttpClient();
        public ActorApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<ActorResponse> GetActorAsync(string actorId)
        {
            ActorResponse actor = new ActorResponse();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}actors/{1}", uri, actorId);
            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                actor = JsonConvert.DeserializeObject<ActorResponse>(dataJson);
            }

            return actor;
        }


        public async Task<IEnumerable<ActorResponse>> GetActorsAsync()
        {
            IEnumerable<ActorResponse> actors = new List<ActorResponse>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}actors", uri);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                actors = JsonConvert.DeserializeObject<List<ActorResponse>>(dataJson);
            }

            return actors;
        }

        public async Task<IEnumerable<ActorResponse>> GetActorsAsync(string filmId)
        {
            IEnumerable<ActorResponse> actors = new List<ActorResponse>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}films/{1}/actors", uri, filmId);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                actors = JsonConvert.DeserializeObject<List<ActorResponse>>(dataJson);
            }

            return actors;
        }

        public async Task<ActorResponseLite> CreateActorAsync(ActorCreateRequest request)
        {
            ActorResponseLite actor = new ActorResponseLite();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}/actors", uri);

            HttpResponseMessage response = await _client.PostAsJsonAsync(url, request);

            string dataJson = await response.Content.ReadAsStringAsync();
            actor = JsonConvert.DeserializeObject<ActorResponseLite>(dataJson);

            return actor;
        }

        public async Task<ActorResponseLite> UpdateActorAsync(ActorFormRequest request, string actorId)
        {
            ActorResponseLite actor = new ActorResponseLite();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}actors/{1}", uri, actorId);

            HttpResponseMessage response = await _client.PutAsJsonAsync(url, request.ToActorUpdateRequest());

            string dataJson = await response.Content.ReadAsStringAsync();
            actor = JsonConvert.DeserializeObject<ActorResponseLite>(dataJson);

            return actor;
        }

        public async Task DeleteActorAsync(string filmId, string actorId)
        {
            string uri = "https://localhost:44306/";
            string url = String.Format("{0}films/{1}/actors/{2}", uri, filmId, actorId);

            HttpResponseMessage response = await _client.DeleteAsync(url);

        }
    }
}
