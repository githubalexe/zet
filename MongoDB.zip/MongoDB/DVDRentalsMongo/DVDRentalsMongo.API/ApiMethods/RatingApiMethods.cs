﻿using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Response.Rating;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class RatingApiMethods: IRatingApiMethods
    {
        private readonly HttpClient _client;

        public RatingApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<RatingResponseLite>> GetRatings()
        {
            IEnumerable<RatingResponseLite> ratings = new List<RatingResponseLite>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}ratings", uri);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                ratings = JsonConvert.DeserializeObject<List<RatingResponseLite>>(dataJson);
            }

            return ratings;
        }
    }
}
