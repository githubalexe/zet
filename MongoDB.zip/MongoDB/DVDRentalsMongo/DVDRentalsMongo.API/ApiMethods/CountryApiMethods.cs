﻿using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Response.City;
using DVDRentalsMongo.API.Response.Country;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class CountryApiMethods :ICountryApiMethods
    {
        private readonly HttpClient _client;

        public CountryApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<CountryResponseLite>> GetCountriesAsync()
        {
            IEnumerable<CountryResponseLite> country = new List<CountryResponseLite>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}countries", uri);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                country = JsonConvert.DeserializeObject<List<CountryResponseLite>>(dataJson);
            }

            return country;
        }

        public async Task<CityResponseLite> GetCityAsync(string cityId)
        {
            CityResponseLite city = new CityResponseLite();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}cities/{1}", uri, cityId);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                city = JsonConvert.DeserializeObject<CityResponseLite>(dataJson);
            }

            return city;
        }
    }
}
