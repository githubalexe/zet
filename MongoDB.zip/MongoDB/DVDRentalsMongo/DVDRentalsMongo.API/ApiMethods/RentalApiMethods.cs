﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.API.Response.Payment;
using DVDRentalsMongo.API.Response.Rental;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class RentalApiMethods: IRentalApiMethods
    {
        private readonly HttpClient _client;
        private readonly ICustomerApiMethods _customerApiMethods;
        private readonly IPaymentApiMethods _paymentApiMethods;

        public RentalApiMethods(HttpClient client, ICustomerApiMethods customerApiMethods, IPaymentApiMethods paymentApiMethods)
        {
            _client = client;
            _customerApiMethods = customerApiMethods;
            _paymentApiMethods = paymentApiMethods;
        }

        public async Task<RentalResponse> GetRentalAsync(string rentalId)
        {
            RentalResponse rental = new RentalResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}rentals/{1}", uri, rentalId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    rental = JsonConvert.DeserializeObject<RentalResponse>(dataJson);
                }
            }

            return rental;
        }

        public async Task<IEnumerable<RentalResponse>> GetRentalsAsync(string storeId)
        {
            IEnumerable<RentalResponse> rentals = new List<RentalResponse>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/rentals", uri, storeId);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                rentals = JsonConvert.DeserializeObject<List<RentalResponse>>(dataJson);
            }

            return rentals;
        }

        public async Task<IEnumerable<RentalResponseLite>> GetInventoryRentalsAsync(string inventoryId)
        {
            IEnumerable<RentalResponseLite> rentals = new List<RentalResponseLite>();


            string uri = "https://localhost:44306/";
            string url = String.Format("{0}inventoryRentals/{1}", uri, inventoryId);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                rentals = JsonConvert.DeserializeObject<List<RentalResponseLite>>(dataJson);
            }

            return rentals;
        }

        public async Task<IEnumerable<PaymentResponseLite>> GetPaymentsAsync(string rentalId)
        {
            IEnumerable<PaymentResponseLite> payments = new List<PaymentResponseLite>();


            string uri = "https://localhost:44306/";
            string url = String.Format("{0}rentals/{1}/payments", uri, rentalId);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                payments = JsonConvert.DeserializeObject<List<PaymentResponseLite>>(dataJson);
            }

            return payments;
        }

        public async Task<RentalResponse> CreateRentalAsync(RentalFormRequest request, string storeId)
        {
            if (request.ExistingCustomer == "No")
            {
                CustomerResponse customer = await _customerApiMethods.CreateCustomerAsync(request.ToCustomerFormRequest(), storeId);
                request.CustomerId = customer.Id;
            }

            RentalResponse rental = new RentalResponse();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}rentals", uri, storeId);

            HttpResponseMessage response = await _client.PostAsJsonAsync(url, request.ToRentalCreateRequest());

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                rental = JsonConvert.DeserializeObject<RentalResponse>(dataJson);

                request.RentalId = rental.Id;
                request.CustomerId = rental.CustomerId;
                request.StaffId = rental.StaffId;

                if (request.Amount != null)
                {
                    PaymentResponseLite payment = await _paymentApiMethods.AddPaymentAsync(request.ToPaymentFormRequest());
                }
            }

            return rental;
        }

        public async Task<RentalResponse> UpdateRentalAsync(RentalFormRequest request, string rentalId)
        {
            RentalResponse rental = new RentalResponse();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}rentals/{1}", uri, rentalId);

            HttpResponseMessage response = await _client.PutAsJsonAsync(url, request.ToRentalUpdateRequest());

            string dataJson = await response.Content.ReadAsStringAsync();
            rental = JsonConvert.DeserializeObject<RentalResponse>(dataJson);

            return rental;
        }

        public async Task DeleteRental(string rentalId)
        {
            string uri = "https://localhost:44306/";
            string url = String.Format("{0}rentals/{1}", uri, rentalId);

            HttpResponseMessage response = await _client.DeleteAsync(url);
        }
    }
}
