﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Payment;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public static class PaymentApiMethods
    {
        public static async Task<PaymentResponseLite> AddPaymentAsync(PaymentFormRequest request)
        {
            PaymentResponseLite payment = new PaymentResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}/payments", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request.ToPaymentCreateRequest());

                string dataJson = await response.Content.ReadAsStringAsync();
                payment = JsonConvert.DeserializeObject<PaymentResponseLite>(dataJson);
            }

            return payment;
        }

        public static async Task DeletePaymentAsync(string paymentId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}payments/{1}", uri, paymentId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}
