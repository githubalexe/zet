﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Payment;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class PaymentApiMethods: IPaymentApiMethods
    {
        private readonly HttpClient _client;

        public PaymentApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<PaymentResponseLite> AddPaymentAsync(PaymentFormRequest request)
        {
            PaymentResponseLite payment = new PaymentResponseLite();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}/payments", uri);

            HttpResponseMessage response = await _client.PostAsJsonAsync(url, request.ToPaymentCreateRequest());

            string dataJson = await response.Content.ReadAsStringAsync();
            payment = JsonConvert.DeserializeObject<PaymentResponseLite>(dataJson);

            return payment;
        }

        public async Task DeletePaymentAsync(string paymentId)
        {
            string uri = "https://localhost:44306/";
            string url = String.Format("{0}payments/{1}", uri, paymentId);

            HttpResponseMessage response = await _client.DeleteAsync(url);

        }
    }
}
