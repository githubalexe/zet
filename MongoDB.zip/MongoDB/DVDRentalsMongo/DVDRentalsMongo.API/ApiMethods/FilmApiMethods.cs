﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Actor;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.FilmActor;
using DVDRentalsMongo.API.Response.FilmCategory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public static class FilmApiMethods
    {
        public static async Task<FilmResponse> GetFilmAsync(string filmId)
        {
            FilmResponse film = new FilmResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}films/{1}", uri, filmId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    film = JsonConvert.DeserializeObject<FilmResponse>(dataJson);
                }
            }

            return film;
        }

        public static async Task<IEnumerable<FilmResponse>> GetFilmsAsync()
        {
            IEnumerable<FilmResponse> films = new List<FilmResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}films", uri);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    films = JsonConvert.DeserializeObject<List<FilmResponse>>(dataJson);
                }
            }

            return films;
        }

        public static async Task<IEnumerable<FilmResponse>> GetStoreFilmsAsync(string storeId)
        {
            IEnumerable<FilmResponse> films = new List<FilmResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}/stores/{1}/films", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    films = JsonConvert.DeserializeObject<List<FilmResponse>>(dataJson);
                }
            }

            return films;
        }

        public static async Task<FilmResponse> CreateFilmAsync(FilmFormRequest request)
        {
            FilmResponse film = new FilmResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}films", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request.ToFilmCreateRequest());
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    film = JsonConvert.DeserializeObject<FilmResponse>(dataJson);
                }
            }

            FilmCategoryResponseLite filmCategory = await CategoryApiMethods.AddCategoryAsync(CategoryExtesionMethods.ToFilmCategoryCreateRequest(film.Id, request.CategoryId));

            return film;
        }

        public static async Task<FilmResponse> UpdateFilm(FilmFormRequest request, string filmId)
        {

            FilmResponse film = await FilmApiMethods.GetFilmAsync(filmId);

            await CategoryApiMethods.DeleteCategoryAsync(filmId, film.Category.Id);
            FilmCategoryResponseLite filmCategory = await CategoryApiMethods.AddCategoryAsync(request.ToFilmCategoryCreateRequest(filmId));

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}films/{1}", uri, filmId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request.ToFilmUpdateRequest());

                string dataJson = await response.Content.ReadAsStringAsync();
                film = JsonConvert.DeserializeObject<FilmResponse>(dataJson);
            }

            return film;
        }

        public static async Task DeleteFilmAsync(string filmId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}films/{1}", uri, filmId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }

        //Actor
        public static async Task<FilmActorResponseLite> AddActorAsync(ActorFormRequest request, string filmId)
        {
            if (request.ExistingActor == "No")
            {
                ActorResponseLite actor = await ActorApiMethods.CreateActorAsync(request.ToActorCreateRequest());
                request.ActorId = actor.Id;
            }

            FilmActorResponseLite filmActor = new FilmActorResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}filmsactor", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request.ToFilmActorCreateRequest(filmId));

                string dataJson = await response.Content.ReadAsStringAsync();
                filmActor = JsonConvert.DeserializeObject<FilmActorResponseLite>(dataJson);
            }
            return filmActor;

        }
    }
}
