﻿using DVDRentalsMongo.API.Response.Language;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public static class LanguageApiMethods
    {
        public static async Task<IEnumerable<LanguageResponseLite>> GetLanguagesAsync()
        {
            IEnumerable<LanguageResponseLite> languages = new List<LanguageResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}languages", uri);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    languages = JsonConvert.DeserializeObject<List<LanguageResponseLite>>(dataJson);
                }
            }

            return languages;
        }
    }
}
