﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static FilmCreateRequest ToFilmCreateRequest(this FilmFormRequest request)
        {
            return new FilmCreateRequest()
            {
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                OriginalLanguageId = request.OriginalLanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                Rating = request.Rating,
                SpecialFeatures = request.SpecialFeatures
            };
        }

        public static FilmUpdateRequest ToFilmUpdateRequest(this FilmFormRequest request)
        {
            return new FilmUpdateRequest()
            {
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                OriginalLanguageId = request.OriginalLanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                Rating = request.Rating,
                SpecialFeatures = request.SpecialFeatures
            };
        }
    }
}
