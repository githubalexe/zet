﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class CategoryExtesionMethods
    {
        public static FilmCategoryCreateRequest ToFilmCategoryCreateRequest(this FilmFormRequest request, string filmId)
        {
            return new FilmCategoryCreateRequest
            {
                FilmId = filmId,
                CategoryId = request.CategoryId
            };
        }

        public static FilmCategoryCreateRequest ToFilmCategoryCreateRequest(string filmId, string categoryId)
        {
            return new FilmCategoryCreateRequest
            {
                FilmId = filmId,
                CategoryId = categoryId
            };
        }
    }
}
