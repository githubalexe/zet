﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static RentalCreateRequest ToRentalCreateRequest(this RentalFormRequest request)
        {
            return new RentalCreateRequest
            {
                RentalDate = request.RentalDate,
                InventoryId = request.InventoryId,
                CustomerId = request.CustomerId,
                ReturnDate = request.ReturnDate,
                StaffId = request.StaffId
            };
        }
        public static RentalUpdateRequest ToRentalUpdateRequest(this RentalFormRequest request)
        {
            return new RentalUpdateRequest
            {
                RentalDate = request.RentalDate,
                InventoryId = request.InventoryId,
                CustomerId = request.CustomerId,
                ReturnDate = request.ReturnDate,
                StaffId = request.StaffId
            };
        }

        public static CustomerFormRequest ToCustomerFormRequest(this RentalFormRequest request)
        {
            return new CustomerFormRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Address = request.Address,
                Address2 = request.Address2,
                Distrinct = request.Distrinct,
                Country = request.CountryId.ToString(),
                CityId = request.CityId,
                City = request.CityId.ToString(),
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }
    }
}
