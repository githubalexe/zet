﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Staff;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static StaffCreateRequest ToStaffCreateRequest(this StaffFormRequest request, string addressId)
        {
            return new StaffCreateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Picture = request.BinaryImage,
                AddressId = addressId,
                Active = true,
                Username = request.Username,
                Password = request.Password
            };
        }

        public static StaffUpdateRequest ToStaffUpdateRequest(this StaffFormRequest request, string addressId)
        {
            return new StaffUpdateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Picture = request.BinaryImage,
                AddressId = addressId,
                Active = request.Active,
                Username = request.Username,
                Password = request.Password
            };
        }

        public static StaffUpdateRequest ToStaffUpdateRequest(this StaffResponse staff, bool isActive)
        {
            return new StaffUpdateRequest
            {
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                Email = staff.Email,
                Picture = staff.Picture,
                AddressId = staff.AddressId,
                Active = isActive,
                Username = staff.Username,
                Password = staff.Password
            };
        }
    }
}
