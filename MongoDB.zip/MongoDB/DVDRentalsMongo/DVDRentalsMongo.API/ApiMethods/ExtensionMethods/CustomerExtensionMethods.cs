﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Customer;
using System;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerCreateRequest ToCustomerCreateRequest(this CustomerFormRequest request, string addressId)
        {
            return new CustomerCreateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                AddressId = addressId,
                Active = true,
                CreateDate = DateTime.Today
            };
        }

        public static CustomerUpdateRequest ToCustomerUpdateRequest(this CustomerFormRequest request, string addressId)
        {
            return new CustomerUpdateRequest
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Active = request.Active,
                AddressId = addressId
            };
        }

        public static CustomerUpdateRequest ToCustomerUpdateRequest(this CustomerResponse customer, bool isActive)
        {
            return new CustomerUpdateRequest
            {
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = isActive
            };
        }
    }
}
