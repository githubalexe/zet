﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class InventoryExtensionMethods
    {
        public static InventoryCreateRequest ToInventoryCreateRequest(this InventoryFormRequest requst)
        {
            return new InventoryCreateRequest()
            {
                FilmId = requst.FilmId
            };
        }
    }
}
