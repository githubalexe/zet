﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreUpdateRequest ToStoreUpdateRequest(this StoreFormRequest request, string addressId)
        {
            return new StoreUpdateRequest
            {
                ManagerStaffId = request.ManagerStaffId,
                AddressId = addressId
            };
        }
    }
}
