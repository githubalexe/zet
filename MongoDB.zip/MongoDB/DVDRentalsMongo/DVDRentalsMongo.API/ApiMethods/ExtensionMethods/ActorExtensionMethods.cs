﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static ActorCreateRequest ToActorCreateRequest(this ActorFormRequest request)
        {
            return new ActorCreateRequest()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
            };
        }

        public static ActorUpdateRequest ToActorUpdateRequest(this ActorFormRequest request)
        {
            return new ActorUpdateRequest()
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
            };
        }

        public static FilmActorCreateRequest ToFilmActorCreateRequest(this ActorFormRequest request, string filmId)
        {
            return new FilmActorCreateRequest()
            {
                FilmId = filmId,
                ActorId = request.ActorId
            };
        }
    }
}
