﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class AddressExtensionMethods
    {
        public static AddressCreateRequest ToAddressCreateRequest(this CustomerFormRequest request)
        {
            return new AddressCreateRequest
            {
                Address1 = request.Address,
                Address2 = request.Address2,
                District = request.Distrinct,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }

        public static AddressUpdateRequest ToAddressUpdateRequest(this CustomerFormRequest request)
        {
            return new AddressUpdateRequest
            {
                Address1 = request.Address,
                Address2 = request.Address2,
                District = request.Distrinct,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }

        //staff
        public static AddressCreateRequest ToAddressCreateRequest(this StaffFormRequest request)
        {
            return new AddressCreateRequest
            {
                Address1 = request.Address,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }

        public static AddressUpdateRequest ToAddressUpdateRequest(this StaffFormRequest request)
        {
            return new AddressUpdateRequest
            {
                Address1 = request.Address,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }
        //store
        public static AddressCreateRequest ToAddressCreateRequest(this StoreFormRequest request)
        {
            return new AddressCreateRequest
            {
                Address1 = request.Address,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }

        public static AddressUpdateRequest ToAddressUpdateRequest(this StoreFormRequest request)
        {
            return new AddressUpdateRequest
            {
                Address1 = request.Address,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }
    }
}
