﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.ApiMethods.ExtensionMethods
{
    public static class PaymentExtensionMethods
    {
        public static PaymentCreateRequest ToPaymentCreateRequest(this PaymentFormRequest request)
        {
            return new PaymentCreateRequest()
            {
                CustomerId = request.CustomerId,
                StaffId = request.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount ?? default(decimal),
                PaymentDate = request.PaymentDate
            };
        }

        public static PaymentFormRequest ToPaymentFormRequest(this RentalFormRequest request)
        {
            return new PaymentFormRequest()
            {
                CustomerId = request.CustomerId,
                StaffId = request.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount,
                PaymentDate = request.PaymentDate
            };
        }
    }
}
