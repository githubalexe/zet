﻿using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Response.SpecialFeatures;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class SpecialFeaturesApiMethods: ISpecialFeaturesApiMethods
    {
        private readonly HttpClient _client;

        public SpecialFeaturesApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<SpecialFeaturesResponseLite>> GetSpecialFeatures()
        {
            IEnumerable<SpecialFeaturesResponseLite> specialFeatures = new List<SpecialFeaturesResponseLite>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}specialFeatures", uri);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                specialFeatures = JsonConvert.DeserializeObject<List<SpecialFeaturesResponseLite>>(dataJson);
            }

            return specialFeatures;
        }
    }
}
