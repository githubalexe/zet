﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.API.Response.Rental;
using DVDRentalsMongo.API.Response.Staff;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class StaffApiMethods
    {
        public static async Task<StaffResponse> GetStaffAsync(string storeId, string staffId)
        {
            StaffResponse staff = new StaffResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
                }
            }

            return staff;
        }

        public static async Task<IEnumerable<StaffResponse>> GetStaffsAsync(string storeId)
        {
            IEnumerable<StaffResponse> staffs = new List<StaffResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/staffs", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staffs = JsonConvert.DeserializeObject<List<StaffResponse>>(dataJson);
                }
            }

            return staffs;
        }

        public static async Task<StaffResponse> CreateStaffAsync(StaffFormRequest request, string storeId)
        {
            AddressResponseLite address = await AddressApiMethods.CreateAddressAsync(request.ToAddressCreateRequest());
            StaffCreateRequest staffRequest = request.ToStaffCreateRequest(address.Id);

            StaffResponse staff = new StaffResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/staffs", uri, storeId);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, staffRequest);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
                }
            }

            return staff;
        }

        public static async Task<IEnumerable<RentalResponse>> GetStaffRentalsAsync(string id)
        {
            IEnumerable<RentalResponse> rentals = new List<RentalResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}staffs/{1}/rentals", uri, id);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    rentals = JsonConvert.DeserializeObject<List<RentalResponse>>(dataJson);
                }
            }

            return rentals;
        }

        public static async Task<StaffResponse> UpdateStaffAsync(StaffFormRequest request, string storeId, string staffId)
        {
            StaffResponse staff = await StaffApiMethods.GetStaffAsync(storeId, staffId);
            AddressResponseLite address = await AddressApiMethods.UpdateAddressAsync(request.ToAddressUpdateRequest(), staff.AddressId);

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request.ToStaffUpdateRequest(address.Id));

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
                }
            }

            return staff;
        }

        public static async Task<StaffResponse> UpdateStaffStatusAsync(bool isActive, string storeId, string staffId)
        {
            StaffResponse staff = await StaffApiMethods.GetStaffAsync(storeId, staffId);

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, staff.ToStaffUpdateRequest(isActive));

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
                }
            }

            return staff;
        }

        public static async Task DeleteStaffAsync(string storeId, string staffId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}
