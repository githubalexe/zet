﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.API.Response.Rental;
using DVDRentalsMongo.API.Response.Staff;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class StaffApiMethods: IStaffApiMethods
    {
        private readonly HttpClient _client;
        private readonly IAddressApiMethods _addressApiMethods;
        public StaffApiMethods(HttpClient client, IAddressApiMethods addressApiMethods)
        {
            _client = client;
            _addressApiMethods = addressApiMethods;
        }

        public async Task<StaffResponse> GetStaffAsync(string storeId, string staffId)
        {
            StaffResponse staff = new StaffResponse();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);
            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
            }

            return staff;
        }

        public async Task<IEnumerable<StaffResponse>> GetStaffsAsync(string storeId)
        {
            IEnumerable<StaffResponse> staffs = new List<StaffResponse>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/staffs", uri, storeId);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                staffs = JsonConvert.DeserializeObject<List<StaffResponse>>(dataJson);
            }

            return staffs;
        }

        public async Task<StaffResponse> CreateStaffAsync(StaffFormRequest request, string storeId)
        {
            AddressResponseLite address = await _addressApiMethods.CreateAddressAsync(request.ToAddressCreateRequest());
            StaffCreateRequest staffRequest = request.ToStaffCreateRequest(address.Id);

            StaffResponse staff = new StaffResponse();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/staffs", uri, storeId);

            HttpResponseMessage response = await _client.PostAsJsonAsync(url, staffRequest);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
            }

            return staff;
        }

        public async Task<IEnumerable<RentalResponse>> GetStaffRentalsAsync(string id)
        {
            IEnumerable<RentalResponse> rentals = new List<RentalResponse>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}staffs/{1}/rentals", uri, id);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                rentals = JsonConvert.DeserializeObject<List<RentalResponse>>(dataJson);
            }

            return rentals;
        }

        public async Task<StaffResponse> UpdateStaffAsync(StaffFormRequest request, string storeId, string staffId)
        {
            StaffResponse staff = await GetStaffAsync(storeId, staffId);
            AddressResponseLite address = await _addressApiMethods.UpdateAddressAsync(request.ToAddressUpdateRequest(), staff.AddressId);


            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

            HttpResponseMessage response = await _client.PutAsJsonAsync(url, request.ToStaffUpdateRequest(address.Id));

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
            }

            return staff;
        }

        public async Task<StaffResponse> UpdateStaffStatusAsync(bool isActive, string storeId, string staffId)
        {
            StaffResponse staff = await GetStaffAsync(storeId, staffId);

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

            HttpResponseMessage response = await _client.PutAsJsonAsync(url, staff.ToStaffUpdateRequest(isActive));

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                staff = JsonConvert.DeserializeObject<StaffResponse>(dataJson);
            }

            return staff;
        }

        public async Task DeleteStaffAsync(string storeId, string staffId)
        {

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/staffs/{2}", uri, storeId, staffId);

            HttpResponseMessage response = await _client.DeleteAsync(url);

        }
    }
}
