﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.API.Response.Store;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class StoreApiMethods
    {
        public static async Task<StoreResponse> GetStoreAsync(string id)
        {
            StoreResponse store = new StoreResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}", uri, id);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    store = JsonConvert.DeserializeObject<StoreResponse>(dataJson);
                }
            }

            return store;
        }

        public static async Task<StoreResponse> UpdateStoreAsync(StoreFormRequest request, string id)
        {
            StoreResponse store = await StoreApiMethods.GetStoreAsync(id);
            AddressResponseLite address = await AddressApiMethods.UpdateAddressAsync(request.ToAddressUpdateRequest(), store.AddressId);

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}", uri, id);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request.ToStoreUpdateRequest(address.Id));

                string dataJson = await response.Content.ReadAsStringAsync();
                store = JsonConvert.DeserializeObject<StoreResponse>(dataJson);
            }

            return store;
        }
    }
}
