﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.API.Response.Rental;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class CustomerApiMethods
    {
        public static async Task<CustomerResponse> GetCustomerAsync(string storeId, string customerId)
        {
            CustomerResponse customer = new CustomerResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
                }
            }

            return customer;
        }

        public static async Task<IEnumerable<CustomerResponse>> GetCustomersAsync(string storeId)
        {
            IEnumerable<CustomerResponse> customers = new List<CustomerResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/customers", uri, storeId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customers = JsonConvert.DeserializeObject<List<CustomerResponse>>(dataJson);
                }
            }

            return customers;
        }

        public static async Task<CustomerResponse> CreateCustomerAsync(CustomerFormRequest request, string storeId)
        {
            AddressResponseLite address = await AddressApiMethods.CreateAddressAsync(request.ToAddressCreateRequest());
            CustomerCreateRequest customerRequest = request.ToCustomerCreateRequest(address.Id);

            CustomerResponse customer = new CustomerResponse();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/customers", uri, storeId);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, customerRequest);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
                }
            }

            return customer;
        }

        public static async Task<IEnumerable<RentalResponse>> GetCustomerRentalsAsync(string id)
        {
            IEnumerable<RentalResponse> rentals = new List<RentalResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}customers/{1}/rentals", uri, id);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    rentals = JsonConvert.DeserializeObject<List<RentalResponse>>(dataJson);
                }
            }

            return rentals;
        }

        public static async Task<CustomerResponse> UpdateCustomerAsync(CustomerFormRequest request, string storeId, string customerId)
        {
            CustomerResponse customer = await CustomerApiMethods.GetCustomerAsync(storeId, customerId);
            AddressResponseLite address = await AddressApiMethods.UpdateAddressAsync(request.ToAddressUpdateRequest(), customer.AddressId);

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request.ToCustomerUpdateRequest(address.Id));


                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
                }
            }

            return customer;
        }

        public static async Task<CustomerResponse> UpdateCustomerStatus(bool isActive, string storeId, string customerId)
        {
            CustomerResponse customer = await CustomerApiMethods.GetCustomerAsync(storeId, customerId);

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, customer.ToCustomerUpdateRequest(isActive));

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
                }
            }

            return customer;
        }

        public static async Task DeleteCustomerAsync(string storeId, string customerId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }
    }
}
