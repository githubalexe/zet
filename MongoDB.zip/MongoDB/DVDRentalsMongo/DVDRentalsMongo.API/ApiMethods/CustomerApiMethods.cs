﻿using DVDRentalsMongo.API.ApiMethods.ExtensionMethods;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.API.Response.Rental;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class CustomerApiMethods: ICustomerApiMethods
    {
        public readonly HttpClient _client;
        public readonly IAddressApiMethods _addressApiMethods;

        public CustomerApiMethods(HttpClient client,IAddressApiMethods addressApiMethods)
        {
            _client = client;
            _addressApiMethods = addressApiMethods;
        }

        public async Task<CustomerResponse> GetCustomerAsync(string storeId, string customerId)
        {
            CustomerResponse customer = new CustomerResponse();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);
            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
            }


            return customer;
        }

        public async Task<IEnumerable<CustomerResponse>> GetCustomersAsync(string storeId)
        {
            IEnumerable<CustomerResponse> customers = new List<CustomerResponse>();


            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/customers", uri, storeId);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                customers = JsonConvert.DeserializeObject<List<CustomerResponse>>(dataJson);
            }


            return customers;
        }

        public async Task<CustomerResponse> CreateCustomerAsync(CustomerFormRequest request, string storeId)
        {
            AddressResponseLite address = await _addressApiMethods.CreateAddressAsync(request.ToAddressCreateRequest());
            CustomerCreateRequest customerRequest = request.ToCustomerCreateRequest(address.Id);

            CustomerResponse customer = new CustomerResponse();


            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/customers", uri, storeId);

            HttpResponseMessage response = await _client.PostAsJsonAsync(url, customerRequest);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
            }


            return customer;
        }

        public async Task<IEnumerable<RentalResponse>> GetCustomerRentalsAsync(string id)
        {
            IEnumerable<RentalResponse> rentals = new List<RentalResponse>();


            string uri = "https://localhost:44306/";
            string url = String.Format("{0}customers/{1}/rentals", uri, id);

            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                rentals = JsonConvert.DeserializeObject<List<RentalResponse>>(dataJson);
            }


            return rentals;
        }

        public async Task<CustomerResponse> UpdateCustomerAsync(CustomerFormRequest request, string storeId, string customerId)
        {
            CustomerResponse customer = await GetCustomerAsync(storeId, customerId);
            AddressResponseLite address = await _addressApiMethods.UpdateAddressAsync(request.ToAddressUpdateRequest(), customer.AddressId);


            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

            HttpResponseMessage response = await _client.PutAsJsonAsync(url, request.ToCustomerUpdateRequest(address.Id));


            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
            }

            return customer;
        }

        public async Task<CustomerResponse> UpdateCustomerStatus(bool isActive, string storeId, string customerId)
        {
            CustomerResponse customer = await GetCustomerAsync(storeId, customerId);

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

            HttpResponseMessage response = await _client.PutAsJsonAsync(url, customer.ToCustomerUpdateRequest(isActive));

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                customer = JsonConvert.DeserializeObject<CustomerResponse>(dataJson);
            }

            return customer;
        }

        public async Task DeleteCustomerAsync(string storeId, string customerId)
        {
            string uri = "https://localhost:44306/";
            string url = String.Format("{0}stores/{1}/customers/{2}", uri, storeId, customerId);

            HttpResponseMessage response = await _client.DeleteAsync(url);

        }
    }
}
