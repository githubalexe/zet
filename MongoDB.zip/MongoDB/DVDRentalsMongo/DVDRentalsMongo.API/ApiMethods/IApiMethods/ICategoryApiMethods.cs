﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.Category;
using DVDRentalsMongo.API.Response.City;
using DVDRentalsMongo.API.Response.Country;
using DVDRentalsMongo.API.Response.FilmCategory;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface ICategoryApiMethods
    {
        Task<IEnumerable<CategoryResponseLite>> GetCategoriesAsync();
        Task<FilmCategoryResponseLite> AddCategoryAsync(FilmCategoryCreateRequest request);
        Task DeleteCategoryAsync(string filmId, string categoryId);
    }
}
