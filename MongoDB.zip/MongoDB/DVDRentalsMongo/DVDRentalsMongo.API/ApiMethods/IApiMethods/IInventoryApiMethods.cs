﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Inventory;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IInventoryApiMethods
    {
        Task<InventoryResponse> GetInventoryAsync(string storeId, string inventoryId);
        Task<IEnumerable<InventoryResponse>> GetFilmInventoriesAsync(string storeId, string filmId);
        Task<IEnumerable<InventoryResponse>> GetInventoriesAsync(string storeId);
        Task<InventoryResponse> CreateInventoryAsync(InventoryFormRequest request, string storeId);
        Task DeleteInventoryAsync(string inventoryId);
    }
}
