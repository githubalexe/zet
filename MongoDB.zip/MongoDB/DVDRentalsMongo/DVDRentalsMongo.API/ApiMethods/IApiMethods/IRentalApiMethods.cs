﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Payment;
using DVDRentalsMongo.API.Response.Rental;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IRentalApiMethods
    {
        Task<RentalResponse> GetRentalAsync(string rentalId);
        Task<IEnumerable<RentalResponse>> GetRentalsAsync(string storeId);
        Task<IEnumerable<RentalResponseLite>> GetInventoryRentalsAsync(string inventoryId);
        Task<IEnumerable<PaymentResponseLite>> GetPaymentsAsync(string rentalId);
        Task<RentalResponse> CreateRentalAsync(RentalFormRequest request, string storeId);
        Task<RentalResponse> UpdateRentalAsync(RentalFormRequest request, string rentalId);
        Task DeleteRental(string rentalId);
    }
}
