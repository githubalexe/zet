﻿using DVDRentalsMongo.API.Response.City;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface ICityApiMethods
    {
        Task<IEnumerable<CityResponse>> GetCitiesByCountryAsync(string countryId);
    }
}
