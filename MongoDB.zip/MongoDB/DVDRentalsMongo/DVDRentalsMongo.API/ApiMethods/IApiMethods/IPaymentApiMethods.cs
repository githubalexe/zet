﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Payment;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IPaymentApiMethods
    {
        Task<PaymentResponseLite> AddPaymentAsync(PaymentFormRequest request);
        Task DeletePaymentAsync(string paymentId);
    }
}
