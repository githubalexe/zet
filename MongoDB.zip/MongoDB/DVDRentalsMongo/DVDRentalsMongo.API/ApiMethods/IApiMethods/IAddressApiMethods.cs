﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Address;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IAddressApiMethods
    {
        Task<AddressResponseLite> GetAddressAsync(int addressId);
        Task<AddressResponseLite> CreateAddressAsync(AddressCreateRequest request);
        Task<AddressResponseLite> UpdateAddressAsync(AddressUpdateRequest request, string addressId);
    }
}
