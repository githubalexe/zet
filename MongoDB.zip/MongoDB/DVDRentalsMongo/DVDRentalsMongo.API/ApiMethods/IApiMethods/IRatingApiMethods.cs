﻿using DVDRentalsMongo.API.Response.Rating;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IRatingApiMethods
    {
        Task<IEnumerable<RatingResponseLite>> GetRatings();
    }
}
