﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Actor;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IActorApiMethods
    {
        Task<ActorResponse> GetActorAsync(string actorId);
        Task<IEnumerable<ActorResponse>> GetActorsAsync();
        Task<IEnumerable<ActorResponse>> GetActorsAsync(string filmId);
        Task<ActorResponseLite> CreateActorAsync(ActorCreateRequest request);
        Task<ActorResponseLite> UpdateActorAsync(ActorFormRequest request, string actorId);
        Task DeleteActorAsync(string filmId, string actorId);
    }
}
