﻿using DVDRentalsMongo.API.Response.SpecialFeatures;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface ISpecialFeaturesApiMethods
    {
        Task<IEnumerable<SpecialFeaturesResponseLite>> GetSpecialFeatures();
    }
}
