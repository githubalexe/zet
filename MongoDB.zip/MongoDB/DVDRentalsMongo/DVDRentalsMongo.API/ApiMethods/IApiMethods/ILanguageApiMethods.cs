﻿using DVDRentalsMongo.API.Response.Language;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface ILanguageApiMethods
    {
        Task<IEnumerable<LanguageResponseLite>> GetLanguagesAsync();
    }
}
