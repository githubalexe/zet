﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.API.Response.Rental;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface ICustomerApiMethods
    {
        Task<CustomerResponse> GetCustomerAsync(string storeId, string customerId);
        Task<IEnumerable<CustomerResponse>> GetCustomersAsync(string storeId);
        Task<CustomerResponse> CreateCustomerAsync(CustomerFormRequest request, string storeId);
        Task<IEnumerable<RentalResponse>> GetCustomerRentalsAsync(string id);
        Task<CustomerResponse> UpdateCustomerAsync(CustomerFormRequest request, string storeId, string customerId);
        Task<CustomerResponse> UpdateCustomerStatus(bool isActive, string storeId, string customerId);
        Task DeleteCustomerAsync(string storeId, string customerId);
    }
}

