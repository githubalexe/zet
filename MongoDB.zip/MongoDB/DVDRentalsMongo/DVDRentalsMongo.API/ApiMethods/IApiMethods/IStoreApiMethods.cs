﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Store;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IStoreApiMethods
    {
        Task<StoreResponse> GetStoreAsync(string id);
        Task<StoreResponse> UpdateStoreAsync(StoreFormRequest request, string id);
    }
}
