﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Rental;
using DVDRentalsMongo.API.Response.Staff;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IStaffApiMethods
    {
        Task<StaffResponse> GetStaffAsync(string storeId, string staffId);
        Task<IEnumerable<StaffResponse>> GetStaffsAsync(string storeId);
        Task<StaffResponse> CreateStaffAsync(StaffFormRequest request, string storeId);
        Task<IEnumerable<RentalResponse>> GetStaffRentalsAsync(string id);
        Task<StaffResponse> UpdateStaffAsync(StaffFormRequest request, string storeId, string staffId);
        Task<StaffResponse> UpdateStaffStatusAsync(bool isActive, string storeId, string staffId);
        Task DeleteStaffAsync(string storeId, string staffId);
    }
}
