﻿using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.FilmActor;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface IFilmApiMethods
    {
        Task<FilmResponse> GetFilmAsync(string filmId);
        Task<IEnumerable<FilmResponse>> GetFilmsAsync();
        Task<IEnumerable<FilmResponse>> GetStoreFilmsAsync(string storeId);
        Task<FilmResponse> CreateFilmAsync(FilmFormRequest request);
        Task<FilmResponse> UpdateFilm(FilmFormRequest request, string filmId);
        Task DeleteFilmAsync(string filmId);
        Task<FilmActorResponseLite> AddActorAsync(ActorFormRequest request, string filmId);
    }
}
