﻿using DVDRentalsMongo.API.Response.City;
using DVDRentalsMongo.API.Response.Country;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods.IApiMethods
{
    public interface ICountryApiMethods
    {
        Task<IEnumerable<CountryResponseLite>> GetCountriesAsync();
        Task<CityResponseLite> GetCityAsync(string cityId);
    }
}
