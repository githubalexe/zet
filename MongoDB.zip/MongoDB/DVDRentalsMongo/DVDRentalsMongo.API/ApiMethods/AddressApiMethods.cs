﻿using DVDRentalsMongo.API.Response.Address;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class AddressApiMethods
    {
        public static async Task<AddressResponseLite> GetAddressAsync(int addressId)
        {
            AddressResponseLite address = new AddressResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}addresses/{1}", uri, addressId);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    address = JsonConvert.DeserializeObject<AddressResponseLite>(dataJson);
                }
            }

            return address;
        }

        public static async Task<AddressResponseLite> CreateAddressAsync(AddressCreateRequest request)
        {
            AddressResponseLite address = new AddressResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}addresses", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    address = JsonConvert.DeserializeObject<AddressResponseLite>(dataJson);

                }

            }

            return address;
        }

        public static async Task<AddressResponseLite> UpdateAddressAsync(AddressUpdateRequest request, string addressId)
        {
            AddressResponseLite address = new AddressResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}addresses/{1}", uri, addressId);

                HttpResponseMessage response = await client.PutAsJsonAsync(url, request);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    address = JsonConvert.DeserializeObject<AddressResponseLite>(dataJson);
                }

            }

            return address;
        }
    }
}
