﻿using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Response.City;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class CityApiMethods:ICityApiMethods
    {
        private readonly HttpClient _client;

        public CityApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<CityResponse>> GetCitiesByCountryAsync(string countryId)
        {
            IEnumerable<CityResponse> cities = new List<CityResponse>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}countries/{1}/cities", uri, countryId);

                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    cities = JsonConvert.DeserializeObject<List<CityResponse>>(dataJson);
                }
            }

            return cities;
        }
    }
}
