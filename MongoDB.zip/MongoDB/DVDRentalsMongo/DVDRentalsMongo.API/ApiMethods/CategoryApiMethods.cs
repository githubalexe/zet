﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.Category;
using DVDRentalsMongo.API.Response.FilmCategory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class CategoryApiMethods
    {
        public static async Task<IEnumerable<CategoryResponseLite>> GetCategoriesAsync()
        {
            IEnumerable<CategoryResponseLite> categories = new List<CategoryResponseLite>();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}categories", uri);
                HttpResponseMessage response = await client.GetAsync(url);

                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                else
                {
                    string dataJson = await response.Content.ReadAsStringAsync();
                    categories = JsonConvert.DeserializeObject<List<CategoryResponseLite>>(dataJson);
                }
            }

            return categories;
        }

        public static async Task<FilmCategoryResponseLite> AddCategoryAsync(FilmCategoryCreateRequest request)
        {
            FilmCategoryResponseLite filmCategory = new FilmCategoryResponseLite();

            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}filmscategories", uri);

                HttpResponseMessage response = await client.PostAsJsonAsync(url, request);

                string dataJson = await response.Content.ReadAsStringAsync();
                filmCategory = JsonConvert.DeserializeObject<FilmCategoryResponseLite>(dataJson);
            }

            return filmCategory;
        }

        public static async Task DeleteCategoryAsync(string filmId, string categoryId)
        {
            using (HttpClient client = new HttpClient())
            {
                string uri = "https://localhost:44306/";
                string url = String.Format("{0}films/{1}/categories/{2}", uri, filmId, categoryId);

                HttpResponseMessage response = await client.DeleteAsync(url);
            }
        }

    }
}
