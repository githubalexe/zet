﻿using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.Category;
using DVDRentalsMongo.API.Response.FilmCategory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace DVDRentalsMongo.API.ApiMethods
{
    public class CategoryApiMethods:ICategoryApiMethods
    {
        private readonly HttpClient _client;
        public CategoryApiMethods(HttpClient client)
        {
            _client = client;
        }

        public async Task<IEnumerable<CategoryResponseLite>> GetCategoriesAsync()
        {
            IEnumerable<CategoryResponseLite> categories = new List<CategoryResponseLite>();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}categories", uri);
            HttpResponseMessage response = await _client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }
            else
            {
                string dataJson = await response.Content.ReadAsStringAsync();
                categories = JsonConvert.DeserializeObject<List<CategoryResponseLite>>(dataJson);
            }


            return categories;
        }

        public async Task<FilmCategoryResponseLite> AddCategoryAsync(FilmCategoryCreateRequest request)
        {
            FilmCategoryResponseLite filmCategory = new FilmCategoryResponseLite();

            string uri = "https://localhost:44306/";
            string url = String.Format("{0}filmscategories", uri);

            HttpResponseMessage response = await _client.PostAsJsonAsync(url, request);

            string dataJson = await response.Content.ReadAsStringAsync();
            filmCategory = JsonConvert.DeserializeObject<FilmCategoryResponseLite>(dataJson);

            return filmCategory;
        }

        public async Task DeleteCategoryAsync(string filmId, string categoryId)
        {
            string uri = "https://localhost:44306/";
            string url = String.Format("{0}films/{1}/categories/{2}", uri, filmId, categoryId);

            HttpResponseMessage response = await _client.DeleteAsync(url);

        }

    }
}
