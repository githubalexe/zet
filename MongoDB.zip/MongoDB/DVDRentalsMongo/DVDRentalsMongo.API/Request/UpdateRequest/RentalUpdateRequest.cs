﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.UpdateRequest
{
    public class RentalUpdateRequest
    {
        public DateTime RentalDate { get; set; }
        public string InventoryId { get; set; }
        public string CustomerId { get; set; }
        public DateTime? ReturnDate { get; set; }
        public string StaffId { get; set; }
    }
}
