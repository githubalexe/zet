﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.UpdateRequest
{
    public class CustomerUpdateRequest
    {
        public string StoreId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string AddressId { get; set; }
        public bool Active { get; set; }
    }
}
