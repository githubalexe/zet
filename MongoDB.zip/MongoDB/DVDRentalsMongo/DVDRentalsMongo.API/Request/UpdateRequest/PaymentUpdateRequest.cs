﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.UpdateRequest
{
    public class PaymentUpdateRequest
    {
        public string CustomerId { get; set; }
        public string StaffId { get; set; }
        public string RentalId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
    }
}
