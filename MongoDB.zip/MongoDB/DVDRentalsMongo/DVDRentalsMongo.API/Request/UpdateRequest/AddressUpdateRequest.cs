﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentalsMongo.API.Request.UpdateRequest
{
    public class AddressUpdateRequest
    {
        [Required]
        public string Address1 { get; set; }

        [Required]
        public string Address2 { get; set; }

        [Required]
        public string District { get; set; }

        [Required]
        public string CityId { get; set; }

        [Required]
        public string PostalCode { get; set; }

        [Required]
        public string Phone { get; set; }
    }
}
