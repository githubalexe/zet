﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentalsMongo.API.Request.UpdateRequest
{
    public class FilmUpdateRequest
    {
        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public int ReleaseYear { get; set; }

        [Required]
        public string LanguageId { get; set; }

        [Required]
        public string OriginalLanguageId { get; set; }

        [Required]
        public int RentalDuration { get; set; }

        [Required]
        public decimal RentalRate { get; set; }

        [Required]
        public int? Length { get; set; }

        [Required]
        public decimal ReplacementCost { get; set; }

        [Required]
        public string Rating { get; set; }

        [Required]
        public string SpecialFeatures { get; set; }
    }
}
