﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentalsMongo.API.Request.UpdateRequest
{
    public class LanguageUpdateRequest
    {
        [Required]
        public string Name { get; set; }
    }
}
