﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.UpdateRequest
{
    public class ActorUpdateRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
