﻿namespace DVDRentalsMongo.API.Request.FormRequest
{
    public class InventoryFormRequest
    {
        public string InventoryId { get; set; }
        public string FilmTitle { get; set; }
        public int ReleaseYear { get; set; }
        public string Rating { get; set; }
        public string FilmId { get; set; }

    }
}
