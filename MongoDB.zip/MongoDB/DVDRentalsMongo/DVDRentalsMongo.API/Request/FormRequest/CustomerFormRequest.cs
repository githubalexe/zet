﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.FormRequest
{
    public class CustomerFormRequest
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string AddressId { get; set; }

        public string Address { get; set; }

        public string Address2 { get; set; }

        public string Distrinct { get; set; }

        public string CountryId { get; set; }

        public string Country { get; set; }

        public string CityId { get; set; }

        public string City { get; set; }

        public string PostalCode { get; set; }

        public bool Active { get; set; }

        public string Phone { get; set; }

        public DateTime CreateDate { get; set; }
    }
}
