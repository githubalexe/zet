﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentalsMongo.API.Request.FormRequest
{
    public class PaymentFormRequest
    {
        public string RentalId { get; set; }
        public string FilmId { get; set; }
        public string StaffId { get; set; }
        public string CustomerId { get; set; }
        public decimal? Amount { get; set; }

        [Display(Name = "Payment Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public DateTime PaymentDate { get; set; }
    }
}
