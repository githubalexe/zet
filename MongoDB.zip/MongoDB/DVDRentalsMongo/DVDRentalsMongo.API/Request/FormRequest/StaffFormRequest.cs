﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.FormRequest
{
    public class StaffFormRequest
    {
        public string StaffId { get; set; }
        public string StoreId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Picture { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string AddressId { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string District { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public bool Active { get; set; }
        public string PostalCode { get; set; }
        public string Phone { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public byte[] BinaryImage { get; set; }
        public string CityId { get; set; }
        public string CountryId { get; set; }
    }
}
