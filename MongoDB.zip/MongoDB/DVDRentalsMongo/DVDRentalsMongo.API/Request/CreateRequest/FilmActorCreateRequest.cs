﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.CreateRequest
{
    public class FilmActorCreateRequest
    {
        public string FilmId { get; set; }
        public string ActorId { get; set; }
    }
}
