﻿using System.ComponentModel.DataAnnotations;

namespace DVDRentalsMongo.API.Request.CreateRequest
{
    public class RatingCreateRequest
    {
        [Required]
        public string Name { get; set; }
    }
}
