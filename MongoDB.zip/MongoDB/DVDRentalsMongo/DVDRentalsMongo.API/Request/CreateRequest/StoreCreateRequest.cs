﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.CreateRequest
{
    public class StoreCreateRequest
    {
        public string ManagerStaffId { get; set; }
        public string AddressId { get; set; }
    }
}
