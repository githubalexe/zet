﻿using System.ComponentModel.DataAnnotations;

namespace DVDRentalsMongo.API.Request.CreateRequest
{
    public class SpecialFeaturesCreateRequest
    {
        [Required]
        public string Name { get; set; }
    }
}
