﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.CreateRequest
{
    public class StaffCreateRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AddressId { get; set; }
        public byte[] Picture { get; set; }
        public string Email { get; set; }
        public string StoreId { get; set; }
        public bool Active { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
