﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentalsMongo.API.Request.CreateRequest
{
    public class FilmCreateRequest
    {
        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public int ReleaseYear { get; set; }

        [Required]
        public string LanguageId { get; set; }

        [Required]
        public int RentalDuration { get; set; }

        [Required]
        public decimal RentalRate { get; set; }

        [Required]
        public int? Length { get; set; }

        [Required]
        public decimal ReplacementCost { get; set; }

        [Required]
        public string RatingId { get; set; }

        [Required]
        public string SpecialFeaturesId { get; set; }
    }
}
