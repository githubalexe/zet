﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Request.CreateRequest
{
    public class RentalCreateRequest
    {
        public DateTime RentalDate { get; set; }
        public string InventoryId { get; set; }
        public string CustomerId { get; set; }
        public DateTime? ReturnDate { get; set; }
        public string StaffId { get; set; }
    }
}
