﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Data
{
    public class FilmSpecialFeatures
    {
        public IDictionary<int, string> SpecialFeaturesList { get; private set; }

        public FilmSpecialFeatures()
        {
            SpecialFeaturesList = GetRating();
        }

        private IDictionary<int, string> GetRating()
        {
            IDictionary<int, string> ratingList = new Dictionary<int, string>();
            ratingList.Add(1, "Trailers");
            ratingList.Add(2, "Commentaries");
            ratingList.Add(3, "Trailers,Commentaries");
            ratingList.Add(4, "Deleted Scenes");
            ratingList.Add(5, "Trailers,Deleted Scenes");
            ratingList.Add(6, "Commentaries,Deleted Scenes");
            ratingList.Add(7, "Trailers,Commentaries,Deleted Scenes");
            ratingList.Add(8, "Behind the Scenes");
            ratingList.Add(9, "Trailers,Behind the Scenes");
            ratingList.Add(10, "Commentaries,Behind the Scenes");
            ratingList.Add(11, "Trailers,Commentaries,Behind the Scenes");
            ratingList.Add(12, "Deleted Scenes,Behind the Scenes");
            ratingList.Add(13, "Trailers,Deleted Scenes,Behind the Scenes");
            ratingList.Add(14, "Commentaries,Deleted Scenes,Behind the Scenes");
            ratingList.Add(15, "Trailers,Commentaries,Deleted Scenes,Behind the Scenes");

            return ratingList;
        }
    }
}
