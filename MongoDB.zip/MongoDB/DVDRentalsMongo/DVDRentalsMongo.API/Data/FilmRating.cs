﻿using System.Collections.Generic;

namespace DVDRentalsMongo.API.Data
{
    public class FilmRating
    {
        public IDictionary<int, string> RatingList { get; private set; }

        public FilmRating()
        {
            RatingList = GetRating();
        }

        private IDictionary<int, string> GetRating()
        {
            IDictionary<int, string> ratingList = new Dictionary<int, string>();
            ratingList.Add(1, "G");
            ratingList.Add(2, "PG");
            ratingList.Add(3, "PG-13");
            ratingList.Add(4, "R");
            ratingList.Add(5, "NC-17");

            return ratingList;
        }
    }
}
