﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Data
{
    public static class DVDRentalsStore
    {
        public static string GetStoreId()
        {
            string storeId = "af9bcd64-f0ad-4cf6-9081-6eaa225c2a0a";

            return storeId;
        }
    }
}
