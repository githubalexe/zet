﻿namespace DVDRentalsMongo.API.Response.Inventory
{
    public class InventoryResponseLite
    {
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string StoreId { get; set; }
    }
}
