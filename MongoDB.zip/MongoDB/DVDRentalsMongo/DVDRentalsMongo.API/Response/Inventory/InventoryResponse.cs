﻿using DVDRentalsMongo.API.Response.Film;

namespace DVDRentalsMongo.API.Response.Inventory
{
    public class InventoryResponse
    {
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string StoreId { get; set; }
        public virtual FilmResponseLite Film { get; set; }
    }
}

