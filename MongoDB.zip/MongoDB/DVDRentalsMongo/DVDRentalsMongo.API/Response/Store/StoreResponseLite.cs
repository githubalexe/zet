﻿namespace DVDRentalsMongo.API.Response.Store
{
    public class StoreResponseLite
    {
        public string Id { get; set; }
        public string ManagerStaffId { get; set; }
        public string AddressId { get; set; }
    }
}
