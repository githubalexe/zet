﻿using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.API.Response.Staff;

namespace DVDRentalsMongo.API.Response.Store
{
    public class StoreResponse
    {

        public string Id { get; set; }
        public string ManagerStaffId { get; set; }
        public string AddressId { get; set; }
        public virtual AddressResponse Address { get; set; }
        public virtual StaffNameResponse ManagerName { get; set; }
    }
}
