﻿namespace DVDRentalsMongo.API.Response.Category
{
    public class CategoryResponseLite
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
