﻿namespace DVDRentalsMongo.API.Response.Country
{
    public class CountryResponseLite
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
