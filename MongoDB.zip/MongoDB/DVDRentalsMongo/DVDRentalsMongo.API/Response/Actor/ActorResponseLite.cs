﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DVDRentalsMongo.API.Response.Actor
{
    public class ActorResponseLite
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
