﻿using System;

namespace DVDRentalsMongo.API.Response.Actor
{
    public class ActorResponse
    {

        public string Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Name { get; set; }
    }
}
