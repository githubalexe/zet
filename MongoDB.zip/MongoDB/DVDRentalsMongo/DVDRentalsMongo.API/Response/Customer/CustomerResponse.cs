﻿using DVDRentalsMongo.API.Response.Address;
using System;

namespace DVDRentalsMongo.API.Response.Customer
{
    public class CustomerResponse
    {
        public string Id { get; set; }
        public string StoreId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string AddressId { get; set; }
        public bool Active { get; set; }
        public DateTime CreateDate { get; set; }
        public virtual AddressResponse Address { get; set; }
    }
}
