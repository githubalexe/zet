﻿namespace DVDRentalsMongo.API.Response.Customer
{
    public class CustomerNameResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
