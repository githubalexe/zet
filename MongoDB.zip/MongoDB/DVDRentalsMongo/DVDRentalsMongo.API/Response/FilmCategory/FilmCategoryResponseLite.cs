﻿namespace DVDRentalsMongo.API.Response.FilmCategory
{
    public class FilmCategoryResponseLite
    {
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string CategoryId { get; set; }
    }
}
