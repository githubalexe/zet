﻿namespace DVDRentalsMongo.API.Response.Film
{
    public class FilmTitleResponse
    {
        public string Id { get; set; }
        public string Title { get; set; }
    }
}
