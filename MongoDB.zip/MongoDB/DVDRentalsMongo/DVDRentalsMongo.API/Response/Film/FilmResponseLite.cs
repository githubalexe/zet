﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DVDRentalsMongo.API.Response.Film
{
    public class FilmResponseLite
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int ReleaseYear { get; set; }
        public string LanguageId { get; set; }
        public string OriginalLanguageId { get; set; }
        public int RentalDuration { get; set; }
        public decimal RentalRate { get; set; }
        public int? Length { get; set; }
        public decimal ReplacementCost { get; set; }
        public string RatingId { get; set; }
        public string SpecialFeaturesId { get; set; }
    }
}
