﻿using DVDRentalsMongo.API.Response.Category;
using DVDRentalsMongo.API.Response.Language;

namespace DVDRentalsMongo.API.Response.Film
{
    public class FilmResponse
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int ReleaseYear { get; set; }
        public string LanguageId { get; set; }
        public string OriginalLanguageId { get; set; }
        public int RentalDuration { get; set; }
        public decimal RentalRate { get; set; }
        public int? Length { get; set; }
        public decimal ReplacementCost { get; set; }
        public string Rating { get; set; }
        public string SpecialFeatures { get; set; }
        public virtual LanguageResponseLite Language { get; set; }
        public virtual CategoryResponseLite Category { get; set; }
    }
}
