﻿namespace DVDRentalsMongo.API.Response.FilmActor
{
    public class FilmActorResponseLite
    {
        public string Id { get; set; }
        public string FilmId { get; set; }
        public string ActorId { get; set; }
    }
}
