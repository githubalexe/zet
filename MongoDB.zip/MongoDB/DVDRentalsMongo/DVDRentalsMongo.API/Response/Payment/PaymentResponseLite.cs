﻿using System;


namespace DVDRentalsMongo.API.Response.Payment
{
    public class PaymentResponseLite
    {
        public string Id { get; set; }
        public string CustomerId { get; set; }
        public string StaffId { get; set; }
        public string RentalId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
    }
}
