﻿using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.Staff;
using System;

namespace DVDRentalsMongo.API.Response.Rental
{
    public class RentalResponse
    {
        public string Id { get; set; }
        public DateTime RentalDate { get; set; }
        public string InventoryId { get; set; }
        public string CustomerId { get; set; }
        public DateTime? ReturnDate { get; set; }
        public string StaffId { get; set; }
        public virtual CustomerNameResponse Customer { get; set; }
        public virtual StaffNameResponse Staff { get; set; }
        public virtual FilmTitleResponse Film { get; set; }
    }
}
