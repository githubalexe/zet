﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace DVDRentalsMongo.API.Response.City
{
    public class CityResponseLite
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string CountryId { get; set; }
    }
}
