﻿using DVDRentalsMongo.API.Response.Country;

namespace DVDRentalsMongo.API.Response.City
{
    public class CityResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string CountryId { get; set; }
        public virtual CountryResponseLite Country { get; set; }
    }
}
