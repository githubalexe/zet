﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentalsMongo.API.Response.SpecialFeatures
{
    public class SpecialFeaturesResponseLite
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
