﻿namespace DVDRentalsMongo.API.Response.Staff
{
    public class StaffNameResponse
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
