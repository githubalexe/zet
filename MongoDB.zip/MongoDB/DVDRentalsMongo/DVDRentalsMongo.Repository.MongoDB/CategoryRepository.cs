﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class CategoryRepository : ICategoryRepository
    {
        private UnitOfWork _unitOfWork;

        public CategoryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Category category)
        {
            await _unitOfWork.Category.InsertOneAsync(category);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Category.DeleteOneAsync(c => c.Id == id);
        }

        public async Task<Category> GetAsync(string id)
        {
            return await _unitOfWork.Category.Find(c => c.Id == id)
                                             .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Category>> GetListAsync()
        {
            return await _unitOfWork.Category.Find(category => true)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, Category category)
        {
            await _unitOfWork.Category.ReplaceOneAsync(a => a.Id == id, category);
        }
    }
}
