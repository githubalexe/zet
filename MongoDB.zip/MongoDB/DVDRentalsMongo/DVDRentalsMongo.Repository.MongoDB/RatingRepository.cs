﻿using DVDRentalsMongo.Domain;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class RatingRepository : IRatingRepository
    {
        private UnitOfWork _unitOfWork;
        public RatingRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Rating rating)
        {
            await _unitOfWork.Rating.InsertOneAsync(rating);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Rating.DeleteOneAsync(r => r.Id == id);
        }

        public async Task<Rating> GetAsync(string id)
        {
            return await _unitOfWork.Rating.Find(r => r.Id == id)
                                           .FirstOrDefaultAsync();
        }

        public IEnumerable<Rating> GetByQuery(IQueryable<Rating> query)
        {
            return query.ToList();
        }

        public IQueryable<Rating> GetQuery()
        {
            IQueryable<Rating> query = _unitOfWork.Rating.AsQueryable();

            return query;
        }
    }
}
