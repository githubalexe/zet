﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class FilmRepository:IFilmRepository
    {
        private UnitOfWork _unitOfWork;

        public FilmRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Film film)
        {
            await _unitOfWork.Film.InsertOneAsync(film);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Film.DeleteOneAsync(f => f.Id == id);
        }

        public async Task<Film> GetAsync(string id)
        {
            return await _unitOfWork.Film.Find(c => c.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Film>> GetListAsync()
        {
            return await _unitOfWork.Film.Find(country => true)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, Film film)
        {
            await _unitOfWork.Film.ReplaceOneAsync(c => c.Id == id, film);
        }
    }
}
