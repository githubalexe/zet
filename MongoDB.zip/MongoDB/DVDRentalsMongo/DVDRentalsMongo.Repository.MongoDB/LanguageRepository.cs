﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class LanguageRepository : ILanguageRepository
    {
        private UnitOfWork _unitOfWork;

        public LanguageRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Language language)
        {
            await _unitOfWork.Language.InsertOneAsync(language);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Language.DeleteOneAsync(a => a.Id == id);
        }

        public async Task<Language> GetAsync(string id)
        {
            return await _unitOfWork.Language.Find(a => a.Id == id)
                                              .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Language>> GetListAsync()
        {
            return await _unitOfWork.Language.Find(language => true)
                                   .ToListAsync();
        }

        public async Task UpdateAsync(string id, Language language)
        {
            await _unitOfWork.Language.ReplaceOneAsync(a => a.Id == id, language);
        }
    }
}
