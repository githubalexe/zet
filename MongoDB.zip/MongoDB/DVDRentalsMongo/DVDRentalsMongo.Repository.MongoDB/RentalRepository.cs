﻿using DVDRentalsMongo.Domain;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class RentalRepository : IRentalRepository
    {
        private UnitOfWork _unitOfWork;
        public RentalRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Rental rental)
        {
            await _unitOfWork.Rental.InsertOneAsync(rental);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Rental.DeleteOneAsync(r => r.Id == id);
        }

        public async Task<Rental> GetAsync(string id)
        {
            return await _unitOfWork.Rental.Find(r => r.Id == id)
                                          .FirstOrDefaultAsync();
        }

        public IEnumerable<Rental> GetByQuery(IQueryable<Rental> query)
        {
            return query.ToList();
        }

        public async Task<IEnumerable<Rental>> GetListAsync()
        {
            return await _unitOfWork.Rental.Find(rental => true)
                                          .ToListAsync();
        }

        public IQueryable<Rental> GetQuery()
        {
            IQueryable<Rental> query = _unitOfWork.Rental.AsQueryable();

            return query;
        }

        public async Task UpdateAsync(string id, Rental rental)
        {
            await _unitOfWork.Rental.ReplaceOneAsync(r => r.Id == id, rental);
        }
    }
}
