﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class FilmActorRepository : IFilmActorRepository
    {
        private UnitOfWork _unitOfWork;

        public FilmActorRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(FilmActor filmActor)
        {
            await _unitOfWork.FilmActor.InsertOneAsync(filmActor);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.FilmActor.DeleteOneAsync(f => f.Id == id);
        }

        public async Task<FilmActor> GetAsync(string id)
        {
            return await _unitOfWork.FilmActor.Find(f => f.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<FilmActor> GetAsync(string filmId, string actorId)
        {
            return await _unitOfWork.FilmActor.Find(f => f.FilmId == filmId && f.ActorId == actorId)
                                              .FirstOrDefaultAsync();
        }

        public IEnumerable<FilmActor> GetByQuery(IQueryable<FilmActor> query)
        {
            return query.ToList();
        }

        public IQueryable<FilmActor> GetQuery()
        {
            IQueryable<FilmActor> query = _unitOfWork.FilmActor.AsQueryable();

            return query;
        }

        public async Task UpdateAsync(string id, FilmActor filmActor)
        {
            await _unitOfWork.FilmActor.ReplaceOneAsync(f => f.Id == id, filmActor);
        }
    }
}
