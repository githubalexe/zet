﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class FilmActorRepository : IFilmActorRepository
    {
        private UnitOfWork _unitOfWork;

        public FilmActorRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(FilmActor filmActor)
        {
            await _unitOfWork.FilmActor.InsertOneAsync(filmActor);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.FilmActor.DeleteOneAsync(f => f.Id == id);
        }

        public async Task<FilmActor> GetAsync(string id)
        {
            return await _unitOfWork.FilmActor.Find(f => f.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<FilmActor> GetAsync(string filmId, string actorId)
        {
            return await _unitOfWork.FilmActor.Find(f => f.FilmId == filmId && f.ActorId == actorId)
                                              .FirstOrDefaultAsync();
        }

        public async Task<FilmActor> GetFilmAsync(string id)
        {
            return await _unitOfWork.FilmActor.Find(f => f.FilmId == id)
                        .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<FilmActor>> GetListAsync()
        {
            return await _unitOfWork.FilmActor.Find(filmActor => true)
                                              .ToListAsync();
        }

        public async Task<IEnumerable<FilmActor>> GetListAsync(string id)
        {
            return await _unitOfWork.FilmActor.Find(f => f.FilmId == id)
                                              .ToListAsync();
        }

        public async Task UpdateAsync(string id, FilmActor filmActor)
        {
            await _unitOfWork.FilmActor.ReplaceOneAsync(f => f.Id == id, filmActor);
        }
    }
}
