﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class CityRepository : ICityRepository
    {
        private UnitOfWork _unitOfWork;

        public CityRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task CreateAsync(City city)
        {
            await _unitOfWork.City.InsertOneAsync(city);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.City.DeleteOneAsync(c => c.Id == id);
        }

        public async Task<City> GetAsync(string id)
        {
            return await _unitOfWork.City.Find(c => c.Id == id)
                                .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<City>> GetListAsync()
        {
            return await _unitOfWork.City.Find(city => true)
                                .ToListAsync();
        }

        public async Task<IEnumerable<City>> GetListAsync(string id)
        {
            return await _unitOfWork.City.Find(c => c.CountryId == id)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, City city)
        {
            await _unitOfWork.City.ReplaceOneAsync(c => c.Id == id, city);
        }
    }
}
