﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class CustomerRepository : ICustomerRepository
    {
        private UnitOfWork _unitOfWork;

        public CustomerRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Customer customer)
        {
            await _unitOfWork.Customer.InsertOneAsync(customer);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Customer.DeleteOneAsync(c => c.Id == id);
        }

        public async Task<Customer> GetAsync(string storeId, string customerId)
        {
            return await _unitOfWork.Customer.Find(c => c.Id == customerId && c.StoreId == storeId)
                                    .FirstOrDefaultAsync();
        }

        public async Task<Customer> GetAsync(string id)
        {
            return await _unitOfWork.Customer.Find(c => c.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Customer>> GetListAsync(string id)
        {
            return await _unitOfWork.Customer.Find(c => c.StoreId == id)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, Customer customer)
        {
            await _unitOfWork.Customer.ReplaceOneAsync(c => c.Id == id, customer);
        }
    }
}
