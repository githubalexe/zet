﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class SpecialFeaturesRepository : ISpecialFeaturesRepository
    {
        private readonly UnitOfWork _unitOfWork;

        public SpecialFeaturesRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(SpecialFeatures SpecialFeatures)
        {
            await _unitOfWork.SpecialFeatures.InsertOneAsync(SpecialFeatures);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Rating.DeleteOneAsync(a => a.Id == id);
        }

        public async Task<SpecialFeatures> GetAsync(string id)
        {
            return await _unitOfWork.SpecialFeatures.Find(s => s.Id == id)
                                   .FirstOrDefaultAsync();
        }

        public IEnumerable<SpecialFeatures> GetByQuery(IQueryable<SpecialFeatures> query)
        {
            return query.ToList();
        }

        public IQueryable<SpecialFeatures> GetQuery()
        {
            IQueryable<SpecialFeatures> query = _unitOfWork.SpecialFeatures.AsQueryable();

            return query;
        }
    }
}
