﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class FilmCategoryRepository : IFilmCategoryRepository
    {
        private UnitOfWork _unitOfWork;

        public FilmCategoryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(FilmCategory filmCategory)
        {
            await _unitOfWork.FilmCategory.InsertOneAsync(filmCategory);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.FilmCategory.DeleteOneAsync(f => f.Id == id);
        }

        public async Task<FilmCategory> GetAsync(string id)
        {
            return await _unitOfWork.FilmCategory.Find(f => f.FilmId == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<FilmCategory> GetAsync(string filmId, string categoryId)
        {
            return await _unitOfWork.FilmCategory.Find(f => f.FilmId == filmId && f.CategoryId == categoryId)
                                    .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<FilmCategory>> GetListAsync()
        {
            return await _unitOfWork.FilmCategory.Find(filmCategory => true)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, FilmCategory filmCategory)
        {
            await _unitOfWork.FilmCategory.ReplaceOneAsync(f => f.Id == id, filmCategory);
        }
    }
}
