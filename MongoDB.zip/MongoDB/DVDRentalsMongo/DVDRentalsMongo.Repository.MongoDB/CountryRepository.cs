﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class CountryRepository : ICountryRepository
    {
        private UnitOfWork _unitOfWork;

        public CountryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Country country)
        {
            await _unitOfWork.Country.InsertOneAsync(country);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Country.DeleteOneAsync(c => c.Id == id);
        }

        public async Task<Country> GetAsync(string id)
        {
            return await _unitOfWork.Country.Find(c => c.Id == id)
                        .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Country>> GetListAsync()
        {
            return await _unitOfWork.Country.Find(country => true)
                              .ToListAsync();
        }

        public async Task UpdateAsync(string id, Country country)
        {
            await _unitOfWork.Country.ReplaceOneAsync(c => c.Id == id, country);
        }
    }
}
