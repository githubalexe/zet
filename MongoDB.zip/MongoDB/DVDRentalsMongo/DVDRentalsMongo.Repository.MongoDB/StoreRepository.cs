﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class StoreRepository:IStoreRepository
    {
        private UnitOfWork _unitOfWork;

        public StoreRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Store store)
        {
            await _unitOfWork.Store.InsertOneAsync(store);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Store.DeleteOneAsync(a => a.Id == id);
        }

        public async Task<Store> GetAsync(string id)
        {
            return await _unitOfWork.Store.Find(a => a.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Store>> GetListAsync()
        {
            return await _unitOfWork.Store.Find(store => true)
                                  .ToListAsync();
        }

        public async Task UpdateAsync(string id, Store store)
        {
            await _unitOfWork.Store.ReplaceOneAsync(a => a.Id == id, store);
        }
    }
}
