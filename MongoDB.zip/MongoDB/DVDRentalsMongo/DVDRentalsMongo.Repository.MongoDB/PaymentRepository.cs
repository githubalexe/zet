﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class PaymentRepository : IPaymentRepository
    {
        private UnitOfWork _unitOfWork;
        public PaymentRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Payment payment)
        {
            await _unitOfWork.Payment.InsertOneAsync(payment);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Payment.DeleteOneAsync(p => p.Id == id);
        }

        public async Task<Payment> GetAsync(string id)
        {
            return await _unitOfWork.Payment.Find(p => p.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Payment>> GetListAsync(string id)
        {
            return await _unitOfWork.Payment.Find(p => p.RentalId == id)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, Payment payment)
        {
            await _unitOfWork.Payment.ReplaceOneAsync(i => i.Id == id, payment);
        }
    }
}
