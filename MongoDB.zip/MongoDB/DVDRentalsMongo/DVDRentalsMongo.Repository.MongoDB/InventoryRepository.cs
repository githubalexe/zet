﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class InventoryRepository : IInventoryRepository
    {
        private UnitOfWork _unitOfWork;
        public InventoryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task CreateAsync(Inventory inventory)
        {
            await _unitOfWork.Inventory.InsertOneAsync(inventory);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Inventory.DeleteOneAsync(i => i.Id == id);
        }

        public async Task<Inventory> GetAsync(string id)
        {
            return await _unitOfWork.Inventory.Find(i => i.Id == id)
                                              .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Inventory>> GetFilmInventoriesListAsync(string storeId, string filmId)
        {
            return await _unitOfWork.Inventory.Find(i => i.StoreId == storeId && i.FilmId == filmId)
                                               .ToListAsync();
        }

        public async Task<IEnumerable<Inventory>> GetListAsync(string id)
        {
            return await _unitOfWork.Inventory.Find(i => i.StoreId == id)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, Inventory inventory)
        {
            await _unitOfWork.Inventory.ReplaceOneAsync(a => a.Id == id, inventory);
        }
    }
}
