﻿using DVDRentalsMongo.Domain;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class UnitOfWork
    {
        public readonly IMongoCollection<Actor> Actor;
        public readonly IMongoCollection<Address> Address;
        public readonly IMongoCollection<City> City;
        public readonly IMongoCollection<Country> Country;
        public readonly IMongoCollection<Language> Language;
        public readonly IMongoCollection<Category> Category;
        public readonly IMongoCollection<Film> Film;
        public readonly IMongoCollection<FilmCategory> FilmCategory;
        public readonly IMongoCollection<FilmActor> FilmActor;
        public readonly IMongoCollection<Store> Store;
        public readonly IMongoCollection<Customer> Customer;
        public readonly IMongoCollection<Staff> Staff;
        public readonly IMongoCollection<Inventory> Inventory;
        public readonly IMongoCollection<Rental> Rental;
        public readonly IMongoCollection<Payment> Payment;

        public UnitOfWork(IConfiguration config)
        {
            var client = new MongoClient(config.GetConnectionString("SakilaMongoDB"));
            var database = client.GetDatabase("SakilaMongoDB");

            Actor = database.GetCollection<Actor>("Actor");
            Address = database.GetCollection<Address>("Address");
            City = database.GetCollection<City>("City");
            Country = database.GetCollection<Country>("Country");
            Language = database.GetCollection<Language>("Language");
            Film = database.GetCollection<Film>("Film");
            Category = database.GetCollection<Category>("Category");
            FilmCategory = database.GetCollection<FilmCategory>("FilmCategory");
            FilmActor = database.GetCollection<FilmActor>("FilmActor");
            Store = database.GetCollection<Store>("Store");
            Customer = database.GetCollection<Customer>("Customer");
            Staff = database.GetCollection<Staff>("Staff");
            Inventory = database.GetCollection<Inventory>("Inventory");
            Rental = database.GetCollection<Rental>("Rental");
            Payment = database.GetCollection<Payment>("Payment");
        }
    }
}
