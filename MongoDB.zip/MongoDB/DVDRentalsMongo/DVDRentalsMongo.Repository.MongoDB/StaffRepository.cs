﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class StaffRepository : IStaffRepository
    {
        private UnitOfWork _unitOfWork;

        public StaffRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task CreateAsync(Staff staff)
        {
            await _unitOfWork.Staff.InsertOneAsync(staff);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Staff.DeleteOneAsync(c => c.Id == id);
        }

        public async Task<Staff> GetAsync(string storeId, string staffId)
        {
            return await _unitOfWork.Staff.Find(c => c.Id == staffId && c.StoreId == storeId)
                                          .FirstOrDefaultAsync();
        }

        public async Task<Staff> GetAsync(string id)
        {
            return await _unitOfWork.Staff.Find(c => c.Id == id)
                                     .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Staff>> GetListAsync(string id)
        {
            return await _unitOfWork.Staff.Find(c => c.StoreId == id)
                                          .ToListAsync();
        }

        public async Task UpdateAsync(string id, Staff staff)
        {
            await _unitOfWork.Staff.ReplaceOneAsync(c => c.Id == id, staff);
        }
    }
}
