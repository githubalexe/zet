﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class AddressRepository : IAddressRepository
    {
        private UnitOfWork _unitOfWork;

        public AddressRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task CreateAsync(Address address)
        {
            await _unitOfWork.Address.InsertOneAsync(address);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Address.DeleteOneAsync(a => a.Id == id);
        }

        public async Task<Address> GetAsync(string id)
        {
            return await _unitOfWork.Address.Find(a => a.Id == id)
                         .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Address>> GetListAsync()
        {
            return await _unitOfWork.Address.Find(address => true)
                              .ToListAsync();
        }

        public async Task UpdateAsync(string id, Address address)
        {
            await _unitOfWork.Address.ReplaceOneAsync(a => a.Id == id, address);
        }
    }
}
