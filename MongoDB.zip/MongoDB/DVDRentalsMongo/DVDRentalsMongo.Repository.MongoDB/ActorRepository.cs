﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class ActorRepository : IActorRepository
    {
        private UnitOfWork _unitOfWork;

        public  ActorRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task CreateAsync(Actor actor)
        {
            await _unitOfWork.Actor.InsertOneAsync(actor);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Actor.DeleteOneAsync(a => a.Id == id);
        }

        public async Task<Actor> GetAsync(string id)
        {
            return await _unitOfWork.Actor.Find(a => a.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Actor>> GetListAsync()
        {
            return await _unitOfWork.Actor.Find(actor => true)
                                    .ToListAsync();
        }

        public async Task UpdateAsync(string id, Actor actor)
        {
            await _unitOfWork.Actor.ReplaceOneAsync(a => a.Id == id, actor);
        }
    }
}
