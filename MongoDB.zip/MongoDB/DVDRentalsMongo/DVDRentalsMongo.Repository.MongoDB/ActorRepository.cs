﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.Domain;
using MongoDB.Driver;

namespace DVDRentalsMongo.Repository.MongoDB
{
    public class ActorRepository : IActorRepository
    {
        private UnitOfWork _unitOfWork;

        public  ActorRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public async Task CreateAsync(Actor actor)
        {
            await _unitOfWork.Actor.InsertOneAsync(actor);
        }

        public async Task DeleteAsync(string id)
        {
            await _unitOfWork.Actor.DeleteOneAsync(a => a.Id == id);
        }

        public async Task<Actor> GetAsync(string id)
        {
            return await _unitOfWork.Actor.Find(a => a.Id == id)
                                    .FirstOrDefaultAsync();
        }

        public IEnumerable<Actor> GetByQuery(IQueryable<Actor> query)
        {
            return query.ToList();
        }

        public IQueryable<Actor> GetQuery()
        {
            IQueryable<Actor> query = _unitOfWork.Actor.AsQueryable();
            return query;
        } 

        public async Task UpdateAsync(string id, Actor actor)
        {
            await _unitOfWork.Actor.ReplaceOneAsync(a => a.Id == id, actor);
        }
    }
}
