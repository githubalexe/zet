﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface ICustomerRepository
    {
        Task<Customer> GetAsync(string storeId, string customerId);
        Task<Customer> GetAsync(string id);
        Task<IEnumerable<Customer>> GetListAsync(string id);
        Task CreateAsync(Customer customer);
        Task UpdateAsync(string id, Customer customer);
        Task DeleteAsync(string id);
    }
}
