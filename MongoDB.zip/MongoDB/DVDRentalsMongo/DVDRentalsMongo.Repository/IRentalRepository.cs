﻿using DVDRentalsMongo.Domain;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IRentalRepository
    {
        Task<Rental> GetAsync(string id);
        Task<IEnumerable<Rental>> GetListAsync();
        Task CreateAsync(Rental rental);
        Task UpdateAsync(string id, Rental rental);
        Task DeleteAsync(string id);

        //
        IQueryable<Rental> GetQuery();
        IEnumerable<Rental> GetByQuery(IQueryable<Rental> query);
    }
}
