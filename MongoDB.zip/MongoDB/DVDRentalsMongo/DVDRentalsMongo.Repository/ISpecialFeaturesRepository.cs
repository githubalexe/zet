﻿using DVDRentalsMongo.Domain;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface ISpecialFeaturesRepository
    {
        IQueryable<SpecialFeatures> GetQuery();
        IEnumerable<SpecialFeatures> GetByQuery(IQueryable<SpecialFeatures> query);
        Task<SpecialFeatures> GetAsync(string id);
        Task CreateAsync(SpecialFeatures SpecialFeatures);
        Task DeleteAsync(string id);
    }
}
