﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IAddressRepository
    {
        Task<Address> GetAsync(string id);
        Task<IEnumerable<Address>> GetListAsync();
        Task CreateAsync(Address address);
        Task UpdateAsync(string id, Address address);
        Task DeleteAsync(string id);
    }
}
