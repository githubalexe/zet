﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface ICountryRepository
    {
        Task<Country> GetAsync(string id);
        Task<IEnumerable<Country>> GetListAsync();
        Task CreateAsync(Country country);
        Task UpdateAsync(string id, Country country);
        Task DeleteAsync(string id);
    }
}
