﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IActorRepository
    {
        Task<Actor> GetAsync(string id);
        Task<IEnumerable<Actor>> GetListAsync();
        Task CreateAsync(Actor actor);
        Task UpdateAsync(string id, Actor actor);
        Task DeleteAsync(string id);
    }
}
