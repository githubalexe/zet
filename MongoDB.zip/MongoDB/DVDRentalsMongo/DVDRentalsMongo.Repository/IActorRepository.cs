﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IActorRepository
    {
        IQueryable<Actor> GetQuery();
        IEnumerable<Actor> GetByQuery(IQueryable<Actor> query);
        Task<Actor> GetAsync(string id);
        Task CreateAsync(Actor actor);
        Task UpdateAsync(string id, Actor actor);
        Task DeleteAsync(string id);
    }
}
