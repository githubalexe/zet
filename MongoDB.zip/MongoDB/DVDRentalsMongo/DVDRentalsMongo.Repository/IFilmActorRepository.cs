﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IFilmActorRepository
    {
        Task<FilmActor> GetAsync(string id);
        Task<IEnumerable<FilmActor>> GetListAsync();
        Task CreateAsync(FilmActor filmActor);
        Task UpdateAsync(string id, FilmActor filmActor);
        Task DeleteAsync(string id);

        //
        Task<IEnumerable<FilmActor>> GetListAsync(string id);
        Task<FilmActor> GetAsync(string filmId,string actorId);
        Task<FilmActor> GetFilmAsync(string id);
    }
}
