﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IFilmActorRepository
    {
        Task<FilmActor> GetAsync(string id);
        Task CreateAsync(FilmActor filmActor);
        Task UpdateAsync(string id, FilmActor filmActor);
        Task DeleteAsync(string id);
        Task<FilmActor> GetAsync(string filmId, string actorId);
  
        ///
        IQueryable<FilmActor> GetQuery();
        IEnumerable<FilmActor> GetByQuery(IQueryable<FilmActor> query);
    }
}
