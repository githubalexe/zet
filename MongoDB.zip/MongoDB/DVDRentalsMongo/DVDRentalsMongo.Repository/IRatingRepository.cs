﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IRatingRepository
    {
        IQueryable<Rating> GetQuery();
        IEnumerable<Rating> GetByQuery(IQueryable<Rating> query);
        Task<Rating> GetAsync(string id);
        Task CreateAsync(Rating rating);
        Task DeleteAsync(string id);
    }
}
