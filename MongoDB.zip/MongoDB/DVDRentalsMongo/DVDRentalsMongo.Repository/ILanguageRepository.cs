﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface ILanguageRepository
    {
        Task<Language> GetAsync(string id);
        Task<IEnumerable<Language>> GetListAsync();
        Task CreateAsync(Language language);
        Task UpdateAsync(string id, Language language);
        Task DeleteAsync(string id);
    }
}
