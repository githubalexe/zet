﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IInventoryRepository
    {
        Task<Inventory> GetAsync(string id);
        Task<IEnumerable<Inventory>> GetListAsync(string id);
        Task CreateAsync(Inventory inventory);
        Task UpdateAsync(string id, Inventory inventory);
        Task DeleteAsync(string id);

        //
        Task<IEnumerable<Inventory>> GetFilmInventoriesListAsync(string storeId, string filmId);
    }
}
