﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface ICityRepository
    {
        Task<City> GetAsync(string id);
        Task<IEnumerable<City>> GetListAsync();
        Task<IEnumerable<City>> GetListAsync(string id);
        Task CreateAsync(City city);
        Task UpdateAsync(string id, City city);
        Task DeleteAsync(string id);
    }
}
