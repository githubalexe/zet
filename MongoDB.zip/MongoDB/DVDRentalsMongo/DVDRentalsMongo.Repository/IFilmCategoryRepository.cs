﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IFilmCategoryRepository
    {
        Task<FilmCategory> GetAsync(string id);
        Task<IEnumerable<FilmCategory>> GetListAsync();
        Task CreateAsync(FilmCategory filmCategory);
        Task UpdateAsync(string id, FilmCategory filmCategory);
        Task DeleteAsync(string id);

        //
        Task<FilmCategory> GetAsync(string filmId, string categoryId);

    }
}
