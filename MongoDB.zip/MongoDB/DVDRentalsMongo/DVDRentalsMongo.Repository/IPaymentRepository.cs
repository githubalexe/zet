﻿using DVDRentalsMongo.Domain;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IPaymentRepository
    {
        Task<Payment> GetAsync(string id);
        Task<IEnumerable<Payment>> GetListAsync(string id);
        Task CreateAsync(Payment payment);
        Task UpdateAsync(string id, Payment payment);
        Task DeleteAsync(string id);
    }
}
