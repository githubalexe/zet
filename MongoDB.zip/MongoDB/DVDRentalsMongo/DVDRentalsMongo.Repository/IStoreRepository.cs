﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IStoreRepository
    {
        Task<Store> GetAsync(string id);
        Task<IEnumerable<Store>> GetListAsync();
        Task CreateAsync(Store store);
        Task UpdateAsync(string id, Store store);
        Task DeleteAsync(string id);
    }
}
