﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IStaffRepository
    {
        Task<Staff> GetAsync(string storeId, string staffId);
        Task<Staff> GetAsync(string id);
        Task<IEnumerable<Staff>> GetListAsync(string id);
        Task CreateAsync(Staff staff);
        Task UpdateAsync(string id, Staff staff);
        Task DeleteAsync(string id);
    }
}
