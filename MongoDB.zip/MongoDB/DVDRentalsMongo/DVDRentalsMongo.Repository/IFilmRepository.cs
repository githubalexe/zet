﻿using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Repository
{
    public interface IFilmRepository
    {
        Task<Film> GetAsync(string id);
        Task<IEnumerable<Film>> GetListAsync();
        Task CreateAsync(Film film);
        Task UpdateAsync(string id, Film film);
        Task DeleteAsync(string id);
    }
}
