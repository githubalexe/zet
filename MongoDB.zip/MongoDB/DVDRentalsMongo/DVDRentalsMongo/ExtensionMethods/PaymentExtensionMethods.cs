﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Payment;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class PaymentExtensionMethods
    {
        public static Payment ToPaymentModel(this PaymentCreateRequest request)
        {
            return new Payment()
            {
                Id = Guid.NewGuid().ToString(),
                CustomerId = request.CustomerId,
                StaffId = request.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount,
                PaymentDate = request.PaymentDate
            };
        }

        public static Payment ToPaymentModel(this PaymentUpdateRequest request, Payment payment)
        {
            payment.CustomerId = request.CustomerId;
            payment.StaffId = request.StaffId;
            payment.RentalId = request.RentalId;
            payment.Amount = request.Amount;
            payment.PaymentDate = request.PaymentDate;

            return payment;
        }

        public static PaymentResponseLite ToPaymentResponseLite(this Payment payment)
        {
            return new PaymentResponseLite()
            {
                Id = payment.Id,
                CustomerId = payment.CustomerId,
                StaffId = payment.StaffId,
                RentalId = payment.RentalId,
                Amount = payment.Amount,
                PaymentDate = payment.PaymentDate,

            };
        }
    }
}
