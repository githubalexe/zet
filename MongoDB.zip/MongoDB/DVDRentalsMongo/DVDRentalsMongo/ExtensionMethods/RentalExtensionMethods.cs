﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Rental;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static Rental ToRentalModel(this RentalCreateRequest request)
        {
            return new Rental()
            {
                Id = Guid.NewGuid().ToString(),
                RentalDate = request.RentalDate,
                InventoryId = request.InventoryId,
                CustomerId = request.CustomerId,
                ReturnDate = request.ReturnDate,
                StaffId = request.StaffId
            };
        }

        public static Rental ToRentalModel(this RentalUpdateRequest request, Rental rental)
        {
            rental.RentalDate = request.RentalDate;
            rental.InventoryId = request.InventoryId;
            rental.CustomerId = request.CustomerId;
            rental.ReturnDate = request.ReturnDate;
            rental.StaffId = request.StaffId;

            return rental;
        }

        public static RentalResponseLite ToRentalResponseLite(this Rental rental)
        {
            return new RentalResponseLite()
            {
                Id = rental.Id,
                RentalDate = rental.RentalDate,
                InventoryId = rental.InventoryId,
                CustomerId = rental.CustomerId,
                ReturnDate = rental.ReturnDate,
                StaffId = rental.StaffId
            };
        }

        public static RentalResponse ToRentalResponse(this Rental rental, Customer customer, Staff staff, Film film)
        {
            return new RentalResponse()
            {
                Id = rental.Id,
                RentalDate = rental.RentalDate,
                InventoryId = rental.InventoryId,
                CustomerId = rental.CustomerId,
                ReturnDate = rental.ReturnDate,
                StaffId = rental.StaffId,
                Customer = customer.ToCustomerNameResponse(),
                Staff = staff.ToStaffNameResponse(),
                Film = film.ToFilmTitleResponse()
            };
        }
    }
}