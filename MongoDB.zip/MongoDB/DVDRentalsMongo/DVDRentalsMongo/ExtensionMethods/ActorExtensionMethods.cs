﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Actor;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static Actor ToActorModel(this ActorCreateRequest request)
        {
            return new Actor()
            {
                Id = Guid.NewGuid().ToString(),
                FirstName = request.FirstName,
                LastName = request.LastName
            };
        }

        public static Actor ToActorModel(this ActorUpdateRequest request, Actor actor)
        {
            actor.FirstName = request.FirstName;
            actor.LastName = request.LastName;

            return actor;
        }

        public static ActorResponseLite ToActorResponseLite(this Actor actor)
        {
            return new ActorResponseLite()
            {
                Id = actor.Id,
                FirstName = actor.FirstName,
                LastName = actor.LastName
            };
        }

        public static ActorResponse ToActorResponse(this Actor actor)
        {
            return new ActorResponse()
            {
                Id = actor.Id,
                FirstName = actor.FirstName,
                LastName = actor.LastName,
                Name = actor.GetName()
            };
        }

        private static string GetName(this Actor actor)
        {
            string name = String.Format("{0} {1}", actor.FirstName, actor.LastName);

            return name;
        }
    }
}
