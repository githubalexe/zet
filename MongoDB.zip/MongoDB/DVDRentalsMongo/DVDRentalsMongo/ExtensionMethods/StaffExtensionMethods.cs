﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Staff;
using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class StaffExtensionMethods
    {
        public static Staff ToStaffModel(this StaffCreateRequest request, string storeId)
        {
            return new Staff()
            {
                Id = Guid.NewGuid().ToString(),
                FirstName = request.FirstName,
                LastName = request.LastName,
                AddressId = request.AddressId,
                Picture = request.Picture,
                Email = request.Email,
                StoreId = storeId,
                Active = request.Active,
                Username = request.Username,
                Password = request.Password,
            };
        }

        public static Staff ToStaffModel(this StaffUpdateRequest request, Staff staff, string storeId)
        {
            staff.FirstName = request.FirstName;
            staff.LastName = request.LastName;
            staff.AddressId = request.AddressId;
            staff.Picture = request.Picture;
            staff.Email = request.Email;
            staff.StoreId = storeId;
            staff.Active = request.Active;
            staff.Username = request.Username;
            staff.Password = request.Password;

            return staff;
        }

        public static StaffResponseLite ToStaffResponseLite(this Staff staff)
        {
            return new StaffResponseLite()
            {
                Id = staff.Id,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                AddressId = staff.AddressId,
                Picture = staff.Picture,
                Email = staff.Email,
                StoreId = staff.StoreId,
                Active = staff.Active,
                Username = staff.Username,
                Password = staff.Password
            };
        }

        public static StaffResponse ToStaffResponse(this Staff staff, Address address, City city, Country country)
        {
            return new StaffResponse()
            {
                Id = staff.Id,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                AddressId = staff.AddressId,
                Picture = staff.Picture,
                Email = staff.Email,
                StoreId = staff.StoreId,
                Active = staff.Active,
                Username = staff.Username,
                Password = staff.Password,
                Name = staff.GetName(),
                Address = address.ToAddressResponse(city, country)
            };
        }

        public static StaffNameResponse ToStaffNameResponse(this Staff staff)
        {
            if (staff == null)
            {
                return null;
            }

            return new StaffNameResponse()
            {
                Id = staff.Id,
                Name = staff.GetName()
            };
        }

        private static string GetName(this Staff staff)
        {
            string name = String.Format("{0} {1}", staff.FirstName, staff.LastName);

            return name;
        }
    }
}
