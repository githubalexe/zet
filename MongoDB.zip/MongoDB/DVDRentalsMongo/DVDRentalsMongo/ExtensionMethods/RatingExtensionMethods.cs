﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.Rating;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class RatingExtensionMethods
    {
        public static Rating ToRatingModel(this RatingCreateRequest request)
        {
            return new Rating()
            {
                Id = Guid.NewGuid().ToString(),
                Name = request.Name
            };
        }

        public static RatingResponseLite ToRatingResponseLite(this Rating request)
        {
            return new RatingResponseLite()
            {
                Id = request.Id,
                Name = request.Name
            };
        }
    }
}
