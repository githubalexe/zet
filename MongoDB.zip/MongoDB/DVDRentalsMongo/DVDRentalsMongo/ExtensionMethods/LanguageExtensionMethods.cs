﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Language;
using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class LanguageExtensionMethods
    {
        public static Language ToLanguageModel(this LanguageCreateRequest request)
        {
            return new Language()
            {
                Id = Guid.NewGuid().ToString(),
                Name = request.Name
            };
        }

        public static Language ToLanguageModel(this LanguageUpdateRequest request, Language language)
        {
            language.Name = request.Name;

            return language;
        }

        public static LanguageResponseLite ToLanguageResponseLite(this Language request)
        {
            return new LanguageResponseLite()
            {
                Id = request.Id,
                Name = request.Name
            };
        }
    }
}
