﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Category;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class CategoryExtensionMethods
    {
        public static Category ToCategoryModel(this CategoryCreateRequest request)
        {
            return new Category
            {
                Id = Guid.NewGuid().ToString(),
                Name = request.Name
            };
        }

        public static Category ToCategoryModel(this CategoryUpdateRequest request, Category category)
        {
            category.Name = request.Name;

            return category;
        }

        public static CategoryResponseLite ToCategoryResponseLite(this Category category)
        {
            if (category == null)
            {
                return null;
            }

            return new CategoryResponseLite()
            {
                Id = category.Id,
                Name = category.Name,
            };
        }
    }
}
