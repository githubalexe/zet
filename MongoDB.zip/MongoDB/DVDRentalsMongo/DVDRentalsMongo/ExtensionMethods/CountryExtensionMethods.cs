﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Country;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class CountryExtensionMethods
    {
        public static Country ToCountryModel(this CountryCreateRequest request)
        {
            return new Country
            {
                Id = Guid.NewGuid().ToString(),
                Name = request.Name
            };
        }

        public static Country ToCountryModel(this CountryUpdateRequest request, Country country)
        {
            country.Name = request.Name;

            return country;
        }

        public static CountryResponseLite ToCountryResponseLite(this Country country)
        {
            return new CountryResponseLite()
            {
                Id = country.Id,
                Name = country.Name,
            };
        }
    }
}
