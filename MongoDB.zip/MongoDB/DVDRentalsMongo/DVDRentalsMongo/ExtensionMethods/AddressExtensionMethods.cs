﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class AddressExtensionMethods
    {
        public static Address ToAddressModel(this AddressCreateRequest request)
        {
            return new Address()
            {
                Id = Guid.NewGuid().ToString(),
                Address1 = request.Address1,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }

        public static Address ToAddressModel(this AddressUpdateRequest request, Address address)
        {
            address.Address1 = request.Address1;
            address.Address2 = request.Address2;
            address.District = request.District;
            address.CityId = request.CityId;
            address.PostalCode = request.PostalCode;
            address.Phone = request.Phone;

            return address;
        }

        public static AddressResponseLite ToAddressResponseLite(this Address request)
        {
            return new AddressResponseLite()
            {
                Id = request.Id,
                Address1 = request.Address1,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone
            };
        }

        public static AddressResponse ToAddressResponse(this Address request, City city, Country country)
        {
            return new AddressResponse()
            {
                Id = request.Id,
                Address1 = request.Address1,
                Address2 = request.Address2,
                District = request.District,
                CityId = request.CityId,
                PostalCode = request.PostalCode,
                Phone = request.Phone,
                City = city.ToCityResponse(country),

            };
        }
    }
}
