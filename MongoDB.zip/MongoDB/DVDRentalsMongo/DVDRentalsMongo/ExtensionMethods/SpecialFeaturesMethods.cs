﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.SpecialFeatures;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class SpecialFeaturesMethods
    {
        public static SpecialFeatures ToSpecialFeaturesModel(this SpecialFeaturesCreateRequest request)
        {
            return new SpecialFeatures()
            {
                Id = Guid.NewGuid().ToString(),
                Name = request.Name
            };
        }

        public static SpecialFeaturesResponseLite ToSpecialFeaturesResponseLite(this SpecialFeatures request)
        {
            return new SpecialFeaturesResponseLite()
            {
                Id = request.Id,
                Name = request.Name
            };
        }
    }
}
