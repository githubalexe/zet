﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static Customer ToCustomerModel(this CustomerCreateRequest request, string storeId)
        {
            return new Customer()
            {
                Id = Guid.NewGuid().ToString(),
                StoreId = storeId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                AddressId = request.AddressId,
                Active = request.Active,
                CreateDate = request.CreateDate
            };
        }

        public static Customer ToCustomerModel(this CustomerUpdateRequest request, Customer customer, string storeId)
        {
            customer.StoreId = storeId;
            customer.FirstName = request.FirstName;
            customer.LastName = request.LastName;
            customer.Email = request.Email;
            customer.AddressId = request.AddressId;
            customer.Active = request.Active;

            return customer;
        }

        public static CustomerResponseLite ToCustomerResponseLite(this Customer customer)
        {
            return new CustomerResponseLite()
            {
                Id = customer.Id,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = DateTime.Today
            };
        }

        public static CustomerResponse ToCustomerResponse(this Customer customer, Address address, City city, Country country)
        {
            return new CustomerResponse()
            {
                Id = customer.Id,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Active = customer.Active,
                CreateDate = customer.CreateDate,
                Name = customer.GetName(),
                Address = address.ToAddressResponse(city, country)
            };
        }

        public static CustomerNameResponse ToCustomerNameResponse(this Customer customer)
        {
            if (customer == null)
            {
                return null;
            }

            return new CustomerNameResponse()
            {
                Id = customer.Id,
                Name = customer.GetName()
            };
        }

        private static string GetName(this Customer customer)
        {
            string name = String.Format("{0} {1}", customer.FirstName, customer.LastName);

            return name;
        }

    }
}

