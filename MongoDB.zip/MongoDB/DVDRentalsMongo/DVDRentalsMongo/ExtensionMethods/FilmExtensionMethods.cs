﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.FilmActor;
using DVDRentalsMongo.API.Response.FilmCategory;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static Film ToFilmModel(this FilmCreateRequest request)
        {
            return new Film()
            {
                Id = Guid.NewGuid().ToString(),
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                RatingId = request.RatingId,
                SpecialFeaturesId = request.SpecialFeaturesId
            };
        }

        public static Film ToFilmModel(this FilmUpdateRequest request, Film film)
        {
            film.Title = request.Title;
            film.Description = request.Description;
            film.ReleaseYear = request.ReleaseYear;
            film.LanguageId = request.LanguageId;
            film.RentalDuration = request.RentalDuration;
            film.RentalRate = request.RentalRate;
            film.Length = request.Length;
            film.ReplacementCost = request.ReplacementCost;
            film.RatingId = request.RatingId;
            film.SpecialFeaturesId = request.SpecialFeaturesId;

            return film;
        }

        public static FilmResponseLite ToFilmResponseLite(this Film request)
        {
            return new FilmResponseLite()
            {
                Id = request.Id,
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                RatingId = request.RatingId,
                SpecialFeaturesId = request.SpecialFeaturesId
            };
        }

        public static FilmResponse ToFilmResponse(this Film request, Language language, Category category, Rating rating, SpecialFeatures specialFeatures)
        {
            return new FilmResponse()
            {
                Id = request.Id,
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                RatingId = request.RatingId,
                SpecialFeaturesId = request.SpecialFeaturesId,
                Language = language.ToLanguageResponseLite(),
                Rating = rating.ToRatingResponseLite(),
                SpecialFeatures = specialFeatures.ToSpecialFeaturesResponseLite(),
                Category = category.ToCategoryResponseLite()
            };
        }

        public static FilmTitleResponse ToFilmTitleResponse(this Film request)
        {
            return new FilmTitleResponse()
            {
                Id = request.Id,
                Title = request.Title
            };
        }

        //FilmCategory
        public static FilmCategory ToFilmCategoryModel(this FilmCategoryCreateRequest request)
        {
            return new FilmCategory()
            {
                Id = Guid.NewGuid().ToString(),
                FilmId = request.FilmId,
                CategoryId = request.CategoryId
            };
        }

        public static FilmCategoryResponseLite ToFilmCategoryResponseLite(this FilmCategory request)
        {
            return new FilmCategoryResponseLite()
            {
                Id = request.Id,
                FilmId = request.FilmId,
                CategoryId = request.CategoryId
            };
        }

        //FilmActor
        public static FilmActor ToFilmActorModel(this FilmActorCreateRequest request)
        {
            return new FilmActor()
            {
                Id = Guid.NewGuid().ToString(),
                FilmId = request.FilmId,
                ActorId = request.ActorId
            };
        }

        public static FilmActorResponseLite ToFilmActorResponseLite(this FilmActor request)
        {
            return new FilmActorResponseLite()
            {
                Id = request.Id,
                FilmId = request.FilmId,
                ActorId = request.ActorId
            };
        }
    }
}
