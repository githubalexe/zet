﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.FilmActor;
using DVDRentalsMongo.API.Response.FilmCategory;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static Film ToFilmModel(this FilmCreateRequest request)
        {
            return new Film()
            {
                Id = Guid.NewGuid().ToString(),
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                OriginalLanguageId = request.OriginalLanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                Rating = request.Rating,
                SpecialFeatures = request.SpecialFeatures
            };
        }

        public static Film ToFilmModel(this FilmUpdateRequest request, Film film)
        {
            film.Title = request.Title;
            film.Description = request.Description;
            film.ReleaseYear = request.ReleaseYear;
            film.LanguageId = request.LanguageId;
            film.OriginalLanguageId = request.OriginalLanguageId;
            film.RentalDuration = request.RentalDuration;
            film.RentalRate = request.RentalRate;
            film.Length = request.Length;
            film.ReplacementCost = request.ReplacementCost;
            film.Rating = request.Rating;
            film.SpecialFeatures = request.SpecialFeatures;

            return film;
        }

        public static FilmResponseLite ToFilmResponseLite(this Film request)
        {
            return new FilmResponseLite()
            {
                Id = request.Id,
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                OriginalLanguageId = request.OriginalLanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                Rating = request.Rating,
                SpecialFeatures = request.SpecialFeatures
            };
        }

        public static FilmResponse ToFilmResponse(this Film request, Language language, Category category)
        {
            return new FilmResponse()
            {
                Id = request.Id,
                Title = request.Title,
                Description = request.Description,
                ReleaseYear = request.ReleaseYear,
                LanguageId = request.LanguageId,
                OriginalLanguageId = request.OriginalLanguageId,
                RentalDuration = request.RentalDuration,
                RentalRate = request.RentalRate,
                Length = request.Length,
                ReplacementCost = request.ReplacementCost,
                Rating = request.Rating,
                SpecialFeatures = request.SpecialFeatures,
                Language = language.ToLanguageResponseLite(),
                Category = category.ToCategoryResponseLite()
            };
        }

        public static FilmTitleResponse ToFilmTitleResponse(this Film request)
        {
            return new FilmTitleResponse()
            {
                Id = request.Id,
                Title = request.Title
            };
        }

        //FilmCategory
        public static FilmCategory ToFilmCategoryModel(this FilmCategoryCreateRequest request)
        {
            return new FilmCategory()
            {
                FilmId = request.FilmId,
                CategoryId = request.CategoryId
            };
        }

        public static FilmCategoryResponseLite ToFilmCategoryResponseLite(this FilmCategory request)
        {
            return new FilmCategoryResponseLite()
            {
                Id = request.Id,
                FilmId = request.FilmId,
                CategoryId = request.CategoryId
            };
        }

        //FilmActor
        public static FilmActor ToFilmActorModel(this FilmActorCreateRequest request)
        {
            return new FilmActor()
            {
                FilmId = request.FilmId,
                ActorId = request.ActorId
            };
        }

        public static FilmActorResponseLite ToFilmActorResponseLite(this FilmActor request)
        {
            return new FilmActorResponseLite()
            {
                Id = request.Id,
                FilmId = request.FilmId,
                ActorId = request.ActorId
            };
        }
    }
}
