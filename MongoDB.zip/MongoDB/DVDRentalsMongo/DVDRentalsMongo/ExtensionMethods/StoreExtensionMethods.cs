﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Store;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static Store ToStoreModel(this StoreCreateRequest request)
        {
            return new Store()
            {
                Id = Guid.NewGuid().ToString(),
                ManagerStaffId = request.ManagerStaffId,
                AddressId = request.AddressId
            };
        }

        public static Store ToStoreModel(this StoreUpdateRequest request, Store store)
        {
            store.ManagerStaffId = request.ManagerStaffId;
            store.AddressId = request.AddressId;

            return store;
        }

        public static StoreResponseLite ToStoreResponseLite(this Store store)
        {
            return new StoreResponseLite()
            {
                Id = store.Id,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId
            };
        }

        public static StoreResponse ToStoreResponse(this Store store, Address address, City city, Country country, Staff staff)
        {
            return new StoreResponse()
            {
                Id = store.Id,
                ManagerStaffId = store.ManagerStaffId,
                AddressId = store.AddressId,
                Address = address.ToAddressResponse(city, country),
                ManagerName = staff.ToStaffNameResponse()
            };
        }
    }
}
