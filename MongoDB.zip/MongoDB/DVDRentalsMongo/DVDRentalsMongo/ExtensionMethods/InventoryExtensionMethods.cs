﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.Inventory;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class InventoryExtensionMethods
    {
        public static Inventory ToInventoryModel(this InventoryCreateRequest request,string storeId)
        {
            return new Inventory()
            {
                Id = Guid.NewGuid().ToString(),
                StoreId = storeId,
                FilmId = request.FilmId
            };
        }

        public static InventoryResponseLite ToInventoryResponseLite(this Inventory request)
        {
            return new InventoryResponseLite()
            {
                Id = request.Id,
                StoreId = request.StoreId,
                FilmId = request.FilmId
            };
        }

        public static InventoryResponse ToInventoryResponse(this Inventory request, Film film)
        {
            return new InventoryResponse()
            {
                Id = request.Id,
                StoreId = request.StoreId,
                FilmId = request.FilmId,
                Film = film.ToFilmResponseLite()
            };
        }
    }
}
