﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.City;
using DVDRentalsMongo.Domain;
using System;

namespace DVDRentalsMongo.ExtensionMethods
{
    public static class CityExtensionMethods
    {
        public static City ToCityModel(this CityCreateRequest request)
        {
            return new City()
            {
                Id = Guid.NewGuid().ToString(),
                Name = request.Name,
                CountryId = request.CountryId
            };
        }

        public static City ToCityModel(this CityUpdateRequest request, City city)
        {
            city.Name = request.Name;
            city.CountryId = request.CountryId;

            return city;
        }

        public static CityResponseLite ToCityResponseLite(this City city)
        {
            return new CityResponseLite()
            {
                Id = city.Id,
                CountryId = city.CountryId,
                Name = city.Name,
            };
        }

        public static CityResponse ToCityResponse(this City city, Country country)
        {
            return new CityResponse()
            {
                Id = city.Id,
                CountryId = city.CountryId,
                Name = city.Name,
                Country = country.ToCountryResponseLite()
            };
        }
    }
}
