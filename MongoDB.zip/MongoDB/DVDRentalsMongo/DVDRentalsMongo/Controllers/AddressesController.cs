﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Address;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class AddressesController : Controller
    {
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;

        public AddressesController(IAddressRepository addressRepository,
                                 ICityRepository cityRepository,
                                 ICountryRepository countryRepository)
        {
            _addressRepository = addressRepository;
            _cityRepository = cityRepository;
            _countryRepository = countryRepository;

        }

        [HttpGet("addresses/{id}", Name = "GetAddress")]
        public async Task<IActionResult> GetAddress(string id)
        {
            Address address = await _addressRepository.GetAsync(id);

            if (address == null)
            {
                return BadRequest("Error");
            }

            City city = await _cityRepository.GetAsync(address.CityId);
            Country country = await _countryRepository.GetAsync(city.CountryId);
            AddressResponse response = address.ToAddressResponse(city, country);

            return Ok(response);
        }

        [HttpGet("addresses")]
        public async Task<IActionResult> GetAddress()
        {
            IEnumerable<Address> addresses = await _addressRepository.GetListAsync();

            if (addresses == null)
            {
                return BadRequest("Error");
            }

            List<AddressResponse> response = new List<AddressResponse>();
            City city = new City();
            Country country = new Country();

            foreach (var address in addresses)
            {
                city = await _cityRepository.GetAsync(address.CityId);
                country = await _countryRepository.GetAsync(city.CountryId);

                response.Add(address.ToAddressResponse(city, country));
            }

            return Ok(response);
        }

        [HttpPost("addresses")]
        public async Task<IActionResult> CreateAddress([FromBody]AddressCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Address address = request.ToAddressModel();

            await _addressRepository.CreateAsync(address);

            AddressResponseLite response = address.ToAddressResponseLite();

            return Ok(response);
        }

        [HttpPut("addresses/{id}")]
        public async Task<IActionResult> UpdateAddress([FromBody]AddressUpdateRequest request, string id)
        {
            Address address = await _addressRepository.GetAsync(id);

            if (address == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            address = request.ToAddressModel(address);

            await _addressRepository.UpdateAsync(id, address);

            AddressResponseLite response = address.ToAddressResponseLite();

            return Ok(response);
        }

        [HttpDelete("addresses/{id}")]
        public async Task<IActionResult> DeleteAddress(string id)
        {
            Address address = await _addressRepository.GetAsync(id);

            if (address == null)
            {
                return BadRequest("Error");
            }

            await _addressRepository.DeleteAsync(id);

            return Ok();
        }
    }
}