﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.Rating;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class RatingsController : Controller
    {
        private IRatingRepository _ratingRepository;

        public RatingsController(IRatingRepository ratingRepository)
        {
            _ratingRepository = ratingRepository;
        }

        [HttpGet("ratings/{id}", Name = "GetRating")]
        public async Task<IActionResult> GetRating(string id)
        {
            Rating rating = await _ratingRepository.GetAsync(id);

            if (rating == null)
            {
                return BadRequest("Error");
            }

            RatingResponseLite response = rating.ToRatingResponseLite();

            return Ok(response);
        }

        [HttpGet("ratings")]
        public ActionResult GetLanguages()
        {
            IQueryable<Rating> query = _ratingRepository.GetQuery();

            query = query.Where(rental => true);

            IEnumerable<Rating> ratings = _ratingRepository.GetByQuery(query);

            if (ratings == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<RatingResponseLite> response = ratings.Select(rating => rating.ToRatingResponseLite());

            return Ok(response);
        }

        [HttpPost("ratings")]
        public async Task<IActionResult> CreateRating([FromBody]RatingCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Rating rating = request.ToRatingModel();

            await _ratingRepository.CreateAsync(rating);

            RatingResponseLite response = rating.ToRatingResponseLite();

            return Ok(response);
        }

        [HttpDelete("ratings/{id}")]
        public async Task<IActionResult> DeleteRating(string id)
        {
            Rating rating = await _ratingRepository.GetAsync(id);

            if (rating == null)
            {
                return BadRequest("Error");
            }

            await _ratingRepository.DeleteAsync(id);

            return Ok();
        }
    }
}