﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using DVDRentalsMongo.Services.AddressService;
using DVDRentalsMongo.Services.RentalService;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class CustomersController : Controller
    {
        private ICustomerRepository _customerRepository;
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;
        private IRentalService _rentalServices;
        private IAddressService _addressService;

        public CustomersController(ICustomerRepository customerRepository,
                                   IAddressRepository addressRepository,
                                   ICountryRepository countryRepository,
                                   IRentalService rentalServices,
                                   ICityRepository cityRepository,
                                   IAddressService addressService)
        {
            _customerRepository = customerRepository;
            _addressRepository = addressRepository;
            _countryRepository = countryRepository;
            _cityRepository = cityRepository;
            _rentalServices = rentalServices;
            _addressService = addressService;
        }

        [HttpGet("stores/{storeId}/customers/{customerId}", Name = "GetCustomer")]
        public async Task<IActionResult> GetCustomer(string storeId, string customerId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            Address address = await _addressRepository.GetAsync(customer.AddressId);
            City city = await _cityRepository.GetAsync(address.CityId);
            Country country = await _countryRepository.GetAsync(city.CountryId);

            CustomerResponse response = customer.ToCustomerResponse(address, city, country);

            return Ok(response);
        }

        [HttpGet("stores/{id}/customers")]
        public async Task<IActionResult> GetCustomers(string id)
        {
            IEnumerable<Customer> customers = await _customerRepository.GetListAsync(id);

            if (customers == null)
            {
                return BadRequest("Error");
            }

            List<CustomerResponse> response = new List<CustomerResponse>();

            foreach (Customer customer in customers)
            {
                Address address = await _addressRepository.GetAsync(customer.AddressId);
                City city = await _cityRepository.GetAsync(address.CityId);
                Country country = await _countryRepository.GetAsync(city.CountryId);

                response.Add(customer.ToCustomerResponse(address, city, country));
            }

            return Ok(response);
        }

        [HttpPost("stores/{id}/customers")]
        public async Task<IActionResult> CreateCustomer([FromBody]CustomerCreateRequest request, string id)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Customer customer = request.ToCustomerModel(id);

            await _customerRepository.CreateAsync(customer);

            CustomerResponseLite response = customer.ToCustomerResponseLite();

            return Ok(response);
        }

        [HttpPut("stores/{storeId}/customers/{customerId}")]
        public async Task<IActionResult> UpdateCustomer([FromBody]CustomerUpdateRequest request, string storeId, string customerId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            customer = request.ToCustomerModel(customer, storeId);

            await _customerRepository.UpdateAsync(customerId, customer);

            CustomerResponseLite response = customer.ToCustomerResponseLite();

            return Ok(response);
        }

        [HttpDelete("stores/{storeId}/customers/{customerId}")]
        public async Task<IActionResult> DeleteCustomer(string storeId, string customerId)
        {
            Customer customer = await _customerRepository.GetAsync(storeId, customerId);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            await _addressService.DeleteAddressAsync(customer.AddressId);
            await _customerRepository.DeleteAsync(customerId);
            await _rentalServices.DeleteCustomerRentalsAsync(customerId);

            return Ok();
        }
    }
}