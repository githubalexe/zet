﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Rental;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class RentalsController : Controller
    {
        private IRentalRepository _rentalRepository;
        private ICustomerRepository _customerRepository;
        private IStaffRepository _staffRepository;
        private IFilmRepository _filmRepository;
        private IInventoryRepository _inventoryRepository;
        public RentalsController(IRentalRepository rentalRepository,
                                 ICustomerRepository customerRepository,
                                 IStaffRepository staffRepository,
                                 IFilmRepository filmRepository,
                                 IInventoryRepository inventoryRepository)
        {
            _rentalRepository = rentalRepository;
            _customerRepository = customerRepository;
            _staffRepository = staffRepository;
            _filmRepository = filmRepository;
            _inventoryRepository = inventoryRepository;
        }

        [HttpGet("rentals/{id:length(24)}", Name = "GetRental")]
        public async Task<IActionResult> GetRental(string id)
        {
            Rental rental = await _rentalRepository.GetAsync(id);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            Customer customer = await _customerRepository.GetAsync(rental.CustomerId);
            Staff staff = await _staffRepository.GetAsync(rental.StaffId);
            Inventory inventory = await _inventoryRepository.GetAsync(rental.InventoryId);
            Film film = await _filmRepository.GetAsync(inventory.FilmId);

            RentalResponse response = rental.ToRentalResponse(customer, staff, film);

            return Ok(response);
        }

        [HttpGet("stores/{id:length(24)}/rentals")]
        public async Task<IActionResult> GetRentals(string id)
        {
            IEnumerable<Rental> rentals = await _rentalRepository.GetListAsync();

            if (rentals == null)
            {
                return BadRequest("Error");
            }

            List<RentalResponse> response = new List<RentalResponse>();

            foreach (Rental rental in rentals)
            {
                Inventory inventory = await _inventoryRepository.GetAsync(rental.InventoryId);

                if (inventory.StoreId == id)
                {
                    Customer customer = await _customerRepository.GetAsync(rental.CustomerId);
                    Staff staff = await _staffRepository.GetAsync(rental.StaffId);
                    Film film = await _filmRepository.GetAsync(inventory.FilmId);

                    response.Add(rental.ToRentalResponse(customer, staff, film));
                }
            }

            return Ok(response);
        }

        [HttpGet("customers/{id:length(24)}/rentals")]
        public async Task<IActionResult> GetCustomerRentals(string id)
        {
            IQueryable<Rental> query = _rentalRepository.GetQuery();

            query = query.Where(p => p.CustomerId == id);

            IEnumerable<Rental> rentals = _rentalRepository.GetByQuery(query);

            if (rentals == null)
            {
                return BadRequest("Error");
            }

            List<RentalResponse> response = new List<RentalResponse>();

            foreach (Rental rental in rentals)
            {
                Inventory inventory = await _inventoryRepository.GetAsync(rental.InventoryId);
                Customer customer = await _customerRepository.GetAsync(rental.CustomerId);
                Staff staff = await _staffRepository.GetAsync(rental.StaffId);
                Film film = await _filmRepository.GetAsync(inventory.FilmId);

                response.Add(rental.ToRentalResponse(customer, staff, film));

            }

            return Ok(response);
        }

        [HttpGet("staffs/{id:length(24)}/rentals")]
        public async Task<IActionResult> GetStaffRentals(string id)
        {
            IQueryable<Rental> query = _rentalRepository.GetQuery();

            query = query.Where(p => p.StaffId == id);

            IEnumerable<Rental> rentals = _rentalRepository.GetByQuery(query);

            if (rentals == null)
            {
                return BadRequest("Error");
            }

            List<RentalResponse> response = new List<RentalResponse>();

            foreach (Rental rental in rentals)
            {
                Inventory inventory = await _inventoryRepository.GetAsync(rental.InventoryId);

                Customer customer = await _customerRepository.GetAsync(rental.CustomerId);
                Staff staff = await _staffRepository.GetAsync(rental.StaffId);
                Film film = await _filmRepository.GetAsync(inventory.FilmId);

                response.Add(rental.ToRentalResponse(customer, staff, film));

            }

            return Ok(response);
        }

        [HttpGet("inventoryRentals/{id:length(24)}")]
        public IActionResult GetInventoryRentals(string id)
        {
            IQueryable<Rental> query = _rentalRepository.GetQuery();

            query = query.Where(p => p.InventoryId == id);

            IEnumerable<Rental> rentals = _rentalRepository.GetByQuery(query);

            if (rentals == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<RentalResponseLite> response = rentals.Select(rental => rental.ToRentalResponseLite());

            return Ok(response);
        }

        [HttpPost("rentals")]
        public async Task<IActionResult> CreateRental([FromBody]RentalCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Rental rental = request.ToRentalModel();

            await _rentalRepository.CreateAsync(rental);

            RentalResponseLite response = rental.ToRentalResponseLite();

            return Ok(response);
        }

        [HttpPut("rentals/{id:length(24)}")]
        public async Task<IActionResult> UpdateRental([FromBody]RentalUpdateRequest request, string id)
        {
            Rental rental = await _rentalRepository.GetAsync(id);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            rental = request.ToRentalModel(rental);

            await _rentalRepository.UpdateAsync(id, rental);

            RentalResponseLite response = rental.ToRentalResponseLite();

            return Ok(response);
        }

        [HttpDelete("rentals/{id:length(24)}")]
        public async Task<IActionResult> DeleteRental(string id)
        {
            Rental rental = await _rentalRepository.GetAsync(id);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            await _rentalRepository.DeleteAsync(id);

            return Ok();
        }
    }
}