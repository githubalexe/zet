﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Country;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Controllers
{
    public class CountriesController : Controller
    {
        private ICountryRepository _countryRepository;
        public CountriesController(ICountryRepository countryRepository)
        {
            _countryRepository = countryRepository;
        }

        [HttpGet("countries/{id}", Name = "GetCountry")]
        public async Task<IActionResult> GetCountry(string id)
        {
            Country country = await _countryRepository.GetAsync(id);

            if (country == null)
            {
                return BadRequest("Error");
            }

            CountryResponseLite response = country.ToCountryResponseLite();

            return Ok(response);
        }

        [HttpGet("countries")]
        public async Task<IActionResult> GetCountries()
        {
            IEnumerable<Country> countries = await _countryRepository.GetListAsync();

            if (countries == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<CountryResponseLite> response = countries.Select(country => country.ToCountryResponseLite());

            return Ok(response);
        }

        [HttpPost("countries")]
        public async Task<IActionResult> CreateCountry([FromBody]CountryCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Country country = request.ToCountryModel();

            await _countryRepository.CreateAsync(country);

            CountryResponseLite response = country.ToCountryResponseLite();

            return Ok(response);
        }

        [HttpPut("countries/{id}")]
        public async Task<IActionResult> UpdateCountry([FromBody]CountryUpdateRequest request, string id)
        {
            Country country = await _countryRepository.GetAsync(id);

            if (country == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            country = request.ToCountryModel(country);

            await _countryRepository.UpdateAsync(id, country);

            CountryResponseLite response = country.ToCountryResponseLite();

            return Ok(response);
        }

        [HttpDelete("countries/{id}")]
        public async Task<IActionResult> DeleteCountry(string id)
        {
            Country country = await _countryRepository.GetAsync(id);

            if (country == null)
            {
                return BadRequest("Error");
            }

            await _countryRepository.DeleteAsync(id);

            return Ok();
        }
    }
}