﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Actor;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.FilmActor;
using DVDRentalsMongo.API.Response.FilmCategory;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using DVDRentalsMongo.Services.FilmService;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Controllers
{
    public class FilmsController : Controller
    {
        private IFilmRepository _filmRepository;
        private ILanguageRepository _languageRepository;
        private IFilmCategoryRepository _filmCategoryRepository;
        private ICategoryRepository _categoryRepository;
        private IFilmActorRepository _filmActorRepository;
        private IActorRepository _actorRepository;
        private IFilmService _filmService;
        private IInventoryRepository _inventoryRepository;
        private IRatingRepository _ratingRepository;
        private ISpecialFeaturesRepository _specialFeaturesRepository;

        public FilmsController(IFilmRepository filmRepository,
                               ILanguageRepository languageRepository,
                               IFilmCategoryRepository filmCategoryRepository,
                               IFilmService filmService,
                               ICategoryRepository categoryRepository,
                               IFilmActorRepository filmActorRepository,
                               IInventoryRepository inventoryRepository,
                               IRatingRepository ratingRepository,
                               ISpecialFeaturesRepository specialFeaturesRepository,
                               IActorRepository actorRepository)

        {
            _filmRepository = filmRepository;
            _languageRepository = languageRepository;
            _filmCategoryRepository = filmCategoryRepository;
            _categoryRepository = categoryRepository;
            _filmActorRepository = filmActorRepository;
            _actorRepository = actorRepository;
            _inventoryRepository = inventoryRepository;
            _filmService = filmService;
            _ratingRepository = ratingRepository;
            _specialFeaturesRepository = specialFeaturesRepository;
        }

        [HttpGet("films/{id}", Name = "GetFilm")]
        public async Task<IActionResult> GetFilm(string id)
        {
            Film film = await _filmRepository.GetAsync(id);

            if (film == null)
            {
                return BadRequest("Error");
            }

            Language language = await _languageRepository.GetAsync(film.LanguageId);
            Rating rating = await _ratingRepository.GetAsync(film.RatingId);
            SpecialFeatures specialFeatures = await _specialFeaturesRepository.GetAsync(film.SpecialFeaturesId);
            FilmCategory filmCategory = await _filmCategoryRepository.GetAsync(film.Id);

            if (filmCategory == null)
            {
                FilmResponse filmResponse = film.ToFilmResponse(language, null, rating, specialFeatures);

                return Ok(filmResponse);
            }

            Category category = await _categoryRepository.GetAsync(filmCategory.CategoryId);
            FilmResponse response = film.ToFilmResponse(language, category, rating, specialFeatures);

            return Ok(response);
        }

        [HttpGet("films")]
        public async Task<IActionResult> GetFilms()
        {
            IEnumerable<Film> films = await _filmRepository.GetListAsync();

            if (films == null)
            {
                return BadRequest("Error");
            }

            List<FilmResponse> response = new List<FilmResponse>();

            foreach (Film film in films)
            {
                Language language = await _languageRepository.GetAsync(film.LanguageId);
                Rating rating = await _ratingRepository.GetAsync(film.RatingId);
                SpecialFeatures specialFeatures = await _specialFeaturesRepository.GetAsync(film.SpecialFeaturesId);
                FilmCategory filmCategory = await _filmCategoryRepository.GetAsync(film.Id);

                if (filmCategory == null)
                {
                    response.Add(film.ToFilmResponse(language, null, rating, specialFeatures));
                }
                else
                {
                    Category category = await _categoryRepository.GetAsync(filmCategory.CategoryId);
                    response.Add(film.ToFilmResponse(language, category, rating, specialFeatures));
                }
            }

            return Ok(response);
        }

        [HttpGet("stores/{id}/films")]
        public async Task<IActionResult> GetStoreFilms(string id)
        {
            IEnumerable<Inventory> inventories = await _inventoryRepository.GetListAsync(id);

            if (inventories == null)
            {
                return BadRequest("Error");
            }

            List<FilmTitleResponse> response = new List<FilmTitleResponse>();

            string copyId = string.Empty;
            foreach (Inventory inventory in inventories)
            {
                string inventoryId = inventory.FilmId;

                if (inventoryId != copyId)
                {
                    Film film = await _filmRepository.GetAsync(inventory.FilmId);
                    response.Add(film.ToFilmTitleResponse());
                }
                copyId = inventoryId;

            }

            return Ok(response);
        }

        [HttpPost("films")]
        public async Task<IActionResult> CreateFilm([FromBody]FilmCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Film film = request.ToFilmModel();

            await _filmRepository.CreateAsync(film);

            FilmResponseLite response = film.ToFilmResponseLite();

            return Ok(response);
        }

        [HttpPut("films/{id}")]
        public async Task<IActionResult> UpdateFilm([FromBody]FilmUpdateRequest request, string id)
        {
            Film film = await _filmRepository.GetAsync(id);

            if (film == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            film = request.ToFilmModel(film);

            await _filmRepository.UpdateAsync(id, film);

            FilmResponseLite response = film.ToFilmResponseLite();

            return Ok(response);
        }

        [HttpDelete("films/{id}")]
        public async Task<IActionResult> DeleteFilm(string id)
        {
            Film film = await _filmRepository.GetAsync(id);

            if (film == null)
            {
                return BadRequest("Error");
            }

            await _filmService.DeleteFilmCategoryAsync(id);
            await _filmService.DeleteFilmActorAsync(id);
            await _filmRepository.DeleteAsync(id);

            return Ok();
        }

        ///FilmCategory
        ///
        [HttpPost("filmscategories")]
        public async Task<IActionResult> CreateFilmCategory([FromBody]FilmCategoryCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            FilmCategory film = request.ToFilmCategoryModel();

            await _filmCategoryRepository.CreateAsync(film);

            FilmCategoryResponseLite response = film.ToFilmCategoryResponseLite();

            return Ok(response);
        }

        ///FilmActor
        ///
        [HttpPost("filmsactor")]
        public async Task<IActionResult> CreateFilmActor([FromBody]FilmActorCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            FilmActor film = request.ToFilmActorModel();

            await _filmActorRepository.CreateAsync(film);

            FilmActorResponseLite response = film.ToFilmActorResponseLite();

            return Ok(response);
        }

        [HttpGet("films/{id}/actors")]
        public async Task<IActionResult> GetFilmActors(string id)
        {
            Film film = await _filmRepository.GetAsync(id);

            if (film == null)
            {
                return BadRequest("Error");
            }

            IQueryable<FilmActor> query = _filmActorRepository.GetQuery();

            query = query.Where(f => f.FilmId == id);

            IEnumerable<FilmActor> actors = _filmActorRepository.GetByQuery(query);

            List<ActorResponse> response = new List<ActorResponse>();
            Actor actor = new Actor();

            foreach (FilmActor filmActor in actors)
            {
                actor = await _actorRepository.GetAsync(filmActor.ActorId);

                response.Add(actor.ToActorResponse());
            }

            return Ok(response);
        }

        [HttpDelete("films/{filmId}/categories/{categoryId}")]
        public async Task<IActionResult> DeleteFilmCategory(string filmId, string categoryId)
        {
            Film film = await _filmRepository.GetAsync(filmId);
            Category category = await _categoryRepository.GetAsync(categoryId);
            FilmCategory filmCategory = await _filmCategoryRepository.GetAsync(filmId, categoryId);

            if (film == null || category == null || filmCategory == null)
            {
                return BadRequest("Error");
            }

            await _filmService.DeleteFilmCategoryAsync(filmCategory.Id);

            return Ok();
        }

        [HttpDelete("films/{filmId}/actors/{actorId}")]
        public async Task<IActionResult> DeleteFilmActors(string filmId, string actorId)
        {
            Film film = await _filmRepository.GetAsync(filmId);

            if (film == null)
            {
                return BadRequest("Error");
            }

            FilmActor filmActor = await _filmActorRepository.GetAsync(filmId, actorId);

            await _filmService.DeleteFilmXActorAsync(filmActor.Id);

            return Ok();
        }
    }
}