﻿using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.SpecialFeatures;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Controllers
{
    public class SpecialFeaturesController : Controller
    {
        private ISpecialFeaturesRepository _specialFeaturesRepository;

        public SpecialFeaturesController(ISpecialFeaturesRepository specialFeaturesRepository)
        {
            _specialFeaturesRepository = specialFeaturesRepository;
        }

        [HttpGet("specialFeatures/{id}", Name = "GetSpecialFeatures")]
        public async Task<IActionResult> GetSpecialFeatures(string id)
        {
            SpecialFeatures specialFeatures = await _specialFeaturesRepository.GetAsync(id);

            if (specialFeatures == null)
            {
                return BadRequest("Error");
            }

            SpecialFeaturesResponseLite response = specialFeatures.ToSpecialFeaturesResponseLite();

            return Ok(response);
        }

        [HttpGet("specialFeatures")]
        public ActionResult GetLanguages()
        {
            IQueryable<SpecialFeatures> query = _specialFeaturesRepository.GetQuery();

            query = query.Where(rental => true);

            IEnumerable<SpecialFeatures> specialFeatures = _specialFeaturesRepository.GetByQuery(query);

            if (specialFeatures == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<SpecialFeaturesResponseLite> response = specialFeatures.Select(SpecialFeatures => SpecialFeatures.ToSpecialFeaturesResponseLite());

            return Ok(response);
        }

        [HttpPost("specialFeatures")]
        public async Task<IActionResult> CreateSpecialFeatures([FromBody]SpecialFeaturesCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            SpecialFeatures specialFeatures = request.ToSpecialFeaturesModel();

            await _specialFeaturesRepository.CreateAsync(specialFeatures);

            SpecialFeaturesResponseLite response = specialFeatures.ToSpecialFeaturesResponseLite();

            return Ok(response);
        }

        [HttpDelete("specialFeatures/{id}")]
        public async Task<IActionResult> DeleteSpecialFeatures(string id)
        {
            SpecialFeatures specialFeatures = await _specialFeaturesRepository.GetAsync(id);

            if (specialFeatures == null)
            {
                return BadRequest("Error");
            }

            await _specialFeaturesRepository.DeleteAsync(id);

            return Ok();
        }
    }
}