﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Store;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class StoresController : Controller
    {
        private IStoreRepository _storeRepository;
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;
        private IStaffRepository _staffRepository;

        public StoresController(IStoreRepository storeRepository,
                                IAddressRepository addressRepository,
                                ICountryRepository countryRepository,
                                IStaffRepository staffRepository,
                                ICityRepository cityRepository)
        {
            _storeRepository = storeRepository;
            _staffRepository = staffRepository;
            _addressRepository = addressRepository;
            _countryRepository = countryRepository;
            _cityRepository = cityRepository;
        }

        [HttpGet("stores/{id:length(24)}", Name = "GetStore")]
        public async Task<IActionResult> GetStore(string id)
        {
            Store store = await _storeRepository.GetAsync(id);

            if (store == null)
            {
                return BadRequest("Error");
            }

            Address address = await _addressRepository.GetAsync(store.AddressId);
            City city = await _cityRepository.GetAsync(address.CityId);
            Country country = await _countryRepository.GetAsync(city.CountryId);
            Staff staff = await _staffRepository.GetAsync(id, store.ManagerStaffId);
            StoreResponse response = store.ToStoreResponse(address, city, country, staff);

            return Ok(response);
        }

        [HttpGet("stores")]
        public async Task<IActionResult> GetStoress(string id)
        {
            IEnumerable<Store> stores = await _storeRepository.GetListAsync();

            if (stores == null)
            {
                return BadRequest("Error");
            }

            List<StoreResponse> response = new List<StoreResponse>();

            foreach (Store store in stores)
            {
                Address address = await _addressRepository.GetAsync(store.AddressId);
                City city = await _cityRepository.GetAsync(address.CityId);
                Country country = await _countryRepository.GetAsync(city.CountryId);
                Staff staff = await _staffRepository.GetAsync(id, store.ManagerStaffId);

                response.Add(store.ToStoreResponse(address, city, country, staff));
            }

            return Ok(response);
        }

        [HttpPost("stores")]
        public async Task<IActionResult> CreateCustomer([FromBody]StoreCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Store store = request.ToStoreModel();

            await _storeRepository.CreateAsync(store);

            StoreResponseLite response = store.ToStoreResponseLite();

            return Ok(response);
        }

        [HttpPut("stores/{storeId:length(24)}")]
        public async Task<IActionResult> UpdateCustomer([FromBody]StoreUpdateRequest request, string storeId, string customerId)
        {
            Store store = await _storeRepository.GetAsync(storeId);

            if (store == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            store = request.ToStoreModel(store);

            await _storeRepository.UpdateAsync(customerId, store);

            StoreResponseLite response = store.ToStoreResponseLite();

            return Ok(response);
        }

        [HttpDelete("stores/{id:length(24)}")]
        public async Task<IActionResult> DeleteCustomer(string id)
        {
            Store customer = await _storeRepository.GetAsync(id);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            await _storeRepository.DeleteAsync(id);

            return Ok();
        }
    }
}