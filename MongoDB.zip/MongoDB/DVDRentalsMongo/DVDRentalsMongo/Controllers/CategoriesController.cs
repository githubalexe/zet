﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Category;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class CategoriesController : Controller
    {
        private ICategoryRepository _categoryRepository;

        public CategoriesController(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        [HttpGet("categories/{id}", Name = "GetCategory")]
        public async Task<IActionResult> GetCategory(string id)
        {
            Category category = await _categoryRepository.GetAsync(id);

            if (category == null)
            {
                return BadRequest("Error");
            }

            CategoryResponseLite response = category.ToCategoryResponseLite();

            return Ok(response);
        }

        [HttpGet("categories")]
        public async Task<IActionResult> GetCategories()
        {
            IEnumerable<Category> categories = await _categoryRepository.GetListAsync();

            if (categories == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<CategoryResponseLite> response = categories.Select(category => category.ToCategoryResponseLite());

            return Ok(response);
        }

        [HttpPost("categories")]
        public async Task<IActionResult> CreateCategory([FromBody]CategoryCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Category category = request.ToCategoryModel();

            await _categoryRepository.CreateAsync(category);

            CategoryResponseLite response = category.ToCategoryResponseLite();

            return Ok(response);
        }

        [HttpPut("categories/{id}")]
        public async Task<IActionResult> UpdateCategory([FromBody]CategoryUpdateRequest request, string id)
        {
            Category category = await _categoryRepository.GetAsync(id);

            if (category == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            category = request.ToCategoryModel(category);

            await _categoryRepository.UpdateAsync(id, category);

            CategoryResponseLite response = category.ToCategoryResponseLite();

            return Ok(response);
        }

        [HttpDelete("categories/{id}")]
        public async Task<IActionResult> DeleteCategory(string id)
        {
            Category category = await _categoryRepository.GetAsync(id);

            if (category == null)
            {
                return BadRequest("Error");
            }

            await _categoryRepository.DeleteAsync(id);

            return Ok();
        }
    }
}