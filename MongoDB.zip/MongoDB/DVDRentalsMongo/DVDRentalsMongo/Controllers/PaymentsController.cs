﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Payment;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class PaymentsController : Controller
    {
        private IPaymentRepository _paymentRepository;
        public PaymentsController(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        [HttpGet("payments/{id}", Name = "GetPayment")]
        public async Task<IActionResult> GetPayment(string id)
        {
            Payment payment = await _paymentRepository.GetAsync(id);

            if (payment == null)
            {
                return BadRequest("Error");
            }

            PaymentResponseLite response = payment.ToPaymentResponseLite();

            return Ok(response);
        }

        [HttpGet("rentals/{id}/payments")]
        public async Task<IActionResult> GetPayments(string id)
        {
            IEnumerable<Payment> payments = await _paymentRepository.GetListAsync(id);

            if (payments == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<PaymentResponseLite> response = payments.Select(payment => payment.ToPaymentResponseLite());

            return Ok(response);
        }

        [HttpPost("payments")]
        public async Task<IActionResult> CreatePayment([FromBody]PaymentCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Payment payment = request.ToPaymentModel();

            await _paymentRepository.CreateAsync(payment);

            PaymentResponseLite response = payment.ToPaymentResponseLite();

            return Ok(response);
        }

        [HttpPut("payments/{id}")]
        public async Task<IActionResult> UpdateActor([FromBody]PaymentUpdateRequest request, string id)
        {
            Payment payment = await _paymentRepository.GetAsync(id);

            if (payment == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            payment = request.ToPaymentModel(payment);

            await _paymentRepository.UpdateAsync(id, payment);

            PaymentResponseLite response = payment.ToPaymentResponseLite();

            return Ok(response);
        }

        [HttpDelete("payments/{id}")]
        public async Task<IActionResult> DeleteActor(string id)
        {
            Payment payment = await _paymentRepository.GetAsync(id);

            if (payment == null)
            {
                return BadRequest("Error");
            }

            await _paymentRepository.DeleteAsync(id);

            return Ok();
        }
    }
}