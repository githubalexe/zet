﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Staff;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using DVDRentalsMongo.Services.RentalService;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffRepository _staffRepository;
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;
        private IRentalService _rentalServices;
        public StaffsController(IStaffRepository staffRepository,
                                IAddressRepository addressRepository,
                                ICountryRepository countryRepository,
                                IRentalService rentalServices,
                                ICityRepository cityRepository)
        {
            _staffRepository = staffRepository;
            _addressRepository = addressRepository;
            _countryRepository = countryRepository;
            _cityRepository = cityRepository;
            _rentalServices = rentalServices;
        }

        [HttpGet("stores/{storeId:length(24)}/staffs/{staffId:length(24)}", Name = "GetStaff")]
        public async Task<IActionResult> GetStaff(string storeId, string staffId)
        {
            Staff staff = await _staffRepository.GetAsync(storeId, staffId);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            Address address = await _addressRepository.GetAsync(staff.AddressId);
            City city = await _cityRepository.GetAsync(address.CityId);
            Country country = await _countryRepository.GetAsync(city.CountryId);

            StaffResponse response = staff.ToStaffResponse(address, city, country);

            return Ok(response);
        }

        [HttpGet("stores/{id:length(24)}/staffs")]
        public async Task<IActionResult> GetStaffs(string id)
        {
            IEnumerable<Staff> staffs = await _staffRepository.GetListAsync(id);

            if (staffs == null)
            {
                return BadRequest("Error");
            }

            List<StaffResponse> response = new List<StaffResponse>();

            foreach (Staff staff in staffs)
            {
                Address address = await _addressRepository.GetAsync(staff.AddressId);
                City city = await _cityRepository.GetAsync(address.CityId);
                Country country = await _countryRepository.GetAsync(city.CountryId);

                response.Add(staff.ToStaffResponse(address, city, country));
            }

            return Ok(response);
        }

        [HttpPost("stores/{id:length(24)}/staffs")]
        public async Task<IActionResult> CreateStaff([FromBody]StaffCreateRequest request, string id)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Staff staff = request.ToStaffModel(id);

            await _staffRepository.CreateAsync(staff);

            StaffResponseLite response = staff.ToStaffResponseLite();

            return Ok(response);
        }

        [HttpPut("stores/{storeId:length(24)}/staffs/{staffId:length(24)}")]
        public async Task<IActionResult> UpdateStaff([FromBody]StaffUpdateRequest request, string storeId, string staffId)
        {
            Staff staff = await _staffRepository.GetAsync(storeId, staffId);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            staff = request.ToStaffModel(staff, storeId);

            await _staffRepository.UpdateAsync(staffId, staff);

            StaffResponseLite response = staff.ToStaffResponseLite();

            return Ok(response);
        }

        [HttpDelete("stores/{storeId:length(24)}/staffs/{staffId:length(24)}")]
        public async Task<IActionResult> DeleteCustomer(string storeId, string staffId)
        {
            Staff staff = await _staffRepository.GetAsync(storeId, staffId);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            await _staffRepository.DeleteAsync(staffId);
            await _rentalServices.DeleteStaffsRentalsAsync(staffId);

            return Ok();
        }

    }
}