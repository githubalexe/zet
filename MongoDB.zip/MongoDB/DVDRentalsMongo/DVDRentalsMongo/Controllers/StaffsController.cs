﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Staff;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using DVDRentalsMongo.Services.AddressService;
using DVDRentalsMongo.Services.RentalService;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class StaffsController : Controller
    {
        private IStaffRepository _staffRepository;
        private IAddressRepository _addressRepository;
        private ICityRepository _cityRepository;
        private IStoreRepository _storeRepository;
        private ICountryRepository _countryRepository;
        private IRentalService _rentalServices;
        private IAddressService _addressService;

        public StaffsController(IStaffRepository staffRepository,
                                IAddressRepository addressRepository,
                                ICountryRepository countryRepository,
                                IRentalService rentalServices,
                                ICityRepository cityRepository,
                                IAddressService addressService,
                                IStoreRepository storeRepository)
        {
            _staffRepository = staffRepository;
            _addressRepository = addressRepository;
            _countryRepository = countryRepository;
            _storeRepository = storeRepository;
            _cityRepository = cityRepository;
            _rentalServices = rentalServices;
            _addressService = addressService;
        }

        [HttpGet("stores/{storeId}/staffs/{staffId}", Name = "GetStaff")]
        public async Task<IActionResult> GetStaff(string storeId, string staffId)
        {
            Staff staff = await _staffRepository.GetAsync(storeId, staffId);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            Address address = await _addressRepository.GetAsync(staff.AddressId);
            City city = await _cityRepository.GetAsync(address.CityId);
            Country country = await _countryRepository.GetAsync(city.CountryId);

            StaffResponse response = staff.ToStaffResponse(address, city, country);

            return Ok(response);
        }

        [HttpGet("stores/{id}/staffs")]
        public async Task<IActionResult> GetStaffs(string id)
        {
            IEnumerable<Staff> staffs = await _staffRepository.GetListAsync(id);

            if (staffs == null)
            {
                return BadRequest("Error");
            }

            List<StaffResponse> response = new List<StaffResponse>();

            foreach (Staff staff in staffs)
            {
                Address address = await _addressRepository.GetAsync(staff.AddressId);
                City city = await _cityRepository.GetAsync(address.CityId);
                Country country = await _countryRepository.GetAsync(city.CountryId);

                response.Add(staff.ToStaffResponse(address, city, country));
            }

            return Ok(response);
        }

        [HttpPost("stores/{id}/staffs")]
        public async Task<IActionResult> CreateStaff([FromBody]StaffCreateRequest request, string id)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Staff staff = request.ToStaffModel(id);

            await _staffRepository.CreateAsync(staff);

            StaffResponseLite response = staff.ToStaffResponseLite();

            return Ok(response);
        }

        [HttpPut("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> UpdateStaff([FromBody]StaffUpdateRequest request, string storeId, string staffId)
        {
            Staff staff = await _staffRepository.GetAsync(storeId, staffId);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            staff = request.ToStaffModel(staff, storeId);

            await _staffRepository.UpdateAsync(staffId, staff);

            StaffResponseLite response = staff.ToStaffResponseLite();

            return Ok(response);
        }

        [HttpDelete("stores/{storeId}/staffs/{staffId}")]
        public async Task<IActionResult> DeleteStaffs(string storeId, string staffId)
        {
            Staff staff = await _staffRepository.GetAsync(storeId, staffId);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            Store store = await _storeRepository.GetAsync(storeId);

            if (store.ManagerStaffId != staffId)
            {
                await _addressService.DeleteAddressAsync(staff.AddressId);
                await _staffRepository.DeleteAsync(staffId);
                await _rentalServices.DeleteStaffsRentalsAsync(staffId);
            }

            return Ok();
        }

    }
}