﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Response.Inventory;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class InventoriesController : Controller
    {
        private IInventoryRepository _inventoryRepository;
        private IFilmRepository _filmRepository;
        private IRatingRepository _ratingRepository;

        public InventoriesController(IInventoryRepository inventoryRepository,
                                     IFilmRepository filmRepository,
                                     IRatingRepository ratingRepository)
        {
            _inventoryRepository = inventoryRepository;
            _filmRepository = filmRepository;
            _ratingRepository = ratingRepository;
        }

        [HttpGet("stores/{storeId}/inventories/{filmId}")]
        public async Task<IActionResult> GetFilmInventory(string storeId, string filmId)
        {
            IEnumerable<Inventory> filmInventories = await _inventoryRepository.GetFilmInventoriesListAsync(storeId, filmId);

            if (filmInventories == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<InventoryResponseLite> response = filmInventories.Select(inventory => inventory.ToInventoryResponseLite());

            return Ok(response);
        }

        [HttpGet("stores/{id}/inventories")]
        public async Task<IActionResult> GetInventories(string id)
        {
            IEnumerable<Inventory> inventories = await _inventoryRepository.GetListAsync(id);

            if (inventories == null)
            {
                return BadRequest("Error");
            }

            List<InventoryResponse> response = new List<InventoryResponse>();

            foreach (Inventory inventory in inventories)
            {
                Film film = await _filmRepository.GetAsync(inventory.FilmId);
                Rating rating = await _ratingRepository.GetAsync(film.RatingId);

                response.Add(inventory.ToInventoryResponse(film, rating.Name));
            }

            return Ok(response);
        }

        [HttpPost("stores/{id}/inventories")]
        public async Task<IActionResult> CreateActor([FromBody]InventoryCreateRequest request, string id)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Inventory inventory = request.ToInventoryModel(id);

            await _inventoryRepository.CreateAsync(inventory);

            InventoryResponseLite response = inventory.ToInventoryResponseLite();

            return Ok(response);
        }

        [HttpDelete("inventories/{id}")]
        public async Task<IActionResult> DeleteInventory(string id)
        {
            Inventory actor = await _inventoryRepository.GetAsync(id);

            if (actor == null)
            {
                return BadRequest("Error");
            }

            await _inventoryRepository.DeleteAsync(id);

            return Ok();
        }
    }
}