﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Language;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class LanguagesController : Controller
    {

        private ILanguageRepository _languageRepository;

        public LanguagesController(ILanguageRepository languageRepository)
        {
            _languageRepository = languageRepository;
        }

        [HttpGet("languages/{id:length(24)}", Name = "GetLanguage")]
        public async Task<IActionResult> GetLanguage(string id)
        {
            Language language = await _languageRepository.GetAsync(id);

            if (language == null)
            {
                return BadRequest("Error");
            }

            LanguageResponseLite response = language.ToLanguageResponseLite();

            return Ok(response);
        }

        [HttpGet("languages")]
        public async Task<IActionResult> GetLanguages()
        {
            IEnumerable<Language> languages = await _languageRepository.GetListAsync();

            if (languages == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<LanguageResponseLite> response = languages.Select(language => language.ToLanguageResponseLite());

            return Ok(response);
        }

        [HttpPost("languages")]
        public async Task<IActionResult> CreateLanguage([FromBody]LanguageCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Language language = request.ToLanguageModel();

            await _languageRepository.CreateAsync(language);

            LanguageResponseLite response = language.ToLanguageResponseLite();

            return Ok(response);
        }

        [HttpPut("languages/{id:length(24)}")]
        public async Task<IActionResult> UpdateLanguage([FromBody]LanguageUpdateRequest request, string id)
        {
            Language language = await _languageRepository.GetAsync(id);

            if (language == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            language = request.ToLanguageModel(language);

            await _languageRepository.UpdateAsync(id, language);

            LanguageResponseLite response = language.ToLanguageResponseLite();

            return Ok(response);
        }

        [HttpDelete("languages/{id:length(24)}")]
        public async Task<IActionResult> DeleteLanguage(string id)
        {
            Language language = await _languageRepository.GetAsync(id);

            if (language == null)
            {
                return BadRequest("Error");
            }

            await _languageRepository.DeleteAsync(id);

            return Ok();
        }
    }
}