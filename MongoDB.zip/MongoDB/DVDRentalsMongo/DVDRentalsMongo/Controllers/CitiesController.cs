﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.City;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class CitiesController : Controller
    {
        private ICityRepository _cityRepository;
        private ICountryRepository _countryRepository;

        public CitiesController(ICityRepository cityRepository, 
                              ICountryRepository countryRepository)
        {
            _cityRepository = cityRepository;
            _countryRepository = countryRepository;
        }

        [HttpGet("cities/{id}", Name = "GetCity")]
        public async Task<IActionResult> GetCity(string id)
        {
            City city = await _cityRepository.GetAsync(id);

            if (city == null)
            {
                return BadRequest("Error");
            }

            Country country = await _countryRepository.GetAsync(city.CountryId);
            CityResponse response = city.ToCityResponse(country);

            return Ok(response);
        }

        [HttpGet("cities")]
        public async Task<IActionResult> GetCities()
        {
            IEnumerable<City> cities = await _cityRepository.GetListAsync();

            if (cities == null)
            {
                return BadRequest("Error");
            }

            List<CityResponse> response = new List<CityResponse>();

            foreach (var city in cities)
            {
                Country country = await _countryRepository.GetAsync(city.CountryId);
                response.Add(city.ToCityResponse(country));
            }

            return Ok(response);
        }

        [HttpGet("countries/{id}/cities")]
        public async Task<IActionResult> GetCitiesByCountry(string id)
        {
            {
                IEnumerable<City> cities = await _cityRepository.GetListAsync(id);

                if (cities == null)
                {
                    return BadRequest("Error");
                }

                List<CityResponse> response = new List<CityResponse>();

                foreach (var city in cities)
                {
                    Country country = await _countryRepository.GetAsync(city.CountryId);
                    response.Add(city.ToCityResponse(country));
                }

                return Ok(response);
            }
        }

        [HttpPost("cities")]
        public async Task<IActionResult> CreateCity([FromBody]CityCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            City city = request.ToCityModel();

            await _cityRepository.CreateAsync(city);

            CityResponseLite response = city.ToCityResponseLite();

            return Ok(response);
        }

        [HttpPut("cities/{id}")]
        public async Task<IActionResult> UpdateCity([FromBody]CityUpdateRequest request, string id)
        {
            City city = await _cityRepository.GetAsync(id);

            if (city == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            city = request.ToCityModel(city);

            await _cityRepository.UpdateAsync(id, city);

            CityResponseLite response = city.ToCityResponseLite();

            return Ok(response);
        }

        [HttpDelete("cities/{id}")]
        public async Task<IActionResult> DeleteCity(string id)
        {
            City city = await _cityRepository.GetAsync(id);

            if (city == null)
            {
                return BadRequest("Error");
            }

            await _cityRepository.DeleteAsync(id);

            return Ok();
        }
    }
}