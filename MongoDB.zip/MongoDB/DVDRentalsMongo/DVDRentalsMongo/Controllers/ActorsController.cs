﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.Request.CreateRequest;
using DVDRentalsMongo.API.Request.UpdateRequest;
using DVDRentalsMongo.API.Response.Actor;
using DVDRentalsMongo.Domain;
using DVDRentalsMongo.ExtensionMethods;
using DVDRentalsMongo.Repository;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentalsMongo.Controllers
{
    public class ActorsController : Controller
    {
        private IActorRepository _actorRepository;
        public ActorsController(IActorRepository actorRepository)
        {
            _actorRepository = actorRepository;
        }

        [HttpGet("actors/{id}", Name = "GetActor")]
        public async Task<IActionResult> GetActor(string id)
        {
            Actor actor = await _actorRepository.GetAsync(id);

            if (actor == null)
            {
                return BadRequest("Error");
            }

            ActorResponse response = actor.ToActorResponse();

            return Ok(response);
        }

        [HttpGet("actors")]
        public IActionResult GetActors()
        {
            IQueryable<Actor> query = _actorRepository.GetQuery();

            query = query.Where(actor => true);

            IEnumerable<Actor> actors = _actorRepository.GetByQuery(query);

            if (actors == null)
            {
                return BadRequest("Error");
            }

            IEnumerable<ActorResponse> response = actors.Select(actor => actor.ToActorResponse());

            return Ok(response);
        }

        [HttpPost("actors")]
        public async Task<IActionResult> CreateActor([FromBody]ActorCreateRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request null");
            }

            Actor actor = request.ToActorModel();

            await _actorRepository.CreateAsync(actor);

            ActorResponseLite response = actor.ToActorResponseLite();

            return Ok(response);
        }

        [HttpPut("actors/{id}")]
        public async Task<IActionResult> UpdateActor([FromBody]ActorUpdateRequest request, string id)
        {
            Actor actor = await _actorRepository.GetAsync(id);

            if (actor == null)
            {
                return BadRequest("Error");
            }

            if (request == null)
            {
                return BadRequest("Request null");
            }

            actor = request.ToActorModel(actor);

            await _actorRepository.UpdateAsync(id, actor);

            ActorResponseLite response = actor.ToActorResponseLite();

            return Ok(response);
        }

        [HttpDelete("actors/{id}")]
        public async Task<IActionResult> DeleteActor(string id)
        {
            Actor actor = await _actorRepository.GetAsync(id);

            if (actor == null)
            {
                return BadRequest("Error");
            }

            await _actorRepository.DeleteAsync(id);

            return Ok();
        }
    }
}