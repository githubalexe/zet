﻿using DVDRentalsMongo.Domain;
using DVDRentalsMongo.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Services.FilmService
{
    public class FilmService : IFilmService
    {
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmActorRepository _filmActorRepository;
        private IInventoryRepository _inventoryRepository;

        public FilmService(IFilmCategoryRepository filmCategoryRepository,
                           IFilmActorRepository filmActorRepository,
                           IInventoryRepository inventoryRepository)
        {
            _filmCategoryRepository = filmCategoryRepository;
            _filmActorRepository = filmActorRepository;
            _inventoryRepository = inventoryRepository;
        }

        public async Task DeleteFilmActorAsync(string id)
        {
            FilmActor filmActor = await _filmActorRepository.GetFilmAsync(id);

            if (filmActor != null)
            {
                await _filmActorRepository.DeleteAsync(filmActor.Id);
            }

        }

        public async Task DeleteFilmXActorAsync(string id)
        {
            FilmActor filmActor = await _filmActorRepository.GetAsync(id);

            await _filmActorRepository.DeleteAsync(filmActor.Id);
        }

        public async Task DeleteFilmCategoryAsync(string id)
        {
            await _filmCategoryRepository.DeleteAsync(id);
        }

        public async Task DeleteFilmInventoriesAsync(string storeId, string filmId)
        {
            IEnumerable<Inventory> inventories = await _inventoryRepository.GetFilmInventoriesListAsync(storeId, filmId);

            foreach (Inventory inventory in inventories)
            {
                await _inventoryRepository.DeleteAsync(inventory.Id);
            }
        }
    }
}
