﻿using DVDRentalsMongo.Domain;
using DVDRentalsMongo.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Services.FilmService
{
    public class FilmService : IFilmService
    {
        private IFilmCategoryRepository _filmCategoryRepository;
        private IFilmActorRepository _filmActorRepository;
        private IInventoryRepository _inventoryRepository;

        public FilmService(IFilmCategoryRepository filmCategoryRepository,
                           IFilmActorRepository filmActorRepository,
                           IInventoryRepository inventoryRepository)
        {
            _filmCategoryRepository = filmCategoryRepository;
            _filmActorRepository = filmActorRepository;
            _inventoryRepository = inventoryRepository;
        }

        public async Task DeleteFilmActorAsync(string id)
        {
            IQueryable<FilmActor> query = _filmActorRepository.GetQuery();

            query = query.Where(f => f.FilmId == id);

            IEnumerable<FilmActor> actors = _filmActorRepository.GetByQuery(query);

            foreach (FilmActor item in actors)
            {
                await _filmActorRepository.DeleteAsync(item.Id);
            }
        }

        public async Task DeleteFilmXActorAsync(string id)
        {
            FilmActor filmActor = await _filmActorRepository.GetAsync(id);

            await _filmActorRepository.DeleteAsync(filmActor.Id);
        }

        public async Task DeleteFilmCategoryAsync(string id)
        {
            FilmCategory filmCategory = await _filmCategoryRepository.GetAsync(id);
            await _filmCategoryRepository.DeleteAsync(filmCategory.Id);
        }

        public async Task DeleteFilmInventoriesAsync(string storeId, string filmId)
        {
            IEnumerable<Inventory> inventories = await _inventoryRepository.GetFilmInventoriesListAsync(storeId, filmId);

            foreach (Inventory inventory in inventories)
            {
                await _inventoryRepository.DeleteAsync(inventory.Id);
            }
        }
    }
}
