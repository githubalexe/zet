﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Services.FilmService
{
    public interface IFilmService
    {
        Task DeleteFilmCategoryAsync(string id);
        Task DeleteFilmActorAsync(string id);
        Task DeleteFilmXActorAsync(string id);
        Task DeleteFilmInventoriesAsync(string storeId, string filmId);
    }
}
