﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Services.RentalService
{
    public interface IRentalService
    {
        Task DeleteCustomerRentalsAsync(string id);
        Task DeleteStaffsRentalsAsync(string id);
    }
}
