﻿using DVDRentalsMongo.Domain;
using DVDRentalsMongo.Repository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Services.RentalService
{
    public class RentalService : IRentalService
    {
        private IRentalRepository _rentalRepository;
        private ICustomerRepository _customerRepository;
        private IStaffRepository _staffRepository;

        public RentalService(IRentalRepository rentalRepository,
                             ICustomerRepository customerRepository,
                             IStaffRepository staffRepository)
        {
            _rentalRepository = rentalRepository;
            _customerRepository = customerRepository;
            _staffRepository = staffRepository;
        }

        public async Task DeleteCustomerRentalsAsync(string id)
        {
            Customer customer = await _customerRepository.GetAsync(id);
            IQueryable<Rental> query = _rentalRepository.GetQuery();

            query = query.Where(p => p.CustomerId == id);

            IEnumerable<Rental> rentals = _rentalRepository.GetByQuery(query);

            foreach (Rental rental in rentals)
            {
                await _rentalRepository.DeleteAsync(rental.Id);
            }
        }

        public async Task DeleteStaffsRentalsAsync(string id)
        {
            Staff staff = await _staffRepository.GetAsync(id);

            IQueryable<Rental> query = _rentalRepository.GetQuery();

            query = query.Where(p => p.StaffId == id);

            IEnumerable<Rental> rentals = _rentalRepository.GetByQuery(query);

            foreach (Rental rental in rentals)
            {
                await _rentalRepository.DeleteAsync(rental.Id);
            }
        }
    }
}
