﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Services.AddressService
{
    public interface IAddressService
    {
        Task DeleteAddressAsync(string Id);
    }
}
