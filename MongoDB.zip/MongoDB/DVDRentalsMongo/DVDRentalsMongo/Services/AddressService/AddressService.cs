﻿using DVDRentalsMongo.Repository;
using System.Threading.Tasks;

namespace DVDRentalsMongo.Services.AddressService
{
    public class AddressService : IAddressService
    {
        private IAddressRepository _addressRepository;
        public AddressService(IAddressRepository addressRepository)
        {
            _addressRepository = addressRepository;
        }

        public async Task DeleteAddressAsync(string Id)
        {
            await _addressRepository.DeleteAsync(Id);
        }
    }
}
