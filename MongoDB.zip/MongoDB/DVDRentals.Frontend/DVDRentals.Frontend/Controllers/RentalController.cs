﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.Response.Payment;
using DVDRentalsMongo.API.Response.Rental;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class RentalController : Controller
    {
        [HttpGet("Rental/RentalDetails/{rentalId:length(24)}")]
        public async Task<IActionResult> RentalDetails(string rentalId)
        {
            RentalResponse rental = await RentalApiMethods.GetRentalAsync(rentalId);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            RentalViewModel model = rental.ToRentalViewModel();

            return View(model);
        }

        public IActionResult CreateRental()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetRental(string rentalId)
        {
            RentalResponse rental = await RentalApiMethods.GetRentalAsync(rentalId);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            return Ok(rental);
        }

        [HttpGet]
        public async Task<IActionResult> GetInventoryRentals(string inventoryId)
        {
            IEnumerable<RentalResponseLite> apiResult = await RentalApiMethods.GetInventoryRentalsAsync(inventoryId);

            if (apiResult == null)
            {
                return BadRequest("Error");
            }

            return Json(apiResult);
        }

        [HttpGet("AddPayment/{rentalId:length(24)}")]
        public IActionResult AddPayment(string rentalId)
        {
            RentalPaymentsView model = new RentalPaymentsView();
            model.RentalId = rentalId;

            return View(model);
        }

        [HttpPost("AddPayment/{rentalId:length(24)}")]
        public async Task<IActionResult> AddPayment(RentalPaymentsView request, string rentalId)
        {
            RentalResponse rental = await RentalApiMethods.GetRentalAsync(rentalId);
            PaymentResponseLite payment = await PaymentApiMethods.AddPaymentAsync(request.ToPaymentFormRequest(rental));

            return new RedirectResult(Url.Action("RentalDetails/") + rental.Id + "#payments");
        }

        [HttpGet("UpdateRental/{rentalId:length(24)}")]
        public async Task<IActionResult> UpdateRental(string rentalId)
        {
            RentalResponse rental = await RentalApiMethods.GetRentalAsync(rentalId);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            RentalViewModel model = rental.ToRentalViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            List<RentalIndexViewModel> list = new List<RentalIndexViewModel>();

            IEnumerable<RentalResponse> apiResult = await RentalApiMethods.GetRentalsAsync(storeId);

            foreach (RentalResponse rental in apiResult)
            {
                list.Add(rental.ToRentalIndexViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost("Rental/RentalDetails/{rentalId:length(24)}")]
        public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request, string rentalId)
        {
            IEnumerable<PaymentResponseLite> apiResult = await RentalApiMethods.GetPaymentsAsync(rentalId);

            List<PaymentViewModel> list = new List<PaymentViewModel>();

            foreach (PaymentResponseLite payment in apiResult)
            {
                list.Add(payment.ToPaymentViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRental(RentalViewModel request)
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            RentalResponse rental = await RentalApiMethods.CreateRentalAsync(request.ToRentalFormRequest(), storeId);

            return RedirectToAction(nameof(RentalDetails), new { id = rental.Id });
        }

        [HttpPost("UpdateRental/{rentailId:length(24)}")]
        public async Task<IActionResult> UpdateRental(RentalViewModel request, string rentailId)
        {

            RentalResponse rental = await RentalApiMethods.UpdateRentalAsync(request.ToRentalFormRequest(), rentailId);

            return RedirectToAction(nameof(RentalDetails), new { rentalId = rental.Id });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> rentalsIds)
        {
            foreach (string rentalId in rentalsIds)
            {
                await RentalApiMethods.DeleteRental(rentalId);
            }

            return RedirectToAction(nameof(Index), new { storeId = "5cf642c0c47b6a3290adb056" });
        }

        [HttpPost]
        public async Task<IActionResult> DeletePayments(IEnumerable<string> paymentsIds)
        {
            foreach (string paymentId in paymentsIds)
            {
                await PaymentApiMethods.DeletePaymentAsync(paymentId);
            }

            return RedirectToAction(nameof(Index), new { storeId = "5cf642c0c47b6a3290adb056" });
        }
    }
}