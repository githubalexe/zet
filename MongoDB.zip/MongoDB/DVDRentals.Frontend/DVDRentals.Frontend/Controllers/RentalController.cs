﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Data;
using DVDRentalsMongo.API.Response.Payment;
using DVDRentalsMongo.API.Response.Rental;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class RentalController : Controller
    {
        private readonly IRentalApiMethods _rentalApiMethods;
        private readonly IPaymentApiMethods _paymentApiMethods;

        public RentalController(IRentalApiMethods rentalApiMethods, IPaymentApiMethods paymentApiMethods)
        {
            _rentalApiMethods = rentalApiMethods;
            _paymentApiMethods = paymentApiMethods;
        }

        [HttpGet("Rental/RentalDetails/{rentalId}")]
        public async Task<IActionResult> RentalDetails(string rentalId)
        {
            RentalResponse rental = await _rentalApiMethods.GetRentalAsync(rentalId);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            RentalViewModel model = rental.ToRentalViewModel();

            return View(model);
        }

        public IActionResult CreateRental()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetRental(string rentalId)
        {
            RentalResponse rental = await _rentalApiMethods.GetRentalAsync(rentalId);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            return Ok(rental);
        }

        [HttpGet]
        public async Task<IActionResult> GetInventoryRentals(string inventoryId)
        {
            IEnumerable<RentalResponseLite> apiResult = await _rentalApiMethods.GetInventoryRentalsAsync(inventoryId);

            if (apiResult == null)
            {
                return BadRequest("Error");
            }

            return Json(apiResult);
        }

        [HttpGet("AddPayment/{rentalId}")]
        public IActionResult AddPayment(string rentalId)
        {
            RentalPaymentsView model = new RentalPaymentsView();
            model.RentalId = rentalId;

            return View(model);
        }

        [HttpPost("AddPayment/{rentalId}")]
        public async Task<IActionResult> AddPayment(RentalPaymentsView request, string rentalId)
        {
            RentalResponse rental = await _rentalApiMethods.GetRentalAsync(rentalId);
            PaymentResponseLite payment = await _paymentApiMethods.AddPaymentAsync(request.ToPaymentFormRequest(rental));

            return new RedirectResult(Url.Action("RentalDetails/") + rental.Id + "#payments");
        }

        [HttpGet("UpdateRental/{rentalId}")]
        public async Task<IActionResult> UpdateRental(string rentalId)
        {
            RentalResponse rental = await _rentalApiMethods.GetRentalAsync(rentalId);

            if (rental == null)
            {
                return BadRequest("Error");
            }

            RentalViewModel model = rental.ToRentalViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            List<RentalIndexViewModel> list = new List<RentalIndexViewModel>();

            IEnumerable<RentalResponse> apiResult = await _rentalApiMethods.GetRentalsAsync(storeId);

            foreach (RentalResponse rental in apiResult)
            {
                list.Add(rental.ToRentalIndexViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost("Rental/RentalDetails/{rentalId}")]
        public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request, string rentalId)
        {
            IEnumerable<PaymentResponseLite> apiResult = await _rentalApiMethods.GetPaymentsAsync(rentalId);

            List<PaymentViewModel> list = new List<PaymentViewModel>();

            foreach (PaymentResponseLite payment in apiResult)
            {
                list.Add(payment.ToPaymentViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRental(RentalViewModel request)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            RentalResponse rental = await _rentalApiMethods.CreateRentalAsync(request.ToRentalFormRequest(), storeId);

            return RedirectToAction(nameof(RentalDetails), new { id = rental.Id });
        }

        [HttpPost("UpdateRental/{rentailId}")]
        public async Task<IActionResult> UpdateRental(RentalViewModel request, string rentailId)
        {

            RentalResponse rental = await _rentalApiMethods.UpdateRentalAsync(request.ToRentalFormRequest(), rentailId);

            return RedirectToAction(nameof(RentalDetails), new { rentalId = rental.Id });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> rentalsIds)
        {
            string id = DVDRentalsStore.GetStoreId();
            foreach (string rentalId in rentalsIds)
            {
                await _rentalApiMethods.DeleteRental(rentalId);
            }

            return RedirectToAction(nameof(Index), new { storeId = id });
        }

        [HttpPost]
        public async Task<IActionResult> DeletePayments(IEnumerable<string> paymentsIds)
        {
            string id = DVDRentalsStore.GetStoreId();
            foreach (string paymentId in paymentsIds)
            {
                await _paymentApiMethods.DeletePaymentAsync(paymentId);
            }

            return RedirectToAction(nameof(Index), new { storeId = id });
        }
    }
}