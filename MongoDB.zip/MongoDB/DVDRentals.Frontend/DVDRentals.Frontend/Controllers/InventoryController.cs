﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.Response.Inventory;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class InventoryController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddInventory()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetFilmInventories(string filmId)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            IEnumerable<InventoryResponse> apiResult = await InventoryApiMethods.GetFilmInventoriesAsync(storeId, filmId);

            return Ok(apiResult);
        }

        [HttpPost]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            List<InventoryViewModel> list = new List<InventoryViewModel>();

            IEnumerable<InventoryResponse> apiResult = await InventoryApiMethods.GetInventoriesAsync(storeId);

            foreach (InventoryResponse inventory in apiResult)
            {
                list.Add(inventory.ToInventoryViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> AddInventory(InventoryViewModel request)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            for (int i = 0; i < request.Copies; i++)
            {
                InventoryResponse inventory = await InventoryApiMethods.CreateInventoryAsync(request.ToInventoryFormRequest(), storeId);
            }

            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> inventoriesIds)
        {

            foreach (string inventoryId in inventoriesIds)
            {
                await InventoryApiMethods.DeleteInventoryAsync(inventoryId);
            }

            return RedirectToAction(nameof(Index));
        }
    }
}