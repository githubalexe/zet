﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Data;
using DVDRentalsMongo.API.Response.Inventory;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class InventoryController : Controller
    {
        private readonly IInventoryApiMethods _inventoryApiMethods;
        public InventoryController(IInventoryApiMethods inventoryApiMethods)
        {
            _inventoryApiMethods = inventoryApiMethods;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult AddInventory()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetFilmInventories(string filmId)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            IEnumerable<InventoryResponse> apiResult = await _inventoryApiMethods.GetFilmInventoriesAsync(storeId, filmId);

            return Ok(apiResult);
        }

        [HttpPost]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            List<InventoryViewModel> list = new List<InventoryViewModel>();

            IEnumerable<InventoryResponse> apiResult = await _inventoryApiMethods.GetInventoriesAsync(storeId);

            foreach (InventoryResponse inventory in apiResult)
            {
                list.Add(inventory.ToInventoryViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> AddInventory(InventoryViewModel request)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            for (int i = 0; i < request.Copies; i++)
            {
                InventoryResponse inventory = await _inventoryApiMethods.CreateInventoryAsync(request.ToInventoryFormRequest(), storeId);
            }

            return RedirectToAction(nameof(Index));
        }
        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> inventoriesIds)
        {

            foreach (string inventoryId in inventoriesIds)
            {
                await _inventoryApiMethods.DeleteInventoryAsync(inventoryId);
            }

            return RedirectToAction(nameof(Index));
        }
    }
}