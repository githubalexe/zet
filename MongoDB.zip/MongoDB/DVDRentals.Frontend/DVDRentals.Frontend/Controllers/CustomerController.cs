﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.API.Response.Rental;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class CustomerController : Controller
    {
        [HttpGet("Customer/CustomerDetails/{id:length(24)}")]
        public async Task<IActionResult> CustomerDetails(string id)
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            CustomerResponse customer = await CustomerApiMethods.GetCustomerAsync(storeId, id);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            CustomerViewModel model = customer.ToCustomerViewModel();

            return View(model);
        }

        public IActionResult CreateCustomer()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("UpdateCustomer/{id:length(24)}")]
        public async Task<IActionResult> UpdateCustomer(string id)
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            CustomerResponse customer = await CustomerApiMethods.GetCustomerAsync(storeId, id);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            CustomerViewModel model = customer.ToCustomerViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CustomersList([DataSourceRequest] DataSourceRequest request)
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            IEnumerable<CustomerResponse> apiResult = await CustomerApiMethods.GetCustomersAsync(storeId);
            List<CustomerIndexViewModel> list = new List<CustomerIndexViewModel>();

            foreach (CustomerResponse customer in apiResult)
            {
                list.Add(customer.ToCustomerIndexViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Ok(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetCustomers()
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            IEnumerable<CustomerResponse> apiResult = await CustomerApiMethods.GetCustomersAsync(storeId);

            return Ok(apiResult);
        }


        [HttpPost("Customer/CustomerDetails/{id:length(24)}")]
        public async Task<IActionResult> GetRentals([DataSourceRequest] DataSourceRequest request, string id)
        {

            List<CustomerRentalsViewModel> list = new List<CustomerRentalsViewModel>();

            IEnumerable<RentalResponse> apiResult = await CustomerApiMethods.GetCustomerRentalsAsync(id);

            foreach (RentalResponse rental in apiResult)
            {
                list.Add(rental.ToCustomerRentalsViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateCustomer(CustomerViewModel request)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            CustomerResponse customer = await CustomerApiMethods.CreateCustomerAsync(request.ToCustomerFormRequest(), storeId);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.Id });
        }

        [HttpPost("UpdateCustomer/{id:length(24)}")]
        public async Task<IActionResult> UpdateCustomer(CustomerViewModel request, string id)
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            CustomerResponse customer = await CustomerApiMethods.UpdateCustomerAsync(request.ToCustomerFormRequest(), storeId, id);

            return RedirectToAction(nameof(CustomerDetails));
        }

        [HttpPost]
        public async Task<IActionResult> UpdateCustomerStatus(bool isActive, string id)
        {
            string storeId = "5cf642c0c47b6a3290adb056";
            CustomerResponse customer = await CustomerApiMethods.UpdateCustomerStatus(isActive, storeId, id);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.Id });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> customersIds)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            foreach (string customerId in customersIds)
            {
                await CustomerApiMethods.DeleteCustomerAsync(storeId, customerId);
            }

            return RedirectToAction(nameof(Index), new { storeId = 1 });
        }
    }
}
