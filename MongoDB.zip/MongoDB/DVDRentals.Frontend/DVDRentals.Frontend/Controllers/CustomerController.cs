﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Data;
using DVDRentalsMongo.API.Response.Customer;
using DVDRentalsMongo.API.Response.Rental;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerApiMethods _customerApiMethods;
        public CustomerController(ICustomerApiMethods customerApiMethods)
        {
            _customerApiMethods = customerApiMethods;
        }

        [HttpGet("Customer/CustomerDetails/{id}")]
        public async Task<IActionResult> CustomerDetails(string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            CustomerResponse customer = await _customerApiMethods.GetCustomerAsync(storeId, id);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            CustomerViewModel model = customer.ToCustomerViewModel();

            return View(model);
        }

        public IActionResult CreateCustomer()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("UpdateCustomer/{id}")]
        public async Task<IActionResult> UpdateCustomer(string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            CustomerResponse customer = await _customerApiMethods.GetCustomerAsync(storeId, id);

            if (customer == null)
            {
                return BadRequest("Error");
            }

            CustomerViewModel model = customer.ToCustomerViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CustomersList([DataSourceRequest] DataSourceRequest request)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            IEnumerable<CustomerResponse> apiResult = await _customerApiMethods.GetCustomersAsync(storeId);
            List<CustomerIndexViewModel> list = new List<CustomerIndexViewModel>();

            foreach (CustomerResponse customer in apiResult)
            {
                list.Add(customer.ToCustomerIndexViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Ok(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetCustomers()
        {
            string storeId = DVDRentalsStore.GetStoreId();
            IEnumerable<CustomerResponse> apiResult = await _customerApiMethods.GetCustomersAsync(storeId);

            return Ok(apiResult);
        }


        [HttpPost("Customer/CustomerDetails/{id}")]
        public async Task<IActionResult> GetRentals([DataSourceRequest] DataSourceRequest request, string id)
        {

            List<CustomerRentalsViewModel> list = new List<CustomerRentalsViewModel>();

            IEnumerable<RentalResponse> apiResult = await _customerApiMethods.GetCustomerRentalsAsync(id);

            foreach (RentalResponse rental in apiResult)
            {
                list.Add(rental.ToCustomerRentalsViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateCustomer(CustomerViewModel request)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            CustomerResponse customer = await _customerApiMethods.CreateCustomerAsync(request.ToCustomerFormRequest(), storeId);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.Id });
        }

        [HttpPost("UpdateCustomer/{id}")]
        public async Task<IActionResult> UpdateCustomer(CustomerViewModel request, string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            CustomerResponse customer = await _customerApiMethods.UpdateCustomerAsync(request.ToCustomerFormRequest(), storeId, id);

            return RedirectToAction(nameof(CustomerDetails));
        }

        [HttpPost]
        public async Task<IActionResult> UpdateCustomerStatus(bool isActive, string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            CustomerResponse customer = await _customerApiMethods.UpdateCustomerStatus(isActive, storeId, id);

            return RedirectToAction(nameof(CustomerDetails), new { id = customer.Id });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> customersIds)
        {
            string id = DVDRentalsStore.GetStoreId();

            foreach (string customerId in customersIds)
            {
                await _customerApiMethods.DeleteCustomerAsync(id, customerId);
            }

            return RedirectToAction(nameof(Index), new { storeId = id });
        }
    }
}
