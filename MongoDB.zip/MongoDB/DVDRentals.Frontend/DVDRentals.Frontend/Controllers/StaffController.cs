﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.Services;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Data;
using DVDRentalsMongo.API.Response.Rental;
using DVDRentalsMongo.API.Response.Staff;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class StaffController : Controller
    {
        private readonly IStaffApiMethods _staffApiMethods;
        public StaffController(IStaffApiMethods staffApiMethods)
        {
            _staffApiMethods = staffApiMethods;
        }

        [HttpGet("Staff/StaffDetails/{id}")]
        public async Task<IActionResult> StaffDetails(string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            StaffResponse staff = await _staffApiMethods.GetStaffAsync(storeId, id);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            StaffViewModel model = staff.ToStaffViewModel();

            return View(model);
        }

        public IActionResult CreateStaff()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("UpdateStaff/{id}")]
        public async Task<IActionResult> UpdateStaff(string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            StaffResponse staff = await _staffApiMethods.GetStaffAsync(storeId, id);

            if (staff == null)
            {
                return BadRequest("Error");
            }

            StaffViewModel model = staff.ToStaffViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> StaffsList([DataSourceRequest] DataSourceRequest request)
        {
            string storeId = DVDRentalsStore.GetStoreId();
            List<StaffViewModel> list = new List<StaffViewModel>();

            IEnumerable<StaffResponse> apiResult = await _staffApiMethods.GetStaffsAsync(storeId);

            foreach (StaffResponse staff in apiResult)
            {

                list.Add(staff.ToStaffViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetStaffs()
        {
            string storeId = DVDRentalsStore.GetStoreId();

            IEnumerable<StaffResponse> apiResult = await _staffApiMethods.GetStaffsAsync(storeId);

            return Json(apiResult);
        }

        [HttpPost("Staff/StaffDetails/{id}")]
        public async Task<IActionResult> GetRentals([DataSourceRequest] DataSourceRequest request, string id)
        {

            List<StaffRentalsViewModel> list = new List<StaffRentalsViewModel>();

            IEnumerable<RentalResponse> apiResult = await _staffApiMethods.GetStaffRentalsAsync(id);

            foreach (RentalResponse rental in apiResult)
            {
                list.Add(rental.ToStaffRentalsViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateStaff(StaffViewModel request)
        {
            if (request.PictureFile != null)
            {
                using (var stream = new MemoryStream())
                {
                    await request.PictureFile.CopyToAsync(stream);
                    request.BinaryImage = stream.ToArray();
                }
            }

            if (request.PictureFile == null && request.Picture == null)
            {
                request.BinaryImage = Convert.FromBase64String(DefaultImage.GetDefaultImage());
            }

            string storeId = DVDRentalsStore.GetStoreId();
            StaffResponse staff = new StaffResponse();
            staff = await _staffApiMethods.CreateStaffAsync(request.ToStaffFormRequest(), storeId);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.Id });
        }

        [HttpPost("UpdateStaff/{id}")]
        public async Task<IActionResult> UpdateStaff(StaffViewModel request, string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            if (request.PictureFile != null)
            {
                using (var stream = new MemoryStream())
                {
                    await request.PictureFile.CopyToAsync(stream);
                    request.BinaryImage = stream.ToArray();
                }
            }

            if (request.PictureFile == null)
            {
                if (request.Picture == null)
                {
                    request.BinaryImage = Convert.FromBase64String(DefaultImage.GetDefaultImage());
                }
                else
                {
                    request.BinaryImage = Convert.FromBase64String(request.Picture);
                }

            }

            StaffResponse staff = new StaffResponse();
            staff = await _staffApiMethods.UpdateStaffAsync(request.ToStaffFormRequest(), storeId, id);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.Id });
        }

        [HttpPost]
        public async Task<IActionResult> UpdateStaffStatus(bool isActive, string id)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            StaffResponse staff = await _staffApiMethods.UpdateStaffStatusAsync(isActive, storeId, id);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.Id });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> staffsIds)
        {
            string id = DVDRentalsStore.GetStoreId();

            foreach (string staffId in staffsIds)
            {
                await _staffApiMethods.DeleteStaffAsync(id, staffId);
            }

            return RedirectToAction(nameof(Index), new { storeId = id });
        }
    }
}