﻿using DVDRentals.Frontend.User;
using DVDRentals.Frontend.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.ErrorMessage = StaffUser.ErrorMessage;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetStaff(LoginViewModel model)
        {
            //StaffResponse staff = await StoreApiMethods.GetStaff(model.ToStaffVerifyRequest());

            //ViewBag.ErrorMessage = "";


            ////return Ok();
            //if (staff != null)
            //{
            //    StaffUser.StaffId = staff.StaffId;
            //    StaffUser.StoreId = staff.StoreId;
            //    StaffUser.Picture = staff.Picture;
            //    StaffUser.Name = String.Format("{0} {1}", staff.FirstName,staff.LastName);
            //    return RedirectToAction("Index", "Customer");
            //}
            //else
            //{
            //    StaffUser.ErrorMessage = "Incorect username or password.";
            //    return RedirectToAction("Index", "Login");
            //}
            return Ok();
        }
    }
}