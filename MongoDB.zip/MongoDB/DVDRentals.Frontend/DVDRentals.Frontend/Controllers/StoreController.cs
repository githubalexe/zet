﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.Response.Store;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class StoreController : Controller
    {
        [HttpGet]
        public async Task<IActionResult> StoreDetails()
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            StoreResponse store = await StoreApiMethods.GetStoreAsync(storeId);

            if (store == null)
            {
                return BadRequest("Error");
            }

            StoreViewModel model = store.ToStoreViewModel();

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> UpdateStore()
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            StoreResponse store = await StoreApiMethods.GetStoreAsync(storeId);

            if (store == null)
            {
                return BadRequest("Error");
            }

            StoreViewModel model = store.ToStoreViewModel();

            return View(model);

        }

        [HttpPost]
        public async Task<IActionResult> UpdateStore(StoreViewModel request)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            StoreResponse store = await StoreApiMethods.UpdateStoreAsync(request.ToStoreFormRequest(), storeId);

            return RedirectToAction(nameof(StoreDetails), new { id = store.Id });
        }
    }
}