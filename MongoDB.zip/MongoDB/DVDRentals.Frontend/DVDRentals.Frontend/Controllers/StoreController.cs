﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Data;
using DVDRentalsMongo.API.Response.Store;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class StoreController : Controller
    {
        private readonly IStoreApiMethods _storeApiMethods;
        public StoreController(IStoreApiMethods storeApiMethods)
        {
            _storeApiMethods = storeApiMethods;
        }

        [HttpGet]
        public async Task<IActionResult> StoreDetails()
        {
            string storeId = DVDRentalsStore.GetStoreId();

            StoreResponse store = await _storeApiMethods.GetStoreAsync(storeId);

            if (store == null)
            {
                return BadRequest("Error");
            }

            StoreViewModel model = store.ToStoreViewModel();

            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> UpdateStore()
        {
            string storeId = DVDRentalsStore.GetStoreId();

            StoreResponse store = await _storeApiMethods.GetStoreAsync(storeId);

            if (store == null)
            {
                return BadRequest("Error");
            }

            StoreViewModel model = store.ToStoreViewModel();

            return View(model);

        }

        [HttpPost]
        public async Task<IActionResult> UpdateStore(StoreViewModel request)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            StoreResponse store = await _storeApiMethods.UpdateStoreAsync(request.ToStoreFormRequest(), storeId);

            return RedirectToAction(nameof(StoreDetails), new { id = store.Id });
        }
    }
}