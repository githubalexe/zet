﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.Response.City;
using DVDRentalsMongo.API.Response.Country;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DVDRentals.Frontend.Controllers
{
    public class CountryController : Controller
    {

        public async Task<IActionResult> GetCountries()
        {
            IEnumerable<CountryResponseLite> apiResult = await CountryApiMethods.GetCountriesAsync();

            return Json(apiResult);
        }

        public async Task<IActionResult> GetCity(string cityId)
        {
            CityResponseLite apiResult = await CountryApiMethods.GetCityAsync(cityId);

            return Json(apiResult);
        }

        [HttpGet]
        public async Task<IActionResult> GetCitiesByCountry(string countryId)
        {

            IEnumerable<CityResponse> apiResult = await CityApiMethods.GetCitiesByCountryAsync(countryId);


            return Json(apiResult);

        }
    }
}