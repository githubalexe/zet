﻿using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Response.City;
using DVDRentalsMongo.API.Response.Country;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class CountryController : Controller
    {
        private readonly ICountryApiMethods _countryApiMethods;
        private readonly ICityApiMethods _cityApiMethods;
        public CountryController(ICountryApiMethods countryApiMethods, ICityApiMethods cityApiMethods)
        {
            _countryApiMethods = countryApiMethods;
            _cityApiMethods = cityApiMethods;
        }

        [HttpGet]
        public async Task<IActionResult> GetCountries()
        {
            IEnumerable<CountryResponseLite> apiResult = await _countryApiMethods.GetCountriesAsync();

            return Ok(apiResult);
        }

        [HttpGet]
        public async Task<IActionResult> GetCity(string cityId)
        {
            CityResponseLite apiResult = await _countryApiMethods.GetCityAsync(cityId);

            return Ok(apiResult);
        }

        [HttpGet]
        public async Task<IActionResult> GetCitiesByCountry(string countryId)
        {

            IEnumerable<CityResponse> apiResult = await _cityApiMethods.GetCitiesByCountryAsync(countryId);


            return Ok(apiResult);

        }
    }
}