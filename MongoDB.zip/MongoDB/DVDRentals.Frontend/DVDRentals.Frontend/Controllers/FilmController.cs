﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.Data;
using DVDRentalsMongo.API.Response.Actor;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.FilmActor;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class FilmController : Controller
    {
        [HttpGet("Film/FilmDetails/{filmId:length(24)}")]
        public async Task<IActionResult> FilmDetails(string filmId)
        {
            FilmResponse film = await FilmApiMethods.GetFilmAsync(filmId);

            if (film == null)
            {
                return BadRequest("Error");
            }

            FilmViewModel model = film.ToFilmViewModel();

            return View(model);
        }

        public IActionResult CreateFilm()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("AddActor/{filmId:length(24)}")]
        public IActionResult AddActor(string filmId)
        {
            return View();
        }

        [HttpGet("UpdateFilm/{filmId:length(24)}")]
        public async Task<IActionResult> UpdateFilm(string filmId)
        {
            FilmResponse film = await FilmApiMethods.GetFilmAsync(filmId);

            if (film == null)
            {
                return BadRequest("Error");
            }

            FilmViewModel model = film.ToFilmViewModel();

            return View(model);
        }

        [HttpGet("Film/{filmId:length(24)}/UpdateActor/{actorId:length(24)}")]
        public async Task<IActionResult> UpdateActor(string actorId, string filmId)
        {
            ActorResponse actor = await ActorApiMethods.GetActorAsync(actorId);

            if (actor == null)
            {
                return BadRequest("Error");
            }

            ActorViewModel model = actor.ToActorViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> FilmsList([DataSourceRequest] DataSourceRequest request)
        {
            List<FilmViewModel> list = new List<FilmViewModel>();

            IEnumerable<FilmResponse> apiResult = await FilmApiMethods.GetFilmsAsync();

            foreach (FilmResponse film in apiResult)
            {
                list.Add(film.ToFilmViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetStoreFilms()
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            IEnumerable<FilmResponse> apiResult = await FilmApiMethods.GetStoreFilmsAsync(storeId);

            return Json(apiResult);
        }

        [HttpGet]
        public async Task<IActionResult> GetFilms()
        {
            IEnumerable<FilmResponse> apiResult = await FilmApiMethods.GetFilmsAsync();

            return Json(apiResult);
        }

        [HttpPost]
        public async Task<IActionResult> CreateFilm(FilmViewModel request)
        {
            FilmResponse film = await FilmApiMethods.CreateFilmAsync(request.ToFilmFormRequest());

            return RedirectToAction(nameof(FilmDetails), new { filmId = film.Id });
        }

        [HttpPost("UpdateFilm/{id:length(24)}")]
        public async Task<IActionResult> UpdateFilm(FilmViewModel request, string id)
        {
            FilmResponse film = await FilmApiMethods.UpdateFilm(request.ToFilmFormRequest(), id);

            return RedirectToAction(nameof(FilmDetails), new { filmId = film.Id });
        }


        [HttpPost("Film/{filmId}/UpdateActor/{actorId}")]
        public async Task<IActionResult> UpdateActor(ActorViewModel request, string actorId, string filmId)
        {
            ActorResponseLite actor = await ActorApiMethods.UpdateActorAsync(request.ToActorFormRequest(), actorId);

            return new RedirectResult(Url.Action("FilmDetails/") + filmId + "#actors");
        }

        [HttpPost("Actors/{filmId}")]
        public async Task<IActionResult> Actors([DataSourceRequest] DataSourceRequest request, string filmId)
        {
            List<ActorViewModel> list = new List<ActorViewModel>();
            FilmResponse film = await FilmApiMethods.GetFilmAsync(filmId);

            IEnumerable<ActorResponse> apiResult = await ActorApiMethods.GetActorsAsync(filmId);

            foreach (ActorResponse actor in apiResult)
            {
                list.Add(actor.ToActorViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }


        [HttpPost("AddActor/{filmId}")]
        public async Task<IActionResult> AddActor(ActorViewModel request, string filmId)
        {
            FilmActorResponseLite filmActor = await FilmApiMethods.AddActorAsync(request.ToActorFormRequest(), filmId);

            return new RedirectResult(Url.Action("FilmDetails/") + filmId + "#actors");
        }

        [HttpGet]
        public async Task<IActionResult> GetActors()
        {
            IEnumerable<ActorResponse> apiResult = await ActorApiMethods.GetActorsAsync();

            return Json(apiResult);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> filmsIds)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            foreach (string filmId in filmsIds)
            {
                await FilmApiMethods.DeleteFilmAsync(filmId);

            }

            return RedirectToAction(nameof(Index), new { id = storeId });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteActor(string filmId, IEnumerable<string> actorIds)
        {
            string storeId = "5cf642c0c47b6a3290adb056";

            foreach (string actorId in actorIds)
            {
                await ActorApiMethods.DeleteActorAsync(filmId, actorId);
            }

            return RedirectToAction(nameof(Index), new { id = storeId });
        }

        //FilmRating
        [HttpGet]
        public IActionResult GetFilmRating()
        {
            FilmRating rating = new FilmRating();
            List<FilmDictionary> response = new List<FilmDictionary>();

            int id = 1;

            foreach (var item in rating.RatingList.Values)
            {
                response.Add(new FilmDictionary
                {
                    Id = id,
                    Name = item
                });
                id++;
            }

            return Ok(response);
        }

        //FilmSpecialFeatures
        [HttpGet]
        public IActionResult GetFilmSpecialFeatures()
        {
            FilmSpecialFeatures rating = new FilmSpecialFeatures();
            List<FilmDictionary> response = new List<FilmDictionary>();

            int id = 1;

            foreach (var item in rating.SpecialFeaturesList.Values)
            {
                response.Add(new FilmDictionary
                {
                    Id = id,
                    Name = item
                });
                id++;
            }

            return Ok(response);
        }
    }
}