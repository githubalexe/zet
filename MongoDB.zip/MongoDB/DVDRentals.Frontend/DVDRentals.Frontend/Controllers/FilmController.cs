﻿using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Data;
using DVDRentalsMongo.API.Response.Actor;
using DVDRentalsMongo.API.Response.Film;
using DVDRentalsMongo.API.Response.FilmActor;
using DVDRentalsMongo.API.Response.Rating;
using DVDRentalsMongo.API.Response.SpecialFeatures;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class FilmController : Controller
    {
        private IFilmApiMethods _filmApiMethods;
        private IActorApiMethods _actorApiMethods;
        private IRatingApiMethods _ratingApiMethods;
        private ISpecialFeaturesApiMethods _specialFeaturesApiMethods;

        public FilmController(IFilmApiMethods filmApiMethods,
                              IActorApiMethods actorApiMethods,
                              IRatingApiMethods ratingApiMethods,
                              ISpecialFeaturesApiMethods specialFeaturesApiMethods)
        {
            _filmApiMethods = filmApiMethods;
            _actorApiMethods = actorApiMethods;
            _ratingApiMethods = ratingApiMethods;
            _specialFeaturesApiMethods = specialFeaturesApiMethods;
        }

        [HttpGet("Film/FilmDetails/{filmId}")]
        public async Task<IActionResult> FilmDetails(string filmId)
        {
            FilmResponse film = await _filmApiMethods.GetFilmAsync(filmId);

            if (film == null)
            {
                return BadRequest("Error");
            }

            FilmViewModel model = film.ToFilmViewModel();

            return View(model);
        }

        public IActionResult CreateFilm()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet("AddActor/{filmId}")]
        public IActionResult AddActor(string filmId)
        {
            return View();
        }

        [HttpGet("UpdateFilm/{filmId}")]
        public async Task<IActionResult> UpdateFilm(string filmId)
        {
            FilmResponse film = await _filmApiMethods.GetFilmAsync(filmId);

            if (film == null)
            {
                return BadRequest("Error");
            }

            FilmViewModel model = film.ToFilmViewModel();

            return View(model);
        }

        [HttpGet("Film/{filmId}/UpdateActor/{actorId}")]
        public async Task<IActionResult> UpdateActor(string actorId, string filmId)
        {
            ActorResponse actor = await _actorApiMethods.GetActorAsync(actorId);

            if (actor == null)
            {
                return BadRequest("Error");
            }

            ActorViewModel model = actor.ToActorViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> FilmsList([DataSourceRequest] DataSourceRequest request)
        {
            List<FilmViewModel> list = new List<FilmViewModel>();

            IEnumerable<FilmResponse> apiResult = await _filmApiMethods.GetFilmsAsync();

            foreach (FilmResponse film in apiResult)
            {
                list.Add(film.ToFilmViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetStoreFilms()
        {
            string storeId = DVDRentalsStore.GetStoreId();

            IEnumerable<FilmResponse> apiResult = await _filmApiMethods.GetStoreFilmsAsync(storeId);

            return Json(apiResult);
        }

        [HttpGet]
        public async Task<IActionResult> GetFilms()
        {
            IEnumerable<FilmResponse> apiResult = await _filmApiMethods.GetFilmsAsync();

            return Json(apiResult);
        }

        [HttpPost]
        public async Task<IActionResult> CreateFilm(FilmViewModel request)
        {
            FilmResponse film = await _filmApiMethods.CreateFilmAsync(request.ToFilmFormRequest());

            return RedirectToAction(nameof(FilmDetails), new { filmId = film.Id });
        }

        [HttpPost("UpdateFilm/{id}")]
        public async Task<IActionResult> UpdateFilm(FilmViewModel request, string id)
        {
            FilmResponse film = await _filmApiMethods.UpdateFilm(request.ToFilmFormRequest(), id);

            return RedirectToAction(nameof(FilmDetails), new { filmId = film.Id });
        }


        [HttpPost("Film/{filmId}/UpdateActor/{actorId}")]
        public async Task<IActionResult> UpdateActor(ActorViewModel request, string actorId, string filmId)
        {
            ActorResponseLite actor = await _actorApiMethods.UpdateActorAsync(request.ToActorFormRequest(), actorId);

            return new RedirectResult(Url.Action("FilmDetails/") + filmId + "#actors");
        }

        [HttpPost("Actors/{filmId}")]
        public async Task<IActionResult> Actors([DataSourceRequest] DataSourceRequest request, string filmId)
        {
            List<ActorViewModel> list = new List<ActorViewModel>();
            FilmResponse film = await _filmApiMethods.GetFilmAsync(filmId);

            IEnumerable<ActorResponse> apiResult = await _actorApiMethods.GetActorsAsync(filmId);

            foreach (ActorResponse actor in apiResult)
            {
                list.Add(actor.ToActorViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }


        [HttpPost("AddActor/{filmId}")]
        public async Task<IActionResult> AddActor(ActorViewModel request, string filmId)
        {
            FilmActorResponseLite filmActor = await _filmApiMethods.AddActorAsync(request.ToActorFormRequest(), filmId);

            return new RedirectResult(Url.Action("FilmDetails/") + filmId + "#actors");
        }

        [HttpGet]
        public async Task<IActionResult> GetActors()
        {
            IEnumerable<ActorResponse> apiResult = await _actorApiMethods.GetActorsAsync();

            return Json(apiResult);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<string> filmsIds)
        {
            string storeId = DVDRentalsStore.GetStoreId(); ;

            foreach (string filmId in filmsIds)
            {
                await _filmApiMethods.DeleteFilmAsync(filmId);
            }

            return RedirectToAction(nameof(Index), new { id = storeId });
        }

        [HttpPost]
        public async Task<IActionResult> DeleteActor(string filmId, IEnumerable<string> actorIds)
        {
            string storeId = DVDRentalsStore.GetStoreId();

            foreach (string actorId in actorIds)
            {
                await _actorApiMethods.DeleteActorAsync(filmId, actorId);
            }

            return RedirectToAction(nameof(Index), new { id = storeId });
        }

        //FilmRating
        [HttpGet]
        public async Task<IActionResult> GetFilmRating()
        {
            IEnumerable<RatingResponseLite> response = await _ratingApiMethods.GetRatings();

            return Ok(response);
        }

        //FilmSpecialFeatures
        [HttpGet]
        public async Task<IActionResult> GetFilmSpecialFeatures()
        {
            IEnumerable<SpecialFeaturesResponseLite> response = await _specialFeaturesApiMethods.GetSpecialFeatures();

            return Ok(response);
        }
    }
}