﻿using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.Response.Language;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class LanguageController : Controller
    {
        public async Task<IActionResult> GetLanguages()
        {
            IEnumerable<LanguageResponseLite> apiResult = await LanguageApiMethods.GetLanguagesAsync();

            return Json(apiResult);
        }

    }
}