﻿using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Response.Language;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class LanguageController : Controller
    {
        private readonly ILanguageApiMethods _languageApiMethods;
        public LanguageController(ILanguageApiMethods languageApiMethods)
        {
            _languageApiMethods = languageApiMethods;
        }

        public async Task<IActionResult> GetLanguages()
        {
            IEnumerable<LanguageResponseLite> apiResult = await _languageApiMethods.GetLanguagesAsync();

            return Json(apiResult);
        }

    }
}