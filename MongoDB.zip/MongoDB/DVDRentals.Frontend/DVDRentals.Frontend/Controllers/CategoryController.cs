﻿using DVDRentalsMongo.API.ApiMethods;
using DVDRentalsMongo.API.ApiMethods.IApiMethods;
using DVDRentalsMongo.API.Response.Category;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ICategoryApiMethods _categoryApiMethods;

        public CategoryController(ICategoryApiMethods categoryApiMethods)
        {
            _categoryApiMethods = categoryApiMethods;
        }

        [HttpGet]
        public async Task<IActionResult> GetCategories()
        {
            IEnumerable<CategoryResponseLite> apiResult = await _categoryApiMethods.GetCategoriesAsync();

            return Ok(apiResult); 
        }
    }
}