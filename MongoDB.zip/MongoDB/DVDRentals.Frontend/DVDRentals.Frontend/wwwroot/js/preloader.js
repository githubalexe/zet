﻿$(document).ready(function () {

    $(window).on("load", function () {

        $("#loader").fadeIn(500);

    });

    $('#loader-wrapper').css("display", "none");
});


