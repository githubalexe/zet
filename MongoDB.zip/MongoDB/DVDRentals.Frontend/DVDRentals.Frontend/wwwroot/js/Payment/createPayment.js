﻿$(document).ready(function () {

    var $form = $("#rentalPaymentForm");
    var $paymentDate = $("#paymentDate");
    var $rentalId = $("#rentalId");
    var $amountInput = $("#amountInput");

    var kendoFields = [
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },
        {
            id: "amountInput",
            kendoType: "kendoNumericTextBox"
        },

    ];

    $paymentDate.data("kendoDatePicker").setOptions({
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

    setKendoValidatior(kendoFields);

    function setKendoValidatior(kendoFields) {

        var options = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(options);

    };

    getRental(parseInt($rentalId.val()));

    function getRental(rentalValueId) {
        var rentalDate = {};

        return $.ajax({
            type: "GET",
            url: "/Rental/GetRental/",
            data: {
                rentalId: rentalValueId
            }

        })
            .done(function (data) {

                rentalDate.RentalDate = data.RentalDate;

                $paymentDate.data("kendoDatePicker").setOptions({
                    min: rentalDate.RentalDate,
                    month: {
                        empty: '<div class="k-state-disabled">#= data.value #</div>'
                    }
                });

            })
            .fail(function () {
                console.log("fail");
            })

    }

    setInputNumber();

    function setInputNumber() {

        var options = {

            $input: $amountInput,
            isArrows: true,
            type: "decimal"

        }

        new NumericField(options);

    }


});