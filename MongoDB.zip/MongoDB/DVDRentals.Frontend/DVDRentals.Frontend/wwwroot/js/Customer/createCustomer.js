﻿$(document).ready(function () {

    var $form = $('#customerCreateForm');
    var $countryId = $("#countryId");
    var $cityId = $("#cityId");
    var kendoFields = [

        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoCity();
    setKendoValidation(kendoFields);

    function setKendoCity() {

        var options = {
            $country: $countryId,
            $city: $cityId,
            setCity: false
        };

        new Cities(options);

    };

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

})