﻿$(document).ready(function () {

    var $activeCustomerStatus = $("#activeCustomerStatus");
    var $inactiveCustomerStatus = $("#inactiveCustomerStatus");
    var $customerModalContainer = $("#customerModalContainer");
    var $customerId = $("#customerId");
    var $customerName = $("#customerName");
    var $customerStatus = $("#customerStatus");
    var $customerRentalsGrid = $("#customerRentalsGrid");

    $activeCustomerStatus.on("click", function () {

        changeStatus(true, "active");

    });

    $inactiveCustomerStatus.on("click", function () {

        changeStatus(false, "inactive");

    });

    function changeStatus(status, statusName) {
        var options = {
            $container: $customerModalContainer,
            entity: "Customer",
            status: statusName,
            name: $customerName.text(),
            url: "/Customer/UpdateCustomerStatus",
            dataJson: {
                isActive: status,
                id: $customerId.text()
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Customer/CustomerDetails/" + $customerId.html();
            },
            onFail: function () {
                console.log("Something is wrong");
            },
            titlePartOne: "Change",
            titlePartTwo: "Status",
            cancelButton: "Cancel",
            acceptButton: "Save",
            warningMessagePartOne: "Are you sure you want to change",
            warningMessagePartTwo: "status to",
            warningMessagePartThree: "?"
        }

        new StatusModal(options);

        $("#generalModal").modal("show");
    }

    setStatusButton();

    function setStatusButton() {

        if ($customerStatus.html() === "True") {

            $activeCustomerStatus.prop("disabled", true);
            $activeCustomerStatus.removeClass("item-color");

        } else {

            $inactiveCustomerStatus.prop("disabled", true);
            $inactiveCustomerStatus.removeClass("item-color");
        }

    }

    setSortKendoGrid();

    function setSortKendoGrid() {

        var options = {
            $kendoGrid: $customerRentalsGrid,
            kendoGridField: "CustomerRentalsGridField",
            kendoGridFieldDir: "CustomerRentalsGridDir",
        };

        new SortKendoGrid(options);
    };
});