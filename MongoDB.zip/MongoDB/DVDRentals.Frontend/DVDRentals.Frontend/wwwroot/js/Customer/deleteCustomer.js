﻿$(document).ready(function () {
    var $customerId = $("#customerId");
    var $customerName = $("#customerName");
    var $deleteButton = $("#deleteCustomerButton");
    var $customerModalContainer = $("#customerModalContainer");

    $deleteButton.on("click", function () {

        var options = {
            title:"Delete",
            $container: $customerModalContainer,
            modelName: "<label class='active-entity'>" + $customerName.text() + "</label>",
            entity: "Customer",
            idsLength: 1,
            url: "/Customer/Delete",
            dataJson: {
                customersIds: $customerId.text()
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Customer/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        };

        new DeleteModal(options);

        $("#generalModal").modal("show");
    });
});