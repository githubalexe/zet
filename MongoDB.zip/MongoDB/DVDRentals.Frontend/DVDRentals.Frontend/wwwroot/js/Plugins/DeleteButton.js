﻿var DeleteButton = (function () {

    function DeleteButton(options) {

        this.$deleteButton = options.$deleteButton;
        this.$toggleDeleteButton = options.$toggleDeleteButton;
        this.$grid = options.$grid;
        this.messageForOne = options.messageForOne;
        this.messageForMany = options.messageForMany;

        this.setDeleteButton();
    };

    DeleteButton.prototype.setDeleteButton = function () {

        var self = this;

        self.$toggleDeleteButton.on("click", function () {

            if (self.$grid.data("kendoGrid").selectedKeyNames().length === 0) {

                self.$deleteButton.text(self.messageForOne);

                self.$deleteButton.prop("disabled", true);
                self.$deleteButton.removeClass("item-color");

            }
            else if (self.$grid.data("kendoGrid").selectedKeyNames().length === 1) {

                self.$deleteButton.text(self.messageForOne);

                self.$deleteButton.addClass("item-color");
                self.$deleteButton.prop("disabled", false);
            }
            else if (self.$grid.data("kendoGrid").selectedKeyNames().length > 1) {

                self.$deleteButton.text(self.messageForMany);

                self.$deleteButton.addClass("item-color");
                self.$deleteButton.prop("disabled", false);
            }

        });

    };

    return DeleteButton;

}());