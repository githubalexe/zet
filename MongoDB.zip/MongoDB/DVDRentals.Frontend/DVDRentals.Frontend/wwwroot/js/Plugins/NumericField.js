﻿var NumericField = (function () {

    function NumericField(options) {
        this.options = $.extend({}, true, NumericField.options, options);

        this.setTypeOfInput();
    };

    NumericField.prototype.setTypeOfInput = function () {

        if (this.options.type === "decimal") {

            this.setDecimalNumericInput();

        }
        else if (this.options.type === "int") {

            this.setIntNumericInput();
        }

    };

    NumericField.prototype.setIntNumericInput = function () {

        var self = this;

        self.options.$input.on("keyup", function (e) {

            var character = String.fromCharCode(e.which);
            var value = this.value;

            if (value > 0) {
                self.options.$input.attr("maxlength", 2);
            }
            else {
                self.options.$input.attr("maxlength", value.length + 3);
            }

            if (character === ".") {

                value = value.substring(0, value.length - 1)

                self.options.$input.val(value);

            }

            if (value === "0") {

                return false;

            } else {

                return true;

            }

        });

    };

    NumericField.prototype.setDecimalNumericInput = function () {

        var self = this;

        var $fieldValidation = $("span.text-danger");

        this.options.$input.data("kendoNumericTextBox").value("");
        self.options.$input.on("keypress keyup", function (e) {

            $fieldValidation.addClass("d-none");
            var value = this.value;

            var character = String.fromCharCode(e.which);

            if (value > 0) {

                if (value.includes(".") === false) {

                    self.options.$input.attr("maxlength", 3);

                    if (value.length > 3) {

                        self.options.$input.attr("maxlength", value.length + 3);

                        if (value > 100) {

                            self.options.$input.attr("maxlength", value.length);

                        }

                        if (character === ".") {

                            self.options.$input.attr("maxlength", value.length + 3);

                        }

                    }

                }

                if (character === "." || character === "n") {

                    if (value.length === 1) {

                        self.options.$input.attr("maxlength", 4);


                    } else if (value.length === 2) {

                        self.options.$input.attr("maxlength", 5);

                    }
                    else if (value.length === 3) {

                        self.options.$input.attr("maxlength", 6);

                    }

                    if (character === "n") {

                        self.options.$input.attr("maxlength", value.length + 2);
                    }
                }

            } else {

                if (value.includes(".") === false) {

                    self.options.$input.attr("maxlength", value.length + 3);

                }

            }

        });

        self.options.$input.on("focusout", function () {

            $fieldValidation.removeClass("d-none");

        })

    };

    NumericField.options = {

        $input: $({}),
        isArrows: $({}),
        type: $({}),
        maxValue: $({}),

    };

    return NumericField;

}());