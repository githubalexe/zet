﻿var Cities = (function () {

    function Cities(options) {

        this.country = options.country;
        this.city = options.city;

        this.setKendo();
    };

    Cities.prototype.setKendo = function () {

        var self = this;

        var $country = $("#" + self.country);
        var $city = $("#" + self.city);

        $country.kendoComboBox({
            filter: "contains",
            placeholder: "Select Country",
            dataTextField: "Name",
            dataValueField: "Id",
            dataSource: {
                serverFiltering: true,
                transport: {
                    read: {
                        url: "/Country/GetCountries"
                    }
                }
            }
        }).data("kendoComboBox");

        $city.kendoComboBox({
            autoBind: false,
            cascadeFrom: self.country,
            filter: "contains",
            placeholder: "Select City",
            dataTextField: "Name",
            dataValueField: "Id",
            dataSource: {
                serverFiltering: true,
                transport: {
                    read: {
                        url: "/Country/GetCitiesByCountry",
                        data: function () {
                            return {
                                countryId: $country.val()
                            };
                        }
                    }
                }
            }
        }).data("kendoComboBox");

    };

    return Cities;

}());