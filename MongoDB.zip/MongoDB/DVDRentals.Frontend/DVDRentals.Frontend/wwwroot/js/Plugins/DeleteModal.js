﻿var DeleteModal = (function () {

    function DeleteModal(options) {

        this.$container =options.$container;
        this.title = options.title;
        this.entity = options.entity;
        this.idsLength = options.idsLength;
        this.modelName = options.modelName;
        this.url = options.url;
        this.dataJson = options.dataJson;
        this.onCancel = options.onCancel;
        this.onSucces = options.onSucces;
        this.onFail = options.onFail;
        this.cancelButton = options.cancelButton;
        this.cancelButton = options.cancelButton;
        this.warningMessagePartOne = options.warningMessagePartOne;
        this.warningMessagePartTwo = options.warningMessagePartTwo;
        this.warningMessagePartThree = options.warningMessagePartThree;

        this.buildBody();
        this.deleteItems();
        this.cancelEvent();
    };

    DeleteModal.prototype.buildBody = function () {

        var entityOption = this.getEntityNounForm();

        entityLower = entityOption.charAt(0).toLowerCase() + entityOption.slice(1);

        var title = `${this.title} ${entityOption} `;
        var message = `${this.warningMessagePartOne}
                       ${entityLower} 
                       ${this.modelName}
                       ${this.warningMessagePartTwo}  
                       ${entityLower}  
                       ${this.warningMessagePartThree}`

        var deleteViewModel = {
            modalTitle: title,
            warningMessage: message,
            cancelButton: this.cancelButton,
            acceptButton: this.acceptButton
        };

        ko.applyBindings(
            deleteViewModel,
            this.$container[0]
        );

        ko.cleanNode(this.$container[0]);

    };

    DeleteModal.prototype.deleteItems = function () {
        var self = this;

        $("#deleteButton").on("click", function () {
            self.deleteItemV2();
        });
    };

    DeleteModal.prototype.cancelEvent = function () {
        var self = this;

        $("#cancelButton").on("click", function () {
            self.onCancel();
        });
    };

    DeleteModal.prototype.deleteItemV2 = function () {
        var self = this;
        return $.ajax({
            type: "POST",
            url: this.url,
            data: this.dataJson,
        })
            .done(function () {
                self.onSucces();
            })
            .fail(function () {
                self.onFail();
            })
    };

    DeleteModal.prototype.getEntityNounForm = function () {
        var entityOption = "";

        if (this.idsLength > 1) {

            var lastCharacter = this.entity.substr(this.entity.length - 1);

            if (lastCharacter === "y") {

                entityOption = this.entity;
                entityOption = entityOption.slice(0, -1) + "ies";

            } else {

                entityOption = this.entity + "s";

            }
        }
        else {
            entityOption = this.entity;
        }

        return entityOption;
    };

    return DeleteModal;

}());