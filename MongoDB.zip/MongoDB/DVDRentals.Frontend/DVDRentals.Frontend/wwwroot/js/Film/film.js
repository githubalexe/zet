﻿$(document).ready(function () {

    var $deleteFilm = $("#deleteFilm");
    var $searchFilmContainer = $("#filmsSearchContainer");
    var $filmDeleteContainer = $("#filmDeleteContainer");
    var $filmsGrid = $("#filmsGrid");
    var $toggleButton = $(".toggle-button");

    setSearchItems();
    setDeleteButton();

    function setDeleteButton() {

        var options = {
            $deleteButton: $deleteFilm,
            $toggleDeleteButton: $toggleButton,
            $grid: $filmsGrid,
            messageForOne: "Delete Film",
            messageForMany: "Delete Films"
        }

        new DeleteButton(options);
    }

    $deleteFilm.on("click", function () {

        var optionsGrid = {
            grid: "filmsGrid",
            id: "FilmId",
            name: "Title"
        }

        var entityGrid = new EntityGrid(optionsGrid);

        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            title:"Delete",
            $container: $filmDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Film",
            idsLength: numberOfIds.length,
            url: "/Film/Delete",
            dataJson: {
                filmsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {

                location.reload();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function () {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#generalModal").modal("show");
        }
    });

    function setSearchItems() {
        var options = {

            $container: $searchFilmContainer,
            $kendoGrid: $("#filmsGrid"),

            buttonFilters: [
                {
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "Release Year"
                },
                {
                    field: "ReleaseYear",
                    operator: "lte",
                    value: 2010,
                    display: "<= 2010",
                },
                {
                    field: "titleField",
                    display: "Language"
                },
                {
                    field: "Language",
                    operator: "eq",
                    value: "English",
                    display: "English"
                },
                {
                    field: "Language",
                    operator: "eq",
                    value: "French",
                    display: "French"
                },
                {
                    field: "titleField",
                    display: "Rating"
                },
                {
                    field: "Rating",
                    operator: "eq",
                    value: "NC-17",
                    display: "NC-17"
                }
 
            ],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "Rating",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Language",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Title",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "ReleaseYear",
                            operator: "eq",
                            value: 0,
                        }
                    ],
                }
            ]
        }

        new SearchLabel(options);
    }

    setSortKendoGrid();

    function setSortKendoGrid() {

        var options = {
            $kendoGrid: $filmsGrid,
            kendoGridField: "FilmsGridField",
            kendoGridFieldDir: "FilmsGridDir",
        };

        new SortKendoGrid(options);
    };

});