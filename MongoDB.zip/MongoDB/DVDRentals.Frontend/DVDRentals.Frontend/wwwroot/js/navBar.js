﻿$(document).ready(function () {

    var activeNavLink = "active-nav-link";
    var $navLink = $(".nav-link");

    $navLink.on("click", function () {
        $navLink.removeClass(activeNavLink);
        $(this).addClass(activeNavLink);
    });

    $('.active-nav-link a').click(function (e) {
        e.preventDefault();
        $(this).tab('show');
    });

    $("ul.nav-tabs > li > a").on("shown.bs.tab", function (e) {
        var id = $(e.target).attr("href").substr(1);
        window.location.hash = id;
    });

    getHas();

    function getHas() {

        var hash = window.location.hash;

        if (hash !== "") {

            $navLink.removeClass(activeNavLink);
        }

        $('.nav-header a[href="' + hash + '"]').tab('show');
        $('.nav-header a[href="' + hash + '"]').addClass(activeNavLink);
    }

});
