﻿$(document).ready(function () {
    
    var $staffId = $("#staffId");
    var $staffName = $("#staffName");
    var $deleteButton = $("#deleteStaffButton");
    var $customerDeleteContainer = $("#staffModalContainer");
    var $searchStaffRentalsContainer = $("#searchStaffRentalsContainer");

    setSearchItems();

    $deleteButton.on("click", function () {

        var options = {
            title:"Delete",
            $container: $customerDeleteContainer,
            modelName: "<label class='active-entity'>" + $staffName.text() + "</label>",
            entity: "Staff",
            idsLength: 1,
            url: "/Staff/Delete",
            dataJson: {
                staffsIds: $staffId.text()
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Staff/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            },
            cancelButton: "Cancel",
            acceptButton: "Delete",
            warningMessagePartOne: "WARNING: The selected",
            warningMessagePartTwo: "will be deleted.There is no way to recover the",
            warningMessagePartThree: "after deletion."
        };

        new DeleteModal(options);

        $("#generalModal").modal("show");
    });

    function setSearchItems() {
        var options = {

            $container: $searchStaffRentalsContainer,
            $kendoGrid: $("#staffRentalsGrid"),
            filterButton: false,
            buttonFilters: [],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "RentalId",
                            operator: "eq",
                            value: 0
                        },
                        {
                            field: "FilmTitle",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "RentalDate",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "ReturnDate",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Customer",
                            operator: "contains",
                            value: "",
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }
});