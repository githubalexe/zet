﻿$(document).ready(function () {

    var $form = $("#createStaffForm");

    var $staffPicture = $("#staffPicture");
    var $pictureSrc = $("#pictureSrc");
    var $countryId = $("#countryId");
    var $cityId = $("#cityId");
    var kendoFields = [

        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoCity();
    setKendoValidation(kendoFields);

    function setKendoCity() {

        var options = {
            $country: $countryId,
            $city: $cityId,
            setCity: false
        };

        new Cities(options);

    };

    $staffPicture.on("load", function () {

        var $src = $staffPicture.attr("src");
        console.log($src);
        $pictureSrc.val($src);
        //$pictureValidation.html("");

    });

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

});