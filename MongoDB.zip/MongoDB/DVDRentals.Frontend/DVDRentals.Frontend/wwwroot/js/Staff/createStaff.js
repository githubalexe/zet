﻿$(document).ready(function () {

    var $form = $("#createStaffForm");

    var $staffPicture = $("#staffPicture");
    var $pictureSrc = $("#pictureSrc");

    var kendoFields = [

        {
            id: "countryInput",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityInput",
            kendoType: "kendoComboBox"
        },

    ];

    setKendoCity();
    setKendoValidation(kendoFields);

    function setKendoCity() {

        var options = {
            country: "countryInput",
            city: "cityInput",
        };

        new Cities(options);
    };

    $staffPicture.on("load", function () {

        var $src = $staffPicture.attr("src");
        console.log($src);
        $pictureSrc.val($src);

    });

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

});