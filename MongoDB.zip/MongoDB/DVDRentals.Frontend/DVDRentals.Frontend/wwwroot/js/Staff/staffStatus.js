﻿$(document).ready(function () {

    var $activeStaffStatus = $("#activeStaffStatus");
    var $inactiveStaffStatus = $("#inactiveStaffStatus");
    var $staffModalContainer = $("#staffModalContainer");
    var $staffId = $("#staffId");
    var $staffName = $("#staffName");
    var $staffStatus = $("#staffStatus");
    var $staffRentalsGrid = $("#staffRentalsGrid");

    setStatusButton();

    $activeStaffStatus.on("click", function () {

        var options = {
            $container: $staffModalContainer,
            entity: "Staff",
            status: "active",
            name: $staffName.text(),
            url: "/Staff/UpdateStaffStatus",
            dataJson: {
                isActive: true,
                id: $staffId.text()
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Staff/StaffDetails/" + $staffId.html();
            },
            onFail: function () {
                console.log("Something is wrong");
            },
            titlePartOne: "Change",
            titlePartTwo: "Status",
            cancelButton: "Cancel",
            acceptButton: "Save",
            warningMessagePartOne: "Are you sure you want to change",
            warningMessagePartTwo: "status to",
            warningMessagePartThree: "?"
        }

        new StatusModal(options);

        $("#generalModal").modal("show");

    });

    $inactiveStaffStatus.on("click", function () {
        console.log($staffName.text());
        var options = {
            $container: $staffModalContainer,
            entity: "Staff",
            status: "inactive",
            name: $staffName.text(),
            url: "/Staff/UpdateStaffStatus",
            dataJson: {
                isActive: false,
                id: $staffId.text()
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Staff/StaffDetails/" + $staffId.html();
            },
            onFail: function () {
                console.log("Something is wrong");
            },
            titlePartOne: "Change",
            titlePartTwo: "Status",
            cancelButton: "Cancel",
            acceptButton: "Save",
            warningMessagePartOne: "Are you sure you want to change",
            warningMessagePartTwo: "status to",
            warningMessagePartThree: "?"
        }

        new StatusModal(options);

        $("#generalModal").modal("show");

    });

    function setStatusButton() {

        if ($staffStatus.html() === "True") {
            $activeStaffStatus.prop("disabled", true);
            $activeStaffStatus.removeClass("item-color");

        } else {
            $inactiveStaffStatus.prop("disabled", true);
            $inactiveStaffStatus.removeClass("item-color");
        }

    }

    setSortKendoGrid();

    function setSortKendoGrid() {

        var options = {
            $kendoGrid: $staffRentalsGrid,
            kendoGridField: "StaffRentalsGridField",
            kendoGridFieldDir: "StaffRentalsGridDir",
        };

        new SortKendoGrid(options);
    };

});