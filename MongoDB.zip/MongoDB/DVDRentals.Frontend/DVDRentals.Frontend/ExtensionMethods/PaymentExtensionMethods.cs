﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Payment;
using DVDRentalsMongo.API.Response.Rental;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class PaymentExtensionMethods
    {
        public static PaymentFormRequest ToPaymentFormRequest(this RentalPaymentsView request, RentalResponse rental)
        {
            return new PaymentFormRequest()
            {
                CustomerId = rental.CustomerId,
                StaffId = rental.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount,
                PaymentDate = request.PaymentDate
            };
        }

        public static PaymentViewModel ToPaymentViewModel(this PaymentResponseLite payment)
        {
            return new PaymentViewModel()
            {
                PaymentId = payment.Id,
                PaymentDate = payment.PaymentDate.ToString("dd/MM/yyyy"),
                Amount = payment.Amount.ToString()
            };
        }
    }
}
