﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Inventory;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class InventoryExtensionMethods
    {
        public static InventoryViewModel ToInventoryViewModel(this InventoryResponse inventory)
        {
            return new InventoryViewModel()
            {
                InventoryId = inventory.Id,
                FilmTitle = inventory.Film.Title,
                ReleaseYear = inventory.Film.ReleaseYear,
                Rating = inventory.Rating,
                FilmId = inventory.FilmId
            };
        }

        public static InventoryFormRequest ToInventoryFormRequest(this InventoryViewModel model)
        {
            return new InventoryFormRequest()
            {
                FilmId = model.FilmId
            };
        }
    }
}
