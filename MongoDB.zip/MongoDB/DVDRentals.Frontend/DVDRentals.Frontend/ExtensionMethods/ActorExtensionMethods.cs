﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Actor;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class ActorExtensionMethods
    {
        public static ActorViewModel ToActorViewModel(this ActorResponse actor)
        {
            return new ActorViewModel()
            {
                ActorId = actor.Id,
                FirstName = actor.FirstName,
                LastName = actor.LastName,
                Name = actor.Name,
            };
        }

        public static ActorFormRequest ToActorFormRequest(this ActorViewModel model)
        {
            return new ActorFormRequest()
            {
                ExistingActor = model.ExistingActor,
                ActorId = model.ActorId,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Name = model.Name,
            };
        }
    }
}
