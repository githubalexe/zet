﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreViewModel ToStoreViewModel(this StoreResponse store)
        {
            return new StoreViewModel()
            {
                StoreId = store.Id,
                ManagerStaffId = store.ManagerStaffId,
                ManagerName = store.ManagerName.Name,
                AddressId = store.AddressId,
                Address = store.Address.Address1,
                Address2 = store.Address.Address2,
                District = store.Address.District,
                City = store.Address.City.Name,
                Country = store.Address.City.Country.Name,
                CityId = store.Address.City.Id,
                CountryId = store.Address.City.Country.Id,
                PostalCode = store.Address.PostalCode,
                Phone = store.Address.Phone
            };
        }

        public static StoreFormRequest ToStoreFormRequest(this StoreViewModel model)
        {
            return new StoreFormRequest
            {
                StoreId = model.StoreId,
                ManagerStaffId = model.ManagerStaffId,
                ManagerName = model.ManagerName,
                AddressId = model.AddressId,
                Address = model.Address,
                Address2 = model.Address2,
                District = model.District,
                City = model.City,
                Country = model.Country,
                CityId = model.CityId,
                CountryId = model.CountryId,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }
    }
}
