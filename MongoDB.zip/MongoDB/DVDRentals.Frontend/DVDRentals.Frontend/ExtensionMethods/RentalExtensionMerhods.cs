﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Rental;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class RentalExtensionMerhods
    {
        public static RentalViewModel ToRentalViewModel(this RentalResponse rental)
        {
            return new RentalViewModel
            {
                RentalId = rental.Id,
                FilmTitle = rental.Film.Title,
                Customer = rental.Customer.Name,
                RentalDate = rental.RentalDate,
                ReturnDate = rental.ReturnDate,
                Staff = rental.Staff.Name,
                StaffId = rental.Staff.Id,
                CustomerId = rental.CustomerId,
                FilmId = rental.Film.Id,
                InventoryId = rental.InventoryId
            };
        }

        public static RentalIndexViewModel ToRentalIndexViewModel(this RentalResponse rental)
        {
            return new RentalIndexViewModel
            {
                RentalId = rental.Id,
                FilmTitle = rental.Film.Title,
                Customer = rental.Customer.Name,
                RentalDate = rental.RentalDate.ToString("dd/MM/yyyy"),
                ReturnDate = rental.ReturnDate?.ToString("dd/MM/yyyy") ?? rental.ReturnDate.ToString(),
                Staff = rental.Staff.Name
            };
        }

        public static CustomerRentalsViewModel ToCustomerRentalsViewModel(this RentalResponse rental)
        {
            return new CustomerRentalsViewModel
            {
                RentalId = rental.Id,
                FilmTitle = rental.Film.Title,
                RentalDate = rental.RentalDate.ToString("dd/MM/yyyy"),
                ReturnDate = rental.ReturnDate?.ToString("dd/MM/yyyy") ?? rental.ReturnDate.ToString(),
                Staff = rental.Staff.Name
            };
        }

        public static StaffRentalsViewModel ToStaffRentalsViewModel(this RentalResponse rental)
        {
            return new StaffRentalsViewModel
            {
                RentalId = rental.Id,
                FilmTitle = rental.Film.Title,
                RentalDate = rental.RentalDate.ToString("dd/MM/yyyy"),
                ReturnDate = rental.ReturnDate?.ToString("dd/MM/yyyy") ?? rental.ReturnDate.ToString(),
                Customer = rental.Customer.Name
            };
        }

        public static PaymentFormRequest ToPaymentFormRequest(this RentalFormRequest request)
        {
            return new PaymentFormRequest()
            {
                CustomerId = request.CustomerId,
                StaffId = request.StaffId,
                RentalId = request.RentalId,
                Amount = request.Amount,
                PaymentDate = request.PaymentDate
            };
        }

        public static RentalFormRequest ToRentalFormRequest(this RentalViewModel model)
        {
            return new RentalFormRequest()
            {
                ExistingCustomer = model.ExistingCustomer,
                StaffId = model.StaffId,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                Address = model.Address,
                Address2 = model.Address2,
                Distrinct = model.Distrinct,
                CountryId = model.CountryId,
                CityId = model.CityId,
                PostalCode = model.PostalCode,
                Phone = model.Phone,
                InventoryId = model.InventoryId,
                CustomerId = model.CustomerId,
                FilmId = model.FilmId,
                RentalDate = model.RentalDate,
                ReturnDate = model.ReturnDate,
                Amount = model.Amount,
                PaymentDate = model.PaymentDate
            };
        }
    }
}
