﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Staff;
using System;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class StaffExtensionMethods
    {

        public static StaffViewModel ToStaffViewModel(this StaffResponse staff)
        {
            StaffViewModel model = new StaffViewModel()
            {
                StaffId = staff.Id,
                StoreId = staff.StoreId,
                Active = staff.Active,
                FirstName = staff.FirstName,
                LastName = staff.LastName,
                Picture = Convert.ToBase64String(staff.Picture),
                BinaryImage = staff.Picture,
                Name = staff.Name,
                Email = staff.Email,
                AddressId = staff.AddressId,
                Address = staff.Address.Address1,
                Address2 = staff.Address.Address2,
                District = staff.Address.District,
                Country = staff.Address.City.Country.Name,
                City = staff.Address.City.Name,
                CityId = staff.Address.City.Id,
                CountryId = staff.Address.City.Country.Id,
                PostalCode = staff.Address.PostalCode,
                Phone = staff.Address.Phone,
                Username = staff.Username,
                Password = staff.Password
            };

            if (staff.Active == false)
            {
                model.Status = "Inactive";
            }
            else
            {
                model.Status = "Active";
            }

            return model;
        }

        public static StaffFormRequest ToStaffFormRequest(this StaffViewModel model)
        {
            return new StaffFormRequest
            {
                StaffId = model.StaffId,
                StoreId = model.StoreId,
                FirstName = model.FirstName,
                LastName = model.LastName,
                Picture = model.Picture,
                Name = model.Name,
                Email = model.Email,
                AddressId = model.AddressId,
                Address = model.Address,
                Address2 = model.Address2,
                District = model.District,
                Country = model.Country,
                City = model.City,
                PostalCode = model.PostalCode,
                Phone = model.Phone,
                Active = model.Active,
                Username = model.Username,
                Password = model.Password,
                CountryId = model.CountryId,
                CityId = model.CityId,
                BinaryImage = model.BinaryImage
            };
        }
    }
}
