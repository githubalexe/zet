﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Customer;
using System;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class CustomerExtensionMethods
    {
        public static CustomerViewModel ToCustomerViewModel(this CustomerResponse customer)
        {
            return new CustomerViewModel
            {
                CustomerId = customer.Id,
                StoreId = customer.StoreId,
                FirstName = customer.FirstName,
                LastName = customer.LastName,
                Name = customer.Name,
                Email = customer.Email,
                AddressId = customer.AddressId,
                Address = customer.Address.Address1,
                Address2 = customer.Address.Address2,
                Distrinct = customer.Address.District,
                CountryId = customer.Address.City.Country.Id,
                Country = customer.Address.City.Country.Name,
                CityId = customer.Address.City.Id,
                City = customer.Address.City.Name,
                PostalCode = customer.Address.PostalCode,
                Phone = customer.Address.Phone,
                Active = customer.Active,
                CreateDate = customer.CreateDate
            };
        }

        public static CustomerIndexViewModel ToCustomerIndexViewModel(this CustomerResponse customer)
        {
            CustomerIndexViewModel model = new CustomerIndexViewModel();

            model.CustomerId = customer.Id;
            model.Name = customer.Name;
            model.Email = customer.Email;

            if (customer.Active == false)
            {
                model.Active = "Inactive";
            }
            else
            {
                model.Active = "Active";
            }

            model.CreateDate = customer.CreateDate.ToString("dd/MM/yyyy");

            return model;
        }

        public static CustomerFormRequest ToCustomerFormRequest(this CustomerViewModel model)
        {
            return new CustomerFormRequest
            {
                FirstName = model.FirstName,
                LastName = model.LastName,
                Email = model.Email,
                AddressId = model.AddressId,
                Address = model.Address,
                Address2 = model.Address2,
                Distrinct = model.Distrinct,
                CountryId = model.CountryId,
                CityId = model.CityId,
                Active = model.Active,
                PostalCode = model.PostalCode,
                Phone = model.Phone
            };
        }
    }
}
