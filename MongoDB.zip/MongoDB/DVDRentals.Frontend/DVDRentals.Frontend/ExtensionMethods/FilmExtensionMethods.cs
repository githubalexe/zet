﻿using DVDRentals.Frontend.ViewModels;
using DVDRentalsMongo.API.Request.FormRequest;
using DVDRentalsMongo.API.Response.Film;

namespace DVDRentals.Frontend.ExtensionMethods
{
    public static class FilmExtensionMethods
    {
        public static FilmViewModel ToFilmViewModel(this FilmResponse film)
        {
            return new FilmViewModel()
            {
                FilmId = film.Id,
                Title = film.Title,
                Description = film.Description,
                ReleaseYear = film.ReleaseYear,
                LanguageId = film.LanguageId,
                OriginalLanguageId = film.LanguageId,
                RentalRate = film.RentalRate,
                RentalDuration = film.RentalDuration,
                Length = film.Length,
                ReplacementCost = film.ReplacementCost,
                Rating = film.Rating,
                SpecialFeatures = film.SpecialFeatures,
                Language = film.Language.Name,
                Category = film.Category.Name,
                CategoryId = film.Category.Id
            };
        }

        public static FilmFormRequest ToFilmFormRequest(this FilmViewModel model)
        {
            return new FilmFormRequest()
            {
                FilmId = model.FilmId,
                Title = model.Title,
                Description = model.Description,
                ReleaseYear = model.ReleaseYear,
                LanguageId = model.LanguageId,
                OriginalLanguageId = model.OriginalLanguageId,
                RentalRate = model.RentalRate,
                RentalDuration = model.RentalDuration,
                Length = model.Length,
                ReplacementCost = model.ReplacementCost,
                Rating = model.Rating,
                SpecialFeatures = model.SpecialFeatures,
                Language = model.Language,
                CategoryId = model.CategoryId
            };
        }
    }
}
