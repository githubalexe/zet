﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class ActorViewModel
    {
        [Display(Name ="Actor Id")]
      
        public string ActorId { get; set; }

        [Display(Name = "Existing Actor")]
        public string ExistingActor { get; set; }

        [Display(Name = "Actors Name")]
        [Required]
        public string Name { get; set; }

        [Display(Name = "First Name")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Length required is between three and thirty characters!")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "First Name is required!")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        [StringLength(30, MinimumLength = 3, ErrorMessage = "Length required is between three and thirty characters!")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Last Name is required!")]
        public string LastName { get; set; }

    }
}
