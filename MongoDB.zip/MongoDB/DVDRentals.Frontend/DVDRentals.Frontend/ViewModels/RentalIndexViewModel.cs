﻿namespace DVDRentals.Frontend.ViewModels
{
    public class RentalIndexViewModel
    {
        public string RentalId { get; set; }

        public string RentalDate { get; set; }

        public string ReturnDate { get; set; }

        public string Customer { get; set; }

        public string Staff { get; set; }

        public string FilmTitle { get; set; }
    }
}
