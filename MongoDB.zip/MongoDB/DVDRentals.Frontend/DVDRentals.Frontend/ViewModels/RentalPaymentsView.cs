﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class RentalPaymentsView
    {
        public string RentalId { get; set; }
        [Display(Name = "Payment Id")]
        public string PaymentId { get; set; }

        [Display(Name = "Payment Date")]
        [Required(ErrorMessage = "Payment Date is required!")]
        public DateTime PaymentDate { get; set; }

        [Display(Name = "Amount")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Amount is required!")]
        [Range(0, 999.99, ErrorMessage = "Replacement Cost cannot be bigger than 999.99!")]
        public decimal Amount { get; set; }
    }
}
