﻿using System.ComponentModel.DataAnnotations;

namespace DVDRentals.Frontend.ViewModels
{
    public class InventoryViewModel
    {
        [Display(Name = "Inventory Id")]
        public string InventoryId { get; set; }

        [Display(Name = "Film Title")]
        public string FilmTitle { get; set; }

        [Display(Name = "Release Year")]
        public int ReleaseYear { get; set; }

        [Display(Name = "Reting")]
        public string Rating { get; set; }

        [Display(Name = "Film")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Film is required!")]
        public string FilmId { get; set; }

        [Display(Name = "Number of copies")]
        [Range(1, 100, ErrorMessage = "Number of copies must be between 1 and 100!")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Number of copies are required!")]
        public int Copies { get; set; }
    }
}
