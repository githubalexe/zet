var hardcodes = {
    PostFirstName: 'Alex',
    PostLastName: 'Badescu'
};

(function () {
    $('#textPostArea').on('keypress keyup focusout keydown', function (e) {
        var textValue = $('textarea').val(),
            textLength = textValue.length,
            set = 500,
            remain = parseInt(set - textLength);
        $('#remainingLength').text(remain);
        if (remain <= 0 && e.which !== 0 && e.charCode !== 0) {
            $('#textPostArea').val((textValue).substring(0, textLength - 1));
            return false;
        }
    })

    $('#textPostArea').focusout(function () {
        if ($('#textPostArea').val() === "") {
            $('#textPostArea').animate({ height: 25 });
        }
    });

    $('#textPostArea').click(function () {
        $('#textPostArea').animate({ height: 55 });
    });

    $('#textPostArea').keyup('change drop keydown cut paste', function () {
        $('#textPostArea').height('auto');
        $('#textPostArea').height($('#textPostArea').prop('scrollHeight'));
    });

    $('#fileInput').change(function (event) {
        var files = event.target.files;
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            if (file.type.match('image.*')) {
                var picReader = new FileReader();
                $(picReader).bind("load", function (event) {
                    var picFile = event.target;
                    var $postImageContainer = " <div class='fileInput'> <span class='remove'></span><img class='postImage' src='" + picFile.result + "'" + "title='press image'/></div>";
                    $('#filesDisplayContainer').append($postImageContainer);
                });
                picReader.readAsDataURL(file);
            }
            else if (file.type.match('video.*')) {
                var source = $('<video/>');
                source.controls = true;
                source.src = URL.createObjectURL(files[i]);
                source.innerHTML = "<video controls><source  src=" + source.src + "></video>";
                var $postVideoContainer = "<div class='fileInput'> <span class='remove'></span>" + source.innerHTML + "</div>";
                $('#filesDisplayContainer').append($postVideoContainer);
            }
            $('#filesDisplayContainer, #inputLine').show();
        }
    });

    $('body').on('click', '.remove', function () {
        $(this).parent().remove();
        if ($('.postImage', $('#filesDisplayContainer')).length === 0) {
            $('#inputLine').css('display', 'none');
            $('#filesDisplayContainer').html('');
        }
    });

    function getFileInput() {
        $('.fileInput', $('#filesDisplayContainer')).each(function () {
            $('.fileInput').find('span').remove();
        });
    }

    function createPost() {
        getFileInput();
        var firstNameUser = hardcodes.PostFirstName;
        var lastNameUser = hardcodes.PostLastName;
        var textContent = $('#textPostArea').val();
        var file = $('#filesDisplayContainer').html();
        var options = {
            firstName: firstNameUser,
            lastName: lastNameUser,
            textPost: textContent,
            fileInput: file
        };
        var post = new Post(options);
        if (post.validateFields(textContent, file) === false) {
            $('.postsContainer').prepend(post.setPost(firstNameUser, lastNameUser, textContent, file));
        }
        else {
            $('.alertMesage').css('display', 'table');
            setTimeout(getTime, 5000);
        }
    }
    function getTime() {
        $('.alertMesage').css('display', 'none');
    }

    function clearFields() {
        $('#inputLine').hide();
        $("#textPostArea").val('');
        $('#fileInput').val('');
        $('#filesDisplayContainer').html('');
        $('#textPostArea').html('');
        $('#remainingLength').html('500');
        $('#textPostArea').animate({ height: 25 });
    }

    $('#postButton').click(function () {
        createPost();
        clearFields();
    });

})();