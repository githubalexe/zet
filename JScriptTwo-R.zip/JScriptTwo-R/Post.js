class Post {
    constructor(options) {
        var todayDate = new Date();
        var time = todayDate.toLocaleTimeString();
        var date = todayDate.toLocaleDateString();
        this.firstName = options.firstName;
        this.lastName = options.lastName;
        this.postDate = date;
        this.postTime = time;
        this.textPost = options.textPost;
        this.fileInput = options.fileInput;
    }
    setPost(firstName, lastName, textPost, file) {      
        var templatePost =
            '<div class="post">' +
            '<div class="userContainer">' +
            '<div class="userAvatar"></div>' +
            '<div class="userDetails">' +
            '<label for="firstName" class="style" id="firstName">' + firstName + '</label>' +
            '<label for="lastName" class="style textMargin" id="lastName">' + lastName + '</label><br>' +
            '<label class="style smallFont">Posted on: </label>' +
            '<label for="postDate" class="style smallFont" id="postDate">' + this.postDate + '</label>' +
            '<label for="postTime" class="style smallFont textMargin" id="postTime">' + this.postTime + '</label>' +
            '</div>' +
            '<div class="clear"></div>' +
            '</div>' +
            '<div class="postContainer">' +
            '<hr class="line postLine">' +
            '<label for="postText" class="style" id="postText">' + textPost + '</label>' +
            '<div class="mainPost">' +
            '<div class="imagesContainer">' + file +
            '<div class="clear"></div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '</div>' +
            '<div class="marginBottom"></div>';
        return templatePost;
    }

    validateFields(textPost, fileInput) {
        if (textPost === "" && fileInput === "") {
            return true;
        }
        return false;
    }
}