$(function () {

    ImageSlider = function (options) {

        var self = this;
        self.$container = options.$container;

        self.buildBody();
        self.addImages();
        self.createEvents();
        //self.getImage();
    }

    ImageSlider.prototype.buildBody = function () {
        var self = this;

        var $pluginWrapper = $('<div/>', {
            class: 'image-slider',
        });
        var $sliderTitle = $('<label/>', {
            class: 'title',
        });
        $sliderTitle.text('Images Slider');

        var $slider = $('<div/>', {
            class: 'slider',
        });

        var $imagesContainer = $('<output/>', {
            id: 'imagesContainer',
        });
        var $imagesInput = $('<input/>', {
            id: 'imagesInput',
            type: 'file',
            multiple: true,
            hidden: true
        });
        var $addPhotoButton = $('<input/>', {
            id: 'addButton',
            type: 'button',
            value: 'AddPhoto',
        });
        var $prevButton = $('<a/>', {
            id: 'prevButton',
            html: '&#10094;',
        });
        var $nextButton = $('<a/>', {
            id: 'nextButton',
            html: '&#10095;',
        });

        $pluginWrapper.append($sliderTitle);
        $slider.append($imagesContainer)
        $slider.append($prevButton);
        $slider.append($nextButton);
        $pluginWrapper.append($slider);
        $pluginWrapper.append($addPhotoButton);
        $pluginWrapper.append($imagesInput);
        self.$container.append($pluginWrapper);
    }

    ImageSlider.prototype.getImage = function () {
        var srcValue = localStorage.getItem('imageSrc');
        alert(srcValue);
    }

    ImageSlider.prototype.addImages = function () {
        var self = this;
        var $imagesInput = $('#imagesInput', self.$container);
        var $imagesContainer = $('#imagesContainer', self.$container);

        function removeActive() {
            $imagesInput.each(function () {
                $('.image').removeClass('active');
            });
        }

        $imagesInput.on('change', function (event) {
            var files = event.target.files;
            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                if (file.type.match('image.*')) {
                    var src = URL.createObjectURL(file);
                    if (i === 0) {
                        removeActive();
                        var $image = $('<img/>', {
                            class: 'image active',
                            src: src
                        });
                    }
                    else {
                        var $image = $('<img/>', {
                            class: 'image',
                            src: src
                        });
                    }
                    $imagesContainer.append($image);
                }
            }
        });
    }

    ImageSlider.prototype.createEvents = function () {

        var self = this;

        var $addPhotoButton = $('#addButton', self.$container);
        var $imagesInput = $('#imagesInput', self.$container);
        var $prevButton = $('#prevButton', self.$container);
        var $nextButton = $('#nextButton', self.$container);

        $addPhotoButton.on('click', function () {
            $imagesInput.click();
        });

        $nextButton.on('click', function () {
            var currentImg = $('.active', self.$container);
            var nextImg = currentImg.next();

            if (nextImg.length) {
                currentImg.removeClass('active').css('z-index', -10);
                nextImg.addClass('active').css('z-index', 10);
            }
        });

        $prevButton.on('click', function () {
            var currentImg = $('.active', self.$container);
            var prevImg = currentImg.prev();

            if (prevImg.length) {
                currentImg.removeClass('active', self.$container).css('z-index', -10);
                prevImg.addClass('active', self.$container).css('z-index', 10);
            }
        });

        self.$container.on('click', '.image', function () {
            var srcValue = this.src;
            window.open('./PhotoEditor.html', srcValue);
            localStorage.setItem('imageSrc', srcValue);
        });
    }
}());

