$(function () {

    PhotoEditor = function (options) {

        var self = this;
        self.$container = options.$container;
        self.buildBody();
        self.convertImageToCanvas();
        self.setFilters();
        //self.setEffects();
    }

    PhotoEditor.prototype.buildBody = function () {
        //create edit page
        var self = this;
        var $editorContainer = $('<div/>', {
            class: 'editor-container'
        });
        var $filtersTitle = $('<p/>', {
            class: 'title'
        });
        $filtersTitle.text('Edit');
        var $efectsTitle = $('<p/>', {
            class: 'title'
        });
        $efectsTitle.text('Filters');
        var filters = document.createElement('div');
        filters.classList.add('filters');
        var $filters = $('<div/>', {
            class: 'filters'
        });
        var $effects = $('<div/>', {
            class: 'effects'
        });
        var $submitButtons = $('<div/>', {
            class: 'submit-buttons'
        });
        var $imageContainer = $('<canvas/>', {
            id: 'imageCanvas'
        });

        ////brightness
        var $brightnessContainer = $('<div/>', {
            class: 'button-container'
        });
        var $brightnessLabel = $('<label/>', {
            class: 'label'
        });
        $brightnessLabel.text('Brightness');
        var $minusBrightnessButton = $('<button/>', {
            id: 'minusBrightnessButton',
            class: 'minus-button button',
        });
        $minusBrightnessButton.text('-');
        var $plusBrightnessButton = $('<button/>', {
            id: 'plusBrightnessButton',
            class: 'plus-button button',
        });
        $plusBrightnessButton.text('+');

        ////filterValue

        var $brightnessFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'brightnessFilterValue'
        });
        $brightnessFilterValue.text('100%');

        var $contrastFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'contrastFilterValue'
        });
        $contrastFilterValue.text('100%');

        var $saturateFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'saturateFilterValue'
        });
        $saturateFilterValue.text('100%');

        var $sepiaFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'sepiaFilterValue'
        });
        $sepiaFilterValue.text('0%');

        ////////////////
        var $grayFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'grayFilterValue'
        });
        $grayFilterValue.text('0%');

        var $invertFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'invertFilterValue'
        });
        $invertFilterValue.text('0%');

        var $hueRotateFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'hueRotateFilterValue'
        });
        $hueRotateFilterValue.text('0deg');

        var $blurFilterValue = $('<label/>', {
            class: 'filter-value',
            id: 'blurFilterValue'
        });
        $blurFilterValue.text('0px');
        ////

        //contrast
        var $contrastContainer = $('<div/>', {
            class: 'button-container'
        });
        var $contrastLabel = $('<label/>', {
            class: 'label'
        });
        $contrastLabel.text('Contrast');
        var $minusContrastButton = $('<button/>', {
            id: 'minusContrastButton',
            class: 'minus-button button',
        });
        $minusContrastButton.text('-');
        var $plusContrastButton = $('<button/>', {
            id: 'plusContrastButton',
            class: 'plus-button button',
        });
        $plusContrastButton.text('+');

        //saturate
        var $saturationContainer = $('<div/>', {
            class: 'button-container'
        });
        var $saturationLabel = $('<label/>', {
            class: 'label'
        });
        $saturationLabel.text('Saturate');
        var $minusSaturateButton = $('<button/>', {
            id: 'minusSaturateButton',
            class: 'minus-button button',
        });
        $minusSaturateButton.text('-');
        var $plusSaturateButton = $('<button/>', {
            id: 'plusSaturateButton',
            class: 'plus-button button',
        });
        $plusSaturateButton.text('+');

        //Sepia
        var $sepiaContainer = $('<div/>', {
            class: 'button-container'
        });
        var $sepiaLabel = $('<label/>', {
            class: 'label'
        });
        $sepiaLabel.text('Sepia');
        var $minusSepiaButton = $('<button/>', {
            id: 'minusSepiaButton',
            class: 'minus-button button',
        });
        $minusSepiaButton.text('-');
        var $plusSepiaButton = $('<button/>', {
            id: 'plusSepiaButton',
            class: 'plus-button button',
        });
        $plusSepiaButton.text('+');

        //grayscale
        var $grayContainer = $('<div/>', {
            class: 'button-container'
        });
        var $grayLabel = $('<label/>', {
            class: 'label'
        });
        $grayLabel.text('Grayscale');
        var $minusGrayButton = $('<button/>', {
            id: 'minusGrayButton',
            class: 'minus-button button',
        });
        $minusGrayButton.text('-');
        var $plusGrayButton = $('<button/>', {
            id: 'plusGrayButton',
            class: 'plus-button button',
        });
        $plusGrayButton.text('+');

        //invert
        var $invertContainer = $('<div/>', {
            class: 'button-container'
        });
        var $invertLabel = $('<label/>', {
            class: 'label'
        });
        $invertLabel.text('Invert');
        var $minusInvertButton = $('<button/>', {
            id: 'minusInvertButton',
            class: 'minus-button button',
        });
        $minusInvertButton.text('-');
        var $plusInvertButton = $('<button/>', {
            id: 'plusInvertButton',
            class: 'plus-button button',
        });
        $plusInvertButton.text('+');
        //hue rotate
        var $hueRotateContainer = $('<div/>', {
            class: 'button-container'
        });
        var $hueRotateLabel = $('<label/>', {
            class: 'label'
        });
        $hueRotateLabel.text('Hue Rotate');
        var $minusHueRotateButton = $('<button/>', {
            id: 'minusHueRotateButton',
            class: 'minus-button button',
        });
        $minusHueRotateButton.text('-');
        var $plusHueRotateButton = $('<button/>', {
            id: 'plusHueRotateButton',
            class: 'plus-button button',
        });
        $plusHueRotateButton.text('+');
        //blur
        var $blurContainer = $('<div/>', {
            class: 'button-container'
        });
        var $blurLabel = $('<label/>', {
            class: 'label'
        });
        $blurLabel.text('Blur');
        var $minusBlurButton = $('<button/>', {
            id: 'minusBlurButton',
            class: 'minus-button button',
        });
        $minusBlurButton.text('-');
        var $plusBlurButton = $('<button/>', {
            id: 'plusBlurButton',
            class: 'plus-button button',
        });
        $plusBlurButton.text('+');

        ///Effects buttons
        var $amaroEfectButton = $('<button/>', {
            id: 'amaroEfectButton',
            class: 'effect-button',
        });
        $amaroEfectButton.text('Vintage');

        var $lemoEffectButton = $('<button/>', {
            id: 'lemoeffectButton',
            class: 'effect-button',
        });
        $lemoEffectButton.text('Lemo');

        var $clarityEffectButton = $('<button/>', {
            id: 'clarityEffectButton',
            class: 'effect-button',
        });
        $clarityEffectButton.text('Clarity');

        var $sinCityEffectButton = $('<button/>', {
            id: 'sinCityEffectButton',
            class: 'effect-button',
        });
        $sinCityEffectButton.text('Sin City');

        var $crossProcessEffectButton = $('<button/>', {
            id: 'crossProcessEffectButton',
            class: 'effect-button',
        });
        $crossProcessEffectButton.text('Cross Process');

        var $pinholeEffectButton = $('<button/>', {
            id: 'pinholeEffectButton',
            class: 'effect-button',
        });
        $pinholeEffectButton.text('Pinhole');

        var $nostalgiaEffectButton = $('<button/>', {
            id: 'nostalgiaEffectButton',
            class: 'effect-button',
        });
        $nostalgiaEffectButton.text('Nostalgia');

        var herMajestyEffectButton = document.createElement('button');
        herMajestyEffectButton.setAttribute('id', 'herMajestyEffectButton');
        herMajestyEffectButton.classList.add('effect-button');
        herMajestyEffectButton.innerHTML = 'Nostalgia';
        var $herMajestyEffectButton = $('<button/>', {
            id: 'herMajestyEffectButton',
            class: 'effect-button',
        });
        $herMajestyEffectButton.text('Her Majesty');
        //download and remove filters
        var $saveButton = $('<button/>', {
            id: 'saveButton',
            class: 'effect-button',
        });
        $saveButton.text('Save');
        var $removeEffectsButton = $('<button/>', {
            id: 'removeEffectsButton',
            class: 'effect-button',
        });
        $removeEffectsButton.text('Remove Filters');
        ///////////
        var srcValue = localStorage.getItem('imageSrc');
        var $image = $('<img/>', {
            id: 'image',
            src: srcValue
        });
        //////////
        //$editorContainer.append($image);

        $brightnessContainer.append($minusBrightnessButton, $brightnessLabel, $plusBrightnessButton, $brightnessFilterValue);
        $contrastContainer.append($minusContrastButton, $contrastLabel, $plusContrastButton, $contrastFilterValue);
        $saturationContainer.append($minusSaturateButton, $saturationLabel, $plusSaturateButton, $saturateFilterValue);

        $sepiaContainer.append($minusSepiaButton, $sepiaLabel, $plusSepiaButton, $sepiaFilterValue);
        $grayContainer.append($minusGrayButton, $grayLabel, $plusGrayButton, $grayFilterValue);
        $invertContainer.append($minusInvertButton, $invertLabel, $plusInvertButton, $invertFilterValue);
        $hueRotateContainer.append($minusHueRotateButton, $hueRotateLabel, $plusHueRotateButton, $hueRotateFilterValue);
        $blurContainer.append($minusBlurButton, $blurLabel, $plusBlurButton, $blurFilterValue);

        $filters.append($brightnessContainer, $contrastContainer, $saturationContainer, $sepiaContainer, $grayContainer, $invertContainer, $hueRotateContainer, $blurContainer);
        $effects.append($amaroEfectButton, $lemoEffectButton, $clarityEffectButton, $sinCityEffectButton, $crossProcessEffectButton, $pinholeEffectButton, $nostalgiaEffectButton, $herMajestyEffectButton);
        $submitButtons.append($removeEffectsButton, $saveButton);
        $editorContainer.append($imageContainer, $filtersTitle, $filters, $efectsTitle, $effects, $submitButtons);
        self.$container.append($editorContainer);
    }



    PhotoEditor.prototype.setFilters = function () {

        var self = this;
        var $brightnessFilterValue = $('#brightnessFilterValue', self.$container);
        var $contrastFilterValue = $('#contrastFilterValue', self.$container);
        var $saturateFilterValue = $('#saturateFilterValue', self.$container);
        var $sepiaFilterValue = $('#sepiaFilterValue', self.$container);
        var $grayFilterValue = $('#grayFilterValue', self.$container);
        var $hueRotateFilterValue = $('#hueRotateFilterValue', self.$container);
        var $invertFilterValue = $('#invertFilterValue', self.$container);
        var $blurFilterValue = $('#blurFilterValue', self.$container);

        var srcValue = localStorage.getItem('imageSrc');
        var $canvas = $('#imageCanvas', self.$container)[0];
        var ctx = $canvas.getContext('2d');
        var editedImage;

        var brightness = 100;
        var contrast = 100;
        var saturate = 100;
        var sepia = 0;
        var gray = 0;
        var invert = 0;
        var hueRotate = 0;
        var blur = 0;

        self.$container.on('click', '#minusBrightnessButton', function () {
            brightness = brightness - 10;
            if (brightness < 10) {
                brightness = 10;
            }
            getImage();

        });

        self.$container.on('click', '#plusBrightnessButton', function () {
            brightness = brightness + 10;
            if (brightness > 300) {
                brightness = 300;
            }
            getImage();

        });

        self.$container.on('click', '#minusContrastButton', function () {
            contrast = contrast - 10;
            if (contrast < 10) {
                contrast = 10;
            }
            getImage();
        });

        self.$container.on('click', '#plusContrastButton', function () {
            contrast = contrast + 10;
            if (contrast > 300) {
                contrast = 300;
            }
            getImage();
        });

        self.$container.on('click', '#minusSaturateButton', function () {
            saturate = saturate - 10;
            if (saturate < 10) {
                saturate = 10;
            }
            getImage();
        });

        self.$container.on('click', '#plusSaturateButton', function () {
            saturate = saturate + 10;
            if (saturate > 300) {
                saturate = 300;
            }
            getImage();
        });

        self.$container.on('click', '#minusSepiaButton', function () {
            sepia = sepia - 10;
            if (sepia < 0) {
                sepia = 0;
            }
            getImage();
        });

        self.$container.on('click', '#plusSepiaButton', function () {
            sepia = sepia + 10;
            if (sepia > 300) {
                sepia = 300;
            }
            getImage();
        });

        self.$container.on('click', '#minusGrayButton', function () {
            gray = gray - 10;
            if (gray < 0) {
                gray = 0;
            }
            getImage();
        });


        self.$container.on('click', '#plusGrayButton', function () {
            gray = gray + 10;
            if (gray > 100) {
                gray = 100;
            }
            getImage();
        });

        self.$container.on('click', '#minusInvertButton', function () {
            invert = invert - 10;
            if (invert < 0) {
                invert = 0;
            }
            getImage();
        });


        self.$container.on('click', '#plusInvertButton', function () {
            invert = invert + 10;
            if (invert > 100) {
                invert = 100;
            }
            getImage();
        });

        self.$container.on('click', '#minusInvertButton', function () {
            invert = invert - 10;
            if (invert < 0) {
                invert = 0;
            }
            getImage();
        });


        self.$container.on('click', '#plusInvertButton', function () {
            invert = invert + 10;
            if (invert > 100) {
                invert = 100;
            }
            getImage();
        });

        self.$container.on('click', '#minusHueRotateButton', function () {
            hueRotate = hueRotate - 10;
            if (hueRotate < 0) {
                hueRotate = 0;
            }
            getImage();
        });


        self.$container.on('click', '#plusHueRotateButton', function () {
            hueRotate = hueRotate + 10;
            if (hueRotate > 360) {
                hueRotate = 360;
            }
            getImage();
        });

        self.$container.on('click', '#minusBlurButton', function () {
            blur = blur - 1;
            if (blur < 0) {
                blur = 0;
            }
            getImage();
        });


        self.$container.on('click', '#plusBlurButton', function () {
            blur = blur + 1;
            if (blur > 10) {
                blur = 10;
            }
            getImage();
        });



        self.$container.on('click', '#removeEffectsButton', function () {
            brightness = 100;
            contrast = 100;
            saturate = 100;
            sepia = 0;
            gray = 0;
            invert = 0;
            hueRotate = 0;
            blur = 0;
            getImage();
        });

        self.$container.on('click', '#saveButton', function (event) {

            event.preventDefault();
            window.location.href = './ImageSlider.html'; //works 
            //localStorage.setItem('getBack', editedImage);
            //window.open(editedImage);
        });

        function displayFilters() {
            $brightnessFilterValue.html(brightness + '%');
            $contrastFilterValue.html(contrast + '%');
            $saturateFilterValue.html(saturate + '%');
            $sepiaFilterValue.html(sepia + '%');
            $grayFilterValue.html(gray + '%');
            $invertFilterValue.html(invert + '%');
            $hueRotateFilterValue.html(hueRotate + 'deg');
            $blurFilterValue.html(blur + 'px');
        }

        function getImage() {
            var image = new Image();
            image.src = srcValue;
            image.onload = function () {
                $canvas.width = image.width;
                $canvas.height = image.height;
                ctx.filter = 'brightness(' + brightness + '%' + ') contrast(' + contrast + '%' + ') saturate(' + saturate + '%' + ') sepia(' + sepia + '%' + ') grayscale(' + gray + '%' + ') invert(' + invert + '%' + ') hue-rotate(' + hueRotate + 'deg' + ') blur(' + blur + 'px' + ')';
                ctx.drawImage(image, 0, 0, $canvas.width, $canvas.height);
                var data = $canvas.toDataURL(image.src);//save the image
                editedImage = data;
                //window.open(data);
            };
            displayFilters();
        }
    }

    PhotoEditor.prototype.setEffects = function () {
        var self = this;
        var $image = $('.image', self.$container);

    }

    PhotoEditor.prototype.convertImageToCanvas = function () {
        var self = this;

        var srcValue = localStorage.getItem('imageSrc');
        var $canvas = $('#imageCanvas', self.$container)[0];
        var ctx = $canvas.getContext('2d');



        var image = new Image();
        image.src = srcValue;

        image.onload = function () {
            $canvas.width = image.width;
            $canvas.height = image.height;
            //ctx.filter = "brightness(350%)";
            ctx.drawImage(image, 0, 0, $canvas.width, $canvas.height);
            var data = $canvas.toDataURL(image.src);//save the image
            //window.open(data);
        };


        //  filter: saturate(1.5) contrast(1.3) hue-rotate(-5deg) blur(.2px) brightness(1.1); lemo
        //https://codepen.io/bradtraversy/pen/qoJZBy--efect
        //https://bennettfeely.com/image-effects/
    }


}());