var options = {
    $container: $('#PhotoEditor')
}
var PhotoEditor = new PhotoEditor(options);