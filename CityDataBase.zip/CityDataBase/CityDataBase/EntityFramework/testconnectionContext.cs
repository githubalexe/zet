﻿using System;
using CityModel.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace CityModel.EntityFramework
{
    public partial class testconnectionContext : DbContext
    {
        public testconnectionContext()
        {
        }

        public testconnectionContext(DbContextOptions<testconnectionContext> options)
            : base(options)
        {
        }

        //db set for each entity you use
        public virtual DbSet<City> City { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseMySql("server=localhost;database=testconnection;user=root");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<City>(entity =>
            {
                entity.ToTable("city");

                //for ids use GUID  -> learn what GUID is
                entity.Property(e => e.Id).HasColumnType("int(11)");

                entity.Property(e => e.Description).HasColumnType("varchar(45)");

                entity.Property(e => e.Name).HasColumnType("varchar(45)");
            });
        }
    }
}
