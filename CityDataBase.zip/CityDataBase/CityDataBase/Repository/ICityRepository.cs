﻿using CityModel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CityDataBase.IRepository
{
    public interface ICityRepository
    {
        Task<City> GetAsync(int id);

        Task<City> GetV2Async(int id);
    }
}
