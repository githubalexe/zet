﻿using CityDataBase.DTO;
using CityModel.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CityDataBase.ExtensionMethods
{
    public static class CityExtensionMethods
    {
        public static CityDTO ToDTO(this City city)
        {
            return new CityDTO
            {
                Description = city.Description,
                Name = city.Name
            };
        }

        //ToDTO(city)
    }
}
