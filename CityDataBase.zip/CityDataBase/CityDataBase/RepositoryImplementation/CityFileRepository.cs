﻿using CityDataBase.DTO;
using CityDataBase.EntityFramework;
using CityDataBase.IRepository;
using CityModel.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CityDataBase.RepositoryImplementation
{
    public class CityFileRepository : ICityRepository
    {
        private UnitOfWork _context;

        public CityFileRepository()
        {

        }
        public async Task<City> GetAsync(int id)
        {
            return _context.c
        }

        public async Task<City> GetV2Async(int id)
        {
            City city = new City();
            city.Description = await File.ReadAllTextAsync("[path to file on disk]");

            return city;
        }
    }
}
