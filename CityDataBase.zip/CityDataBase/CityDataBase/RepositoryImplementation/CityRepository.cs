﻿using CityDataBase.IRepository;
using CityDataBase.Models;
using CityModel.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CityDataBase.Repository
{
    public class CityRepository : ICityRepository
    {
        private testconnectionContext _context;

        public async Task<City> GetAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<City> GetV2Async(int id)
        {
            //asynchoronous operation
            return await _context.City.FindAsync(id);

            //synchronous operation
            //return _context.City.Find(id);
        }
    }
}
