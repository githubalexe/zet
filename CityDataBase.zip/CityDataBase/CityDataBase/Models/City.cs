﻿using System;
using System.Collections.Generic;

namespace CityModel.Models
{
    public partial class City
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public string GetSomething()
        {
            return Name + Description;
        }

        //THIS IS WRONG! DONT DO THIS!
        public CityDataBase.DTO.CityDTO ToDTO()
        {
            return new CityDataBase.DTO.CityDTO
            {
                //bal bal
            };
        }
    }
}
