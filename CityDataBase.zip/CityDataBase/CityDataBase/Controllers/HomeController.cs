﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CityDataBase.DTO;
using Microsoft.AspNetCore.Mvc;
using CityDataBase.ExtensionMethods;
using CityModel.Models;

namespace CityDataBase.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : ControllerBase
    {
        //// GET api/values/5
        //[HttpGet("{id}")]
        //public ActionResult<CityDTO> Get(int id)
        //{
        //    //find my city object in DB
        //    City myObj = new City();

        //    //transform it to DTO using Extension Methods
        //    CityDTO result = myObj.ToDTO();

        //    return result;
        //}


        [HttpGet("{id}")]
        public JsonResult<CityDTO> Get(int id)
        {

        }
    }
}
