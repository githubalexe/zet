requirejs.config({
    paths: {
        jquery: "node_modules/jquery/dist/jquery.min",
        bootstrap: "node_modules/bootstrap/dist/js/bootstrap.bundle.min",
        knockout: "node_modules/knockout/build/output/knockout-latest",
        CodeMirror: "node_modules/codeMirror/lib/codemirror",
        Dropdown: "node_modules/bootstrap-select/js/bootstrap-select",
        DateTimePicker: "node_modules/bootstrap-datetime-picker/js/bootstrap-datetimepicker.min",
        ControlInput: "InputGenerator/Control/Control",
        InputGenerator: "InputGenerator/Main/InputGenerator",
        Templates: "InputGenerator/Dictionary/Templates",
        Type: "InputGenerator/Dictionary/InputsType",
        InputHelper: "InputGenerator/Helpers/InputHelper",
        TextBoxInput: "InputGenerator/Inputs/TextBoxInput",
        DropDownListInput: "InputGenerator/Inputs/DropDownListInput",
        DateTimeInput: "InputGenerator/Inputs/DateTimeInput",
        CheckBoxInput: "InputGenerator/Inputs/CheckBoxInput",
        Factory: "InputGenerator/Factory/InputFactory",
        JsonSchemaValidation: "JsonSchemaValidation/Main/JsonSchemaValidation",
        JsonHelper: "JsonSchemaValidation/Helpers/JsonHelper",
        InputsType: "JsonSchemaValidation/Dictionary/InputsType",
        InputErrorMessages: "JsonSchemaValidation/Dictionary/InputErrorMessages",
        DataTypes: "JsonSchemaValidation/Dictionary/DataTypes",
        InputFactory: "JsonSchemaValidation/Factory/InputFactory",
        Control: "JsonSchemaValidation/Control/Control",
        TextboxInput: "JsonSchemaValidation/Inputs/TextboxInput",
        DropdownListInput: "JsonSchemaValidation/Inputs/DropdownListInput",
        DatetimeInput: "JsonSchemaValidation/Inputs/DateTimeInput",
        CheckboxInput: "JsonSchemaValidation/Inputs/CheckBoxInput",
        InputValidations: "InputValidations/InputValidations",
        //
        FormGenerator: "FormGenerator/main/FormGenerator"
    }
});