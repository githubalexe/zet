define([], function() {

    var Templates = {
        TextBoxTemplate: "textboxTemplate",
        DropDownListTemplate: "dropDownListTemplate",
        DataTimeTemplate: "dateTimeTemplate",
        CheckBoxTemplate: "checkBoxTemplate"
    }

    return Templates;
});