define(["jquery", "ControlInput", "Templates"], function($, ControlInput, Templates) {

    function DateTimeInput(options) {
        var self = this;
        this.options = $.extend({}, DateTimeInput.defaultOptions, true, options);
        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        ControlInput.call(this);

        this.BuildHtml(
            self.$wrapperInput,
            Templates.DataTimeTemplate,
            dateTimeOptions = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label
            }
        );
    };

    DateTimeInput.defaultOptions = {
        $wrapperInput: $({}),
        jsonOptions: {}
    }

    return DateTimeInput;
});