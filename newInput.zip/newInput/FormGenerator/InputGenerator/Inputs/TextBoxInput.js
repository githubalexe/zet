define(["jquery", "ControlInput", "Templates"], function($, ControlInput, Templates) {

    function TextBoxInput(options) {
        var self = this;
        this.options = $.extend({}, TextBoxInput.defaultOptions, true, options);
        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        ControlInput.call(this);

        this.BuildHtml(
            self.$wrapperInput,
            Templates.TextBoxTemplate,
            textboxOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label,
                placeholder: self.jsonOptions.inputOptions.placeholder,
                name: self.jsonOptions.inputOptions.name,
                type: self.jsonOptions.inputOptions.type
            }
        );
    };

    TextBoxInput.defaultOptions = {
        $wrapperInput: $({}),
        jsonOptions: {}
    }

    return TextBoxInput;
});