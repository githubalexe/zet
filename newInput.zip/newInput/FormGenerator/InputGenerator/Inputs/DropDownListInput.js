define(["jquery", "ControlInput", "Templates"], function($, ControlInput, Templates) {

    function DropDownListInput(options, callback) {
        var self = this;
        this.options = $.extend({}, true, DropDownListInput.defaultOptions, options);
        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        ControlInput.call(this);

        this.BuildHtml(
            self.$wrapperInput,
            Templates.DropDownListTemplate,
            dropDownListOptios = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label,
                name: self.jsonOptions.inputOptions.name,
                dropdownList: [...self.jsonOptions.inputOptions.items]
            }
        );
    }

    DropDownListInput.defaultOptions = {
        $wrapperInput: $({}),
        jsonOptions: {}
    };

    return DropDownListInput;
});