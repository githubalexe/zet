define(["jquery", "ControlInput", "Templates"], function($, ControlInput, Templates) {

    function CheckBoxInput(options, ) {
        var self = this;
        this.options = $.extend({}, true, CheckBoxInput.defaultOptions, options);
        this.$wrapperInput = this.options.$wrapperInput;
        this.jsonOptions = this.options.jsonOptions;

        ControlInput.call(this);

        this.BuildHtml(
            self.$wrapperInput,
            Templates.CheckBoxTemplate,
            checkBoxOptions = {
                containerId: self.containerId,
                inputId: self.inputId,
                label: self.jsonOptions.inputOptions.label,
                items: [...self.jsonOptions.inputOptions.items]
            }
        );
    };

    CheckBoxInput.defaultOptions = {
        $wrapperInput: $({}),
        jsonOptions: {}
    };

    return CheckBoxInput;
});