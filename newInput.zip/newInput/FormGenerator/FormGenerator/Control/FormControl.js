define(["jquery"], function($) {

    var _index = null;

    function generateNewId() {
        _index = InputHelper.GenerateNewGuid();
    }

    function FormControl() {
        this.containerId =
            this.BuildHtml = function(container, template, options) {
                ko.applyBindingsToNode(container[0], {
                    template: {
                        name: template,
                        data: options
                    }
                });
                container.find("[data-bind]").removeAttr("data-bind");
            };
    }
});