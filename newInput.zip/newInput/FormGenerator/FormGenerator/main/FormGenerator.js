define(["jquery", "knockout"], function($, ko) {

    function FormGenerator() {

    };

    FormGenerator.prototype.BuildHtml = function(container, template, options) {
        ko.applyBindingsToNode(container[0], {
            template: {
                name: template,
                data: options
            }
        });
        container.find("[data-bind]").removeAttr("data-bind");
    };

    return FormGenerator;
});