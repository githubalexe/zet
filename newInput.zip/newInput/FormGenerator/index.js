define(["jquery"], function($) {

    var index = {};

    var $generateForm = $("#generateForm");
    var $formContainer = $("#formContainer");


    this.generateForm = function(inputs, validations) {

    };

    return index;
});