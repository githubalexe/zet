define([], function() {

    var InputErrorMessages = {}

    InputErrorMessages.GetErrorMessageForDataType = function(dataType) {
        var errorMessage = `The field must be a ${dataType}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForNumberMinValue = function(min) {
        var errorMessage = `The number must be bigger or equal with ${min}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForDateMinValue = function(min) {
        var errorMessage = `The date must be higher or the same with ${_convertDate(min)}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForDateMaxValue = function(max) {
        var errorMessage = `The date must be smaller or the same with ${_convertDate(max)}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForNumberMaxValue = function(max) {
        var errorMessage = `The number must be smaller or equal with ${max}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForStringMinValue = function(min) {
        var errorMessage = `Length required must be bigger or equal with ${min}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForStringMaxValue = function(max) {
        var errorMessage = `Length required must be smaller or equal with ${max}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForNumberValue = function(min, max) {
        var errorMessage = `The number must be between ${min} and ${max}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForStringValue = function(min, max) {
        var errorMessage = `Length required is between ${min} and ${max} characters!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForDateValue = function(min, max) {
        var errorMessage = `Date must be between ${_convertDate(min)} and ${_convertDate(max)}!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForRequired = function() {
        var errorMessage = `This field is required!`;

        return errorMessage;
    };

    InputErrorMessages.GetErrorMessageForRegex = function() {
        var errorMessage = `The value is incorrect!`;

        return errorMessage;
    };

    function _convertDate(date) {
        var formattedDate = new Date(date);
        var d = formattedDate.getDate();
        var m = formattedDate.getMonth();
        m += 1;
        var y = formattedDate.getFullYear();

        var date = d + "/" + m + "/" + y;
        return date;
    }

    return InputErrorMessages;
});