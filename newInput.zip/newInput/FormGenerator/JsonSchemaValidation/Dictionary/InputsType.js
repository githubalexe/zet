define([], function() {

    var InputsType = {
        Textbox: "textbox",
        Dropdown: "dropdown",
        DateTime: "dateTime",
        CheckBox: "checkBox"
    };

    return InputsType;
});