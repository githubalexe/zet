define(["jquery", "InputGenerator", "JsonSchemaValidation", "DateTimePicker", "Dropdown"], function($, InputGenerator, JsonSchemaValidation) {

    function InputValidations(options) {
        this.options = $.extend({}, true, InputValidations.defaultOptions, options);
        this.$inputsContainer = this.options.$inputsContainer;
        this.onErrorMessages = this.options.onErrorMessages;
        this.inputGeneratorCopy = null;
        this.controls = [];
    };

    InputValidations.prototype.CreateInputGenerator = function(inputs) {
        var self = this;
        var options = {
            $inputsContainer: self.$inputsContainer,
            onControlCreate: function(control) {
                self._createControl(control);
            }
        }
        var inputGenerator = new InputGenerator(options);
        inputGenerator.createByJsonValue(inputs);
        self.inputGeneratorCopy = inputGenerator;
    };

    InputValidations.prototype.CreateJsonSchemaValidation = function(inputs, values, validations) {
        var self = this;
        var options = {
            onControlErrorMessages: function(errorMessages) {
                self._getControlsErrorMessages(errorMessages);
            }
        }

        var jsonSchemaValidation = new JsonSchemaValidation(options);
        jsonSchemaValidation.CreateInputByJsonValue(
            _convertObjectToString(inputs),
            validations,
            _convertObjectToString(values)
        );
    };

    InputValidations.prototype.ValidateInputs = function(validations) {
        var self = this;
        var values = [];
        var inputs = [];
        var controlsLength = self.controls.length;
        for (var i = 0; i < controlsLength; i++) {
            let value = self.controls[i].GetInputDomElement().val(); //get values from every input

            if (value === "") {
                value = null;
            } else
            if ($.isNumeric(value)) {
                value = parseInt(value);
            }

            var inputObject = {
                name: self.controls[i].jsonOptions.inputOptions.name,
                inputType: self.controls[i].jsonOptions.type,
                dataType: self.controls[i].jsonOptions.inputOptions.type,
                items: self.controls[i].jsonOptions.inputOptions.items
            }
            var valueInputObject = {
                name: self.controls[i].jsonOptions.inputOptions.name,
                value: value
            }
            values.push(valueInputObject);
            inputs.push(inputObject);
        }
        self.CreateJsonSchemaValidation(inputs, values, validations);
    };

    InputValidations.prototype.DeleteControls = function() {
        var self = this;
        var controlsLength = self.controls.length;
        for (var i = 0; i < controlsLength; i++) {
            self.inputGeneratorCopy.deleteControl(self.controls[i].inputId);
            self.controls[i].DestroyContainer();
        }
        self.controls = [];
    };

    InputValidations.prototype._createControl = function(control) {
        var self = this;
        self.controls.push(control);
    };

    InputValidations.prototype._getControlsErrorMessages = function(errorMessagesObject) {
        var self = this;
        self.onErrorMessages(errorMessagesObject);
    };

    function _convertObjectToString(object) {
        return JSON.stringify(object, null, '\t');
    };

    InputValidations.defaultOptions = function() {
        var self = this;
        self.$inputsContainer = null;
        self.onErrorMessages = null;
    }

    return InputValidations;
})