define(["jquery", "CodeMirror", "InputValidations", "FormGenerator", "bootstrap", "Dropdown"], function($, CodeMirror, InputValidations, FormGenerator) {

    var index = {};
    var $inputsJsonSchema = $("#inputsJsonSchema");
    var $validationsJsonSchema = $("#validationsJsonSchema");
    var $errorsJsonSchema = $("#errorsJsonSchema");
    var $inputsContainer = $("#inputsContainer");
    var $generateInputsButton = $("#generateInputsButton");
    var $validateButton = $("#validateButton");
    var $warningInputSchema = $("#warningInputSchema");
    var $warningValidationSchema = $("#warningValidationSchema");
    var $clearValidateButton = $("#clearValidateButton");
    var $clearInputsButton = $("#clearInputsButton");
    var $deleteInputsButton = $("#deleteInputsButton");
    var $generateFormButton = $("#generateFormButton");
    var $formsContainer = $("#formsContainer");
    var controlsErrorMessages = [];
    var $inputsJsonSchemaEditor = CodeMirror.fromTextArea($inputsJsonSchema[0], {
        lineNumbers: true,
    });
    var $validationsJsonSchemaEditor = CodeMirror.fromTextArea($validationsJsonSchema[0], {
        lineNumbers: true,
    });
    var $errorsJsonSchemaEditor = CodeMirror.fromTextArea($errorsJsonSchema[0], {
        lineNumbers: true,
    });

    var inputValidationsTest = null;

    index.generateForm = function(inputs, validations) {
        $validationsJsonSchemaEditor.setValue(
            JSON.stringify(validations, null, '\t')
        );
        createInputValidations(inputs);
    };

    bindEvents();

    function bindEvents() {
        $generateInputsButton.on("click", function() {
            var inputsSchema = $inputsJsonSchemaEditor.getValue();
            if (inputsSchema) {
                deleteInputs();
                createInputValidations(inputsSchema);
            }
        })

        $generateFormButton.on("click", function() { //create form
            createForm();
        })

        $validateButton.on("click", function() {
            validateInputs();
        })

        $deleteInputsButton.on("click", function() {
            deleteInputs();

            controlsErrorMessages = [];
            var errorMessagesObject = {
                errorMessages: []
            }

            getControlsErrorMessagesTest(errorMessagesObject)
        })

        $inputsJsonSchemaEditor.on("change", function() {
            var value = $inputsJsonSchemaEditor.getValue();
            setWarningMessage(value, $warningInputSchema);
        })

        $validationsJsonSchemaEditor.on("change", function() {
            var value = $validationsJsonSchemaEditor.getValue();
            setWarningMessage(value, $warningValidationSchema);
        })

        $clearValidateButton.on("click", function() {
            $validationsJsonSchemaEditor.setValue("");
        })

        $clearInputsButton.on("click", function() {
            $inputsJsonSchemaEditor.setValue("");
        })
    };

    function deleteInputs() {
        inputValidationsTest.DeleteControls();
    }

    function validateInputs() {
        controlsErrorMessages = [];
        var validations = $validationsJsonSchemaEditor.getValue();
        inputValidationsTest.ValidateInputs(validations);
    };

    function createInputValidations(inputs) {
        var options = {
            $inputsContainer: $inputsContainer,
            onErrorMessages: function(errorMessage) {
                getControlsErrorMessagesTest(errorMessage);
            }
        }

        var inputValidations = new InputValidations(options);
        inputValidations.CreateInputGenerator(inputs);
        inputValidationsTest = inputValidations;
    };

    function getControlsErrorMessagesTest(errorMessagesObject) {
        if (errorMessagesObject.errorMessages.length !== 0) {
            controlsErrorMessages.push(errorMessagesObject);
        }

        $errorsJsonSchemaEditor.setValue(JSON.stringify(controlsErrorMessages, null, '\t'));
    };

    function setWarningMessage(value, $container) {

        if (isJson(value) || value === "") {
            $container.addClass("d-none");
        } else {
            $container.removeClass("d-none");
        }
    };

    function isJson(textInput) {
        try {
            JSON.parse(textInput);
        } catch (e) {
            return false;
        }
        return true;
    };

    //form
    function createForm() {

        var optionFom = {
            titleForm: "Test Title",
            cancelButton: "Cancel",
            submitButton: "Submit"
        }

        var formCreate = new FormGenerator();
        formCreate.BuildHtml($formsContainer, "formTemplate", optionFom);
    }

    return index;
});