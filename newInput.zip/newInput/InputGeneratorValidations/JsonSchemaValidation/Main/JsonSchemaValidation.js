define(["jquery", "JsonHelper", "InputFactory", "InputsType", "DataTypes", "bootstrap"], function($, JsonHelper, InputFactory, InputsType, DataTypes) {

    function JsonSchemaValidation(options) {
        this.options = $.extend({}, true, JsonSchemaValidation.defaultOptions, options);
        this.onControlErrorMessages = this.options.onControlErrorMessages;
        this.jsonOptions = {};
        this.controlsErrorMessages = [];
    };

    JsonSchemaValidation.prototype.CreateInputByJsonValue = function(inputs, validations, values) {
        var self = this;
        if (validations === "") {
            var emptyMessage = {
                errorMessages: []
            }
            self.onControlErrorMessages(emptyMessage);
        } else
        if (JsonHelper.IsJson(inputs) && JsonHelper.IsJson(validations)) {
            self.jsonOptions = {
                inputs: JSON.parse(inputs),
                values: JSON.parse(values),
                validations: JSON.parse(validations)
            }
            self._createInput();
        }
    };

    JsonSchemaValidation.prototype._createInput = function() {
        var self = this;
        var inputsArray = [...self.jsonOptions.inputs];
        var validationsArray = [...self.jsonOptions.validations];

        inputsArray.forEach(function(input) {
            var validations = null;
            var inputValidations = validationsArray.find(function(element) {
                return element.name === input.name;
            });

            if (inputValidations !== undefined) {
                if (inputValidations.validationRules !== undefined) {
                    validations = inputValidations.validationRules;
                }
            }
            var options = {
                inputName: input.name,
                inputType: input.inputType,
                items: input.items,
                dataType: input.dataType,
                validations: validations
            }
            InputFactory.CreateControl(options, function(control) {
                self._setControlValue(control, self.jsonOptions.values);
            })
        });
    };

    JsonSchemaValidation.prototype._setControlValue = function(control, values) {
        var self = this;
        var value = null;
        var inputValidations = control.validations;
        var inputValue = values.find(function(element) {
            return element.name === control.inputName;
        });

        if (inputValue !== undefined) {
            value = inputValue.value;
        }

        if (!(inputValidations)) {
            var emptyMessage = {
                errorMessages: []
            }
            self.onControlErrorMessages(emptyMessage);
        } else {

            self._setControls(control, value);
        }
    }

    JsonSchemaValidation.prototype._setControls = function(control, inputValue) {
        var self = this;
        var inputType = control.inputType;
        var inputValidations = control.validations;
        switch (inputType) {
            case InputsType.Textbox:
                {
                    self._setTextboxErrorMessages(control, inputValue, inputValidations);
                    break;
                }
            case InputsType.Dropdown:
                {
                    self._setDropDownListErrorMessages(control, inputValue, inputValidations);
                    break;
                }
            case InputsType.DateTime:
                {
                    self._setDataTimeErrorMessages(control, inputValue, inputValidations);
                    break;
                }
            case InputsType.CheckBox:
                {
                    self._setCheckBoxErrorMessages(control, inputValue, inputValidations);
                    break;
                }
            default:
                {
                    console.log("something went wrong");
                }
        }
    };

    JsonSchemaValidation.prototype._setTextboxErrorMessages = function(control, inputValue, inputValidations) {
        var self = this;
        if (inputValidations) {
            var controlInput = {
                name: control.inputName,
                errorMessages: _getErrorMessages(control, inputValue, inputValidations)
            }
            self.onControlErrorMessages(controlInput);
        }
    };

    JsonSchemaValidation.prototype._setDropDownListErrorMessages = function(control, inputValue, inputValidations) {
        var self = this;
        var valuesLength = null;
        var valuesLength = inputValue.length;

        if (valuesLength === 0) {
            valuesLength = null;
            control.dataType = DataTypes.Null;
        }

        var controlInput = getControlInput(control, valuesLength, inputValidations)
        self.onControlErrorMessages(controlInput);
    };


    JsonSchemaValidation.prototype._setCheckBoxErrorMessages = function(control, inputValue, inputValidations) {
        var self = this;
        if (inputValue === null) {
            inputValue = [];
        }
        var valuesLength = inputValue.length;

        if (valuesLength >= 1) {
            var controlInput = getControlInput(control, valuesLength, inputValidations)
            self.onControlErrorMessages(controlInput);
        }

        if (valuesLength === 0) {
            valuesLength = null;
            control.dataType = DataTypes.Null;
            var controlInput = getControlInput(control, valuesLength, inputValidations)
            self.onControlErrorMessages(controlInput);
        }

    };


    JsonSchemaValidation.prototype._setDataTimeErrorMessages = function(control, inputValue, inputValidations) {
        inputValue = _convertToDate(inputValue);
        inputValidations.min = _convertToDate(inputValidations.min);
        inputValidations.max = _convertToDate(inputValidations.max);

        var self = this;
        if (inputValidations) {
            var controlInput = {
                name: control.inputName,
                errorMessages: _getErrorMessages(control, inputValue, inputValidations)
            }
            self.onControlErrorMessages(controlInput);
        }
    };

    function getControlInput(control, inputValue, inputValidations) {
        var controlInput = {
            name: control.inputName,
            errorMessages: _getErrorMessages(control, inputValue, inputValidations)
        }

        return controlInput;
    };

    function _convertToDate(value) {
        if ((value !== null) && (value !== undefined)) {
            value = new Date(value);
        }

        return value;
    };

    function _getErrorMessages(control, inputValue, inputValidations) {
        var isControlRequired = inputValidations.required;
        var minValidation = inputValidations.min;
        var maxValidatiton = inputValidations.max;
        var regex = inputValidations.regex;
        var dataTypeValidation = control.dataType;
        var controlValueDataType = $.type(inputValue);
        var errors = [];

        errors.push(
            control.GetErrorMessageForRequired(inputValue, isControlRequired)
        );

        errors.push(
            control.GetErrorMessageForRegex(inputValue, regex)
        );

        errors.push(
            control.GetErrorMessageForDataType(controlValueDataType, dataTypeValidation)
        );

        errors.push(
            control.GetValueErrorMessage(inputValue, dataTypeValidation, minValidation, maxValidatiton)
        );

        var errorsFiltered = errors.filter(function(element) {
            return element != null;
        });

        return errorsFiltered;
    }

    JsonSchemaValidation.defaultOptions = {
        $inputsContainer: $({}),
        onControlDestroy: null,
        onControlCreate: null,
    };

    return JsonSchemaValidation;
});