﻿using DVDRentals.Repository;
using DVDRentals.Repository.MySql;
using DVDRentals.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DVDRentals
{
    public class Startup
    {
        private IConfiguration _configuration;
        public Startup(IConfiguration configuration)
        {
            _configuration = configuration;
        }
    
        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<UnitOfWork>(options => options.UseMySql(_configuration.GetConnectionString("Sakila")));
            services.AddScoped<IStoreRepository, StoreRepository>();
            services.AddScoped<IAddressRepository, AddressRepository>();
            services.AddScoped<IRentalRepository, RentalRepository>();
            services.AddScoped<IStaffRepository, StaffRepository>();
            services.AddScoped<ICustomerRepository, CustomerRepository>();
            services.AddScoped<IFilmRepository, FilmRepository>();
            services.AddScoped<ILanguageRepository, LanguageRepository>();
            services.AddScoped<IActorRepository, ActorRepository>();
            services.AddScoped<IFilmActorRepository, FilmActorRepository>();
            services.AddScoped<IInventoryRepository, InventoryRepository>();
            services.AddScoped<IPaymentRepository, PaymentRepository>();
            services.AddScoped<ICityRepository, CityRepository>();
            services.AddScoped<ICountryRepository, CountryRepository>();
            services.AddScoped<ICategoryRepository, CategoryRepository>();
            services.AddScoped<IFilmCategoryRepository, FilmCategoryRepository>();
            services.AddScoped<IFilmServices, FilmServices>();
            services.AddScoped<IRentalService, RentalService>();
            services.AddScoped<IPaymentService, PaymentService>();

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
