﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Response.Language;
using DVDRentals.Domain;

namespace DVDRentals.ExtensionMethods
{
    public static class LanguageExtensionMethods
    {
        public static LanguageResponseLite ToLanguageResponseLite(this Language language)
        {
            return new LanguageResponseLite()
            {
                LanguageId = language.LanguageId,
                Name = language.Name,
                LastUpdate = language.LastUpdate
            };

        }

        public static Language ToLanguageModel(this LanguageCreateRequest request)
        {
            return new Language()
            {
                Name = request.Name
            };

        }
    }
}
