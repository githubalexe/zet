﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Rental;
using DVDRentals.API.Response.Store;
using DVDRentals.Domain;
using System.Collections;
using System.Collections.Generic;

namespace DVDRentals.ExtensionMethods
{
    public static class RentalExtensionMethods
    {
        public static RentalResponse ToRentalResponse(this Rental rental)
        {
            if (rental == null)
            {
                return null;
            }
            else
            {
                return new RentalResponse()
                {
                    RentalId = rental.RentalId,
                    RentalDate = rental.RentalDate,
                    InventoryId = rental.InventoryId,
                    CustomerId = rental.CustomerId,
                    ReturnDate = rental.ReturnDate,
                    StaffId = rental.StaffId,
                    LastUpdate = rental.LastUpdate,
                    Film = rental.Inventory.Film.ToFilmTitleResponse()
                };
            }
        }

        public static StoreRentalResponse ToStoreRentalsResponse(this Rental rental)
        {
            if (rental == null)
            {
                return null;
            }
            else
            {
                return new StoreRentalResponse()
                {
                    RentalId = rental.RentalId,
                    RentalDate = rental.RentalDate,
                    InventoryId = rental.InventoryId,
                    CustomerId = rental.CustomerId,
                    ReturnDate = rental.ReturnDate,
                    StaffId = rental.StaffId,
                    LastUpdate = rental.LastUpdate,
                    Film = rental.Inventory.Film.ToFilmTitleResponse(),
                    Staff = rental.Staff.ToStaffPaymentResponse(),
                    Customer = rental.Customer.ToCustomerPaymentResponse()
                };
            }
        }

        public static CustomerRentalsResponse ToCustomerRentalsResponse(this Rental rental)
        {
            if (rental == null)
            {
                return null;
            }
            else
            {
                return new CustomerRentalsResponse()
                {
                    RentalId = rental.RentalId,
                    RentalDate = rental.RentalDate,
                    InventoryId = rental.InventoryId,
                    CustomerId = rental.CustomerId,
                    ReturnDate = rental.ReturnDate,
                    StaffId = rental.StaffId,
                    LastUpdate = rental.LastUpdate,
                    Film = rental.Inventory.Film.ToFilmTitleResponse(),
                    Staff = rental.Staff.ToStaffPaymentResponse(),
                };
            }
        }

        public static StaffRentalsResponse ToStaffRentalsResponse(this Rental rental)
        {
            if (rental == null)
            {
                return null;
            }
            else
            {
                return new StaffRentalsResponse()
                {
                    RentalId = rental.RentalId,
                    RentalDate = rental.RentalDate,
                    InventoryId = rental.InventoryId,
                    CustomerId = rental.CustomerId,
                    ReturnDate = rental.ReturnDate,
                    StaffId = rental.StaffId,
                    LastUpdate = rental.LastUpdate,
                    Film = rental.Inventory.Film.ToFilmTitleResponse(),
                    Customer = rental.Customer.ToCustomerPaymentResponse(),
                };
            }
        }

        public static RentalResponseLite ToRentalResponseLite(this Rental rental)
        {
            return new RentalResponseLite()
            {
                RentalId = rental.RentalId,
                RentalDate = rental.RentalDate,
                InventoryId = rental.InventoryId,
                CustomerId = rental.CustomerId,
                ReturnDate = rental.ReturnDate,
                StaffId = rental.StaffId,
                LastUpdate = rental.LastUpdate,
            };
        }

        public static Rental ToRentalModel(this RentalCreateRequest request)
        {
            return new Rental()
            {
                RentalDate = request.RentalDate,
                InventoryId = request.InventoryId,
                CustomerId = request.CustomerId,
                ReturnDate = request.ReturnDate,
                StaffId = request.StaffId
            };
        }

        public static Rental ModifyRental(this RentalUpdateRequest request, Rental rental)
        {
            rental.RentalDate = request.RentalDate;
            rental.InventoryId = request.InventoryId;
            rental.CustomerId = request.CustomerId;
            rental.ReturnDate = request.ReturnDate;
            rental.StaffId = request.StaffId;

            return rental;
        }
    }
}
