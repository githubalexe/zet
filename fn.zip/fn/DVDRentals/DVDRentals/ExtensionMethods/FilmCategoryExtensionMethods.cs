﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.UpdateRequest;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Film;
using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.ExtensionMethods
{
    public static class FilmCategoryExtensionMethods
    {
        public static FilmCategory ToFilmCategoryModel(this FilmCategoryCreateRequest request)
        {
            return new FilmCategory()
            {
                FilmId = request.FilmId,
                CategoryId = request.CategoryId
            };
        }

        public static FilmCategory ToFilmCategoryUpdate(this FilmCategoryUpdateRequest request, FilmCategory filmCtegory, int filmId)
        {
            filmCtegory.FilmId = filmId;
            filmCtegory.CategoryId = request.CategoryId;

            return filmCtegory;
        }

        public static FilmCategoryResponse ToFilmCategoryResponse(this FilmCategoryUpdateRequest request, int filmId)
        {
            return new FilmCategoryResponse()
            {
                FilmId = filmId,
                CategoryId = request.CategoryId
            };
        }

        public static FilmCategoryResponse ToFilmCategoryResponse(this FilmCategory filmCategory)
        {
            return new FilmCategoryResponse()
            {
                FilmId = filmCategory.FilmId,
                CategoryId = filmCategory.CategoryId
            };
        }
    }
}
