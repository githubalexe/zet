﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.Domain
{
    public class FilmText
    {
        public int FilmId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
