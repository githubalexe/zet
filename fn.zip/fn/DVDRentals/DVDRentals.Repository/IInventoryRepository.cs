﻿using DVDRentals.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVDRentals.Repository
{
    public interface IInventoryRepository
    {
        IQueryable<Inventory> InventoriesQuery();
        Task<IEnumerable<Inventory>> ListCopiesAsync(IQueryable<Inventory> query, int filmId, bool asNoTracking = false);
        Task<IEnumerable<Inventory>> ListStoreInventoriesAsync(IQueryable<Inventory> query, int storeId, bool asNoTracking = false);
        Task<IEnumerable<Inventory>> ListInventoriesAsync(IQueryable<Inventory> query, int storeId, int filmId, bool asNoTracking = false);
        Task<Inventory> GetInventoryAsync(int storeId, int inventoryId);
        Task<Inventory> GetInventoryAsync(int inventoryId);
        Task CreateInventoryAsync(Inventory inventory);
        Task<bool> ExistInventoryAsync(int inventoryId);
        void DeleteInventory(Inventory inventory);
        Task SaveChangesAsync();
    }
}