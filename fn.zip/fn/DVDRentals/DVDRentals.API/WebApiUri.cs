﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API
{
    public class WebApiUri
    {
        public string Uri { get; set; }
    }
}
