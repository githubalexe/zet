﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.FormRequest
{
    public class CustomerFormRequest
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public int  AddressId { get; set; }

        public string Address { get; set; }

        public string Address2 { get; set; }

        public string Distrinct { get; set; }

        public int CountryId { get; set; }

        public string Country { get; set; }

        public int CityId { get; set; }

        public string City { get; set; }

        public string PostalCode { get; set; }

        public bool Active { get; set; }

        public string Phone { get; set; }

        public DateTime CreateDate { get; set; }
    }
}
