﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class StaffVerifyRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
