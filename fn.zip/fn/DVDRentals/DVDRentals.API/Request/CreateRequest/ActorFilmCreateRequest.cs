﻿using System.ComponentModel.DataAnnotations;

namespace DVDRentals.API.Request.CreateRequest
{
    public class ActorFilmCreateRequest
    {
        [Required(ErrorMessage = "ActorId is required.")]
        public int ActorId { get; set; }
        [Required(ErrorMessage = "FilmId is required.")]
        public int FilmId { get; set; }
    }
}
