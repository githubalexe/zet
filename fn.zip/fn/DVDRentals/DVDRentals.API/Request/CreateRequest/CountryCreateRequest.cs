﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DVDRentals.API.Request.CreateRequest
{
    public class CountryCreateRequest
    {
        [Required(ErrorMessage = "Country is required.")]
        public string Country { get; set; }
    }
}
