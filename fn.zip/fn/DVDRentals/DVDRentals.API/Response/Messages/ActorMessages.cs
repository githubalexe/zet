﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace DVDRentals.API.Response.Messages
{
    public enum ActorMessages
    {
        [Description("The actor list is empty!")]
        InvalidActorList,
        [Description("The actor doesn't exist!")]
        NoActorResponse,
        [Description("The film already has this actor!")]
        AddActorFailed,
        [Description("The actor doesn't exist in this film!")]
        DeleteActorFailed,
        [Description("The actor request is NULL!")]
        InvalidActorRequest,
    }
}
