﻿using DVDRentals.API.Response.Customer;
using DVDRentals.API.Response.Rental;
using DVDRentals.API.Response.Staff;
using System;

namespace DVDRentals.API.Response.Store
{
    public class StorePaymentsResponse
    {
        public int PaymentId { get; set; }
        public int CustomerId { get; set; }
        public int StaffId { get; set; }
        public int? RentalId { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaymentDate { get; set; }
        public DateTime LastUpdate { get; set; }
        public virtual RentalResponse Rental { get; set; }
        public virtual StaffNameResponse Staff { get; set; }
        public virtual CustomerNameResponse Customer { get; set; }
    }
}
