﻿using DVDRentals.API.Request.CreateRequest;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Request.UpdateRequest;
using System;
using System.Collections.Generic;
using System.Text;

namespace DVDRentals.API.ApiMethods.ExtensionMethods
{
    public static class StoreExtensionMethods
    {
        public static StoreUpdateRequest ToStoreUpdateRequest(this StoreFormRequest request, int addressId)
        {
            return new StoreUpdateRequest
            {
                ManagerStaffId = request.ManagerStaffId,
                AddressId = addressId
            };
        }
    }
}
