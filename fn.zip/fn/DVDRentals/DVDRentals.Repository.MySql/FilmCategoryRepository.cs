﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class FilmCategoryRepository : IFilmCategoryRepository
    {
        private UnitOfWork _unitOfWork;
        public FilmCategoryRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<FilmCategory> CategoriesQuery()
        {
            IQueryable<FilmCategory> categoriesQuery = _unitOfWork.FilmCategory;
            return categoriesQuery;
        }
        public async Task<IEnumerable<FilmCategory>> FilmCategoriesListAsync(IQueryable<FilmCategory> query, int filmId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(f => f.FilmId == filmId)
                                  .Include(c => c.Category)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(f => f.FilmId == filmId)
                                  .ToListAsync();
            }
        }

        public async Task<IEnumerable<FilmCategory>> FilmsListAsync(IQueryable<FilmCategory> query, int categoryId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(c => c.CategoryId == categoryId)
                                  .Include(c => c.Category)
                                  .Include(f => f.Film)
                                  .ThenInclude(l => l.Language)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public async Task<FilmCategory> GetFilmCategoryAsync(int filmId, int categoryId)
        {
            return await _unitOfWork.FilmCategory.Where(f => f.FilmId == filmId)
                                    .Include(c => c.Category)
                                    .FirstOrDefaultAsync(c => c.CategoryId == categoryId);
        }

        public async Task<FilmCategory> GetFilmCategoryAsync(int filmId)
        {
            return await _unitOfWork.FilmCategory.Include(c => c.Category)
                                                 .FirstOrDefaultAsync(f => f.FilmId == filmId);
        }

        public async Task AddCategoryAsync(FilmCategory category)
        {
            await _unitOfWork.FilmCategory.AddAsync(category);
        }

        public void DeleteCategoryAsync(FilmCategory category)
        {
            _unitOfWork.FilmCategory.Remove(category);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }

        public void UpdateFilm (FilmCategory category)
        {
             _unitOfWork.FilmCategory.Update(category);
        }
    }
}