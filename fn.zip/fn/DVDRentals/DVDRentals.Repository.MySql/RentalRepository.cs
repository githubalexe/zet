﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DVDRentals.Domain;
using Microsoft.EntityFrameworkCore;

namespace DVDRentals.Repository.MySql
{
    public class RentalRepository : IRentalRepository
    {
        private UnitOfWork _unitOfWork;
        public RentalRepository(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IQueryable<Rental> RentalsQuery()
        {
            IQueryable<Rental> rentalsQuery = _unitOfWork.Rental;
            return rentalsQuery;
        }

        public async Task<IEnumerable<Rental>> CustomersRentalsListAsync(IQueryable<Rental> query, int customerId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(c => c.CustomerId == customerId)
                                           .Include(i => i.Inventory)
                                           .ThenInclude(f => f.Film)
                                           .Include(c => c.Customer)
                                           .Include(s => s.Staff)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(c => c.CustomerId == customerId)
                                           .Include(i => i.Inventory)
                                           .ThenInclude(f => f.Film)
                                           .Include(c => c.Customer)
                                           .Include(s => s.Staff)
                                  .ToListAsync();
            }
        }

        public async Task<IEnumerable<Rental>> InventoriesListAsync(IQueryable<Rental> query, int inventoryId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(i => i.InventoryId == inventoryId)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(i => i.InventoryId == inventoryId)
                                  .ToListAsync();
            }
        }

        public async Task<IEnumerable<Rental>> RentalsListAsync(IQueryable<Rental> query, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.ToListAsync();
            }
        }

        public async Task<IEnumerable<Rental>> StaffsRentalsListAsync(IQueryable<Rental> query, int staffId, bool asNoTracking = false)
        {
            if (asNoTracking)
            {
                return await query.Where(c => c.StaffId == staffId)
                                  .Include(i => i.Inventory)
                                  .ThenInclude(f => f.Film)
                                  .Include(c => c.Customer)
                                  .Include(s => s.Staff)
                                  .AsNoTracking()
                                  .ToListAsync();
            }
            else
            {
                return await query.Where(c => c.StaffId == staffId)
                                  .ToListAsync();
            }
        }

        public async Task<bool> RentalExistsAsync(int? rentalId)
        {
            return await _unitOfWork.Rental.AnyAsync(r => r.RentalId == rentalId);
        }

        public async Task<Rental> GetRentalAsync(int? rentalId)
        {
            return await _unitOfWork.Rental.Include(i => i.Inventory)
                                           .Include(i => i.Inventory)
                                           .ThenInclude(f => f.Film)
                                           .Include(c => c.Customer)
                                           .Include(s => s.Staff)
                                           .FirstOrDefaultAsync(r => r.RentalId == rentalId);
        }

        public async Task CreateRentalAsync(Rental rental)
        {
            await _unitOfWork.Rental.AddAsync(rental);
        }

        public void DeleteRental(Rental rental)
        {
            _unitOfWork.Rental.Remove(rental);
        }

        public async Task SaveChangesAsync()
        {
            await _unitOfWork.SaveChangesAsync();
        }
    }
}