﻿$(document).ready(function () {

    var $deleteCustomer = $("#deleteCustomer");
    var $customersSearchContainer = $("#customersSearchContainer");
    var $customerModalContainer = $("#customerModalContainer");
    var $toggleButton = $(".toggle-button");
    var $customersGrid = $("#customersGrid");

    setSearchItems();


    $deleteCustomer.prop("disabled", true);

    $toggleButton.on("click", function () {

        if ($customersGrid.data("kendoGrid").selectedKeyNames().length === 0) {

            $deleteCustomer.prop("disabled", true);
            $deleteCustomer.removeClass("item-color");

        }
        else {

            $deleteCustomer.addClass("item-color");
            $deleteCustomer.prop("disabled", false);
        }

    });

    $deleteCustomer.on("click", function () {

        var optionsGrid = {
            grid: "customersGrid",
            id: "CustomerId",
            name: "Name"
        }

        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $customerModalContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Customer",
            idsLength: numberOfIds.length,
            url: "/Customer/Delete",
            dataJson: {
                customersIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }


        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });


    function setSearchItems() {
        var options = {

            $container: $customersSearchContainer,
            $kendoGrid: $("#customersGrid"),

            buttonFilters: [
                {
                    field: "All",
                    operator: "",
                    value: "",
                    display: "All"
                },
                {
                    field: "titleField",
                    display: "Status"
                },
                {
                    field: "Active",
                    operator: "eq",
                    value: "Active",
                    display: "Active"
                },
                {
                    field: "Active",
                    operator: "eq",
                    value: "Inactive",
                    display: "Inactive"
                },

            ],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "Name",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Email",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "CreateDate",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "Active",
                            operator: "contains",
                            value: "",
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }

});