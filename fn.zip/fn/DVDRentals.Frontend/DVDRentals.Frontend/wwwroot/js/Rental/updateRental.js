﻿$(document).ready(function () {

    var $rentalDate = $("#rentalDate");
    var $returnDate = $("#returnDate");
    var $form = $("#updateRentalForm"); 

    var kendoFields = [
        {
            id: "rentalDate",
            kendoType: "kendoDatePicker"
        },
        {
            id: "returnDate",
            kendoType: "kendoDatePicker"
        }

    ];

    setKendoalidation(kendoFields);

    function setKendoalidation(kendoFields) {

        var options = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(options);

    };

    changeDate();

    function changeDate() {

        $rentalDate.bind("change", function () {

            var $chosenDateValue = $(this).val();
            var presentDate = new Date();

            $returnDate.data("kendoDatePicker").min($chosenDateValue);
            $returnDate.data("kendoDatePicker").value($chosenDateValue);

            if ($returnDate.val() === "") {

                $returnDate.data("kendoDatePicker").min(presentDate);
                $returnDate.data("kendoDatePicker").value(presentDate);
            }

        });

    }

    var presentDate = new Date();

    $rentalDate.data("kendoDatePicker").setOptions({
        max: presentDate,
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

    $returnDate.data("kendoDatePicker").setOptions({
        min: presentDate,
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

    $returnDate.data("kendoDatePicker").min($rentalDate.val());

});