﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#createRentalForm");
    var $filmId = $("#filmComboBox");
    var $countryId = $("#countryId");
    var $cityId = $("#cityId");
    var $inventoryId = $("#inventoryId");
    var $rentalDate = $("#rentalDate");
    var $paymentDate = $("#paymentDate");
    var kendoFields = [
        {
            id: "staffId",
            kendoType: "kendoComboBox"
        },
        {
            id: "filmComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "customerComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "rentalDate",
            kendoType: "kendoDatePicker"
        },
        {
            id: "inventoryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },

    ];

    changeDate();
    setKendoCity();
    setKendoCustomer(kendoFields);

    $inventoryId.kendoComboBox({
        dataTextField: "Text",
        dataValueField: "Value"
    });

    $filmId.on("change", function () {

        var filmId = $(this).val();

        if ($.isNumeric(filmId)) {

            $inventoryId.data("kendoComboBox").setDataSource();
            getInventories(filmId);

        }
        else {
            $inventoryId.data("kendoComboBox").setDataSource();
        }

    });

    $kListFilter.addClass("d-none");

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");

        var isCustomer = $activeform.data("kendoDropDownList").value();

        if (isCustomer === "Yes") {

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "customerComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
                {
                    id: "inventoryId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "paymentDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            $(".customer-field").prop("required", true);

            setKendoCustomer(kendoFields);

        }
        else {
            $(".customer-field").prop("required", false);

            var kendoFields = [
                {
                    id: "staffId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "countryId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "cityId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
                {
                    id: "paymentDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            setKendoCustomer(kendoFields);
        }

    });

    function setKendoCustomer(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

    function getInventories(filmIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Inventory/GetFilmInventories",
            data: {
                filmId: filmIdValue
            },
        })
            .done(function (data) {
                var dataLength = data.length;

                for (var i = 0; i < dataLength; i++) {

                    var inventoryId = {};

                    inventoryId.InventoryId = data[i].InventoryId;

                    getInventoryRentals(inventoryId.InventoryId);

                }

            })
            .fail(function () {
                self.options.onFail();
            })
    }

    function getInventoryRentals(inventoryIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Rental/GetInventoryRentals",
            data: {
                inventoryId: inventoryIdValue
            },
        })
            .done(function (data) {

                if (data === null) {

                    $inventoryId.data("kendoComboBox").dataSource.add({
                        Text: inventoryIdValue.toString(),
                        Value: inventoryIdValue
                    });

                }
                else {

                    var isRented = true;

                    for (var i = 0; i < data.length; i++) {

                        var returnDate = {};

                        returnDate.ReturnDate = data[i].ReturnDate;

                        if (returnDate.ReturnDate === null) {

                            isRented = false;

                            break;
                        }
                    }

                    if (isRented === true) {


                        $inventoryId.data("kendoComboBox").dataSource.add({
                            Text: inventoryIdValue.toString(),
                            Value: inventoryIdValue
                        });
                    }
                }

            })

            .fail(function () {
                console.log("eroare");
            })
    }

    function setKendoCity() {

        var options = {
            $country: $countryId,
            $city: $cityId,
            setCity: false
        };

        new Cities(options);

    };

    function changeDate() {

        $rentalDate.bind("change", function () {

            var $chosenDateValue = $(this).val();
            var presentDate = new Date();

            $paymentDate.data("kendoDatePicker").min($chosenDateValue);
            $paymentDate.data("kendoDatePicker").value($chosenDateValue);

            if ($paymentDate.val() === "") {

                $paymentDate.data("kendoDatePicker").min(presentDate);
                $paymentDate.data("kendoDatePicker").value(presentDate);
            }

        });

    }

    var presentDate = new Date();

    $rentalDate.data("kendoDatePicker").setOptions({
        max: presentDate,
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

    $paymentDate.data("kendoDatePicker").setOptions({
        min: presentDate,
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

});