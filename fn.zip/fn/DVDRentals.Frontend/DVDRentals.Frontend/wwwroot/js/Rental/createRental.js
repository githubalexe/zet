﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $activeform = $("#rentalActiveForm");
    var $customerNameContainer = $("#customerNameContainer");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#createRentalForm");
    var $filmId = $("#filmComboBox");
    var $countryId = $("#countryId");
    var $cityId = $("#cityId");
    var $inventoryId = $("#inventoryId");

    $inventoryId.kendoComboBox({
        dataTextField: 'Text',
        dataValueField: 'Value'
    });

    $filmId.on("change", function () {

        var filmId = $(this).val();

        if ($.isNumeric(filmId)) {

            $inventoryId.data("kendoComboBox").setDataSource();
            getInventories(filmId);

        }
        else {
            $inventoryId.data("kendoComboBox").setDataSource();
        }

    });

    $kListFilter.addClass("d-none");

    var kendoFields = [
        {
            id: "staffId",
            kendoType: "kendoComboBox"
        },
        {
            id: "filmComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "customerComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "rentalDate",
            kendoType: "kendoDatePicker"
        },
        {
            id: "inventoryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },

    ];

    setKendoCity();
    setKendoCustomer(kendoFields);

    $activeform.on("change", function () {
        $containerForm.slideToggle("slow");
        $customerNameContainer.toggleClass("display-none");

        var isCustomer = $activeform.data("kendoDropDownList").value();

        if (isCustomer === "Yes") {

            var kendoFields = [
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "customerComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
                {
                    id: "inventoryId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "paymentDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            $(".customer-field").prop("required", true);

            setKendoCustomer(kendoFields);

        }
        else {
            $(".customer-field").prop("required", false);

            var kendoFields = [
                {
                    id: "staffId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "filmComboBox",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "countryId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "cityId",
                    kendoType: "kendoComboBox"
                },
                {
                    id: "rentalDate",
                    kendoType: "kendoDatePicker"
                },
                {
                    id: "paymentDate",
                    kendoType: "kendoDatePicker"
                },
            ];

            setKendoCustomer(kendoFields);
        }

    });

    function setKendoCustomer(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

    function getInventories(filmIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Inventory/GetFilmInventories",
            data: {
                filmId: filmIdValue
            },
        })
            .done(function (data) {
                var dataLength = data.length;

                for (var i = 0; i < dataLength; i++) {

                    var inventoryId = {};

                    inventoryId.InventoryId = data[i].InventoryId;

                    getInventoryRentals(inventoryId.InventoryId);

                }

            })
            .fail(function () {
                self.options.onFail();
            })
    }

    function getInventoryRentals(inventoryIdValue) {

        return $.ajax({
            type: "GET",
            url: "/Rental/GetInventoryRentals",
            data: {
                inventoryId: inventoryIdValue
            },
        })
            .done(function (data) {

                if (data === null) {

                    $inventoryId.data("kendoComboBox").dataSource.add({
                        Text: inventoryIdValue.toString(),
                        Value: inventoryIdValue
                    });

                }
                else {

                    var isRented = true;

                    for (var i = 0; i < data.length; i++) {

                        var returnDate = {};

                        returnDate.ReturnDate = data[i].ReturnDate;

                        if (returnDate.ReturnDate === null) {

                            isRented = false;

                            break;
                        }
                    }

                    if (isRented === true) {


                        $inventoryId.data("kendoComboBox").dataSource.add({
                            Text: inventoryIdValue.toString(),
                            Value: inventoryIdValue
                        });
                    }
                }

            })

            .fail(function () {
                console.log("eroare");
            })
    }

    function setKendoCity() {

        var options = {
            $country: $countryId,
            $city: $cityId,
            setCity: false
        };

        new Cities(options);

    };

    ////
    //  var $rentalId = $("#rentalId");
    //  var $rentalDate = $("#rentalDate");

    //  var presentDate = new Date();

    //  var $paymentId = $("#paymentId");

    //  $rentalId.kendoDatePicker({
    //      value: presentDate,
    //      max: presentDate,
    //      format: "dd/MM/yyyy",
    //      culture: "en-GB",
    //      month: {
    //          empty: '<div class="k-state-disabled">#= data.value #</div>'
    //      }

    //  }).data("kendoDatePicker");

    //var merge=  $paymentId.kendoDatePicker({
    //      value: presentDate,
    //      format: "dd/MM/yyyy",
    //      culture: "en-GB",
    //      month: {
    //          empty: '<div class="k-state-disabled">#= data.value #</div>'
    //      }

    //  }).data("kendoDatePicker");

    //  $rentalId.bind("change", function () {

    //      var x = new Date($(this).val());

    //      //var dateLimit = new Date(new Date().setDate(x.getDate() - 30));

    //      //d.setDate(new Date(x.getDate() - 1));

    //      merge.min(x);

    //  });


    var $rentalDate = $("#rentalDate").data("kendoDatePicker");
    var presentDate = new Date();

    $rentalDate.max(presentDate);
    //$rentalDate.kendoDatePicker({

    //    month: {
    //        empty: '<div class="k-state-disabled">#= data.value #</div>'
    //    }
    //})


});