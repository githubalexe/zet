﻿$(document).ready(function () {

    var $deletePayment = $("#deletePayment");
    var $paymentDeleteContainer = $("#paymentDeleteContainer");
    var $deleteButton = $("#deleteRentalButton");
    var $rentalId = $("#rentalId");
    var $paymentSearchContainer = $("#paymentSearchContainer");
    var $toggleButton = $(".toggle-button");
    var $rentalPaymentsGrid = $("#rentalPaymentsGrid");

    setDeleteButton();

    function setDeleteButton() {

        var options = {
            $deleteButton: $deletePayment,
            $toggleDeleteButton: $toggleButton,
            $grid: $rentalPaymentsGrid,
            messageForOne: "Delete Payment",
            messageForMany: "Delete Payments"
        }

        new DeleteButton(options);
    }

    $deletePayment.on("click", function () {

        var optionsGrid = {
            grid: "rentalPaymentsGrid",
            id: "PaymentId",
            name: "PaymentId"
        }

        var entityGrid = new EntityGrid(optionsGrid);
        var numberOfIds = entityGrid.getSelectedIds();

        var options = {
            $container: $paymentDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Payment",
            idsLength: numberOfIds.length,
            url: "/Rental/DeletePayments",
            dataJson: {
                paymentsIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });

    $deleteButton.on("click", function () {
        console.log($rentalId.text());
        var options = {
            $container: $paymentDeleteContainer,
            modelName: "<label class='active-entity'>" + $rentalId.text() + "</label>",
            entity: "Rental",
            idsLength: 1,
            url: "/Rental/Delete",
            dataJson: {
                rentalsIds: parseInt($rentalId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Rental/Index";
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        };

        new DeleteModal(options);

        $("#deleteModal").modal("show");
    });

    setSearchItems();

    function setSearchItems() {
        var options = {

            $container: $paymentSearchContainer,
            $kendoGrid: $("#rentalPaymentsGrid"),
            filterButton: false,
            buttonFilters: [],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "PaymentId",
                            operator: "eq",
                            value: 0
                        },
                        {
                            field: "Amount",
                            operator: "contains",
                            value: ""
                        },
                        {
                            field: "PaymentDate",
                            operator: "contains",
                            value: ""
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }
});