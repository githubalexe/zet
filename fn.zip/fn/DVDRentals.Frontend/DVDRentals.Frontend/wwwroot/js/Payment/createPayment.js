﻿$(document).ready(function () {

    var $form = $("#rentalPaymentForm");

    var kendoFields = [
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },

    ];

    setKendoValidatior(kendoFields);

    function setKendoValidatior(kendoFields) {

        var options = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(options);

    };

});