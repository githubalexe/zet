﻿$(document).ready(function () {

    var $form = $("#rentalPaymentForm");
    var $paymentDate = $("#paymentDate");
    var kendoFields = [
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },

    ];

    $paymentDate.data("kendoDatePicker").setOptions({
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

    setKendoValidatior(kendoFields);

    function setKendoValidatior(kendoFields) {

        var options = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(options);

    };

});