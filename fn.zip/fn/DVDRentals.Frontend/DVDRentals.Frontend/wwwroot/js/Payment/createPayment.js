﻿$(document).ready(function () {

    var $form = $("#rentalPaymentForm");
    var $paymentDate = $("#paymentDate");
    var $rentalId = $("#rentalId");
    var $amountId = $("#amountId");

    var kendoFields = [
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },
        {
            id: "amountId",
            kendoType: "kendoNumericTextBox"
        },

    ];

    $paymentDate.data("kendoDatePicker").setOptions({
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

    setKendoValidatior(kendoFields);

    function setKendoValidatior(kendoFields) {

        var options = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(options);

    };

    getRental(parseInt($rentalId.val()));

    function getRental(rentalValueId) {
        var rentalDate = {};

        return $.ajax({
            type: "GET",
            url: "/Rental/GetRental/",
            data: {
                rentalId: rentalValueId
            }

        })
            .done(function (data) {

                rentalDate.RentalDate = data.RentalDate;

                $paymentDate.data("kendoDatePicker").setOptions({
                    min: rentalDate.RentalDate,
                    month: {
                        empty: '<div class="k-state-disabled">#= data.value #</div>'
                    }
                });

            })
            .fail(function () {
                console.log("fail");
            })

    }

    $amountId.on("keypress", function (e) {

        if (IsTextSelected(this) == false && e.keyCode !== kendo.keys.ENTER) {
            var character = String.fromCharCode(e.keyCode)
            var newValue = this.value + character;
            if (isNaN(newValue) || parseFloat(newValue) * 100 % 1 > 0) {
                e.preventDefault();
                return false;
            }
            if (parseFloat(newValue) > 1000) {
                e.preventDefault();
                return false;
            }
        }
    });

    function IsTextSelected(input) {
        if (typeof input.selectionStart == "number") {
            return input.selectionStart == 0 && input.selectionEnd == input.value.length;
        } else if (typeof document.selection != "undefined") {
            input.focus();
            return document.selection.createRange().text == input.value;
        }
    }

    $(".k-numeric-wrap span:eq(0)").remove();//merge




    //test();

    //function test() {

    //    var isTrue = false;

    //    $amountId.on("keypress", function (e) {

    //        var value = $(this).val();
    //        var character = String.fromCharCode(e.keyCode);

    //        if (character === ".") {
    //            console.log("in punct");
    //            isTrue = true;
    //            return true;
    //        }

    //        if (value.includes(".") === false) {

    //            console.log("il include");

    //            isTrue = false;
    //        }
      

    //        if (isTrue === false) {
    //            console.log("in false cu 100");
    //            if (parseInt(value) > 100) {

    //                return false;
    //            }

    //        }


    //    });

    //}

    //function existPoint(value) {

    //    for (var i = 0; i < value.length; i++) {

    //        if (value === ".") {
    //            console.log("are punct");
    //            return true;
    //        }

    //    }

    //    return false;
    //}









    //$amountId.remove(".k-warning");

    //$("input[data-role='numerictextbox']").attr('maxlength', '4');

    //$amountId.on("keypress", function () {

    //    var value = $(this).val();
    //    var lastChar = value.substr(value.length - 1);

    //    if (value.length === 4) {
    //        if (lastChar !== ".") {
    //            value = value.slice(0, -1);
    //            $(this).val(value);
    //            lastChar = value.substr(value.length - 1);

    //            if (lastChar === ".") {

    //                $("input[data-role='numerictextbox']").attr('maxlength', '6');

    //            }

    //        }

    //    }
    //})


    //$amountId.data("kendoNumericTextBox").toString(123.33,"c0");

    //$amountId.on('keypress', function () {

    //    this.value = this.value
    //        .replace(/[^\d.]/g, '')             // numbers and decimals only
    //        .replace(/(^[\d]{10})[\d]/g, '$1')   // not more than 2 digits at the beginning
    //        .replace(/(\..*)\./g, '$1')         // decimal can't exist more than once
    //        .replace(/(\.[\d]{1})./g, '$1');    // not more than 4 digits after decimal

    //});



    //$amountId.on("focusout", function () {

    //    var value = $(this).val();

    //    var isFalse = false;

    //    if (value[0] === "0") {

    //        for (var i = 1; i < value.length; i++) {

    //            if (value[i] === "0" && value[i - 1] !== "0") {
    //                isFalse = true;
    //                break;
    //            }
    //        }

    //    }

    //    console.log("intra");

    //    if (isFalse === true) {
    //        $(this).val("0." + value.charAt(value.length - 3));
    //    }

    //});


    //$amountId.on("focusout", function () {

    //    var value = $(this).val();

    //    if ((value.substr(0, 1) === "0")) {

    //        if ((value.substr(0, 2) !== "0.")) {
    //            $(this).val("0");
    //        }

    //        else {
    //            if (value.length > 4) {

    //                $(this).val(value.substr(0, 4));
    //            }
    //        }

    //    }

    //    else {
    //        if (parseInt(value) > 10 && parseInt(value) < 100) {

    //            $(this).val(value.substr(0, 5));
    //        }

    //        if (parseInt(value) > 100 && parseInt(value) < 1000) {

    //            $(this).val(value.substr(0, 6));
    //        }
    //    }


    //    //format: "0.00"

    //});


    //$amountId.on("keyup", function () {

    //    var regex = /^[^a-zA-Z]+$/;

    //    if (regex.test($(this).val()) == true) {
    //        console.log("nu este");

    //    } else {
    //        $(this).val("");
    //    }



    //    //if (value)

    //});


});