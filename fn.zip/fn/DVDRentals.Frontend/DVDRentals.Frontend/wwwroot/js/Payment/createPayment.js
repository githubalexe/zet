﻿$(document).ready(function () {

    var $form = $("#rentalPaymentForm");
    var $paymentDate = $("#paymentDate");
    var $rentalId = $("#rentalId");
    var $amountId = $("#amountId");

    var kendoFields = [
        {
            id: "paymentDate",
            kendoType: "kendoDatePicker"
        },

    ];

    $paymentDate.data("kendoDatePicker").setOptions({
        month: {
            empty: '<div class="k-state-disabled">#= data.value #</div>'
        }
    });

    setKendoValidatior(kendoFields);

    function setKendoValidatior(kendoFields) {

        var options = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(options);

    };

    getRental(parseInt($rentalId.val()));

    function getRental(rentalValueId) {
        var rentalDate = {};

        return $.ajax({
            type: "GET",
            url: "/Rental/GetRental/",
            data: {
                rentalId: rentalValueId
            }

        })
            .done(function (data) {

                rentalDate.RentalDate = data.RentalDate;

                $paymentDate.data("kendoDatePicker").setOptions({
                    min: rentalDate.RentalDate,
                    month: {
                        empty: '<div class="k-state-disabled">#= data.value #</div>'
                    }
                });

            })
            .fail(function () {
                console.log("fail");
            })

    }

    $amountId.on("focusout", function () {

        var value = $(this).val();

        if ((value.substr(0, 1) === "0")) {

            if ((value.substr(0, 2) !== "0.")) {
                $(this).val("0");
            }

            else {
                if (value.length > 4) {

                    $(this).val(value.substr(0, 4));
                }
            }

        }

        else {
            if (parseInt(value) > 10 && parseInt(value) < 100) {

                $(this).val(value.substr(0, 5));
            }

            if (parseInt(value) > 100 && parseInt(value) < 1000) {

                $(this).val(value.substr(0, 6));
            }
        }


        //format: "0.00"

    });

});