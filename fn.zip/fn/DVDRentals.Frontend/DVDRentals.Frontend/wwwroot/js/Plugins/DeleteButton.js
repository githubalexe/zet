﻿$(function () {

    DeleteButton = function (options) {
        this.options = $.extend({}, true, DeleteModal.options, options);

        this.setDeleteButton();
    };

    DeleteButton.prototype.setDeleteButton = function () {

        var self = this;

        self.options.$toggleDeleteButton.on("click", function () {

            if (self.options.$grid.data("kendoGrid").selectedKeyNames().length === 0) {

                self.options.$deleteButton.text(self.options.messageForOne);

                self.options.$deleteButton.prop("disabled", true);
                self.options.$deleteButton.removeClass("item-color");

            }
            else if (self.options.$grid.data("kendoGrid").selectedKeyNames().length === 1) {

                self.options.$deleteButton.text(self.options.messageForOne);

                self.options.$deleteButton.addClass("item-color");
                self.options.$deleteButton.prop("disabled", false);
            }
            else if (self.options.$grid.data("kendoGrid").selectedKeyNames().length > 1) {

                self.options.$deleteButton.text(self.options.messageForMany);

                self.options.$deleteButton.addClass("item-color");
                self.options.$deleteButton.prop("disabled", false);
            }

        });

    };

    DeleteButton.options = {

        $deleteButton: $({}),
        $toggleDeleteButton: $({}),
        $grid: $({}),
        messageForOne: $({}),
        messageForMany: $({})

    };

}());