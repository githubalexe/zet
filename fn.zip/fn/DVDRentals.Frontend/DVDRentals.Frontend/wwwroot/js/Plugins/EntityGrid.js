﻿$(function () {

    EntityGrid = function (options) {

        this.grid = options.grid;
        this.id = options.id;
        this.name = options.name;

        this.$kendoGridData = $("#" + this.grid).data("kendoGrid");
        this.$grid = $("#" + this.grid + " tr.k-state-selected");

        this.selectedItems = [];
        this.modelNameorId = "";
    };

    EntityGrid.prototype.getSelectedIds = function () {

        var self = this;

        for (var i = 0; i < self.$grid.length; i++) {

            var item = self.$kendoGridData.dataItem(self.$grid[i]);

            self.selectedItems.push(item[self.id]);
        }

        return self.selectedItems;
    };

    EntityGrid.prototype.setSelectedItems = function () {

        var self = this;

        for (var i = 0; i < self.$grid.length; i++) {

            var item = self.$kendoGridData.dataItem(self.$grid[i]);

            if (i === self.$grid.length - 1) {

                self.modelNameorId += "<label class='active-entity'>" + item[self.name] + "&nbsp" + "</label>";
            }
            else {
                self.modelNameorId += "<label class='active-entity'>" + item[self.name] + ",&nbsp" + "</label>";
            }
        }

        return self.modelNameorId;
    };

    EntityGrid.prototype.uncheckedItems = function () {

        this.$kendoGridData.clearSelection();
    };

    EntityGrid.prototype.refreshGrid = function () {

        this.$kendoGridData.refresh();
        this.$kendoGridData.dataSource.read();
   
    };

}());