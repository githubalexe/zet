﻿$(function () {

    KendoValidation = function (options) {

        this.$form = options.$form;
        this.kendoFileds = options.kendoFileds;

        this.IsData();
        this.setRequired();
    };

    KendoValidation.prototype.IsData = function () {

        var self = this;

        for (var i = 0; i < self.kendoFileds.length; i++) {

            var $kendoField = $("#" + self.kendoFileds[i].id);

            if (self.kendoFileds[i].kendoType === "kendoComboBox") {

                self.setFields($kendoField, self.kendoFileds[i].id, self.kendoFileds[i].kendoType);

            }


            if (self.kendoFileds[i].kendoType === "kendoDatePicker") {

                self.setKendoDatePicker($kendoField, self.kendoFileds[i].id);

            }
        }

    };

    KendoValidation.prototype.setFields = function ($field, id, type) {

        var kendoValue;
        
        $field.on("change", function () {

            kendoValue = $field.data(type).dataItem();

            if (typeof kendoValue !== "undefined") {

                $("#" + id + "-error").remove();
            }

        });

        $field.on("focusout", function () {

            if (typeof kendoValue === "undefined") {

                $field.data(type).value("");
            }

        });
    };

    KendoValidation.prototype.setRequired = function () {

        var self = this;

        var ids = "";

        for (var i = 0; i < self.kendoFileds.length; i++) {

            if (i === self.kendoFileds.length - 1) {
                ids = ids + "#" + self.kendoFileds[i].id;
            }
            else {

                ids = ids + "#" + self.kendoFileds[i].id + ", ";
            }

        }

        self.$form.data("validator").settings.ignore = ":hidden:not(" + ids + ")";
    };

    KendoValidation.prototype.setKendoDatePicker = function ($datePicker) {

        var $kendoDatePicker = $datePicker.data("kendoDatePicker");
        var todayDate = new Date();

        $kendoDatePicker.bind("change", function () {

            var value = this.value();

            if (value === null) {

                $datePicker.data("kendoDatePicker").value(todayDate);
    
            }

        });

    };

}());
