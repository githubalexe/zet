﻿$(function () {

    SearchLabel = function (options) {

        this.$container = options.$container
        this.$kendoGrid = options.$kendoGrid;
        this.buttonFilters = options.buttonFilters;
        this.orFilters = options.orFilters;
        this.filterButton = options.filterButton;

        this.filterObject = {
            logic: "or", filters: []
        };

        this.nameFilterButton = [];

        this.buildBody();
        this.selFilterButton();
        this.searchItem();
        this.setFilterButtons();
        this.setSelectedFilters();

    }

    SearchLabel.prototype.selFilterButton = function () {
        if (this.filterButton === false) {

            $("#searchFilterButton").addClass("d-none");
        }
    };

    SearchLabel.prototype.buildBody = function () {

        var searchBody = `<div class="search-container float-sm-left">
                        <input class="form-control search " type="text" id="searchTextBox" placeholder="Search" id="searchFilm" aria-label="Search">
                            <button type="button" class="close d-none" id="deleteSearchInput" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div id="searchFilterButton" class="btn-group float-sm-left search-button">
                            <button type="button" class="btn button" id="filterButton">All</button>
                            <button type="button" class="btn dropdown-toggle dropdown-toggle-split button toggle-button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu dropdown-button"></div>
                        </div>`

        this.$container.append(searchBody);
    };

    SearchLabel.prototype.setFilterButtons = function () {
        var self = this;
        var $filterButton = $(".dropdown-menu", this.$container);
        var button = "";

        for (var i = 0; i < self.buttonFilters.length; i++) {
            if (self.buttonFilters[i].field === "titleField") {
                button = `<div><label class='fild-title'>${self.buttonFilters[i].display}</label >
                                    <div class="hr-style"></div></div>`;
                $filterButton.append(button);
            }
            else {
                if (i === 0) {
                    button = `<div class='dropdown-item dropdown-list-button item-color'>
                      <input class="checkbox-style" id="allCheckbox" type = "checkbox">
                      <label class="item filter search-filter-button">${self.buttonFilters[i].display}</label> </div >`;
                    $filterButton.append(button);

                } else {
                    button = `<div class='dropdown-item dropdown-list-button item-color'>
                      <input class="checkbox-style" type = "checkbox">
                      <label class="item filter search-filter-button">${self.buttonFilters[i].display}</label> </div >`;
                    $filterButton.append(button);
                }
            }
        }
    };

    SearchLabel.prototype.searchItem = function () {
        var self = this;

        $("#searchTextBox").on("keyup", function () {

            var val = $(this).val();
            setCloseButton(val);

            self.setMultipleFilters(val);
        });

        $(".close").on("click", function () {
            $(".search").val("");
            setCloseButton("");
            self.setMultipleFilters("");
        });
    };

    function setCloseButton(value) {

        var $deleteSearchInput = $("#deleteSearchInput");

        if (value !== "") {

            $deleteSearchInput.removeClass("d-none");

        } else {

            $deleteSearchInput.addClass("d-none");
        }

    }

    SearchLabel.prototype.setMultipleFilters = function (val) {
        var self = this

        for (var i = 0; i < this.orFilters[0].filters.length; i++) {

            if ($.type(self.orFilters[0].filters[i].value) !== "string") {
                var integerValue = parseInt(val);


                if (isNaN(integerValue)) {

                    self.orFilters[0].filters[i].value = 0;
                }
                else {
                    self.orFilters[0].filters[i].value = integerValue;
                }

            } else {

                self.orFilters[0].filters[i].value = val;
            }
        }


        self.$kendoGrid.data("kendoGrid").dataSource.filter(self.orFilters);
    };

    SearchLabel.prototype.setSelectedFilters = function () {

        var self = this;
        var indexField = 0;
        var filterName = "";

        $(".checkbox-style").on("click", function () {

            indexField = $(this).parent().index();
            filterName = $(this).siblings().text();

            if ($(this).is(':checked')) {

                self.setButton(filterName);

                if (self.buttonFilters[indexField].field === "All") {

                    $(".checkbox-style").prop('checked', false);

                    $(this).prop("checked", true);

                    self.filterObject.filters = [];

                    if (self.orFilters.length > 1) {

                        for (var i = 1; i <= self.orFilters.length; i++) {

                            self.orFilters.splice($.inArray(self.orFilters[i], self.orFilters), 1);
                        }

                    }

                    self.$kendoGrid.data("kendoGrid").dataSource.filter(self.orFilters);


                }
                else {

                    $("#allCheckbox").prop('checked', false);

                    if (self.filterObject.filters.length !== 0) {

                        var isFalse = false;

                        for (var i = 1; i < self.orFilters.length; i++) {

                            if (self.orFilters[i].filters[0].field === self.buttonFilters[indexField].field) {
                                self.orFilters[i].filters.push({
                                    field: self.buttonFilters[indexField].field,
                                    operator: self.buttonFilters[indexField].operator,
                                    value: self.buttonFilters[indexField].value
                                });
                                isFalse = true;
                            }
                        }

                        if (isFalse === false) {

                            var element = {
                                logic: "or", filters: []
                            };

                            element.filters.push(
                                {
                                    field: self.buttonFilters[indexField].field,
                                    operator: self.buttonFilters[indexField].operator,
                                    value: self.buttonFilters[indexField].value
                                });

                            self.orFilters.push(element);
                        }

                        self.$kendoGrid.data("kendoGrid").dataSource.filter(self.orFilters);

                    } else {

                        self.filterObject.filters.push(

                            {
                                field: self.buttonFilters[indexField].field,
                                operator: self.buttonFilters[indexField].operator,
                                value: self.buttonFilters[indexField].value
                            });

                        self.orFilters.push(self.filterObject);

                        self.$kendoGrid.data("kendoGrid").dataSource.filter(self.orFilters);

                    }
                }

            } else {

                if (self.buttonFilters[indexField].field !== "All") {

                    for (var i = 1; i < self.orFilters.length; i++) {

                        for (var j = 0; j < self.orFilters[i].filters.length; j++) {


                            if (self.orFilters[i].filters[j].value.toString() === filterName) {
                                var x = {};


                                x = self.orFilters[i].filters[j];

                                self.orFilters[i].filters.splice($.inArray(x, self.orFilters[i].filters), 1);

                                if (self.orFilters[i].filters.length === 0) {

                                    self.orFilters.splice($.inArray(self.orFilters[i], self.orFilters), 1);
                                }

                                break;
                            }
                        }
                    }

                    self.$kendoGrid.data("kendoGrid").dataSource.filter(self.orFilters);
                    self.deleteNameFilterButton(filterName);

                }
            }
        });
    };

    SearchLabel.prototype.setButton = function ($filterName) {
        var self = this;

        var nameButton = "";

        if ($filterName === "All") {
            self.nameFilterButton = [];

            $("#filterButton").text("All");

        } else {

            if (self.nameFilterButton.length === 0) {

                self.nameFilterButton.push($filterName);

                nameButton = self.nameFilterButton[0];

                $("#filterButton").text(nameButton);

            } else {
                var isFalse = false;

                for (var i = 0; i < self.nameFilterButton.length; i++) {

                    if (self.nameFilterButton[i] === $filterName) {
                        isFalse = true;
                    }
                }

                if (isFalse === false) {
                    self.nameFilterButton.push($filterName);
                }

                if (self.nameFilterButton.length > 2) {

                    $("#filterButton").text(self.nameFilterButton.length + " selected");
                }
                else {

                    for (var i = 0; i < self.nameFilterButton.length; i++) {

                        if (i === 0) {

                            nameButton = self.nameFilterButton[i];

                        }
                        else {
                            nameButton = nameButton + ", " + self.nameFilterButton[i];
                        }
                    }
                    $("#filterButton").text(nameButton);
                }
            }
        }
    };

    SearchLabel.prototype.deleteNameFilterButton = function ($filterName) {

        var self = this;

        var nameButton = "";

        for (var i = 0; i < self.nameFilterButton.length; i++) {

            if (self.nameFilterButton[i] === $filterName) {

                self.nameFilterButton.splice($.inArray(self.nameFilterButton[i], self.nameFilterButton), 1);
                break;
            }
        }

        if (self.nameFilterButton.length > 2) {

            $("#filterButton").text(self.nameFilterButton.length + " selected");
        }
        else {
            for (var i = 0; i < self.nameFilterButton.length; i++) {

                if (i === 0) {

                    nameButton = self.nameFilterButton[i];

                }
                else {
                    nameButton = nameButton + ", " + self.nameFilterButton[i];
                }
            }
            if (nameButton === "") {
                nameButton = "All";
            }
            $("#filterButton").text(nameButton);

        }
    };

}());