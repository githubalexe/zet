﻿$(function () {

    NumericField  = function (options) {
        this.options = $.extend({}, true, DeleteModal.options, options);

        this.setDeleteButton();
    };

    NumericField.prototype.setDeleteButton = function () {


    };

    NumericField.options = {

        $deleteButton: $({}),
        $toggleDeleteButton: $({}),
        $grid: $({}),
        messageForOne: $({}),
        messageForMany: $({})

    };

}());