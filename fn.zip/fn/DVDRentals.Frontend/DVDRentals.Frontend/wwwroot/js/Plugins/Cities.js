﻿$(function () {

    Cities = function (options) {
        this.options = $.extend({}, true, Cities.options, options);

        this.onChangeCountry();
        this.setKendoCity();
        
    };

    Cities.prototype.setKendoCity = function () {

        this.getCities(this.options.$country.val());
        this.options.$city.data("kendoComboBox").enable(false);

        if (this.options.setCity === true) {

            this.options.$city.data("kendoComboBox").enable(true);
            this.setCity(this.options.$city.val());
        }

    };

    Cities.prototype.onChangeCountry = function () {

        var self = this;


        this.options.$country.on("change", function () {

            var countryId = $(this).val();
            self.options.$city.data("kendoComboBox").setDataSource();
            self.options.$city.data("kendoComboBox").input.val("");
            self.options.$city.data("kendoComboBox").value("");

            self.options.$city.data("kendoComboBox").enable(false);

            if ($.isNumeric(countryId)) {

                self.options.$city.data("kendoComboBox").enable(true);
                self.options.$city.data("kendoComboBox").setDataSource();
                self.getCities(countryId);

            }
        });
    };

    Cities.prototype.getCities = function (countyIdValue) {

        var self = this;

        self.options.$city.kendoComboBox({
            dataTextField: "Name",
            dataValueField: "CityId",
            dataSource: {
                transport: {
                    read: {
                        url: "/Country/GetCitiesByCountry",
                        data: {
                            countryId: countyIdValue
                        }
                    }
                }
            },
            filter: "contains",
            placeholder: "Select City",
            autoBind: false,
        });
    };


    Cities.prototype.setCity = function (cityIdValue) {

        var self = this;

        $.ajax({
            type: "GET",
            url: "/Country/GetCity",
            data: {
                cityId: cityIdValue
            },
        })
            .done(function (data) {
                var city = {};
                city.Name = data.Name;
                cityFilter: self.options.$city.data("kendoComboBox").input.val(city.Name);
            })
            .fail(function () {
                console.log("wrong");
            })
    };

    Cities.options = {

        $country: $({}),
        $city: $({}),
        setCity: $({})

    };

}());