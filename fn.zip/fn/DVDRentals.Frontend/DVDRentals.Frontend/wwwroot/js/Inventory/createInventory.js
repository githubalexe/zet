﻿$(document).ready(function () {

    var $form = $("#inventoryAddForm");
    var length = $("#Length");

    length.kendoNumericTextBox();

    var kendoFields = [

        {
            id: "filmComboBox",
            kendoType: "kendoComboBox"
        },
        {
            id: "copiesId",
            kendoType: "kendoNumericTextBox"
        },
        {
            id: "Length",
            kendoType: "kendoNumericTextBox"
        }
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

    //$("#copiesId").kendoValidator({
    //    messages: {

    //        range: "Incerc sa validez!!",
    //    },
    //    rules: {
    //        range: function (input) {
    //            if (input.is("[id=copiesId]")) {
    //                return kendo.format("Value should be between {0} and {1}!");
    //            }
    //            return true;
    //        }
    //    }
    //});
    //$("#amount").kendoNumericTextBox();

    //var validator = $("#ticketsForm").kendoValidator({
    //    rules: {
    //        range: function (input) {
    //            var min = parseFloat($(input).data("min"), 10);
    //            var max = parseFloat($(input).data("max"), 10);
    //            var value = parseFloat($(input).val(), 10);

    //            if (isNaN(min) || isNaN(max) || isNaN(value)) {
    //                return true;
    //            }

    //            return min <= value && value <= max;
    //        }
    //    },
    //    messages: {
    //        range: function (input) {
    //            var min = parseFloat($(input).data("min"), 10);
    //            var max = parseFloat($(input).data("max"), 10);

    //            return kendo.format("Value should be between {0} and {1}!", min, max);
    //        }
    //    }
    //}).data("kendoValidator");

});