﻿$(document).ready(function () {

    var $form = $("#updateStoreForm");
    var $countryId = $("#countryId");
    var $cityId = $("#cityId");
    var kendoFields = [

        {
            id: "staffId",
            kendoType: "kendoComboBox"
        },
        {
            id: "countryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "cityId",
            kendoType: "kendoComboBox"
        },
    ];

    setKendoValidation(kendoFields);
    setKendoCity();

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

    function setKendoCity() {

        var options = {
            $country: $countryId,
            $city: $cityId,
            setCity: true
        };

        new Cities(options);

    };

});