﻿$(document).ready(function () {

    var $form = $("#updateFilmForm");
    var $kListFilter = $(".k-list-filter");
    var $rentalRateInput = $("#rentalRateInput");
    var $replacementCostInput = $("#replacementCostInput");

    $form.data("validator").settings.ignore = "";
    $kListFilter.addClass("d-none");

    var kendoFields = [

        {
            id: "languageId",
            kendoType: "kendoComboBox"
        },
        {
            id: "categoryId",
            kendoType: "kendoComboBox"
        },
        {
            id: "ratingId",
            kendoType: "kendoComboBox"
        },
        {
            id: "specialFeaturesId",
            kendoType: "kendoComboBox"
        },
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var optionCustomer = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(optionCustomer);

    };

    $(".k-numeric-wrap span:eq(0)").remove();

    setInputNumber();

    function setInputNumber() {

        var optionsRentalRate = {

            $input: $rentalRateInput,
            isArrows: true,
            type: "decimal"

        }

        var optionsReplacementCost = {

            $input: $replacementCostInput,

            type: "decimal"

        }

        var x = new NumericField(optionsRentalRate);

        var y = new NumericField(optionsReplacementCost);


    }

});