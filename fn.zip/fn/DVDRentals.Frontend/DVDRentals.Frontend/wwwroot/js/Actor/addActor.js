﻿
$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $actorNameContainer = $("#actorNameContainer");
    var $actorActiveCombobox = $("#actorActiveDropDownList");
    var $kListFilter = $(".k-list-filter");
    var $form = $("#addActorForm");

    $kListFilter.addClass("d-none");

    $actorActiveCombobox.on("change", function () {

        $containerForm.slideToggle("slow");
        $actorNameContainer.toggleClass("display-none");
        console.log($actorActiveCombobox.val());


        if ($(this).val() === "No") {

            var kendoFields = [];
            setKendoValidation(kendoFields);
        }
        else {
            var kendoFields = [

                {
                    id: "actorsName",
                    kendoType: "kendoComboBox"
                }
            ];

            setKendoValidation(kendoFields);
        }

    });

    var kendoFields = [

        {
            id: "actorsName",
            kendoType: "kendoComboBox"
        }
    ];

    setKendoValidation(kendoFields);

    function setKendoValidation(kendoFields) {

        var options = {
            $form: $form,
            kendoFileds: kendoFields
        };

        new KendoValidation(options);

    };

});