﻿$(document).ready(function () {

    var $containerForm = $(".container-form");
    var $actorNameContainer = $("#actorNameContainer");
    var $deleteActor = $("#deleteActor");
    var $actorDeleteContainer = $("#actorDeleteContainer");
    var $filmId = $("#filmId");
    var $filmTitle = $("#filmTitle");
    var $deleteButton = $("#deleteFilmButton");
    var $actorActiveCombobox = $("#actorActiveCombobox");
    var $actorsSearchContainer = $("#actorsSearchContainer");
    var $actorsGrid = $("#actorsGrid");

    setSearchItems();

    var $toggleButton = $(".toggle-button");

    $deleteActor.prop("disabled", true);

    $toggleButton.on("click", function () {

        if ($actorsGrid.data("kendoGrid").selectedKeyNames().length === 0) {

            $deleteActor.prop("disabled", true);
            $deleteActor.removeClass("item-color");

        }
        else {

            $deleteActor.addClass("item-color");
            $deleteActor.prop("disabled", false);
        }

    });

    $actorActiveCombobox.on("change", function () {
        $containerForm.slideToggle("slow");
        $actorNameContainer.toggleClass("display-none");
    });



    $deleteActor.on("click", function () {

        var optionsGrid = {
            grid: "actorsGrid",
            id: "ActorId",
            name: "Name"
        }

        var entityGrid = new EntityGrid(optionsGrid);

        var numberOfIds = entityGrid.getSelectedIds();

        console.log(numberOfIds.length);

        var options = {
            $container: $actorDeleteContainer,
            modelName: entityGrid.setSelectedItems(),
            entity: "Actor",
            idsLength: numberOfIds.length,
            url: "/Film/DeleteActor",
            dataJson: {
                filmId: parseInt($filmId.text()),
                actorIds: numberOfIds
            },
            onCancel: function () {

                entityGrid.uncheckedItems();

                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                entityGrid.refreshGrid();
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        }

        if (numberOfIds.length > 0) {

            new DeleteModal(options);

            $("#deleteModal").modal("show");
        }
    });


    $deleteButton.on("click", function () {

        var options = {
            $container: $actorDeleteContainer,
            modelName: "<label class='active-entity'>" + $filmTitle.text() + "</label>",
            entity: "Film",
            idsLength: 1,
            url: "/Film/Delete",
            dataJson: {
                filmsIds: parseInt($filmId.text())
            },
            onCancel: function () {
                $(".modal-backdrop").remove(".show");
                $(".container").remove();
            },
            onSucces: function () {
                window.location.href = "/Film/Index";
            },
            onFail: function () {
                console.log("Something is wrong");
            }
        };

        new DeleteModal(options);

        $("#deleteModal").modal("show");
    });

    function setSearchItems() {
        var options = {

            $container: $actorsSearchContainer,
            $kendoGrid: $("#actorsGrid"),
            filterButton: false,
            buttonFilters: [],
            orFilters: [
                {
                    logic: "or", filters: [
                        {
                            field: "Name",
                            operator: "contains",
                            value: ""
                        }
                    ],
                }
            ]
        }
        new SearchLabel(options);
    }

    setSortKendoGrid();

    function setSortKendoGrid() {

        var options = {
            $kendoGrid: $actorsGrid,
            kendoGridField: "ActorsGridField",
            kendoGridFieldDir: "ActorsGridDir",
        };

        new SortKendoGrid(options);
    };

});