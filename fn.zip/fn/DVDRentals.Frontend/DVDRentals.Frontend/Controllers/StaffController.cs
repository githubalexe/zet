﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Staff;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.User;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using DVDRentals.Frontend.wwwroot.images;
using DVDRentals.API.Response.Rental;

namespace DVDRentals.Frontend.Controllers
{
    public class StaffController : Controller
    {
        [HttpGet("Staff/StaffDetails/{staffId}")]
        public async Task<IActionResult> StaffDetails(int staffId)
        {

            int storeId = 1;
            StaffView model = new StaffView();
            StaffResponse staff = new StaffResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            //ViewBag.FirstName = StaffUser.Name;
            //ViewBag.Picture = Convert.ToBase64String(StaffUser.Picture);

            staff = await StaffApiMethods.GetStaff(storeId, staffId);

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = staff.ToStaffResponseView();

            return View(model);
        }

        public IActionResult CreateStaff()
        {
            return View();
        }
        public IActionResult Index()
        {
            //ViewBag.FirstName = StaffUser.Name;
            //ViewBag.Picture = Convert.ToBase64String(StaffUser.Picture);
            return View();
        }

        [HttpGet("UpdateStaff/{staffId}")]
        public async Task<IActionResult> UpdateStaff(int staffId)
        {
            int storeId = 1;
            //make this a global setting

            //a real scenario -> fetch store ID from login cookie not now

            StaffView model = new StaffView();
            StaffResponse staff = new StaffResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            staff = await StaffApiMethods.GetStaff(storeId, staffId);

            if (staff == null)
            {
                errorMessage.Message = StaffMessages.NoStaffResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = staff.ToStaffResponseView();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> StaffsList([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            List<StaffView> list = new List<StaffView>();

            IEnumerable<StaffResponse> apiResult = await StaffApiMethods.GetStaffs(storeId);

            foreach (StaffResponse staff in apiResult)
            {

                list.Add(staff.ToStaffResponseView());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpGet]
        public async Task<IActionResult> GetStaffs()
        {
            int storeId = 1;
            IEnumerable<StaffNameResponse> apiResult = await StaffApiMethods.GetStaffsName(storeId);

            return Json(apiResult);
        }

        //[HttpPost("Staff/StaffDetails/{staffId}")]
        //public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request, int staffId)
        //{
        //    int storeId = 1;

        //    List<StaffPaymentsViewModel> list = new List<StaffPaymentsViewModel>();
        //    StaffView model = new StaffView();

        //    IEnumerable<StaffPaymentsResponse> apiResult = await StaffApiMethods.GetPayments(storeId, staffId);

        //    if (apiResult == null)
        //    {
        //        return Ok();
        //    }
        //    else
        //    {
        //        foreach (StaffPaymentsResponse payment in apiResult)
        //        {
        //            if (payment.Rental != null)
        //            {
        //                list.Add(payment.ToStaffPaymentsResponseView());
        //            }
        //        }

        //        DataSourceResult result = list.ToDataSourceResult(request);

        //        return Json(result);
        //    }
        //}

        [HttpPost("Staff/StaffDetails/{staffId}")]
        public async Task<IActionResult> GetRentals([DataSourceRequest] DataSourceRequest request, int staffId)
        {

            List<StaffRentalsViewModel> list = new List<StaffRentalsViewModel>();

            IEnumerable<StaffRentalsResponse> apiResult = await RentalApiMethods.GetStaffRentalsAsync(staffId);

            if (apiResult == null)
            {
                return Ok();
            }
            else
            {
                foreach (StaffRentalsResponse rental in apiResult)
                {
                    if (rental != null)
                    {
                        list.Add(rental.ToStaffRentalsViewModel());
                    }
                }

                DataSourceResult result = list.ToDataSourceResult(request);

                return Json(result);
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateStaff(StaffView request)
        {

            if (request.PictureFile != null)
            {
                using (var stream = new MemoryStream())
                {
                    await request.PictureFile.CopyToAsync(stream);
                    request.BinaryImage = stream.ToArray();
                }

            }

            if (request.PictureFile == null && request.Picture == null)
            {
                request.BinaryImage = Convert.FromBase64String(DefaultImage.GetDefaultImage());
            }

            int storeId = 1;
            StaffResponse staff = new StaffResponse();
            staff = await StaffApiMethods.CreateStaff(request.ToStaffForm(), storeId);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.StaffId });
        }

        [HttpPost("UpdateStaff/{staffId}")]
        public async Task<IActionResult> UpdateStaff(StaffView request, int staffId)
        {
            int storeId = 1;

            if (request.PictureFile != null)
            {
                using (var stream = new MemoryStream())
                {
                    await request.PictureFile.CopyToAsync(stream);
                    request.BinaryImage = stream.ToArray();
                }

            }

            if (request.PictureFile == null)
            {
                if (request.Picture == null)
                {
                    request.BinaryImage = Convert.FromBase64String(DefaultImage.GetDefaultImage());
                }
                else
                {
                    request.BinaryImage = Convert.FromBase64String(request.Picture);
                }
            }

            StaffResponse staff = new StaffResponse();
            staff = await StaffApiMethods.UpdateStaff(request.ToStaffForm(), storeId, staffId);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.StoreId });
        }

        [HttpPost]
        public async Task<IActionResult> UpdateStaffStatus(bool isActive, int staffId)
        {
            int storeId = 1;

            StaffResponse staff = await StaffApiMethods.UpdateCustomerStatus(isActive, storeId, staffId);

            return RedirectToAction(nameof(StaffDetails), new { id = staff.StaffId });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<int> staffsIds)
        {
            int storeId = 1;

            foreach (int staffId in staffsIds)
            {
                await StaffApiMethods.DeleteStaff(storeId, staffId);
            }

            return RedirectToAction(nameof(Index), new { storeId = 1 });
        }
    }
}