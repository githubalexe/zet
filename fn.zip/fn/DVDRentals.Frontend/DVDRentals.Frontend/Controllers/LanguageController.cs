﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.Language;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class LanguageController : Controller
    {
        public async Task<IActionResult> GetLanguages()
        {
            IEnumerable<LanguageResponseLite> apiResult = await LanguageApiMethods.GetLanguagesAsync();

            return Json(apiResult);
        }

    }
}