﻿using System.Collections.Generic;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Request.FormRequest;
using DVDRentals.API.Response.Messages;
using DVDRentals.API.Response.Payment;
using DVDRentals.API.Response.Rental;
using DVDRentals.API.Response.Store;
using DVDRentals.Frontend.ExtensionMethods;
using DVDRentals.Frontend.ViewModels;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Microsoft.AspNetCore.Mvc;

namespace DVDRentals.Frontend.Controllers
{
    public class RentalController : Controller
    {
        [HttpGet("Rental/RentalDetails/{rentalId}")]
        public async Task<IActionResult> RentalDetails(int rentalId)
        {
            int storeId = 1;
            RentalView model = new RentalView();
            StoreRentalResponse rental = new StoreRentalResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            rental = await RentalApiMethods.GetRental(storeId, rentalId);

            if (rental == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = rental.ToRentalResponseView();

            return View(model);
        }

        public IActionResult CreateRental()
        {
            return View();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetRental(int rentalId)
        {
            int storeId = 1;

            StoreRentalResponse rental = await RentalApiMethods.GetRental(storeId, rentalId);

            return Ok(rental);
        }

        [HttpGet]
        public async Task<IActionResult> GetInventoryRentals(int inventoryId)
        {

            IEnumerable<RentalResponseLite> apiResult = await RentalApiMethods.GetInventoryRentalsAsync(inventoryId);

            return Json(apiResult);
        }


        [HttpGet("AddPayment/{rentalId}")]
        public IActionResult AddPayment(int rentalId)
        {
            RentalPaymentsView model = new RentalPaymentsView();
            model.RentalId = rentalId;
        
            return View(model);
        }

        [HttpPost("AddPayment/{rentalId}")]
        public async Task<IActionResult> AddPayment(RentalPaymentsView request, int rentalId)
        {
            int storeId = 1;

            PaymentResponseLite payment = new PaymentResponseLite();
            StoreRentalResponse rental = new StoreRentalResponse();

            rental = await RentalApiMethods.GetRental(storeId, rentalId);
            payment = await RentalApiMethods.AddPayment(request.ToModelCreatePayment(rental));

            return new RedirectResult(Url.Action("RentalDetails/") + rental.RentalId + "#payments");
        }

        [HttpGet("UpdateRental/{rentalId}")]
        public async Task<IActionResult> UpdateRental(int rentalId)
        {
            int storeId = 1;
            RentalView model = new RentalView();
            StoreRentalResponse rental = new StoreRentalResponse();
            ErrorMessage errorMessage = new ErrorMessage();

            rental = await RentalApiMethods.GetRental(storeId, rentalId);

            if (rental == null)
            {
                errorMessage.Message = CustomerMessages.NoCustomerResponse.GetDescription();

                return BadRequest(errorMessage);
            }

            model = rental.ToRentalResponseView();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Index([DataSourceRequest] DataSourceRequest request)
        {
            int storeId = 1;
            List<RentalIndexViewModel> list = new List<RentalIndexViewModel>();

            IEnumerable<StoreRentalResponse> apiResult = await RentalApiMethods.GetRentals(storeId);

            foreach (StoreRentalResponse rental in apiResult)
            {
                list.Add(rental.ToRentalIndexViewModel());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost("Rental/RentalDetails/{rentalId}")]
        public async Task<IActionResult> Payments([DataSourceRequest] DataSourceRequest request, int rentalId)
        {
            int storeId = 1;

            List<PaymentViewModel> list = new List<PaymentViewModel>();
            RentalView model = new RentalView();

            IEnumerable<PaymentResponseLite> apiResult = await RentalApiMethods.GetPayments(storeId, rentalId);

            foreach (PaymentResponseLite payment in apiResult)
            {
                list.Add(payment.ToRentalPaymentsResponse());
            }

            DataSourceResult result = list.ToDataSourceResult(request);

            return Json(result);
        }

        [HttpPost]
        public async Task<IActionResult> CreateRental(RentalView request)
        {
            int storeId = 1;

            StoreRentalResponse rental = await RentalApiMethods.CreateRental(request.ToRentalViewForm(), storeId);

            return RedirectToAction(nameof(RentalDetails), new { id = rental.RentalId });
        }

        [HttpPost("UpdateRental/{rentailId}")]
        public async Task<IActionResult> UpdateRental(RentalView request, int rentailId)
        {
            int storeId = 1;
            StoreRentalResponse rental = new StoreRentalResponse();
            rental = await RentalApiMethods.UpdateRental(request.ToModelUpdateRental(), storeId, rentailId);

            return RedirectToAction(nameof(RentalDetails), new { id = rentailId });
        }

        [HttpPost]
        public async Task<IActionResult> Delete(IEnumerable<int> rentalsIds)
        {
            foreach (int rentalId in rentalsIds)
            {
                await RentalApiMethods.DeleteRental(rentalId);
            }

            return RedirectToAction(nameof(Index), new { storeId = 1 });
        }

        [HttpPost]
        public async Task<IActionResult> DeletePayments(IEnumerable<int> paymentsIds)
        {
            foreach (int paymentId in paymentsIds)
            {
                await RentalApiMethods.DeletePayment(paymentId);
            }

            return RedirectToAction(nameof(Index), new { storeId = 1 });
        }
    }
}