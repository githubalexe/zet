﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DVDRentals.API.ApiMethods;
using DVDRentals.API.Response.City;
using DVDRentals.API.Response.Country;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace DVDRentals.Frontend.Controllers
{
    public class CountryController : Controller
    {

        public async Task<IActionResult> GetCountries()
        {
            IEnumerable<CountryResponseLite> apiResult = await CountryApiMethods.GetCountriesAsync();

            return Json(apiResult);
        }

        public async Task<IActionResult> GetCity(int cityId)
        {
            CityResponseLite apiResult = await CountryApiMethods.GetCityAsync(cityId);

            return Json(apiResult);
        }

        [HttpGet]
        public async Task<IActionResult> GetCitiesByCountry(int countryId/*, string cityFilter*/)
        {
            //cityFilter = cityFilter.ToLower();

            IEnumerable<CityResponse> apiResult = await CityApiMethods.GetCitiesByCountryAsync(countryId);


            //if (countryId != null)
            //{
            //    apiResult = apiResult.Where(p => p.CountryId == countryId);
            //}

            //if (!string.IsNullOrEmpty(cityFilter))
            //{
            //    apiResult = apiResult.Where(p => p.Name.ToLower().Contains(cityFilter));
            //}


            return Json(apiResult);
        }
    }
}