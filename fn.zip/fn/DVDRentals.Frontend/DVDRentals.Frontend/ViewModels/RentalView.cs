﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class RentalView
    {
        [Display(Name = "Existing Customer")]
        public string ExistingCustomer { get; set; }

        [Display(Name = "Rental Id")]
        public int RentalId { get; set; }

        [Display(Name = "Film Title")]
        [Required(ErrorMessage = "Select a film!")]
        public int FilmId { get; set; }

        [Display(Name = "Customer Name")]
        [Required(ErrorMessage = "Select a customer!")]
        public int CustomerId { get; set; }

        [Display(Name = "Inventories")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Inventory is required!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = " ")]
        public int InventoryId { get; set; }

        [Display(Name = "Rental Date")]
        [Required]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public DateTime RentalDate { get; set; }

        [Display(Name = "Return Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy")]
        public DateTime? ReturnDate { get; set; }

        [Display(Name = "Amount")]
        public decimal? Amount { get; set; }

        [Display(Name = "Payment Date")]
        [DisplayFormat(DataFormatString = "{dd/MM/yyyy}")]
        public DateTime PaymentDate { get; set; }

        [Display(Name = "First Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "First Name is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between 3 and 50 characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Last Name is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between 3 and 50 characters!")]
        [RegularExpression("^[a-zA-Z ]*$", ErrorMessage = "Only alpha characters are allowed!")]
        public string LastName { get; set; }

        [Display(Name = "Email")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Email is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Maximum length required 30 characters!")]
        [RegularExpression(@"^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$", ErrorMessage = "Incorect email format!")]
        public string Email { get; set; }

        [Display(Name = "Address")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Address is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between 3 and 50 characters!")]
        [RegularExpression("^[a-zA-Z z0-9/ -.,']*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string Address { get; set; }

        [Display(Name = "Address 2")]
        [RegularExpression("^[a-zA-Z z0-9/ -.,']*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string Address2 { get; set; }

        [Display(Name = "District")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "District is required!")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Length required is between 3 and 50 characters!")]
        [RegularExpression("^[a-zA-Z z0-9/ -.,']*$", ErrorMessage = "Only alpha characters and digits are allowed!")]
        public string Distrinct { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Country is required!")]
        public int CountryId { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "City is required!")]
        public int CityId { get; set; }


        [Display(Name = "Postal Code")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Postal Code is required!")]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "Length required is between 3 and 10 digits!")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Only digits are allowed!")]
        public string PostalCode { get; set; }

        [Display(Name = "Phone")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Phone is required!")]
        [StringLength(15, MinimumLength = 5, ErrorMessage = "Length required is between 5 and 15 digits!")]
        [RegularExpression("^[0-9/ -:]+$", ErrorMessage = "Only digits are allowed!")]
        public string Phone { get; set; }


        [Display(Name = "Staff")]
        public int StaffId { get; set; }

        public string Customer { get; set; }

        public string Staff { get; set; }

        public string FilmTitle { get; set; }
    }

}
