﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class CustomerRentalsViewModel
    {
        [Display(Name = "Rental Id")]
        public int RentalId { get; set; }

        [Display(Name = "Rental Date")]
        public string RentalDate { get; set; }

        [Display(Name = "Return Date")]
        public string ReturnDate { get; set; }

        [Display(Name = "Staff Name")]
        public string Staff { get; set; }

        [Display(Name = "Film Title")]
        public string FilmTitle { get; set; }
    }
}
