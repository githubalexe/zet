﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class RentalPaymentsView
    {
        public int RentalId { get; set; }
        [Display(Name = "Payment Id")]
        public int PaymentId { get; set; }

        [Display(Name = "Payment Date")]
        [Required(ErrorMessage = "Payment Date is required!")]
        public DateTime PaymentDate { get; set; }

        [Display(Name = "Amount")]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Amount is required!")]
        //[RegularExpression(@"^(\.[0-9]{1,2})?$", ErrorMessage = "The length of decimal numbers can't be bigger than 2 digits!")]
        [Range(0, 999.00, ErrorMessage = "Replacement Cost cannot be bigger than 999.00!")]
        public decimal Amount { get; set; }
    }
}
