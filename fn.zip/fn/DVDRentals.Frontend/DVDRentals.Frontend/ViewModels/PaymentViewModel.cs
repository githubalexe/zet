﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DVDRentals.Frontend.ViewModels
{
    public class PaymentViewModel
    {
        public int PaymentId { get; set; }
        public string PaymentDate { get; set; }
        public string Amount { get; set; }
    }
}
